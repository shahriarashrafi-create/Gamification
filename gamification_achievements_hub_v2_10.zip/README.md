# Gamification Android — v2.10.0

نسخه Android گیمیفیکیشن روزانه با صفحه بازی، مدیریت تسک‌ها، تایمر تمرکز ۲۵ دقیقه‌ای، آمار هفتگی و Achievement Hub کامل.

## Achievement Hub
- بیش از ۷۰ دستاورد آماده
- روزانه، هفتگی، ماهانه، ویژه و مخفی
- فیلتر و صفحه‌بندی بدون اسکرول
- پیشرفت خودکار
- افزودن دستاورد شخصی
- حذف دستاورد
- بازیابی پیش‌فرض‌ها

## Build
GitHub Actions فایل APK را با نام `Gamification-Update10-AchievementsHub.apk` تولید می‌کند.
