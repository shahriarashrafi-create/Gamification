# Gamification Android — Update 7

اپ گیمیفیکیشن روزانه با رابط بدون اسکرول، مدیریت تسک‌ها، لول، رنک، مجیک تمرکز و مشوق، تایمر ۲۵ دقیقه‌ای و دستاوردها.

این نسخه طراحی موکاپ مرجع را در سه لایه اصلی دنبال می‌کند:
1. نوار بالای چهارکارت وضعیت از Update 6
2. نوار تایمر و کارت مأموریت مرکزی در Update 7
3. Bottom Navigation جدید در Update 7

نسخه Android: **2.7.0**

خروجی GitHub Actions: **Gamification-Update7-CenterBottomHUD.apk**

فایل ZIP را در ریشه Repository قرار دهید/Extract کنید و Workflow ساخت APK را اجرا کنید.
