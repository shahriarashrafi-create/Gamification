# Update 4 — Layout Balance + Persistent Focus Timer

## Layout
- Home screen spacing rebalanced.
- Mission title, R/B badge and score are separated to prevent overlap.
- Large unused mission area is replaced with a centered Focus Console.
- Later queue is compact and shows only the most useful items without scrolling.

## 25-minute Focus
- Starting Focus creates a real 25-minute countdown.
- The session is stored as an absolute end timestamp.
- It survives task changes, tab changes, WebView redraws, and app background/return.
- Every task completed while the timer is active receives the Focus multiplier.
- A Focus magic usage is awarded once, when the full 25-minute session completes.
- The timer switch locks while active so task rerenders cannot accidentally cancel it.

## Compatibility
The local storage version key and Android data schema are intentionally unchanged, so upgrading from Update 3 preserves existing progress.
