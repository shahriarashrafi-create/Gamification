# SHAHRIAR GAME — STEP 44
## BATTLEFIELD REAL VISUAL COMPOSITION

مرجع رسمی چیدمان واقعی میدان نبرد Portrait.

## 1. Goal
Battlefield باید در یک نگاه شبیه میدان بازی واقعی باشد، نه صفحه مدیریت کارها.

## 2. Screen Mode
Portrait only.
Immersive gameplay.
Android status/navigation bars hidden.
App Bottom Nav hidden.

## 3. World
Three lanes:
A left
B center
C right

Own Base bottom.
Enemy Base top.
Two Towers per lane.

## 4. Camera
Hero follows Step28 camera:
anchorX .50
anchorY .63
smooth follow
no teleport

## 5. Hero
Hero positioned slightly below visual center.
Full gameplay sprite/art later replaces current production reference.

## 6. HUD Top
Timer
Current objective
Match XP
Match Gold
Match Diamond if >0
Pause

No Energy.

## 7. Timer
Default 30:00.
Gold warning <=5 minutes.
Danger state <=1 minute.
No punishment at zero.

## 8. Minimap
Top corner.
Own Base bottom.
Enemy Base top.
Hero
Towers
current objective
No tap-to-teleport.

## 9. World Objective
Current target can show compact HP and marker.
Do not cover Hero.

## 10. Tower
Two per lane.
Tower2 locked until Tower1 destroyed.
Destroyed Tower becomes passable after commit.

## 11. Enemy Base
Shielded/locked until one complete lane by current rule.
Base Victory only at HP 0.

## 12. Minions
Actionable Minion = real Task.
Visual escort Minions may exist later but must not look actionable.

## 13. Joystick
Lower-left.
112–132dp.
No continuous haptic.

## 14. Context Action
Lower-right.
Appears/enables only when relevant target is in interaction radius.

## 15. Pause
Top HUD.
Opens pause sheet.
Timer/wave scheduler pause per Step30.

## 16. Rewards
Small HUD counters.
Reward fly-up after committed transaction.
No giant modal.

## 17. Objective Marker
Gold/Cyan.
Current target visually distinct.
No forced lane lock.

## 18. Fog
Unseen
Known
Visible

Minimap respects known state.

## 19. Lane Switching
Crossroads remain walkable.
Backtracking allowed.

## 20. Input Priority
modal
encounter
critical cinematic
pause
context action
joystick
world

## 21. Safe Controls
Joystick/action stay clear of gesture inset.

## 22. 360×800
Minimap about 82–90px.
Controls remain usable.
Timer readable.

## 23. 430×932
World gets more breathing room.
Do not upscale HUD excessively.

## 24. Entity Scale
Hero visually strongest mobile entity.
Tower clearly larger than Minion.
Base strongest objective silhouette.

## 25. Background
Dark fantasy battlefield:
navy
obsidian
cyan rune lanes
gold objective accents

## 26. World Depth
terrain
lane glow
props
entities
VFX
fog
world HUD
screen HUD

## 27. Actionable Task Cue
Minion/target receives subtle ring/marker.
Task text never floats permanently over battlefield.

## 28. Encounter
When triggered:
movement soft-stop
camera focus
Task Sheet overlays while battlefield remains visible.

## 29. Tower Warning
Ground ring + charge cue.
Does not imply player health system.

## 30. No Player Combat Stats
No attack damage stat.
No armor.
No mana.
No energy.
Hero appearance gives no power.

## 31. Prototype
Step44 executable concept includes:
three lanes
six towers
two bases
Hero
Minions
timer
minimap
reward HUD
joystick
context action
pause
objective focus

## 32. Prototype Movement
Joystick simulation moves Hero smoothly.
No teleport.

## 33. Objective Demo
Action button cycles a target hit demo.
Actual Task Encounter remains authoritative from Step22.

## 34. Minimap Demo
Hero marker follows normalized visual position.
Minimap is display-only.

## 35. Pause Demo
Pause freezes prototype timer and movement.

## 36. Accessibility
Controls >=44dp.
State labels remain textual where important.
Reduce Motion compatible.

## 37. Performance
Use transform for Hero movement.
Avoid per-frame expensive blur.
Bound VFX.

## 38. QA
bottom nav absent
timer visible
minimap no teleport
joystick lower-left
action lower-right
Hero smooth movement
six towers visible in world model
Own/Enemy Base orientation correct
no Energy
no combat-power stats

## 39. Failure Conditions
dashboard layout
bottom nav visible
Hero teleports
minimap tap moves Hero
controls overlap system gesture area
Energy appears
player HP/mana introduced
Task text permanently clutters world

## 40. Quality Gate
At 360×800 the battlefield must remain playable with timer, minimap, Hero, joystick and action control all visible simultaneously.

## STEP 45
BATTLEFIELD ENTITY ART & STATE COMPOSITION
Replace geometric battlefield entities with the first dedicated Minion, Tower, Base and objective-marker production art/state pack.
