# SHAHRIAR GAME — STEP 25
## MATCH INITIALIZATION / PRE-BATTLE EXPERIENCE

مرجع رسمی آماده‌سازی Match قبل از ورود به Battlefield.

## 1. Start Source
Home CTA:
شروع بازی — {matchMinutes} دقیقه

## 2. Pre-Battle Goal
شروع باید سریع، سینمایی و قابل‌اعتماد باشد؛ نه یک فرم تنظیمات طولانی.

## 3. Initialization Sequence
Start Tap
→ validate selected Hero
→ snapshot Match settings
→ build eligible Task Pool
→ initialize map/entities
→ assign encounter queue
→ create Match ID
→ persist initial state
→ enter immersive
→ battle intro
→ controls enabled
→ timer starts

## 4. Selected Hero
Uses currently selected Hero.
Hero is visual/personality identity.
No combat power advantage.

## 5. Match Settings Snapshot
At Match start snapshot:
duration
wave interval
tower/base HP
damage per task
timerRunsDuringTask
entity reward multipliers
accessibility/reduce motion
control settings needed for deterministic session

Mid-match Settings edits do not retroactively alter current match rules unless explicitly marked live-safe.

## 6. Task Eligibility
activeInGame = true
master status active
not deleted
valid category/difficulty
available under repeat rules
not blocked

## 7. Task Pool
Build immutable MatchTaskPool references/snapshots.
Master Task edits later do not corrupt active encounter reward/title snapshot rules.

## 8. Empty Pool
Do not enter broken Match.
Show:
«برای شروع بازی حداقل یک کار فعال لازم است»
CTA → کارها
CTA → بازگشت

## 9. Pool Strategy
Default:
shuffle eligible tasks
preserve priority weighting
today-linked Timesheet tasks may receive future priority
avoid immediate duplicate encounter assignment when enough tasks exist

## 10. Encounter Assignment
Minions receive first eligible tasks.
Tower/Base encounters draw subsequent tasks as player reaches them.
System must have fallback if pool is smaller than total theoretical objectives.

## 11. Small Pool Fallback
Reusable active Tasks may cycle only after unused pool exhausted.
No duplicate simultaneous assignment.
Future one-time tasks never cycle.

## 12. Match ID
Unique stable ID.
Used by:
transactions
rewards
entity destruction
results
recovery

## 13. Entity Initialization
Own Base
Enemy Base
6 Towers
initial Minion waves
all reset to default Match state.

## 14. Tower
HP from snapshot.
Default 100.

## 15. Base
HP from snapshot.
Default 100.

## 16. Hero Spawn
Own Base area.
Normalized around X50/Y89.
No teleport after intro.

## 17. Camera
Starts framing Own Base + Hero.
Short forward reveal.
Returns to Hero follow anchor.

## 18. Intro
Suggested:
0–250ms fade from Home
250–650ms map reveal
650–1000ms Hero spawn/ready
1000–1300ms objective callout
~1300ms controls enabled + timer start

Reduce Motion = short fade + immediate ready.

## 19. Timer
Timer begins only after initialization succeeds and controls become active.
Never consume Match time during loading/preparation.

## 20. Immersive
Enter Android immersive immediately before/with battlefield transition.
Reapply on focus/visibility.

## 21. Bottom Navigation
Absent throughout Pre-Battle and Match.

## 22. Loading
Local initialization should feel near-instant.
If asset load needed:
show cinematic loading state with progress.
Do not fake progress percentages.

## 23. Asset Readiness
Critical:
selected Hero runtime asset
battlefield base layers
Tower/Base
essential HUD/icons
Encounter UI

Secondary VFX may lazy-load with safe fallback.

## 24. Failure
If critical initialization fails:
do not start timer
do not spend/reward anything
restore normal system UI
return safe error state.

## 25. Resume Existing Match
Future app recovery can detect persisted active Match.
Fresh launch still opens Home.
Home may offer explicit «ادامه Match» if recovery policy is enabled later.
Never auto-drop user into battlefield on launch.

## 26. Match State
initializing
intro
active
encounter
paused
ending
result
closed

## 27. Initial Task Session State
All pool entries start unused.
No task is completed/deferred before encounter.

## 28. Initial Entity State
alive/unlocked based on lane rules.
Tower2 may remain progression-locked until Tower1 destroyed if final lane rules choose that behavior.
Configuration-driven.

## 29. Lane Freedom
Hero starts at Own Base and chooses lane naturally.
No forced lane teleport.

## 30. Objective Prompt
Initial prompt can say:
«مسیرت را انتخاب کن»
Then nearby minion/objective guidance.

## 31. Pre-Battle UI
Hero portrait/name
30-minute duration
eligible task count
selected mode/rules summary
Start transition
No Energy.

## 32. No Loadout Power
Cosmetics and Hero choice cannot modify HP/damage/reward multipliers.

## 33. Data Safety
Create initial Match record before enabling input.
Use schema version.

## 34. Deterministic Rules
All economy/damage settings needed for current Match are snapshotted to prevent settings drift.

## 35. Network
Core Match should remain local-first.
No internet dependency for movement/task completion if app data already local.

## 36. Mobile
360–430 portrait.
Pre-Battle sheet/content must not hide Start/Cancel behind safe area.

## 37. Accessibility
Reduced Motion snapshot.
Readable status.
No essential info only through animation.

## 38. Prototype
Step25 concept simulates Ready → Validate → Snapshot → Task Pool → Map Init → Immersive → Battle Ready.

## 39. Failure Conditions
timer starts before ready
no task pool but match starts
Hero power affects rules
mid-match settings mutate snapshot
fresh launch auto-opens match
Bottom Nav visible
teleport lane selection
fake loading progress

## 40. Quality Gate
Pressing Start should create one valid, recoverable, deterministic Match before the player receives control.

## STEP 26
MINION WAVE & TASK DISTRIBUTION SYSTEM
Wave spawning, task assignment, reuse rules, encounter spacing, lane distribution and anti-repetition logic.
