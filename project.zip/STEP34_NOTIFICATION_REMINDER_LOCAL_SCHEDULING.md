# SHAHRIAR GAME — STEP 34
## NOTIFICATION / REMINDER / LOCAL SCHEDULING ARCHITECTURE

مرجع رسمی Notification و Reminder محلی برای Task، Timesheet، Event و Match نیمه‌تمام.

## 1. Goal
یادآوری‌ها باید مفید، قابل‌کنترل و بدون مزاحمت باشند.

## 2. Local First
نسخه اول از Local Notifications اندروید استفاده می‌کند.
برای Reminderهای شخصی نیازی به سرور Push نیست.

## 3. Permission
Android notification permission only when required by platform/version.
در اولین اجرای اپ فوراً Permission نخواه.

## 4. Permission Timing
Permission زمانی درخواست شود که کاربر اولین Reminder را فعال می‌کند یا وارد تنظیمات اعلان‌ها می‌شود.

## 5. Channels
task_reminders
timesheet_alerts
event_alerts
match_recovery
achievement_updates

## 6. Task Reminder
Master Task می‌تواند Reminder اختیاری داشته باشد:
enabled
date/time
repeatRule
notificationId

## 7. Task Notification
Title:
«یادآوری کار»
Body:
Task title

No reward claim directly from notification.

## 8. Timesheet Alert
Can notify before scheduled entry.
Default lead options:
at time
5 min
10 min
15 min
30 min
60 min

## 9. Timesheet Completion
Notification does not automatically mark entry complete.

## 10. Event Alert
Event countdown options:
same day
1 day before
3 days before
custom

## 11. Match Recovery
If recoverable Match exists, optional reminder can say:
«یک Match نیمه‌تمام داری»

Opening it routes Home with recovery card.
Never directly enters Match.

## 12. Achievement
Optional low-priority notification for achievement ready-to-claim.
No auto-claim.

## 13. Notification Tap Routing
Task → Tasks
Timesheet → Timesheet selected date
Event → Event detail
Match Recovery → Home
Achievement → Achievements

All route guards still apply.

## 14. Fresh Launch Rule
Even when notification launches app, unsafe gameplay routes are never bypassed.

## 15. Scheduling IDs
Stable deterministic notification IDs mapped to source entity.
Rescheduling cancels/replaces old schedule.

## 16. Delete Entity
Deleting/archiving source cancels pending reminder where appropriate.

## 17. Timezone
Store schedule intent with timezone-aware semantics.
Display local time.

## 18. Device Time Change
Reconcile future local schedules on app resume/bootstrap when needed.

## 19. Reboot
Production Android implementation must restore persistent schedules after reboot if platform/plugin requires it.

## 20. Recurrence
none
daily
weekly
custom future

Initial production can support none/daily/weekly.

## 21. Quiet Hours
Optional global quiet hours.
Default disabled.

## 22. Quiet Hours Behavior
Non-critical reminders inside quiet hours move to quiet-hours end.
No critical alarm category exists in this productivity game.

## 23. Notification Settings
Master toggle
Task reminders
Timesheet alerts
Event alerts
Match recovery
Achievement updates
Quiet hours

## 24. Default Policy
Task reminders OFF until user schedules one.
Timesheet alerts user-controlled.
Event alerts user-controlled.
Match recovery OFF by default.
Achievement updates OFF by default.

## 25. No Spam
Do not send repeated nagging notification for same incomplete Task unless recurrence explicitly configured.

## 26. Missed Notification
If scheduled time passed while device/app unavailable, avoid burst of many stale reminders on next launch.

## 27. Deduplication
notificationKey unique by source + schedule occurrence.

## 28. Cancel
Every scheduled notification must have a cancellation path.

## 29. Update
Editing Task/Timesheet/Event schedule updates pending notification atomically.

## 30. Persistence
Notification schedule metadata persists in local DB:
notificationId
sourceType
sourceId
scheduledAt
repeatRule
channel
enabled
lastScheduledAt

## 31. Permission Denied
App remains fully usable.
Show Settings guidance only when user tries notification feature.

## 32. Exact Alarm
Do not require exact-alarm permission by default.
Use normal local scheduling appropriate for productivity reminders.

## 33. Battery
No continuous background polling for local reminders.

## 34. Privacy
Notification body can optionally hide sensitive task title:
«یک یادآوری جدید داری»

## 35. Lock Screen Privacy
Setting:
show full content
hide content

## 36. Visual Style
Use app icon/channel identity.
Notification UI remains native Android, not fake game popup.

## 37. Prototype
Step34 concept simulates channels, reminder scheduling, permission state and notification tap destination.

## 38. QA
No duplicate reminder
edit reschedules
delete cancels
permission denied safe
notification tap obeys route guards
Match reminder opens Home
quiet hours shift correctly
no stale notification burst

## 39. Failure Conditions
auto-enter Match from notification
auto-complete Task
auto-claim reward
spam repeats
permission demanded on first launch
continuous polling
orphan notification after delete

## 40. Quality Gate
Every notification must be traceable to a user-enabled source, cancellable and route safely into the app.

## STEP 35
SEARCH / FILTER / COMMAND PALETTE ARCHITECTURE
Unified fast search across Tasks, Timesheet, CRM, Network Tree and secondary modules without turning Home into a dashboard.
