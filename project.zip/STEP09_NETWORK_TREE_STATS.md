# SHAHRIAR GAME — 100 STEP REBUILD
## STEP 09 — NETWORK TREE / STATS EXPERIENCE

این سند مرجع رسمی صفحه «آمار» است.

---

# 1. اصل غیرقابل تغییر

صفحه «آمار» فقط و فقط Network Tree است.

نباید شامل:
- KPI Dashboard
- نمودار شخصی
- Win/Loss
- Match History
- Minion/Tower Stats
- Cards آماری جدا
- Charts

باشد.

---

# 2. Bottom Navigation

آیتم سوم:
آمار

Tap:
مستقیماً Network Tree باز می‌شود.

---

# 3. Tree Purpose

Tree باید ساختار واقعی شبکه را نشان دهد:

Root:
Player

Generation 1:
Direct Members

Generation 2+:
Descendants

هر Person Node می‌تواند Child داشته باشد.

---

# 4. Visual Identity

هویت:
Strategic Command Tree

Background:
Deep Navy / Black

Lines:
Cyan / Gold

Root:
Gold emphasis

Active Member:
Cyan

Needs Attention:
Amber / Crimson accent

---

# 5. Full-Screen Canvas

Tree باید تقریباً تمام فضای Screen را بگیرد.

Reserved:
- compact top toolbar
- bottom nav
- optional member detail panel

No extra dashboard above tree.

---

# 6. Node Fields

Member Node:

- id
- parentId
- name
- rank
- level
- status
- sales
- gpv
- networkingProgress
- goal
- avatar optional
- expanded
- createdAt
- updatedAt

---

# 7. Status

Default statuses:

- active
- growing
- follow_up
- inactive

نمایش فارسی:

فعال
در حال رشد
نیازمند پیگیری
غیرفعال

---

# 8. Rank

هر Member می‌تواند Rank خودش را داشته باشد.

Rank:
editable

Tree Node:
Rank به صورت compact tag

---

# 9. Sales & GPV

Sales:
عدد قابل ویرایش

GPV:
عدد قابل ویرایش

نمایش داخل Node:
Compact

No separate chart.

---

# 10. Goals

Member Goal:

- target
- progress
- unit
- period optional

مثال:
هدف فروش 500
پیشرفت 320

نمایش:
64%

---

# 11. Networking Progress

Member می‌تواند Action Progress داشته باشد:

- ارتباط‌سازی
- پیش‌مشاوره
- دعوت
- معرفی کار
- فالوآپ

در Step Networking سیستم کامل قفل می‌شود.

در Tree:
فقط Summary compact.

---

# 12. Expand / Collapse

Tap روی Toggle:

Expanded:
Children visible

Collapsed:
Children hidden

Parent node باقی می‌ماند.

---

# 13. Recursive Tree

Tree باید recursion نامحدود منطقی را پشتیبانی کند.

نسخه UI:
با performance limit منطقی

مثلاً:
صدها Member با virtualization / efficient rendering در Build step.

---

# 14. Pan

کاربر باید بتواند Tree را:

- بالا
- پایین
- چپ
- راست

Drag کند.

Pan smooth.

---

# 15. Zoom

Zoom:
Pinch در mobile

Buttons:
+
-

Reset:
fit to root / fit tree

---

# 16. Zoom Range

Default:
1.0

Min:
0.55

Max:
1.8

قابل تنظیم بعداً.

---

# 17. Root Position

Root:
بالای Tree

Center horizontal

Children:
پایین

Tree direction:
Top → Bottom

---

# 18. Generation Spacing

Vertical:
110–150px logical

Horizontal:
dependent on sibling count

هدف:
Lineها overlap شدید نداشته باشند.

---

# 19. Connector Lines

Line:
parent → child

Style:
thin luminous stroke

Root branches:
Gold/Cyan

Inactive:
muted

---

# 20. Tap Node

Tap روی Member:
Open Member Detail Sheet

Detail:
- Name
- Rank
- Level
- Status
- Sales
- GPV
- Goal
- Progress
- Actions

---

# 21. Edit Member

Member Detail:
Edit

Fields:
Name
Rank
Level
Status
Sales
GPV
Goal

---

# 22. Add Child

Action:
`+ افزودن عضو زیرمجموعه`

Parent:
همان Node انتخاب‌شده

---

# 23. Remove Member

Remove:
Confirmation required

Policy:
دو گزینه در implementation future:

1. Remove subtree
2. Reassign children

Default safe proposal:
Reassign children to parent

اما باید explicit باشد.

---

# 24. Root Cannot Delete

Root Player:
قابل حذف نیست

قابل Edit:
Name
Rank
Level
Goals

---

# 25. Search

Search Member:

- name
- rank

Result:
Tree pan/zoom به Node موردنظر

Node highlight.

---

# 26. Filter

Tree-only page می‌تواند Filter compact داشته باشد:

- همه
- فعال
- در حال رشد
- نیازمند پیگیری
- غیرفعال

اما Filter نباید ساختار را به Dashboard تبدیل کند.

---

# 27. Focus Mode

Focus Member:

Selected Node:
center screen

Ancestors:
visible

Descendants:
optional

برای شبکه‌های بزرگ.

---

# 28. Generation Badge

هر Node می‌تواند generation نشان دهد:

G0
G1
G2
...

اختیاری و compact.

---

# 29. Node Density

Mobile:
Node width:
120–150px logical

Height:
70–90px

اطلاعات اضافه در Detail Sheet.

---

# 30. Node Visual Priority

1. Name
2. Status
3. Rank
4. Goal Progress
5. Sales/GPV

---

# 31. Status Visual

Active:
cyan dot

Growing:
green/cyan pulse subtle

Follow-up:
gold dot

Inactive:
gray

No aggressive flashing.

---

# 32. Goal Progress

داخل Node:
thin progress strip

مثال:
64%

---

# 33. Member Details Stay In Tree Context

Detail Sheet:
از پایین باز شود

Tree پشت آن باقی بماند.

No page change.

---

# 34. Data Ownership

Tree Member data:
persistent

Networking Records:
separate data model

Member can link to networking/contact record later.

---

# 35. Recursive Data Shape

Preferred:

Flat map with parentId

Advantages:
- update آسان
- search آسان
- reparent آسان
- persistence ساده

Rendering:
derive children.

---

# 36. Example Root

Name:
شهریار

Rank:
حماسی III

Level:
28

Status:
active

---

# 37. Example Members

Member A:
علی
حرفه‌ای II
Growing

Member B:
مریم
پیگیر III
Active

Member C:
رضا
تازه‌کار II
Follow-up

---

# 38. Summary Inside Node

Allowed:
Sales
GPV
Goal %

Not allowed:
separate analytics cards.

---

# 39. Toolbar

Compact toolbar:

- Search
- Zoom -
- Zoom +
- Reset
- Add direct member

Toolbar should float over Tree.

---

# 40. Minimap Optional

برای Tree بسیار بزرگ:
Overview minimap future

نه الزامی در Step اولیه.

---

# 41. Persistence

Tree:
save every CRUD operation

Expand/collapse:
can be UI state only

Member data:
persistent.

---

# 42. Undo

Future recommended:
Undo after remove/reparent

نه Step اولیه.

---

# 43. Accessibility

Node touch:
44dp+

Text readable

Status:
text + color

Zoom buttons:
large enough

---

# 44. RTL

Member names:
RTL

Tree geometry:
neutral

Toolbar:
RTL

---

# 45. Performance

Avoid:
DOM explosion

Build future:
SVG connectors + positioned nodes
or Canvas/WebGL for large scale

Step prototype:
DOM + SVG acceptable.

---

# 46. Tree Layout Strategy

Initial:
Layered generation layout

Parent centered over child group

Cross-links:
not supported initially

Each Member:
single parent.

---

# 47. Add Member Flow

Select parent
→ Add
→ Form
→ Save
→ Node appears
→ connector animates

---

# 48. Edit Flow

Tap node
→ Detail
→ Edit
→ Save
→ node updates in place

---

# 49. Remove Flow

Tap node
→ More
→ Remove
→ Confirmation
→ policy choice
→ save
→ tree relayout

---

# 50. Quality Gate

Stats PASS اگر:

- فقط Tree باشد
- هیچ chart/dashboard جدا نباشد
- Expand/Collapse کار کند
- Zoom/Pan کار کند
- Add/Edit/Remove member ممکن باشد
- Root حذف نشود
- recursive structure باشد
- Member details داخل Node/Sheet باشند
- Sales/GPV/Goal داخل context خود Member بماند
- روی mobile قابل استفاده باشد

---

# STEP 10

TIMESHEET / WEEKLY TACTICAL PLANNER

در قدم ۱۰:
- هفته شنبه‌محور
- ۷ روز
- CRUD
- recurring
- complete/revert
- search
- ارتباط با Task و Gameplay
طراحی می‌شود.
