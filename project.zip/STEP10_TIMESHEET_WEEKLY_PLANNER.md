# SHAHRIAR GAME — 100 STEP REBUILD
## STEP 10 — TIMESHEET / WEEKLY TACTICAL PLANNER

این سند مرجع رسمی صفحه «تایم‌شیت» است.

---

# 1. نقش Timesheet

تایم‌شیت باید برنامه‌ریزی هفتگی را به شکل یک Tactical Planner نمایش دهد.

هدف:
کاربر بداند:
- امروز چه برنامه‌ای دارد
- چه کاری انجام شده
- چه چیزی باقی مانده
- چه Taskهایی برای Gameplay آماده‌اند

---

# 2. Bottom Navigation

آیتم چهارم:

تایم‌شیت

Navigation ثابت:

خانه | کارها | آمار | تایم‌شیت | شبکه‌سازی

---

# 3. Week Structure

هفته:
شنبه تا جمعه

روزها:
- شنبه
- یکشنبه
- دوشنبه
- سه‌شنبه
- چهارشنبه
- پنجشنبه
- جمعه

---

# 4. Week Header

Top:

- عنوان هفته
- تاریخ شروع / پایان
- هفته قبل
- هفته بعد
- بازگشت به هفته جاری

---

# 5. Date Chips

۷ Chip برای هفت روز

هر Chip:
- نام روز
- روز ماه
- active state
- تعداد برنامه‌ها
- completion indicator

---

# 6. Selected Day

فقط برنامه‌های روز انتخاب‌شده نمایش داده می‌شوند.

Tap Day:
Selected date changes

---

# 7. Entry Model

Timesheet Entry:

- id
- title
- date
- startTime
- endTime
- linkedTaskId optional
- category
- note
- completed
- recurring
- recurrenceRule optional
- createdAt
- updatedAt

---

# 8. CRUD

User can:

- Add
- Edit
- Delete
- Complete
- Revert

---

# 9. Add Entry

Primary CTA:
`+ برنامه جدید`

Fields:
- title
- date
- start time
- end time
- category
- linked Task optional
- recurring
- note

---

# 10. Linked Task

Entry می‌تواند به یک Master Task لینک شود.

Linked Task:
- همان Task حذف نمی‌شود
- فقط reference ذخیره می‌شود

Gameplay:
می‌تواند Taskهای برنامه‌ریزی‌شده امروز را Priority بدهد.

---

# 11. No Forced Link

Timesheet Entry الزاماً Task نیست.

مثال:
- جلسه
- استراحت
- مطالعه
- تماس
- مسیر رفت‌وآمد

linkedTaskId optional.

---

# 12. Completion

Complete:
entry.completed = true

Visual:
- check
- muted completed style
- timestamp future optional

---

# 13. Revert

Completed Entry:
قابل برگشت به incomplete

Action:
`بازگردانی`

---

# 14. Delete

Delete:
confirmation

Timesheet delete:
Task linked را حذف نمی‌کند.

---

# 15. Recurring

Recurring modes future-friendly:

- none
- daily
- weekly
- custom

Step اولیه:
none / weekly

---

# 16. Weekly Recurrence

اگر Weekly:

Entry template:
هر هفته همان روز/زمان تکرار شود.

Instance state:
Completion هر هفته جدا.

---

# 17. Search

Search در:

- title
- category
- note

نتیجه:
برای روز انتخاب‌شده یا کل هفته، بسته به toggle future.

Step اولیه:
selected day.

---

# 18. Categories

Examples:

- شبکه‌سازی
- فروش
- جلسه
- یادگیری
- برنامه‌ریزی
- شخصی
- سلامت

Editable later.

---

# 19. Day Summary

Compact:

- تعداد برنامه
- انجام‌شده
- باقی‌مانده

No big dashboard.

---

# 20. Timeline Style

Entry Card:
time rail

Right/Left depending RTL:
- start/end
- title
- category
- status
- linked Task badge

---

# 21. Visual Hierarchy

1. Current/Selected Day
2. Time
3. Entry Title
4. Completion State
5. Task Link
6. Note

---

# 22. Tactical Aesthetic

Background:
Deep Navy

Time Rail:
Cyan

Selected Day:
Gold accent

Completed:
Muted cyan/steel

Urgent:
Gold/Crimson subtle

---

# 23. Current Time Indicator

Future build:
خط Current Time

فقط برای Today

Step prototype:
optional visual.

---

# 24. Empty Day

Copy:
«برای این روز برنامه‌ای ثبت نشده.»

CTA:
`برنامه جدید`

---

# 25. Current Week Start

Week starts:
Saturday 00:00 local

Week ends:
Friday 23:59

---

# 26. Persian Calendar Display

UI نهایی:
نمایش تاریخ فارسی/شمسی

Data:
ISO date canonical

هدف:
display و storage از هم جدا باشند.

---

# 27. Date Storage

Store:
YYYY-MM-DD

Display:
Persian localized date

---

# 28. Time Storage

24-hour local time

Format:
HH:mm

---

# 29. Validation

endTime باید:
بعد از startTime باشد

Exception:
overnight entry future

Step اولیه:
same-day only.

---

# 30. Overlap

Overlapping entries:
Allowed

اما UI:
Warning subtle

مثال:
«این زمان با برنامه دیگری هم‌پوشانی دارد.»

---

# 31. Recurring Edit

Future options:

- فقط این مورد
- این مورد و موارد بعد
- کل سری

Step design باید schema-compatible باشد.

---

# 32. Task Integration

اگر Entry linkedTaskId دارد:

Task Card badge:
`Linked Objective`

Gameplay selection future:
priority boost for today's planned tasks

---

# 33. Gameplay Integration Rule

Timesheet:
Task را Complete نمی‌کند مگر user explicitly linked completion action future.

Default:
Timesheet completion و Task completion جدا هستند.

---

# 34. Match Preparation

قبل Match:
Home/Gameplay می‌تواند بفهمد:

Today's linked active tasks

و آنها را در Encounter Pool اولویت دهد.

---

# 35. No Automatic Reward

Timesheet Complete:
XP/Gold/Diamond نمی‌دهد.

Reward فقط از سیستم Task/Gameplay یا Achievement rules.

---

# 36. Week Navigation

Prev:
weekStart - 7 days

Next:
weekStart + 7 days

Today:
jump to current week + current day

---

# 37. Persistence

Entries:
persistent

Selected day:
UI state

Selected week:
UI state

---

# 38. Search UX

Search:
compact field

No complex filter bar required.

Future filters:
completed / pending / category / linked.

---

# 39. Edit Sheet

Same Tactical Sheet design as Tasks.

Consistency:
- dark panel
- gold primary CTA
- cyan accents
- Persian RTL

---

# 40. Entry Card Actions

Primary:
Complete/Revert

Secondary:
Edit

Danger:
Delete

No action overload.

---

# 41. Recurring Badge

Weekly entry:
↻ هفتگی

Compact.

---

# 42. Linked Task Badge

Linked:
⚔ Task

Tap future:
open Task detail

---

# 43. Day Progress

Date Chip can show:
small ring/dot

Example:
3/5 completed

No chart.

---

# 44. Mobile Density

360px:
horizontal 7-day strip scrollable if needed

Selected chip:
fully visible

Timeline:
single-column

---

# 45. Safe Area

Bottom:
respect nav + safe-area

Entry list:
must not hide under nav.

---

# 46. RTL

Day strip:
RTL natural order

Times:
LTR-safe numeric rendering

Text:
RTL

---

# 47. Performance

100+ entries/week:
smooth

Render:
selected day only

---

# 48. Example Entry

Title:
فالوآپ با ۳ پراسپکت

Date:
Saturday

Time:
10:00–11:00

Category:
شبکه‌سازی

Linked Task:
yes

Recurring:
weekly

Completed:
false

---

# 49. STEP 10 LOCKED STRUCTURE

Header:
Week navigation

7 Day Chips

Search

Day summary

Timeline entries

Add CTA

Bottom Nav

---

# 50. Quality Gate

Timesheet PASS اگر:

- هفته شنبه‌محور باشد
- ۷ روز قابل انتخاب باشد
- Prev/Next/Today کار کند
- CRUD کامل باشد
- Complete/Revert کار کند
- recurring پشتیبانی شود
- Task link optional باشد
- حذف Entry، Task را حذف نکند
- هیچ Reward مستقیم از Timesheet داده نشود
- UI روی mobile readable باشد

---

# STEP 11

NETWORKING / CRM COMMAND CENTER

در قدم ۱۱:
- ارتباط‌سازی
- پیش‌مشاوره
- دعوت
- معرفی کار
- فالوآپ
- Prospect CRUD
- result
- next actions
- follow-up dates
طراحی می‌شود.
