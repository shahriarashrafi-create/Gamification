# STEP 49 — TOWER & BASE DESTRUCTION CINEMATIC RUNTIME

این مرحله نابودی Objectiveها را به progression واقعی Match وصل می‌کند.

## Tower Destruction
Task completion
→ damage commit
→ HP 0
→ destroyed state commit
→ controls briefly constrained
→ objective marker clears
→ crystal fracture
→ collapse burst
→ debris/smoke
→ collision release
→ destruction bonus once
→ lane progression commit
→ next objective unlock
→ controls resume

## Tower1
Tower1 destroyed:
Tower2 همان Lane unlock می‌شود.
هیچ Lane دیگری قفل نمی‌شود.

## Tower2
Tower2 destroyed:
Lane = complete.
Enemy Base unlock condition دوباره محاسبه می‌شود.

## Enemy Base Unlock
طبق Rule فعلی:
حداقل یک Lane کامل → Enemy Base قابل حمله.

## Base Destruction
Base HP reaches 0
→ authoritative destroyed commit
→ controls lock
→ scheduler stops
→ final collapse
→ Victory trigger
→ Victory transaction once
→ result snapshot
→ Results route

## Victory Safety
Victory فقط از Enemy Base HP=0.
Tower destruction Victory نیست.
Time End Victory نیست.
Manual Exit Victory نیست.

## Collision
Tower collision فقط بعد از destroyed commit آزاد می‌شود.
انیمیشن زودتر collision را باز نمی‌کند.

## Rewards
Tower destruction bonus once.
Base Victory bonus once.
Duplicate transaction IDs ignored.

## Camera
Tower:
short focus + light impact.

Base:
stronger focus + controlled zoom.
No disorienting shake.

## Reduce Motion
No large collapse motion.
Use fracture flash + dissolve + state swap.

## Failure Recovery
اگر cinematic قطع شود:
authoritative progression حفظ می‌شود.
در Resume، UI از committed state بازسازی می‌شود.

## Lane State
locked
tower1_active
tower2_active
complete

## Objective Priority
near actionable minion
current lane tower
unlocked enemy base
other valid target

## QA
Tower1 unlocks Tower2 only after commit
Tower2 completes lane
one complete lane unlocks Base
Tower bonus once
Base Victory once
collision release after commit
cinematic failure cannot roll back progression
no Energy
no Mana

## STEP 50
MATCH VICTORY & RESULTS CINEMATIC INTEGRATION
نیمه اول طراحی: Victory/Time End/Manual Exit را به Results واقعی، progression summary و بازگشت امن Home وصل می‌کنیم.
