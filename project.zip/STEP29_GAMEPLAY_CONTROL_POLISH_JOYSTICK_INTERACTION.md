# SHAHRIAR GAME — STEP 29
## GAMEPLAY CONTROL POLISH / JOYSTICK & INTERACTION SYSTEM

مرجع رسمی کنترل Hero، Joystick، Target Selection و Touch Priority.

## 1. Goal
کنترل باید روی گوشی واقعی نرم، دقیق و قابل پیش‌بینی باشد.
هیچ حرکت ناگهانی، stuck input یا target اشتباه نباید تجربه را خراب کند.

## 2. Joystick
Default lower-left.
Base diameter target: 112–132dp.
Thumb diameter target: 42–52dp.

## 3. Dead Zone
Default normalized dead zone = 0.12.
Input زیر این مقدار صفر محسوب می‌شود.

## 4. Response Curve
responseExponent = 1.35.
حرکت آرام نزدیک مرکز و سریع‌تر در انتهای شعاع.

## 5. Max Speed
Default maxSpeed = 6.6 world units/sec.

## 6. Acceleration
4.2 units/sec² normalized tuning reference.

## 7. Deceleration
5.4 units/sec².
Hero باید سریع‌تر از شتاب‌گیری متوقف شود تا حس کنترل بهتر باشد.

## 8. Walk / Run
run threshold = 0.62 joystick magnitude.
Below = walk.
Above = run.

## 9. Direction
8-direction visual facing.
Actual movement remains continuous vector-based.

## 10. Facing Threshold
Facing only changes when meaningful velocity > 0.18.
Prevents flicker near stop.

## 11. Delta Clamp
Frame delta clamped to max 0.05 sec to prevent giant movement jumps after app hiccup.

## 12. Touch Capture
Joystick owns its touch pointer until release/cancel.
Moving finger outside joystick base still continues normalized drag within max radius.

## 13. Multi-touch
Joystick and Action can be used independently.
Encounter/Modal can override both.

## 14. Touch Priority
1 Modal / Encounter
2 Critical Confirmation
3 Pause
4 Context Action
5 Joystick
6 World informational touch

## 15. Context Action
Lower-right.
Only activates when valid actionable target exists.
Otherwise disabled/subdued.

## 16. Target Selection
Candidate must be:
alive/actionable
unlocked
within interaction relevance
not already reserved by another active transaction
not behind invalid progression gate

## 17. Target Priority
1 currently focused encounter candidate
2 closest valid target in front cone
3 closest valid target overall
4 recommended objective if within action radius

## 18. Front Cone
Use facing direction preference.
Does not block valid nearby target if nothing is in cone.

## 19. Sticky Target
Once target selected, retain briefly while Hero remains within hysteresis radius.
Prevents flickering between two close entities.

## 20. Hysteresis
exit radius > enter radius.
Use Step05 entity trigger radii + ~1.5 world units default.

## 21. Soft Stop
When Encounter opens:
movement target velocity → zero
current velocity decelerates smoothly
input locks after short transition.

## 22. Resume
After Encounter:
joystick state resets to neutral before re-enabling.
Prevents unintended movement if finger remained on screen.

## 23. Left-Hand Mode
Default layout:
Joystick left / Action right.
Left-hand accessibility option can mirror primary controls:
Joystick right / Action left
without mirroring whole battlefield/HUD.

## 24. Joystick Size
Settings range suggested 85–125%.
Minimum touch target maintained.

## 25. Opacity
Settings 45–100%.
Hit area remains full even at lower visual opacity.

## 26. Camera Sensitivity
Affects look-ahead/follow responsiveness only within safe ranges.
Does not alter Hero speed.

## 27. Action Button
Minimum 72–88dp visual circle.
Hit target >=88dp preferred for gameplay.

## 28. Press Feedback
Down:
scale ~0.96 + light haptic optional.
Disabled state clearly different.

## 29. No Auto Attack
Completing real-world Task authorizes the attack.
Action button opens/engages valid Task Encounter; it does not grind enemies automatically.

## 30. World Tap
No tap-to-move in default architecture.
No tap-to-teleport.

## 31. Collision
Movement vector is passed to collision system.
Slide along surface.
No clipping through Tower/Base.

## 32. Control Lock States
initializing
intro
encounter
committing
victory
result
pause

Movement disabled where appropriate.

## 33. Android Back
During active gameplay:
open Pause/Exit confirmation, not accidental app exit.

## 34. App Focus Loss
Clear active touch pointers.
Velocity can soft-stop/pause according to final lifecycle rule.
On return, never assume finger still held.

## 35. Haptics
Joystick: no continuous vibration.
Action press: light.
Target acquired: optional subtle.
Settings-aware.

## 36. Accessibility
Left-hand mode
joystick size
opacity
Reduce Motion
clear disabled/actionable state
>=44dp general target; gameplay controls larger.

## 37. Mobile QA
360×800
360×880
390×844
412×915
430×932
Controls never overlap gesture unsafe area or Task Sheet CTA.

## 38. Prototype
Step29 concept supports pointer-like joystick simulation, response curve, run threshold, target switching and left-hand mirroring.

## 39. Failure Conditions
stuck joystick
input after modal opens
target flicker
tap teleport
Hero speed changes with camera sensitivity
controls overlap safe area
left-hand mode mirrors map
movement jump after frame stall

## 40. Quality Gate
Hero motion must remain stable, deterministic and comfortable under quick direction changes and multitouch on a real Android phone.

## STEP 30
PAUSE / LIFECYCLE / ANDROID IMMERSIVE RECOVERY
Pause state, app background/foreground, focus loss, Android back behavior, immersive restore and active Match recovery.
