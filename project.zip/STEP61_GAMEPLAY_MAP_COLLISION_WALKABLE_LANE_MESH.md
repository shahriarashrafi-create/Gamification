# STEP 61 — GAMEPLAY MAP COLLISION GEOMETRY & WALKABLE LANE MESH

این مرحله World Architecture قدم 3 را به collision geometry واقعی وصل می‌کند.

## World Size

1200 × 2600 world units

## Main Regions

Own Base Zone
Lower Crossroad
Middle Crossroad
Upper Crossroad
Enemy Base Zone

## Lanes

Lane A — left
Lane B — center
Lane C — right

Approx normalized lane centers:
A = 0.28
B = 0.50
C = 0.72

## Walkable Mesh

Walkable areas از polygonهای مجزا ساخته می‌شوند:

lane_a_lower
lane_a_mid
lane_a_upper

lane_b_lower
lane_b_mid
lane_b_upper

lane_c_lower
lane_c_mid
lane_c_upper

crossroad_lower
crossroad_mid
crossroad_upper

own_base_zone
enemy_base_zone

objective_approach zones

## Crossroads

Y normalized:
0.73
0.51
0.29

Hero می‌تواند فقط از این corridorها بین Laneها جابه‌جا شود.

هیچ lane switching teleport وجود ندارد.

## Obstacles

rocks
walls
ruins
tower foundations
base walls
decorative props with collision flag

هر prop دو حالت دارد:
collision = true
collision = false

Visual prop بدون collision نباید movement را بلاک کند.

## Tower Collision

Tower alive:
collision ON

Tower destruction committed:
collision OFF

Collision release فقط بعد از destruction transaction.

## Enemy Base Gate

تا زمانی که Base locked است:
base approach gate collision ON

وقتی حداقل یک Lane کامل شود:
gate unlock
collision OFF
objective interaction ON

## Own Base

Hero Spawn:
X 0.50
Y 0.89

Own Base center:
X 0.50
Y 0.93

Spawn باید داخل walkable mesh معتبر باشد.

## Enemy Base

Enemy Base center:
X 0.50
Y 0.07

## Collision Query

Broad phase:
spatial grid

Narrow phase:
circle vs segment
circle vs polygon boundary
circle vs entity collider

Hero radius:
2.3 world units

## Slide

Collision normal محاسبه می‌شود.
Velocity component داخل normal حذف می‌شود.
Tangent movement باقی می‌ماند.

## Safety

Hero never:
leaves world bounds
crosses blocker
spawns inside blocker
teleports between polygons

## Recovery

اگر persisted Hero position نامعتبر باشد:
nearest valid point روی walkable mesh پیدا شود.

Recovery نباید reward/objective state را تغییر دهد.

## Debug

Development-only overlay:
walkable polygons
blockers
tower colliders
base gate
Hero collider
collision normals

Production:
debug overlay OFF

## QA

spawn valid
three lanes walkable
crossroads connect lanes
no teleport
Hero cannot leave mesh
tower blocks before destruction
destroyed Tower releases collision
locked Base gate blocks
completed lane unlocks gate
nearest valid point recovery works
visual-only props do not block
debug overlay production off
no Energy

## STEP 62

OBJECTIVE INTERACTION ZONES + TARGET ACQUISITION

Minion، Tower و Base را به interaction radius، current target، objective marker و Task Encounter trigger واقعی وصل می‌کنیم.
