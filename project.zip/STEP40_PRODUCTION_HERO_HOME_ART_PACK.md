# SHAHRIAR GAME — STEP 40
## PRODUCTION HERO & HOME ART PACK v1

این مرحله اولین پکیج گرافیکی واقعی پروژه است.

### خروجی واقعی این Step
سه Artboard تولیدشده با مدل تصویر داخل پکیج قرار گرفته‌اند و ظاهر هدف Home را قفل می‌کنند.
از روی Artboardها، Reference Cropهای Hero، Home Background، Rank Frame، Resource Icons و Start Game Button ساخته شده‌اند.
همچنین یک Icon Pack و Vector UI Pack واقعی و قابل استفاده برای Runtime اضافه شده است.

### Canonical Home Contract
Bottom Nav دقیقاً:
خانه | کارها | آمار | تایم‌شیت | شبکه‌سازی

Home Modules:
فروشگاه | رویدادها | آینده‌بینی | دستاوردها

بدون Friend List.
بدون Mission Strip.
بدون Energy.

### Visual Identity
Dark Navy / Obsidian
Royal Gold
Cyan crystal accents
Fantasy citadel / command-lobby atmosphere
Full-body premium Hero
Ornate but readable game UI

### Hero
Reference art برای Hero تمام‌قد تولید شده است.
Production crop باید در ادامه به Transparent WebP تبدیل/بازسازی شود و Head/Feet کامل باقی بمانند.

### Background
Castle/citadel fantasy background reference تولید شده است.
در Integration نهایی هیچ نوشته UI داخل Background bake نمی‌شود.

### Rank
Gold ornate rank-frame visual direction + usable SVG frame.

### Currency
Gold / Diamond / XP icon family اضافه شده.
Energy ممنوع است.

### Start Game
Ornate gold/navy CTA frame واقعی SVG اضافه شد.
متن CTA در Runtime فارسی و live خواهد بود:
«شروع بازی — ۳۰ دقیقه»

### Icon Pack
Canonical bottom nav:
home
tasks
stats_tree
timesheet
networking

Secondary:
shop
events
vision
achievements
settings

Currency:
gold
diamond
xp

### Important Production Note
Artboardها Reference/approved direction هستند. بعضی cropهای raster هنوز به صورت JPG reference هستند و cutout شفاف نهایی نیستند.
این موضوع عمداً در Manifest ثبت شده تا Reference با Final Runtime Asset اشتباه نشود.

### QA
- CSS Human silhouette ممنوع.
- Emoji icon ممنوع.
- Energy asset ممنوع.
- Hero head/feet نباید crop شود.
- CTA باید در 360×800 دیده شود.
- Bottom Nav دقیقاً پنج آیتم canonical باقی بماند.
- Stats فقط Tree باشد.
- Background متن UI bake‌شده نداشته باشد.
- Production runtime باید از vector icons واقعی استفاده کند.

## STEP 41
HOME SCREEN REAL ASSET COMPOSITION
ترکیب واقعی Art Pack مرحله ۴۰ در یک Home Screen اجرایی و Responsive: Hero Stage، Castle Background، HUD، Rank، چهار Module، CTA و Bottom Nav دقیقاً روی 360–430px.
