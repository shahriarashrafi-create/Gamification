# STEP 46 — ENTITY RUNTIME CUTOUT & BATTLEFIELD INTEGRATION

این مرحله Contract اجرایی Entityها را از Reference Art مرحله ۴۵ وارد Runtime می‌کند.

## اصل مهم
Reference Crop مرحله ۴۵ به‌عنوان Final transparent asset جا زده نمی‌شود.
تا زمان داشتن cutout شفاف مستقل، Runtime از Asset Slot + State Resolver استفاده می‌کند و fallback توسعه‌ای مشخص دارد.

## Runtime Entity
هر Entity:
id
type
team
lane
tier
hp
maxHP
visualState
assetSetId
worldX
worldY
pivot
collisionRadius
interactionRadius
healthBarAnchor
projectileHitAnchor
objectiveState

## Tower Resolver
67–100 healthy
34–66 damaged
1–33 critical
0 destroyed

## Base Resolver
76–100 stable
51–75 unstable
26–50 critical
1–25 collapse_ready
0 destroyed

## Minion Resolver
idle
walk
focused
hit
defeated

## Asset Slot
هر State مسیر مستقل دارد:
tower_enemy_t1_healthy
tower_enemy_t1_damaged
tower_enemy_t1_critical
tower_enemy_t1_destroyed

همین الگو برای Tower2، Base و Minion.

## Rendering
World position → camera transform → entity layer.
Entity DOM/Canvas object از transform استفاده می‌کند.
HP bar با entity حرکت می‌کند.
Objective ring زیر Entity قرار می‌گیرد.

## State Authority
Visual State فقط از state authoritative مشتق می‌شود.
Animation اجازه تغییر HP ندارد.

## Damage Flow
Task commit
→ damage transaction
→ authoritative HP
→ resolve visual state
→ play transition
→ if zero, destruction commit
→ reward bonus once
→ unlock routing if applicable

## Tower Destruction
Destroyed asset/state
collision release after commit
objective marker removed
next objective unlocked

## Base Destruction
Destroyed state
controls lock
Victory cinematic
Victory transaction once

## Minion Defeat
Task completion commit
attack/hit
defeated state
reward transaction
release task reservation
despawn after feedback

## Fallback
Development fallback مجاز است ولی:
- explicit data-fallback
- بدون Emoji
- بدون CSS انسان
- Production QA آن را رد می‌کند.

## Transparent Runtime Asset Requirement
Final:
WebP transparent
no baked UI text
correct pivot
consistent floor contact
state dimensions aligned

## Battlefield Integration
Step44 Battlefield اکنون Entity Registry، State Resolver و state-demo integration دارد.
Geometric entity rendering فقط fallback توسعه‌ای است.

## QA
HP → state deterministic
zero HP → destroyed
destroy bonus once
Tower1 unlocks Tower2 only after commit
Base victory only at zero
Minion defeated only after Task commit
no teleport
no Energy
no Mana

## STEP 47
TASK ENCOUNTER REAL UI IN BATTLEFIELD
Task Sheet واقعی را روی Battlefield Step46 می‌گذاریم و Complete/Defer/Cancel را به attack/damage/reward runtime وصل می‌کنیم.
