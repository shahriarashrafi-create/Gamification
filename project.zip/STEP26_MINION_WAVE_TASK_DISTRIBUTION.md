# SHAHRIAR GAME — STEP 26
## MINION WAVE & TASK DISTRIBUTION SYSTEM

مرجع رسمی Spawn موج‌ها و توزیع Task بین سه Lane.

## 1. هدف
موج‌ها باید حس زنده بودن Battlefield را ایجاد کنند، اما هر Minion همچنان نماینده یک اقدام واقعی باشد؛ نه دشمن تزئینی بی‌معنی.

## 2. Lanes
A = چپ
B = وسط
C = راست

هر Lane مستقل Task Assignment دارد اما از Match Task Pool مشترک استفاده می‌کند.

## 3. Default Wave Interval
45 seconds.
Editable in Settings and snapshotted at Match start.

## 4. Initial Wave
پس از Battle Ready، یک موج اولیه نزدیک نیمه پایین Map آماده است تا بازیکن سریع وارد Loop شود.

## 5. Wave Composition
Default:
1 actionable Minion per lane per wave opportunity.
Visual escort minions may exist later only if clearly non-interactive.
Core actionable entities must remain understandable.

## 6. Task Assignment
Minion spawn requests one eligible unused Task snapshot.
Assignment is atomic:
reserve task → create minion → link taskSnapshotId → persist.

## 7. No Duplicate Simultaneous Assignment
یک Task Snapshot نمی‌تواند همزمان روی دو Minion/Tower/Base فعال باشد.

## 8. Priority
Default weighted priority:
Important/Strategic > Normal > Easy
But randomness remains to prevent predictability.
Weights editable later.

## 9. Anti-Repetition
Avoid same Task title in consecutive encounters when pool allows.
Avoid same category more than 2 consecutive assignments when pool allows.
Avoid immediate lane duplicate.

## 10. Unused First
تمام Taskهای unused قبل از recycle شدن reusable Tasks اولویت دارند.

## 11. Reuse
Reusable Task may return only after unused pool exhausted.
One-time Task never returns after completion.

## 12. Deferred
deferred_current_match Task is excluded from further assignment for remainder of current Match by default.

## 13. Cancel
Cancel encounter does not consume Task permanently.
But re-entry guard prevents instant popup spam on same entity.

## 14. Completed
Completed session Task cannot be assigned again unless reusable cycle policy explicitly starts after pool exhaustion.

## 15. Small Pool
If only 1–2 Tasks exist:
system can reuse reusable tasks after completion cooldown.
Never spawn multiple actionable Minions linked to same Task simultaneously.

## 16. Empty Available Pool Mid-Match
Pause actionable spawning.
Existing objectives remain.
Show no fake task.
When reusable cooldown becomes eligible, spawning resumes.

## 17. Spawn Cap
Prevent battlefield clutter.
Default max actionable Minions alive:
6 total
2 per lane.

## 18. Spawn Distance
Never spawn directly on Hero.
Minimum world-space distance from Hero and camera edge rules apply.

## 19. Spawn Zone
Wave anchors:
lower
mid
upper
from Step03 map architecture.

## 20. Progression
Early match favors lower anchors.
As Towers fall, wave anchors may advance naturally.

## 21. Tower Gate
Minion spawning should not place actionable units behind a still-locked progression gate unless lane rules allow free exploration there.

## 22. Lane Selection
Player chooses lane by movement.
No lane-select teleport.

## 23. Lane Balance
Scheduler tracks recent assignments per lane.
If player ignores a lane, it does not endlessly accumulate actionable Minions beyond cap.

## 24. Despawn
Actionable Minions should not silently despawn while linked to an unresolved Task unless explicit safe cleanup rule applies.
Default: persist until resolved/current match cleanup.

## 25. Wave Timer
Wave scheduler continues independently from encounter unless match snapshot says timer/waves pause during encounter.
Default Match timer continues; spawn may queue until encounter closes to avoid UI overload.

## 26. Encounter Open
While Task sheet is open:
new waves can be scheduled but actual actionable spawn can be deferred until sheet closes.

## 27. Entity IDs
Unique:
minion_<lane>_<waveIndex>_<slot>

## 28. Task Reservation
Reservation states:
available
reserved
active_entity
completed
deferred_current
released

## 29. Release
If entity creation fails before persistence, reservation returns safely to available.

## 30. Crash Recovery
Persist task↔entity link.
Reload/recovery must not duplicate reservation.

## 31. Difficulty Visual
Minion visual can subtly indicate task difficulty through ornament/halo, but not imply different combat damage.

## 32. Rewards
Reward comes from Task snapshot × entity multiplier.
Minion does not invent a separate random reward.

## 33. No Random Loot
No loot-box behavior.
No random Diamond drop.

## 34. Diamond
Only if Task snapshot or explicit deterministic achievement/objective rule grants it.

## 35. Minimap
Actionable Minions may appear only within vision/relevance rules.
Do not overcrowd minimap.

## 36. Performance
Pool scheduler is data-driven.
Visual wave count capped.
No unnecessary offscreen DOM/entity buildup.

## 37. Accessibility
Difficulty/status not color-only.
Reduced Motion affects spawn animation, not scheduler.

## 38. Prototype
Step26 concept simulates waves, three lanes, assignment queue, anti-duplicate behavior and small-pool recycling.

## 39. Failure Conditions
same Task active twice
one-time Task recycled
unbounded minions
spawn on Hero
teleport lane choice
random Diamond
fake Task when pool empty
repetition despite alternatives

## 40. Quality Gate
Every actionable Minion must map to exactly one valid real-world Task and every Task reservation must have exactly one authoritative state.

## STEP 27
LANE PROGRESSION & OBJECTIVE ROUTING
Tower1/Tower2 gating, crossroads, lane switching, backtracking, objective recommendations and free-choice routing.
