# COMPONENT CATALOG

## sg-button
Variants: primary-gold, secondary-cyan, ghost, danger, icon, battle-cta.

## sg-card
Base surface for tactical/objective/reward/hero content.

## sg-panel
Variants: ornate, utility, hud.

## sg-chip
Filter/status/category/period selector.

## sg-input
Text, number, select, textarea with RTL and cyan focus.

## sg-sheet
Bottom-sheet default for mobile editing/details.

## sg-hud
Player/level/xp/gold/diamond/settings compact HUD.

## sg-bottom-nav
Exactly five canonical destinations.

## sg-progress
XP, task, rank, achievement, vision progress.

## sg-toast
Short non-blocking feedback.

## sg-confirm
Named destructive confirmation.

## sg-empty-state
Short message + one CTA.

## sg-currency
Gold / Diamond / XP semantic presentation.
