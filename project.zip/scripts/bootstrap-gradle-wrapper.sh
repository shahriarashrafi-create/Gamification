#!/usr/bin/env bash
set -euo pipefail

cd android

if command -v gradle >/dev/null 2>&1; then
  gradle wrapper --gradle-version 8.10.2
else
  echo "Gradle command not found. Install Gradle once, then rerun this script." >&2
  exit 1
fi
