#!/usr/bin/env bash
set -euo pipefail

required=(
  package.json
  capacitor.config.ts
  vite.config.js
  index.html
  android/app/src/main/AndroidManifest.xml
  android/app/src/main/java/com/shahriar/game/MainActivity.java
  android/app/src/main/java/com/shahriar/game/ImmersiveModePlugin.java
  .github/workflows/android-apk.yml
)

for f in "${required[@]}"; do
  if [[ ! -f "$f" ]]; then
    echo "Missing: $f" >&2
    exit 1
  fi
done

grep -q "com.shahriar.game" capacitor.config.ts
grep -q 'screenOrientation="portrait"' android/app/src/main/AndroidManifest.xml
grep -q "assembleDebug" .github/workflows/android-apk.yml

echo "Repository structure OK"
