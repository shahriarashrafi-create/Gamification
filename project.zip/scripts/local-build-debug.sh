#!/usr/bin/env bash
set -euo pipefail

npm ci
npm run build
npx cap sync android
chmod +x android/gradlew
(
  cd android
  ./gradlew --no-daemon assembleDebug
)

echo "APK ready at: android/app/build/outputs/apk/debug/app-debug.apk"
