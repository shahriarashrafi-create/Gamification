#!/usr/bin/env bash
set -euo pipefail

npm ci
npm run build
npx cap sync android
cd android
./gradlew assembleDebug

echo "APK: android/app/build/outputs/apk/debug/app-debug.apk"
