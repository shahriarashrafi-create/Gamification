import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const required = [
  'package.json',
  'capacitor.config.ts',
  'vite.config.js',
  'index.html',
  'app/src/main.js',
  'android/app/src/main/AndroidManifest.xml',
  'android/app/src/main/java/com/shahriar/game/MainActivity.java',
  'android/app/src/main/java/com/shahriar/game/ImmersiveModePlugin.java'
];

let failed = false;

for (const rel of required) {
  if (!fs.existsSync(path.join(root, rel))) {
    console.error(`MISSING: ${rel}`);
    failed = true;
  } else {
    console.log(`OK: ${rel}`);
  }
}

const manifestPath = path.join(root,'android/app/src/main/AndroidManifest.xml');
if (fs.existsSync(manifestPath)) {
  const manifest = fs.readFileSync(manifestPath,'utf8');
  if (!manifest.includes('screenOrientation="portrait"')) {
    console.error('FAIL: portrait');
    failed = true;
  } else console.log('OK: portrait');
}

if (failed) process.exit(1);
console.log('FINAL SOURCE STRUCTURE CHECK PASSED');
