$ErrorActionPreference = "Stop"
npm ci
npm run build
npx cap sync android
Set-Location android
./gradlew assembleDebug
Write-Output "APK: android/app/build/outputs/apk/debug/app-debug.apk"
