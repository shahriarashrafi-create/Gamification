# STEP 51 — RESULTS PRODUCTION VISUAL & PROGRESSION CEREMONY

این مرحله Results را از Summary کاربردی به یک پایان سینمایی و حرفه‌ای Match تبدیل می‌کند.

## Ceremony Order
Result Reveal
→ Match Summary
→ Reward Count-up
→ XP Progress
→ Level Up if crossed
→ RP Progress
→ Rank Up if crossed
→ Diamond reveal only if positive
→ Continue Home

## Victory
Gold/Cyan flare
VICTORY / پیروزی
Enemy Base destruction context
strongest ceremony

## Time End
Neutral Cyan
پایان زمان
No defeat language
No red failure treatment

## Manual Exit
Calm neutral treatment
پایان Match
No penalty language

## Reward Count-up
XP / Gold / RP:
visual count-up only.
Final values come from committed result snapshot.

Diamond:
never count fake values.
Show only positive committed delta.

## Level Ceremony
When levelAfter > levelBefore:
Level emblem pulse
old → new
short gold flare
No gameplay power claim.

## Rank Ceremony
When rankAfter != rankBefore:
rank medallion
old → new
RP overflow supported
No combat advantage.

## No Ceremony Replay Reward
Reopening Results can replay visuals if desired,
but cannot reapply progression or reward.

## Home Transition
Continue:
fade Results
restore normal Android system UI
route Home
Home renders canonical five nav
Hero/Rank/HUD refresh from committed player state

## Back
Same safe Home transition.

## Accessibility
Reduce Motion:
fade + static final values
no count-up required
no large flare travel

## Responsive
360–430 CSS px
100dvh
CTA always reachable
safe area top/bottom
no bottom nav on Results

## QA
Victory visually strongest
Time End neutral
Manual Exit neutral
count-up cannot mutate ledger
Level Up only when crossed
Rank Up only when crossed
Diamond only positive
Home CTA always visible
Stats remains Tree only
no Energy

## STEP 52
HOME RETURN STATE REFRESH & POST-MATCH LOOP
بعد از Results، Home را با XP/Gold/Diamond/Level/Rank جدید Refresh می‌کنیم و حلقه Match → Results → Home → Next Match را کامل می‌کنیم.
