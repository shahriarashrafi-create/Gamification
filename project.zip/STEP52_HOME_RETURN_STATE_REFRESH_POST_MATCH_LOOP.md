# STEP 52 — HOME RETURN STATE REFRESH & POST-MATCH LOOP

این مرحله حلقه اصلی بازی را می‌بندد:

Home
→ Pre-Battle
→ Match
→ Results
→ Player Progression Commit
→ Home Refresh
→ Next Match

## Source of Truth
Home هیچ Reward را دوباره محاسبه نمی‌کند.
بعد از Results، Player State از storage/committed progression دوباره خوانده می‌شود.

## Refresh Fields
Level
Current XP
XP Required
Gold
Diamond
Rank
Rank RP
Selected Hero
Recoverable Match state

## Return Order
Results Continue / Back
→ ensure Match finalization persisted
→ clear active Match pointer
→ leave immersive mode
→ restore Android system bars
→ route Home
→ read committed player state
→ update HUD
→ update Rank card
→ update Hero selection if changed
→ enable Start Game

## Fresh Launch
همچنان همیشه Home.
آخرین Route ذخیره‌شده باعث ورود خودکار به Results یا Match نمی‌شود.

## Next Match
Start Game:
validate Hero
validate eligible Tasks
verify no active Match
snapshot current settings
create new Match ID

Match قبلی هرگز reuse نمی‌شود.

## HUD Refresh
Player name
Level
XP bar
Gold
Diamond
Settings

Energy وجود ندارد.

## Rank Refresh
Rank card از committed rank state خوانده می‌شود.
Results ceremony فقط نمایش است.

## Diamond
اگر Match Diamond نداشته:
Home مقدار قبلی را نگه می‌دارد.
هیچ Diamond نمایشی ساخته نمی‌شود.

## Recovery
اگر final Match ذخیره شده ولی active pointer پاک نشده:
startup reconciliation آن pointer را پاک می‌کند.
اگر finalization ناقص باشد:
Home recoverable state نشان می‌دهد، نه duplicate reward.

## Double Navigation Guard
Continue چندبار زده شود:
Home transition فقط یک بار.

## Android
Gameplay immersive ends before Home render.
Home از normal system UI + safe areas استفاده می‌کند.

## Bottom Navigation
Exactly five:
خانه
کارها
آمار
تایم‌شیت
شبکه‌سازی

## Stats
آمار همچنان فقط درختواره.

## QA
Home values equal committed Player State
no reward recalculation on Home
finished Match cannot resume
new Match gets new ID
fresh launch Home
system bars normal on Home
five bottom nav only
no Energy

## STEP 53
HOME LIVE HUD & RANK CARD PRODUCTION STATE
HUD و Rank Card صفحه Home را به State Store واقعی متصل می‌کنیم و loading/error/reconciliation stateهای آن را نهایی می‌کنیم.
