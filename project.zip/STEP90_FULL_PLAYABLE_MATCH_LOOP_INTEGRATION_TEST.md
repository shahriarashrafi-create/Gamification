# STEP 90 — FULL PLAYABLE MATCH LOOP INTEGRATION TEST

این مرحله تمام سیستم‌های ساخته‌شده تا Step89 را برای اولین بار به یک Match Loop کامل و قابل‌بازی متصل می‌کند.

## End-to-End Flow

Fresh Launch
→ Home
→ Start Game Guard
→ PreBattle Validation
→ Match Bootstrap
→ Gameplay Bootstrap
→ Timer/Wave Scheduler
→ Hero Movement
→ Fog/Minimap
→ Live Wave
→ Real Task Minion
→ Task Encounter
→ Combat Handoff
→ Minion Defeat
→ Tower Interaction
→ Tower Damage/Destruction
→ Lane Complete
→ Enemy Base Unlock
→ Base Damage
→ Victory OR Time End
→ Results
→ Home Refresh

## Authority Chain

Home:
start request only

PreBattle:
new Match creation authority

Gameplay Bootstrap:
start running Match

Timer/Waves:
Step72 authority

Task:
real Task snapshot only

Combat:
visuals never mutate authoritative state

Entity HP:
entity transaction pipeline only

Rewards:
ledger/reward transaction only

Results:
committed result snapshot only

Home refresh:
committed Player State only

## Full Match State Machine

HOME
PREBATTLE
MATCH_READY
MATCH_RUNNING
TASK_ENCOUNTER
COMBAT_HANDOFF
MATCH_RUNNING
MATCH_ENDING
RESULTS
HOME

Terminal result types:
victory
time_end
manual_exit

## New Match Boot

Start is allowed only when:

Player State valid
Hero valid + battle assets ready
at least one activeInGame Task
Settings valid
Map valid
no blocking active Match

PreBattle persists Match before Gameplay.

## Gameplay Start

Gameplay:
loads persisted Match
hydrates world
places Hero
initializes Camera
binds HUD
enters immersive mode
commits startedAt once
starts Timer/Wave Scheduler
unlocks controls last

## Live Wave

Default first due wave:
45 seconds

No instant fake wave.

Wave:
checks caps
reserves real Tasks
persists Minion entities
stagger-spawns visuals
starts lane path movement

## Minion Encounter

Hero reaches valid Minion
→ Multi-target chooses one
→ Encounter Lock
→ real Task Sheet

Complete:
Task commit
→ Step86 combat handoff
→ Minion defeat commit
→ reward commit
→ reservation complete
→ despawn
→ movement resumes

Defer/Cancel:
no reward
no damage

## Tower Progression

Tower1:
100 HP
Task hit = 34
Expected:
100 → 66 → 32 → 0

Tower1 destroyed:
unlock Tower2 same Lane

Tower2 destroyed:
complete Lane

Any completed Lane:
Enemy Base unlock

## Enemy Base

Base:
100 HP
Task hit = 25

Expected:
100 → 75 → 50 → 25 → 0

Base HP 0:
destruction commit
→ Victory lock
→ Victory bonus
→ Victory cinematic
→ Results

## Time End

If remaining time <= 0 before Victory authority wins:

stop new encounters
stop Wave Scheduler
lock new objective transactions
resolve safe committed transaction
finalize time_end
preserve committed rewards
no Victory bonus
Results

## Result Race

Single finalization lock.

Victory cannot coexist with Time End.

If Base destruction commit happened first:
Victory.

If Time End finalization lock happened first:
Time End.

## Manual Exit

Confirmation required.

Committed rewards preserved.

No penalty.

No Victory bonus.

## Results

Bind only:
committed result snapshot
committed ledger
committed progression state

Show:
duration
Tasks completed
Minions defeated
Towers destroyed
Lanes completed
XP
Gold
Diamond
Level/Rank changes

Stats page remains Network Tree only.

## Return Home

Results → Home:

exit immersive mode
restore system bars
clear finalized activeMatchId
load Player State
refresh Level/XP/Gold/Diamond/Rank/Hero
optional one-time celebration
Home interactive

Fresh launch still always Home.

## Recovery Checkpoints

Before Gameplay:
persisted ready Match

During Match:
timer
wave index
Hero position
fog exploration
Minions/path progress
entity HP
objective progression
encounter lock
transaction stages

On recovery:
Home first
show recoverable Match card
never auto-open Match

Resume:
validate
hydrate
reconcile
continue

## Playable Loop Acceptance Criteria

A user can:

open app
start Match
move Hero
wait for Wave
approach Minion
complete a real Task
see attack/reward
continue moving
damage Tower
destroy Tower
unlock Tower2
complete Lane
unlock Enemy Base
damage Base
win
see Results
return Home
see committed progression

Or:
reach Time End
see neutral Results
keep committed rewards

## Integration Guards

No fake Tasks.
No fake Minions.
No duplicate Match creation.
No duplicate Task commit.
No duplicate damage.
No duplicate reward.
No duplicate Victory.
No stacked Task Sheets.
No teleport.
No forced lane.
No Energy.
No Mana.
Hero has no power advantage.

## QA — Critical End-to-End

Home always fresh launch
Start Guard blocks zero Tasks
PreBattle alone creates Match
Gameplay cannot create Match
Timer starts once
Wave first due at 45s
real Task reservation before Minion spawn
Minion uses persisted entity
Hero movement smooth
Fog follows Hero not Camera
Minimap shares state
one Encounter at a time
Task Complete requires commit
combat visual cannot mutate HP
Minion defeat idempotent
Tower damage idempotent
Tower1 unlocks Tower2
Tower2 completes Lane
one completed Lane unlocks Base
Base needs four default hits
Base destruction creates Victory once
Time End neutral
Manual Exit preserves committed rewards
Results are ledger-bound
Home refresh does not recalculate rewards
replay creates new Match ID
Fresh launch never auto-enters Match
Recovery does not duplicate rewards
Stats remains Tree only
Bottom nav outside gameplay exactly five
Gameplay has no app bottom nav
No Energy
No Mana

## STEP 91

PLAYABLE LOOP FAILURE INJECTION + CRASH RECOVERY QA

در نقاط حساس Match عمداً Crash/Background/Double Tap/Storage Failure شبیه‌سازی می‌کنیم تا مطمئن شویم هیچ Reward، Damage، Match یا Encounter دوبار ثبت نمی‌شود.
