# SHAHRIAR GAME — STEP 41
## HOME SCREEN REAL ASSET COMPOSITION

مرجع رسمی ترکیب Asset Pack مرحله ۴۰ در Home واقعی و Responsive.

## 1. Goal
Home باید در اولین قاب حس Lobby بازی بدهد، نه داشبورد مدیریتی.

## 2. Viewport
Portrait only.
Target widths:
360
390
412
430 CSS px

Reference heights:
800
844
915
932

## 3. Launch
Fresh launch always Home.

## 4. Composition Stack
Safe Top
Player HUD
Hero Stage
Secondary Modules
Rank Panel
Start Game CTA
Canonical Bottom Nav

## 5. Player HUD
Profile
Player name
Level
XP
Gold
Diamond
Settings

No Energy.

## 6. Hero Stage
Selected Hero is dominant visual subject.
Full-body framing.
Use reference/generated Hero visual until final transparent production cut is available.
Hero can be tapped to open Hero Hub.

## 7. Background
Fantasy citadel/castle reference from Step40.
Must remain decorative; all text stays live in UI.

## 8. Secondary Modules
Exactly four:
فروشگاه
رویدادها
آینده‌بینی
دستاوردها

No Friend List.
No Mission Strip.

## 9. Rank
Compact ornate rank card.
Visible without scrolling on normal target devices.

## 10. CTA
Primary:
«شروع بازی — ۳۰ دقیقه»

Uses real SVG ornate frame from Step40.
Always above Bottom Nav.

## 11. Bottom Nav
Exactly five:
خانه
کارها
آمار
تایم‌شیت
شبکه‌سازی

No sixth item.

## 12. Stats
آمار → Network Tree only.

## 13. Height Priority
If vertical space is tight:
shrink Hero first
then reduce vertical gaps
never hide CTA
never hide canonical nav

## 14. Hero Visual Target
360×800:
34–38vh

390×844:
37–41vh

430×932:
40–44vh

## 15. Top Safe Area
Respect env(safe-area-inset-top).

## 16. Bottom Safe Area
Bottom Nav includes env(safe-area-inset-bottom).

## 17. 100dvh
Use dynamic viewport height.
Avoid 100vh-only mobile bugs.

## 18. Layout
CSS Grid/Flex.
No giant fixed min-height for Hero stage.

## 19. Background Loading
Reserve container.
No UI jump after decode.

## 20. Hero Loading
Hero frame reserves size.
Fallback preserves full-body stage proportions.

## 21. HUD Legibility
Dark translucent glass behind critical counters if required.

## 22. Currency
Use Step40 SVG icons:
Gold
Diamond
XP

## 23. Module Icons
Use production SVG:
shop
events
vision
achievements

## 24. Navigation Icons
Use production SVG:
home
tasks
stats_tree
timesheet
networking

## 25. Settings
Use production settings SVG.

## 26. Rank Frame
Use `ui_rank_frame_gold.svg`.

## 27. CTA Frame
Use `ui_start_game_frame.svg`.

## 28. Interaction
Settings → Settings
Hero → Hero Hub
Shop → Shop
Events → Events
Vision → Vision
Achievements → Achievements
Start → Pre-Battle
Bottom nav → canonical routes

## 29. No Auto Keyboard
No input on Home.

## 30. No Horizontal Scroll
All supported widths must fit.

## 31. Touch Targets
Minimum 44dp.

## 32. Visual Style
Navy/Obsidian glass
aged gold
cyan crystal highlights
fantasy citadel
high visual depth
minimal dashboard feel

## 33. Mobile Density
HUD compact.
Modules compact 2×2.
Rank one-line/compact card if needed.
CTA large but not oversized.

## 34. Asset Policy
Production icons are SVG.
No emoji.
No CSS human silhouette in final production.

## 35. Current Step Limitation
Hero is currently sourced from generated Step40 visual reference/crop.
Final transparent production Hero cutout remains a later asset refinement task.

## 36. Prototype Runtime
`concept/home-real.html` is an executable responsive composition using Step40 assets.

## 37. QA Devices
360×800
360×880
390×844
412×915
430×932

## 38. Failure Conditions
CTA under nav
Hero cropped
modules missing
rank inaccessible
Energy appears
sixth bottom-nav item
Friend List appears
mission strip appears
Home resembles admin dashboard
horizontal overflow

## 39. Quality Gate
At 360×800, Home must still show:
HUD
Hero
4 modules
Rank
Start CTA
5-item Bottom Nav

## 40. Locked Result
Step41 becomes the canonical Home composition for later production implementation.

## STEP 42
HOME INTERACTION / MICROSTATE / HERO HUB ENTRY
Wire all Home taps, pressed states, module transitions, Hero Hub entry, route-safe Start Game and resume-Match card behavior.
