# STEP 67 — TOWER ENCOUNTER + DAMAGE TRANSACTION PIPELINE

این مرحله همان معماری idempotent قدم 66 را برای Tower می‌سازد.

## Full Tower Pipeline

Hero enters Tower interaction radius
→ Tower target acquired
→ Task Encounter opens
→ user taps Complete
→ Task completion commit
→ encounter sheet exits
→ Hero faces Tower
→ attack windup
→ projectile travel
→ impact
→ committed Tower damage -34
→ Tower HP state resolve
→ reward commit
→ if HP > 0: resume
→ if HP == 0:
    destruction commit
    destruction bonus commit
    Tower collision release
    objective marker clear
    lane progression commit
    next Tower or Enemy Base unlock
    resume

## Tower Rules

Tower HP default:
100

Damage per completed Task:
34

Expected default:
3 completed Tower Tasks destroy Tower
because:
100 → 66 → 32 → 0

Damage clamp:
HP never below 0.

## Tower Visual State

67–100:
healthy

34–66:
damaged

1–33:
critical

0:
destroyed

Visual state is derived from committed HP.

## Eligibility

Tower interaction valid only when:

Tower not destroyed
Tower objective unlocked
Match active
current target matches Tower
no active duplicate encounter
result not finalized

Tower2 is locked until Tower1 same Lane destroyed.

## Transaction IDs

taskCommitTxId
attackTxId
damageTxId
rewardTxId
destructionTxId
destructionBonusTxId
collisionReleaseTxId
laneProgressTxId

Each stage is once-only.

## Damage Authority

Only committed damage transaction changes HP.

Projectile and impact animations never mutate HP.

Duplicate impact callback cannot apply additional damage.

## Reward

Task reward uses encounter snapshot:
XP
Gold
Diamond if positive snapshot only

Reward atomic and once-only.

Tower destruction bonus is separate from Task reward.

Default Tower bonus:
Tower1 +150 XP / +60 Gold
Tower2 +220 XP / +90 Gold

Bonus committed once after destruction commit.

## Tower Destruction

When committed HP reaches zero:

Tower state = destroyed
interaction disabled
objective marker = completed
movement blocker remains until destruction commit finishes

Then:
collision release committed

Only after that Hero may move through Tower footprint.

## Lane Progression

Tower1 destroyed:
Tower2 same Lane unlocks.

Tower2 destroyed:
Lane state = complete.

Enemy Base:
unlocks when completedLanes >= 1.

No other Lane is automatically completed.

## Defer

Tower Task Defer:
no task completion
no attack
no damage
no reward
Tower remains available

## Cancel

Cancel:
no task completion
no attack
no damage
no reward
Tower remains current objective after cooldown

## Crash Recovery

Crash after damage commit:
HP must not be damaged again.

Crash after destruction commit before collision release:
resume collision-release stage.

Crash after reward commit:
reward cannot duplicate.

Crash after lane progression commit:
unlock state rebuilt from committed progression.

## Persist Stages

TASK_COMMITTED
DAMAGE_COMMITTED
REWARD_COMMITTED
DESTRUCTION_COMMITTED
COLLISION_RELEASED
LANE_PROGRESS_COMMITTED
DONE

## State Machine

READY
TASK_COMMITTING
TASK_COMMITTED
SHEET_EXIT
FACE_TARGET
ATTACK_WINDUP
PROJECTILE
IMPACT
DAMAGE_COMMIT
HP_SYNC
REWARD_COMMIT
CHECK_DESTROYED
DESTRUCTION_COMMIT
DESTRUCTION_BONUS
COLLISION_RELEASE
LANE_PROGRESS
FEEDBACK
RESUME
DONE

## QA

Tower damage exactly 34
HP clamps at zero
visual state derives from committed HP
duplicate damage ignored
duplicate reward ignored
destruction only at HP zero
Tower collision persists until destruction commit
Tower1 unlocks Tower2 only
Tower2 completes same Lane
one completed Lane unlocks Enemy Base
Defer no damage/reward
Cancel no damage/reward
crash recovery idempotent
no Hero combat stat advantage
no Energy

## STEP 68

TOWER DESTRUCTION VISUAL + COLLISION RELEASE RUNTIME

Tower collapse، debris، smoke، objective marker clear و collision release را به destruction commit واقعی وصل می‌کنیم.
