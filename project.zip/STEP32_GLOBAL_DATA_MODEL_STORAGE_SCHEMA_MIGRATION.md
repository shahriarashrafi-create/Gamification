# SHAHRIAR GAME — STEP 32
## GLOBAL DATA MODEL / STORAGE & SCHEMA MIGRATION

مرجع رسمی ذخیره‌سازی دائمی، Schema Versioning، Migration، Ledger، Backup/Export و Reset امن.

## 1. Goal
داده‌های اپ باید بعد از بستن برنامه، آپدیت نسخه، Crash و Recovery پایدار بمانند و هیچ Reward یا Wallet Transaction دوبار ثبت نشود.

## 2. Storage Strategy
Local-first.
Core gameplay must work without internet.
Primary persistent store should be transactional and versioned.

## 3. Recommended Android Storage
Phase 1 production:
Capacitor Preferences for lightweight settings/bootstrap metadata.
SQLite for structured persistent app data and ledgers.

Do not store all critical state as one giant JSON blob.

## 4. Data Domains
player
wallet
progression
tasks
taskCategories
networkTree
timesheet
networkingCRM
heroes
heroLoadouts
shop
realLifeRewards
events
visionGoals
achievements
settings
matchHistory
activeMatch
transactionLedger
schemaMeta

## 5. Schema Version
Current:
schemaVersion = 32

Every persisted database must store:
schemaVersion
createdAt
updatedAt
appBuildVersion optional

## 6. IDs
Use stable unique IDs.
Recommended:
UUID v4 or monotonic UUID/ULID strategy.
Never use array index as persistent entity identity.

## 7. Timestamps
ISO-8601 UTC for storage.
Convert to Persian/local display only at UI layer.

## 8. Player
Single logical profile:
id
name
level
xp
totalXP
rankId
rankScore
selectedHeroId
createdAt
updatedAt

## 9. Wallet
gold
diamonds
updatedAt

Wallet mutation must occur through ledger transaction, not arbitrary UI assignment.

## 10. Ledger
Each economy mutation:
transactionId
type
source
sourceId
matchId optional
xpDelta
goldDelta
diamondDelta
createdAt
metadataSnapshot

Unique transactionId prevents duplicates.

## 11. Ledger Types
task_reward
tower_bonus
base_victory_bonus
match_completion_bonus
achievement_claim
hero_purchase
cosmetic_purchase
real_reward_claim
admin_adjustment
migration_adjustment

## 12. Atomicity
For reward:
begin transaction
validate duplicate transactionId
apply ledger row
update wallet/progression
update source state
commit

If any write fails:
rollback all.

## 13. Task Model
Persist Master Task separately from Match Task Snapshot.

Master Task:
id
title
categoryId
difficulty
xp
gold
diamond
activeInGame
status
note
repeatMode
createdAt
updatedAt

## 14. Match Task Snapshot
Immutable during Match:
snapshotId
sourceTaskId
title
category
difficulty
xp
gold
diamond
note
repeatMode
capturedAt

## 15. Active Match
Persisted separately from history.
Only one active/recoverable Match by default.

## 16. Active Match Core
matchId
state
schemaVersion
createdAt
startedAt
plannedDurationSec
remainingDurationMs
settingsSnapshot
playerSnapshot
heroSnapshot
taskPoolSnapshot
taskSessionStates
laneStates
entityStates
heroPosition
fogDiscovery
rewardLedgerRefs
currentEncounter
updatedAt

## 17. Match History
After close/result:
summary snapshot
resultType
duration
task summary
objective summary
reward totals
rank/level change
finishedAt

No Stats dashboard dependency.
Stats route remains Network Tree only.

## 18. Network Tree
Flat relational model:
memberId
parentId nullable
name
rank
level
status
sales
gpv
networkingProgress
goal
avatarRef
createdAt
updatedAt

Root delete blocked at business layer.

## 19. Timesheet
Entry persists date/time values independently:
id
title
date
startTime
endTime
linkedTaskId optional
category
note
completed
recurrenceRule
createdAt
updatedAt

## 20. Networking CRM
prospects and actions stored separately.
Foreign key action.prospectId.

## 21. Hero Inventory
hero ownership and loadouts persisted separately from Hero catalog.

Catalog can be app-shipped static data.
Ownership:
heroId
unlocked
purchasedAt
selected

## 22. Shop Catalog
Static default catalog can live in app assets.
User-created real-life rewards persist in database.

## 23. Settings
Persist only user-configurable values.
Defaults remain in versioned app config.
On missing key:
read current default.

## 24. Migration Principle
Never reset user data merely because schema changed.

Migration:
detect old version
backup metadata
apply ordered migration steps
validate
commit new schemaVersion

## 25. Ordered Migrations
Example:
v31 → v32
- add transactionLedger
- normalize wallet
- add repeatMode default
- add activeMatch schemaVersion
- add backup metadata

## 26. Migration Idempotency
Each migration stores applied migration ID.
Running bootstrap again must not duplicate changes.

## 27. Migration Failure
Rollback transaction.
Keep old database untouched if possible.
Show recoverable error.
Never silently wipe data.

## 28. Backup
Manual export from Settings:
JSON package or ZIP package.

Backup includes user data and schema metadata.
It should NOT include app secrets or unnecessary cache.

## 29. Export Manifest
backupVersion
schemaVersion
exportedAt
appVersion
recordCounts
checksum map optional

## 30. Import
Validate:
file structure
supported schema
checksums if present
required entities
duplicate IDs
numeric bounds

Import should create safety backup before replacing data.

## 31. Import Modes
First production:
replace-all with confirmation.

Future:
merge mode with conflict handling.

## 32. Reset
Reset options:
reset gameplay history
reset tasks only
reset CRM only
reset all user data

Full reset requires explicit destructive confirmation.

## 33. Reset Wallet
Full reset may restore default wallet/profile values only after confirmation.
No hidden partial reset.

## 34. Soft Delete
Use archive/status where history references must remain.
Hard delete allowed only where no ledger/history integrity is broken.

## 35. Referential Integrity
Deleting Master Task does not delete historical Match snapshots.
Deleting CRM prospect requires defined action handling.
Deleting Hero catalog entry must not corrupt ownership rows.

## 36. Data Validation
No negative Gold/Diamond.
XP >= 0.
Tower/Base HP clamped.
Required title strings trimmed.
Invalid enum values migrate/fallback safely.

## 37. Corruption Guard
On boot:
validate schema meta
validate critical wallet/player rows
validate active Match version
quarantine invalid active Match rather than crashing.

## 38. Performance
Indexes:
ledger.transactionId UNIQUE
ledger.matchId
tasks.status + activeInGame
timesheet.date
networkTree.parentId
crmActions.prospectId + actionDate
matchHistory.finishedAt

## 39. Privacy
Local-first data.
Export is user-triggered.
Do not collect network/team/task data externally unless future sync is explicitly added.

## 40. Quality Gate
After any app update, crash or reload:
user wallet, tasks, team tree and committed rewards must remain correct with no duplicate transaction.

## STEP 33
BACKUP / EXPORT / IMPORT & SAFE RESET UX
User-facing Settings flows for backup files, restore validation, destructive confirmations, selective reset and recovery.
