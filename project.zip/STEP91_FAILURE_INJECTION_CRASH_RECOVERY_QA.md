# STEP 91 — FAILURE INJECTION + CRASH RECOVERY QA

در این مرحله عمداً Match را در نقاط حساس خراب می‌کنیم تا مطمئن شویم هیچ Task، Damage، Reward، Wave، Encounter یا Victory دوبار ثبت نمی‌شود.

## Failure Injection Points

1. بعد از Task commit و قبل از Sheet exit
2. وسط Attack windup
3. وسط Projectile
4. بعد از Impact visual و قبل از entity commit
5. بعد از entity commit و قبل از reward commit
6. بعد از reward commit و قبل از UI feedback
7. بعد از Tower destruction commit و قبل از collision release
8. بعد از Lane complete و قبل از Base unlock presentation
9. بعد از Base destruction commit و قبل از Victory finalization
10. بعد از Victory finalization و قبل از Results
11. وسط Wave spawn persistence
12. بعد از reservation و قبل از Minion visual spawn
13. وسط Encounter Lock
14. هنگام Background
15. هنگام Process Death
16. Double Tap روی Complete
17. Double Tap روی Start
18. Double Tap روی Reward-sensitive actions
19. Storage write failure
20. Corrupt active Match pointer

## Recovery Principle

Committed state wins.

Visual state never wins.

If a transaction is committed:
do not repeat it.

If a transaction is not committed:
resume/retry from last safe checkpoint.

## Transaction Journal

Each critical transaction stores:

txId
matchId
type
stage
committed
createdAt
committedAt
payloadHash

Critical types:

task_commit
minion_defeat
tower_damage
tower_destruction
base_damage
base_destruction
reward_commit
wave_spawn
lane_progress
victory_finalize
result_finalize

## Crash Recovery Decision

For every pipeline:

read persisted Match
read transaction journal
read ledger
read entity committed state
derive safe next stage

Never infer committed reward from animation.

## Task Crash

Task committed:
do not ask user to complete Task again.

Combat may resume or safely skip visual.

Task not committed:
Task sheet may reopen.

## Damage Crash

Entity damage committed:
HP remains changed.
Do not damage again.

Impact happened visually but no commit:
HP remains unchanged.
Retry authoritative transaction safely.

## Reward Crash

Reward committed in ledger:
do not grant again.
UI feedback may replay display-only once if desired.

Reward not committed:
no balance change.

## Tower Destruction Crash

Destruction committed:
Tower remains destroyed after recovery.

Collision release can be safely retried idempotently.

Lane progression can be reconciled.

## Base/Victory Crash

Base destruction committed:
Victory must eventually finalize.

Victory bonus:
exactly once.

If Victory finalization already committed:
Time End cannot replace it.

## Wave Crash

Reservation persisted but Minion visual not spawned:
recover persisted Minion entity and render it.

Wave spawn tx committed:
do not spawn same wave again.

## Encounter Lock Crash

Persisted valid lock:
restore/reconcile one encounter.

Stale uncommitted lock:
release safely.

Never restore two Task sheets.

## Background

Step72 background timer continues.

On return:
reconcile elapsed time.
Collapse missed Waves.
Do not burst spawn.

## Process Death

Fresh app launch still opens Home.

If valid running Match exists:
show recoverable Match card.

Never auto-enter Gameplay.

## Storage Failure

Write failure:
do not advance UI as if committed.

Keep previous authoritative state.

Expose recoverable error.

No destructive reset.

## Corrupt Pointer

If activeMatchId points to missing/invalid Match:
do not guess.

Quarantine pointer/state.
Show recovery action.

Never create replacement Match silently.

## Double Tap Guards

Start:
one PreBattle request / one Match.

Complete:
one Task commit.

Impact:
one damage tx.

Reward:
one ledger tx.

Victory:
one finalization tx.

## Failure Matrix Acceptance

Every injected crash must satisfy:

0 duplicate Task completion
0 duplicate damage
0 duplicate reward
0 duplicate wave
0 duplicate Minion
0 duplicate encounter
0 duplicate Victory
0 lost committed reward
0 fake HP loss
0 auto-enter Gameplay on fresh launch

## STEP 92

PERFORMANCE + 60FPS + MEMORY + MOBILE THERMAL OPTIMIZATION

Hero movement، Minions، Fog، Minimap، VFX، asset loading و render loop را برای گوشی واقعی Android optimize می‌کنیم.
