# STEP 66 — MINION ENCOUNTER + DEFEAT FULL TRANSACTION PIPELINE

این مرحله چرخه کامل Minion را در یک Transaction Pipeline واحد و idempotent می‌بندد.

## Full Pipeline

Hero enters interaction radius
→ target acquired
→ Task Encounter opens
→ user taps Complete
→ task completion transaction starts
→ encounter UI exits
→ Hero faces Minion
→ attack windup
→ projectile / impact
→ Minion hit visual
→ Minion defeat commit
→ reward commit
→ reservation complete
→ task repeat policy update
→ defeat feedback
→ Minion despawn
→ target clear
→ Hero movement resume

## Core Rule

Visual animation هرگز source of truth نیست.

Source of truth:
committed transactions + runtime state.

## Transaction IDs

taskCommitTxId
attackTxId
defeatTxId
rewardTxId
reservationTxId
despawnTxId

هر مرحله unique transaction ID دارد.

## Idempotency

Duplicate Complete tap:
ignored.

Duplicate impact callback:
ignored.

Duplicate reward callback:
ignored.

Duplicate despawn callback:
ignored.

## Task Completion

Task completion فقط زمانی committed می‌شود که:
Task هنوز valid باشد
reservation active باشد
encounter target همان Minion باشد
Match active باشد

## Attack

Attack sequence display-only است.

Attack cannot:
complete task
grant reward
complete reservation

## Defeat

Minion defeat فقط بعد از Task commit معتبر.

Minion defeat commit:
state = defeated
interaction disabled
target invalidated
movement disabled

## Reward

Reward snapshot از reservation/task encounter snapshot می‌آید.

Reward:
XP
Gold
Diamond only if snapshot > 0

Reward commit atomic و once-only.

## Reservation Completion

بعد از defeat commit:
reservation state = completed

Task:
one_time → remains completed
reusable → released according to reuse policy

## Despawn

بعد از feedback:
visual despawn

Data entity می‌تواند archived/removed شود.

Despawn failure:
committed defeat/reward حفظ می‌شود.
Recovery بعداً visual cleanup را کامل می‌کند.

## Defer Path

Task Defer:
no task completion
no attack
no defeat reward
reservation = deferred_current_match
Minion fade/despawn
target clear
movement resume

## Cancel Path

Cancel:
no task completion
no attack
no reward
reservation remains reserved
Minion remains waiting_for_player
short cooldown
movement resume

## Error Recovery

Crash after Task commit before Reward:
resume pipeline from committed stage.

Crash after Reward before Despawn:
do not reward again.
finish defeat/despawn only.

Crash before Task commit:
encounter may reopen safely.

## Pipeline Stage

READY
TASK_COMMITTING
TASK_COMMITTED
SHEET_EXIT
FACE_TARGET
ATTACK_WINDUP
PROJECTILE
IMPACT
DEFEAT_COMMIT
REWARD_COMMIT
RESERVATION_COMPLETE
FEEDBACK
DESPAWN
RESUME
DONE

## Persistence

Persist after:
TASK_COMMITTED
DEFEAT_COMMIT
REWARD_COMMIT
RESERVATION_COMPLETE
DONE

## Guards

Match active
target valid
reservation valid
Task snapshot valid
transaction unseen
result not finalized

## QA

Complete pipeline executes in order
reward once
defeat once
reservation complete once
duplicate callbacks ignored
Defer produces no reward
Cancel keeps reservation
crash recovery resumes stage
visual failure never rolls back committed reward
Diamond only if snapshot positive
no fake task
no Energy

## STEP 67

TOWER ENCOUNTER + DAMAGE TRANSACTION PIPELINE

همین معماری transaction را برای Tower می‌سازیم:
Task → Attack → Damage -34 → HP state → destruction unlock.
