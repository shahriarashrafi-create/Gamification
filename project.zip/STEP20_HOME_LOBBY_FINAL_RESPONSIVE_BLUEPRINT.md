# SHAHRIAR GAME — STEP 20
## HOME LOBBY — FINAL RESPONSIVE VISUAL BLUEPRINT

این مرحله ترکیب نهایی Home را قبل از Production Implementation قفل می‌کند.

## 1. هدف اصلی
Home باید در اولین نگاه «Lobby یک بازی Premium» باشد و در عین حال روی گوشی واقعی 360×800 نیز تمام کنترل‌های اصلی قابل دسترسی باشند.

## 2. Launch
هر Fresh Launch همیشه Home.
آخرین صفحه بازشده نباید Launch Route را تغییر دهد.

## 3. Canonical Bottom Navigation
دقیقاً:
خانه | کارها | آمار | تایم‌شیت | شبکه‌سازی

هیچ آیتم ششم وجود ندارد.

## 4. Home Stack
از بالا به پایین:
1. Safe Area
2. Player HUD
3. Hero Stage
4. Four Secondary Modules
5. Rank / RP
6. Start Game CTA
7. Bottom Navigation + gesture safe area

## 5. HUD
Profile/name + Level + XP + Gold + Diamond + Settings.
Compact.
هیچ Energy وجود ندارد.

## 6. Hero
Full-body centered.
Tap = Hero Hub.
Target size:
360×800: حدود 34–38% viewport
390×844: حدود 37–41%
430×932: حدود 40–44%

Hero size نباید CTA یا Moduleها را خارج صفحه هل دهد.

## 7. Hero Asset
Production uses actual full-body art.
Blueprint uses an explicit placeholder only for layout measurement.

## 8. Secondary Modules
چهار Module:
فروشگاه
رویدادها
آینده‌بینی
دستاوردها

Layout:
2×2 compact buttons around/below Hero stage depending available height.
All four must be visible/reachable.

## 9. Rank
Rank emblem + label + RP progress.
Compact horizontal panel.

## 10. CTA
`شروع بازی — {matchMinutes} دقیقه`
Always visible directly above Bottom Nav.
Default 30 minutes.
Settings value updates CTA.

## 11. No Home Mission Strip
No ماموریت اصلی
No کار بزرگ
No Focus Mission
No Friend List

## 12. Responsive Height Strategy
Use CSS variables driven by viewport height.
No giant fixed hero min-height.
Use clamp() and 100dvh.

## 13. 360×800
Critical target.
Everything essential fits without CTA/nav overlap.
Hero intentionally smaller than taller phones.

## 14. 390×844
Balanced default Android target.

## 15. 430×932
Hero can grow, but UI hierarchy remains identical.

## 16. Width
Primary supported 360–430 CSS px.
Cards use fluid width.
No horizontal overflow.

## 17. Bottom Nav
Visual height ~64px + safe area.
Main content reserves its height.

## 18. CTA Reserve
CTA bottom offset = nav height + safe-area + spacing.
Never positioned behind nav.

## 19. Hero Safe Box
Hero feet remain above rank/module/CTA region.
Head remains below HUD.

## 20. Module Hit Targets
>=44dp.

## 21. System Bars
Outside gameplay:
normal Android bars allowed.
Home must respect safe insets.

## 22. Immersive
Home is NOT immersive gameplay.
Only Match hides system bars.

## 23. Art Layers
background environment
atmosphere
hero back-light
hero
foreground pedestal
UI

## 24. Readability
Hero/background never reduce HUD/CTA readability.
Use localized vignette/gradient behind UI if needed.

## 25. Dynamic Content
Long player name truncates.
Large Gold/Diamond values use compact formatting later.
Persian labels remain readable.

## 26. Interaction
Settings → Settings
Hero → Hero Hub
Shop → Shop
Events → Events
Vision → Vision
Achievements → Honor Hall
Start → Gameplay
Bottom nav → canonical pages

## 27. Rank Example
حماسی III
72 / 100 RP

## 28. QA Widths
360
390
412
430

## 29. QA Heights
800
844
915
932

## 30. Visual Failure Conditions
FAIL if:
- CTA hidden
- bottom nav overlaps CTA
- any secondary module disappears
- Hero cropped unintentionally
- Rank inaccessible
- HUD unreadable
- horizontal overflow
- giant empty stage
- dashboard look dominates game-lobby look

## 31. Production Art Exit Gate
Final Home cannot ship with CSS Hero placeholder.
Actual approved Step18 Hero + environment assets required.

## 32. Quality Gate
Home PASS if 360×800 is fully usable and 430×932 scales up gracefully without changing information architecture.

## STEP 21
GAMEPLAY HUD & BATTLEFIELD — FINAL RESPONSIVE BLUEPRINT
Exact portrait battlefield composition, timer, minimap, joystick, objective feedback, task encounter overlay and safe zones.
