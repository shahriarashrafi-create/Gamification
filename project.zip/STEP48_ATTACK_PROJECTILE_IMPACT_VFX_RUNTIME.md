# STEP 48 — ATTACK PROJECTILE IMPACT VFX RUNTIME

این مرحله Attack Feedback را از یک Demo ساده به Runtime سینمایی و deterministic تبدیل می‌کند.

## Goal
Complete Task باید یک پاسخ واضح و رضایت‌بخش داشته باشد:
Hero windup
→ Projectile travel
→ Impact burst
→ HP tween
→ Entity state change
→ Reward fly-up
→ Resume

## Projectile
Trajectory:
Hero muzzle/origin
→ target projectileHitAnchor

Duration:
180–320ms based on distance.

No teleporting projectile.

## Curve
Quadratic arc:
start
control point
end

Default arc height:
18–42 px

## Windup
180ms default.

## Hit
120ms burst.

## HP Tween
220ms.
Authoritative HP is committed instantly in state.
UI bar animates toward committed value.

## Tower Impact
healthy:
small cyan/gold sparks

damaged:
extra crack pulse

critical:
orange/red fracture flare

destroyed:
collapse burst + smoke + debris
no repeated destruction

## Base Impact
stable:
crystal pulse

unstable:
surface crack

critical:
strong red-gold fracture

collapse_ready:
unstable core pulse

destroyed:
major collapse + Victory trigger once

## Minion Impact
focused:
ring lock
hit:
small flash
defeated:
short dissolve/fade

## Reward Fly-Up
XP:
cyan/gold text chip

Gold:
gold chip

Diamond:
cyan crystal chip only if >0 committed delta

Duration:
~360ms

## Reward Authority
Fly-up only after ledger transaction commit.

## Damage Authority
Projectile and VFX never mutate HP.
They visualize already-authorized actions.

## Camera
On hit:
very light nudge.
No disorienting shake.

## Reduce Motion
No projectile arc travel.
Use fast fade from origin to impact.
No camera shake.
Fewer particles.
HP tween retained.

## Performance
transform / opacity.
No large blur loops.
Particle cap small.
No canvas full-screen particle storm.

## Sequence
READY
COMMITTING
SHEET_EXIT
HERO_FACE_TARGET
ATTACK_WINDUP
PROJECTILE_TRAVEL
IMPACT
DAMAGE_COMMIT_VISIBLE
HP_TWEEN
ENTITY_STATE_SYNC
REWARD_COMMIT_VISIBLE
REWARD_FLYUP
RESUME

## Duplicate Guard
transactionId
damageTxId
rewardTxId
destructionTxId

Each once.

## Failure Recovery
If reward UI animation fails:
ledger still authoritative.

If VFX fails:
state still updates.

If HP bar animation fails:
next render snaps to authoritative HP.

## QA
Projectile reaches target anchor
HP tween matches committed HP
destroyed effect once
Reward fly-up after commit
Diamond only positive delta
Reduce Motion bypasses travel
VFX failure cannot corrupt state
no Energy
no Mana

## STEP 49
TOWER & BASE DESTRUCTION CINEMATIC RUNTIME
ساخت Collapse sequence کامل برای Tower/Base، objective unlock، lane progression و Victory trigger.
