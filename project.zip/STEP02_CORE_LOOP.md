# SHAHRIAR GAME — 100 STEP REBUILD
## STEP 02 — CORE LOOP & 30-MINUTE MATCH ARCHITECTURE

این سند مرجع رسمی Core Loop بازی است و از این مرحله به بعد هر طراحی Gameplay باید با آن سازگار باشد.

---

# 1. اصل اصلی Gameplay

بازی یک MOBA معمولی نیست که Taskها فقط روی آن چسبانده شده باشند.

قانون اصلی:

**Real Action → Combat Action**

بازیکن برای پیشروی واقعی در میدان باید یک اقدام واقعی در زندگی انجام دهد.

نمونه:

Hero به Minion می‌رسد  
→ Objective Panel باز می‌شود  
→ بازیکن یک Task واقعی را انجام می‌دهد  
→ Complete را می‌زند  
→ Hero Attack اجرا می‌شود  
→ Minion Hit / Defeat  
→ XP / Gold / Diamond Reward  
→ مسیر دوباره آزاد می‌شود

---

# 2. ساختار Match

مدت پیش‌فرض:
**30 دقیقه**

قابل تغییر از Settings.

این ۳۰ دقیقه یک «ساختار فشار و ریتم» است، نه یک مسیر اجباری.

یعنی:
- بازی هیچ‌وقت Hero را Teleport نمی‌کند.
- Tower فقط به دلیل رسیدن زمان باز نمی‌شود.
- بازیکن باید واقعاً به Objective برسد.
- بعد از Tower می‌تواند Lane را عوض کند.
- اگر زمان Match تمام شود، نتیجه بر اساس Progress واقعی ثبت می‌شود.

---

# 3. نقشه Portrait

جهت اصلی:

Enemy Base
↑
Tower 2
↑
Minion / Wave
↑
Tower 1
↑
Minion / Wave
↑
Own Base

سه Lane:

- Top Lane
- Mid Lane
- Bottom Lane

در Portrait:
- Own Base در پایین نقشه
- Enemy Base در بالای نقشه
- Camera همراه Hero حرکت می‌کند
- Hero معمولاً در نیمه پایین / مرکز Viewport نگه داشته می‌شود
- Map زیر Camera Scroll می‌شود

---

# 4. Spawn

شروع Match:

1. Countdown کوتاه
2. Hero داخل Own Base Spawn می‌شود
3. Camera روی Hero Lock می‌شود
4. Objective HUD می‌گوید:
   «به اولین موج مینیون نزدیک شو»
5. کنترل Hero فعال می‌شود

ممنوع:
- شروع Hero وسط Lane
- Teleport به Minion
- Auto-complete کردن مسیر

---

# 5. Movement Model

Hero Movement باید:

- Smooth
- Slow / Controlled
- Natural
- Analog-like
- با Acceleration
- با Deceleration
- با Direction Change نرم

Stateهای Hero:

- Idle
- Walk
- Run
- Attack
- Hit
- Victory
- Recall

Camera:
- Follow با Lag بسیار کم
- Snap ممنوع
- Camera Zone برای جلوگیری از لرزش
- Hero ترجیحاً در 55% تا 68% ارتفاع Viewport بماند

---

# 6. Encounter Radius

هر Entity یک Radius دارد:

Minion:
- Trigger Radius کوچک

Tower:
- Detection Radius بزرگ‌تر
- Attack/Objective Radius مشخص

Base:
- Core Radius

وقتی Hero وارد Radius می‌شود:

`EXPLORE → NEAR_OBJECTIVE`

و سپس اگر Objective قابل فعال شدن باشد:

`NEAR_OBJECTIVE → ENCOUNTER`

---

# 7. Minion Loop

Minion = یک Task واقعی

Flow:

1. Hero نزدیک Minion
2. Minion Target Lock
3. Battlefield کمی Dark/Blur
4. Task Encounter Overlay
5. نمایش:
   - Task Name
   - Category
   - Difficulty
   - XP
   - Gold
   - Diamond احتمالی
   - Note
6. بازیکن کار واقعی را انجام می‌دهد
7. Complete
8. Battlefield Focus برمی‌گردد
9. Hero Attack
10. Projectile / Hit
11. Minion Defeat
12. Reward Fly
13. XP/Gold به HUD منتقل می‌شود
14. Control آزاد می‌شود

گزینه‌ها:
- Complete
- Defer
- Cancel Current Encounter

Defer/Cancel فقط برای Match جاری است.
Task دائمی حذف نمی‌شود.

---

# 8. Wave System

Default:
Wave Interval = 45 seconds

قابل ویرایش در Settings.

Wave:
- چند Minion در Lane
- Minionها Visual Movement دارند
- Waveهای بعدی پس از Progress بازیکن و زمان ظاهر می‌شوند
- تعداد Waveها نباید UI را شلوغ کند

هدف:
حس زنده بودن Lane بدون تبدیل بازی به Combat پیچیده.

---

# 9. Tower 1

Tower 1 یک Objective چندمرحله‌ای است.

Default:
**3 Hit / 3 Task**

هر Complete:
- Attack
- Projectile
- Tower HP کاهش
- Damage number / fracture / glow state

Tower HP پیش‌فرض:
100

Tower Damage پیش‌فرض Task Hit:
34

بعد از سومین Hit:
Tower Destroyed

پس از Tower 1:
بازیکن آزاد است:

- ادامه همان Lane
- برگشت به Wave
- رفتن به Lane دیگر
- Push به Tower 2

هیچ Teleport یا forced path وجود ندارد.

---

# 10. Tower Danger

هنگام نزدیک شدن به Tower:

- Tower Range روی زمین نمایش داده شود
- HUD Warning
- Tower Core Charge
- Target line کوتاه
- اگر Hero هنوز Objective شرایط لازم را ندارد، Attack State باز نمی‌شود

هدف این سیستم:
Realism بصری، نه Damage پیچیده به Player.

---

# 11. Tower 2

Tower 2 قوی‌تر دیده می‌شود ولی Power Hero تغییر نمی‌کند.

Default:
- HP = 100
- Task Hits = 3

می‌تواند از Taskهای مهم‌تر یا سخت‌تر استفاده کند.

پس از Destroy:
Enemy Base Path باز می‌شود.

---

# 12. Enemy Base

Base = Final Objective

Default:
**4 Task / Hit**

Base HP:
100

Base Damage per completed Task:
25

هر مرحله:
- Core Crack
- Light instability
- Particle burst
- Map ambience stronger

Final Hit:
- Hero Attack
- Enemy Core Collapse
- Explosion
- Shockwave
- Screen Light Burst
- Victory Sequence

---

# 13. 30-Minute Rhythm

این زمان‌بندی Soft Guidance است:

## 00:00–02:00 — Spawn & Orientation
- ورود
- حرکت از Base
- اولین Wave

## 02:00–08:00 — First Progress
- Minion Tasks
- آشنایی با Flow
- نزدیک شدن به Tower 1

## 08:00–14:00 — Tower 1
- Objectiveهای چندمرحله‌ای
- اولین تصمیم جدی

## 14:00–21:00 — Lane Freedom
- Lane switch
- Minion waves
- Task انتخابی
- Push آزاد

## 21:00–27:00 — Tower 2 / Final Push
- Taskهای مهم‌تر
- فشار زمانی بیشتر

## 27:00–30:00 — Base Pressure
- Enemy Base
- Final Tasks
- Victory یا End-of-Match Summary

مهم:
اگر کاربر سریع‌تر یا کندتر پیش برود، Flow باید تطبیق پیدا کند.
زمان قفل مرحله نیست.

---

# 14. Match End States

## Victory
Enemy Base destroyed before timer ends.

## Time End
Timer = 00:00

Result:
- Tasks Completed
- Minions Defeated
- Towers Destroyed
- Base Damage
- XP Earned
- Gold Earned
- Diamonds Earned
- Network Actions مرتبط (در آینده)
- Progress %

Time End = شکست تحقیرآمیز نیست.
پیام باید:
«Progress ثبت شد؛ Push بعدی را قوی‌تر ادامه بده.»

---

# 15. Gameplay State Machine

States:

PRE_MATCH  
SPAWN  
EXPLORE  
NEAR_OBJECTIVE  
ENCOUNTER  
TASK_ACTIVE  
TASK_COMPLETE  
ATTACK  
REWARD  
EXPLORE  
TOWER_PHASE  
BASE_PHASE  
VICTORY  
TIME_END  
RESULT

قانون:
UI و Controls باید بر اساس State فعال/غیرفعال شوند.

---

# 16. Encounter Priority

اگر چند Entity نزدیک باشند:

1. Entity داخل Trigger Radius
2. Entity نزدیک‌تر
3. Entity Unlocked
4. Entity زنده
5. Entity مرتبط با Lane فعلی

این باعث جلوگیری از Trigger اشتباه می‌شود.

---

# 17. Objective Selection

Task Pool از Tasks فعال می‌آید.

Filter:
- activeInGame = true
- not deferred in current Match
- not completed in current Match

Priority قابل توسعه:
- Category
- Difficulty
- Lane preference
- Time remaining

---

# 18. Reward Model

Minion:
- XP + Gold
- Diamond rare / optional

Tower:
- XP + Gold بیشتر
- Visual milestone

Base:
- XP + Gold
- امکان Diamond بیشتر
- Victory bonus

همه اعداد در Settings قابل ویرایش باشند.

---

# 19. HUD Vision

Top HUD:
- Timer
- XP
- Gold
- Diamond
- Current Objective

Mini-map:
- Own Base
- Enemy Base
- Hero
- Towers
- Alive Waves
- Lane state

Bottom:
- Left: Joystick
- Right:
  - Focus / Interact
  - Recall / utility در آینده
- Task panel فقط هنگام Encounter

---

# 20. Task Encounter UX

وقتی Task باز می‌شود:

Battlefield حذف نمی‌شود.

بلکه:
- Battlefield در پس‌زمینه Dark
- Blur بسیار کم
- Hero / Target هنوز قابل تشخیص
- Encounter Panel به صورت Cinematic Sheet
- Objective Name محور اصلی

این باعث حفظ حس «من هنوز داخل بازی هستم» می‌شود.

---

# 21. Non-Linearity

بعد از Tower 1:
بازیکن مجبور نیست فقط مستقیم بالا برود.

Allowed:
- Lane switch
- Backtrack
- Find another Wave
- Push another Tower
- Continue current Lane

این آزادی باید واقعی باشد، نه فقط ظاهری.

---

# 22. No Power-to-Win Heroes

Hero Choice:
فقط Visual / Personality

هیچ Hero:
- Damage بیشتر
- XP بیشتر
- Task skip
- Reward bonus

ندارد.

این بازی باید روی اقدام واقعی کاربر عادلانه بماند.

---

# 23. Audio / Haptic Direction

بعداً در Implementation:

- Joystick soft feedback
- Encounter lock haptic
- Complete haptic
- Tower hit stronger haptic
- Victory layered haptic

Sound:
- Ambient map
- UI click
- Objective lock
- Attack
- Tower break
- Reward
- Victory

---

# 24. Android Gameplay Rule

Gameplay:
- Portrait
- Fullscreen immersive
- Status Bar hidden
- Navigation Bar hidden
- Swipe = transient system bars

Outside Gameplay:
- System UI normal

---

# 25. STEP 02 LOCKED DECISIONS

Core Loop رسمی:

`Spawn → Explore → Encounter → Real Task → Attack → Reward → Free Movement → Tower → Lane Choice → Final Push → Enemy Base → Victory/Time End`

Default Rules:
- Match: 30 min
- Wave: 45 sec
- Tower HP: 100
- Tower hit: 34
- Base HP: 100
- Base hit: 25
- Tower objective hits: ~3
- Base objective hits: 4

همه این مقادیر بعداً از Settings قابل ویرایش‌اند.

---

# STEP 03

GAME WORLD & MAP ARCHITECTURE

در قدم ۳:
- نقشه Portrait دقیق
- سه Lane
- Spawn points
- Camera zones
- Objective positions
- Tower/Base placement
- Collision zones
- World scale
- Minimap logic
طراحی می‌شود.
