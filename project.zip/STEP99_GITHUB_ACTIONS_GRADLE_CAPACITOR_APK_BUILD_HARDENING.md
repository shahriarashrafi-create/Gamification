# STEP 99 — GITHUB ACTIONS + GRADLE + CAPACITOR APK BUILD HARDENING

این مرحله پروژه را برای Upload مستقیم داخل GitHub و ساخت APK واقعی Debug با GitHub Actions آماده می‌کند.

## هدف

فایل‌های Repository باید طوری باشند که بعد از Upload:

GitHub Actions
→ Node install
→ Web build
→ Capacitor sync
→ Gradle assembleDebug
→ APK artifact

## Repository Root

این فایل‌ها باید در ریشه Repository باشند:

package.json
package-lock.json
capacitor.config.ts
vite.config.js
index.html
app/
android/
.github/workflows/android-apk.yml
README.md

## Build Command

npm ci
npm run build
npx cap sync android
cd android
./gradlew assembleDebug

APK:

android/app/build/outputs/apk/debug/app-debug.apk

## Node

Node 22

## Java

Temurin 17

## Android SDK

compileSdk 35
targetSdk 35
minSdk 24

## GitHub Actions

Manual trigger:
workflow_dispatch

Push trigger:
main

Build artifact:
shahriar-game-debug-apk

## Gradle Wrapper

Repository باید Gradle wrapper واقعی داشته باشد:

gradlew
gradlew.bat
gradle/wrapper/gradle-wrapper.properties
gradle/wrapper/gradle-wrapper.jar

Step99 ساختار wrapper را harden می‌کند. در محیطی که Gradle wrapper jar واقعی قابل bootstrap باشد، script مخصوص برای تولید wrapper هم اضافه شده است.

## Capacitor Android

`npx cap sync android` باید قبل از Gradle اجرا شود تا web assets و native bridge هماهنگ شوند.

## Native Plugin

ImmersiveModePlugin داخل package:

com.shahriar.game

MainActivity آن را register می‌کند.

## APK Debug

برای نصب مستقیم روی گوشی:

app-debug.apk

Release signing هنوز در Repository قرار نمی‌گیرد.

## Release Security

هیچ‌کدام از این‌ها commit نمی‌شوند:

*.jks
*.keystore
local.properties
signing.properties
private keys

## Failure Diagnostics

Workflow در صورت failure این بخش‌ها را قابل تشخیص می‌کند:

npm install
web build
capacitor sync
Gradle compile
APK packaging

## QA

- workflow file exists
- Node 22
- Java 17
- npm ci
- npm run build
- cap sync android
- Gradle assembleDebug
- APK artifact upload
- package com.shahriar.game
- portrait retained
- no release key committed
- fresh launch Home retained
- Gameplay immersive retained
- Bottom Nav exactly five outside Gameplay
- Stats tree only
- no Energy
- no Mana

## STEP 100

FINAL RELEASE PACKAGE + COMPLETE GITHUB UPLOAD STRUCTURE + APK HANDOFF GUIDE

تمام پروژه را تمیز می‌کنیم، Placeholder/DEV-only موارد را Audit می‌کنیم، فایل نهایی Upload-ready می‌سازیم و دقیقاً می‌گوییم چه چیزهایی را در GitHub آپلود کنی و از کجا APK را بگیری.
