# STEP 54 — HOME MODULE CARDS LIVE ROUTING & STATE

چهار ماژول ثانویه Home به Route و State واقعی متصل می‌شوند:

فروشگاه
رویدادها
آینده‌بینی
دستاوردها

## Navigation Rule
این ماژول‌ها Bottom Nav نیستند.
فقط از Home / card entry باز می‌شوند.

Bottom Nav همیشه دقیقاً پنج مورد:
خانه
کارها
آمار
تایم‌شیت
شبکه‌سازی

## Module Card State
idle
pressed
loading
ready
empty
recoverable_error
blocked

## Shop
Route:
shop

Reads:
heroes
cosmetics
real-life rewards
wallet snapshot

Gold:
hero/cosmetic only

Diamond:
real-life rewards only

No power advantage.

## Events
Route:
events

Reads:
active events
participants
qualification progress

No direct automatic reward.

## Vision
Route:
vision

Reads:
goals
years
progress
status

No automatic reward.

## Achievements
Route:
achievements

Reads:
progress states
ready-to-claim
claimed history

Claim remains atomic.

## Card Badges
Shop:
optional unlocked/new asset count

Events:
active event count

Vision:
active goal count

Achievements:
ready-to-claim count

Badge count is derived display state only.

## Loading
Home remains stable.
Cards can show per-module skeleton/status.
No route jump until route payload is valid.

## Empty
Shop:
فروشگاه آماده است

Events:
رویداد فعالی نداری

Vision:
هنوز هدفی ثبت نکردی

Achievements:
دستاورد جدیدی برای دریافت نیست

## Error
Only affected card gets recoverable error.
Entire Home must not fail because one secondary module failed.

## Route Guard
double tap → one navigation
active Match → secondary module access may be disabled by gameplay route isolation
fresh launch → Home only

## Back
Secondary module Back → Home.

## Home Layout
Four cards stay visible around/below Hero according responsive Home composition.
They cannot hide Start CTA.

## Stats
Stats still Network Tree only.

## Energy
No Energy.

## STEP 55
SHOP LIVE DATA & PURCHASE FLOW
فروشگاه را از module shell به خرید واقعی Hero/Cosmetic و claim Reward با wallet transaction وصل می‌کنیم.
