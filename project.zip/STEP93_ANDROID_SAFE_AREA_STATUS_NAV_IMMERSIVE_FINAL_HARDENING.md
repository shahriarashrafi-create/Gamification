# STEP 93 — ANDROID SAFE AREA + STATUS/NAV BAR + IMMERSIVE FINAL HARDENING

این مرحله رفتار UI روی گوشی واقعی Android را نهایی می‌کند تا Home و صفحات عادی با Status Bar / Navigation Bar قاطی نشوند و فقط Gameplay وارد Fullscreen Immersive شود.

## Core Rule

Outside Gameplay:
system bars visible

Inside Gameplay:
immersive fullscreen

Leaving Gameplay:
system bars restored immediately

Fresh app launch:
Home with normal system bars

## Android Modes

### Main UI Mode
Used for:
Home
Tasks
Stats
Timesheet
Networking
Shop
Events
Vision
Achievements
Hero Hub
Settings
PreBattle
Results

Status bar:
visible

Navigation bar / gesture area:
visible

App content:
respects safe-area insets.

### Gameplay Mode
Used only for active Match battlefield.

Status + Navigation bars:
hidden

Gesture reveal:
transient swipe allowed

On focus regain:
reapply immersive if Match still active.

## Safe Area CSS

Use env():

safe-area-inset-top
safe-area-inset-right
safe-area-inset-bottom
safe-area-inset-left

Fallback:
0px

Top HUD outside Gameplay must never begin behind status bar.

Bottom nav outside Gameplay must never collide with gesture navigation.

Recommended tokens:

--safe-top
--safe-right
--safe-bottom
--safe-left

## Main Screen Layout

Root:

min-height: 100dvh
padding-top: env(safe-area-inset-top)
padding-bottom: env(safe-area-inset-bottom)

Avoid fixed 100vh where browser/system chrome can cause overlap.

Bottom navigation:

bottom: 0
padding-bottom: max(8px, env(safe-area-inset-bottom))

Content area reserves nav height + safe bottom.

## Home Hardening

Home top HUD:
safe top respected.

Hero stage:
flexible height.

CTA:
always above bottom nav.

Bottom nav:
exactly five items.

No Hero/CTA/nav overlap at:
360×800
360×880
390×844
412×915
430×932

## Gameplay Hardening

Gameplay root:
100dvh
overflow hidden
no app bottom nav

System bars hidden via native plugin.

Gameplay overlays use internal insets, not Android system-bar insets once immersive is active.

Still reserve small internal HUD margins:
top 12–20dp
sides 12–16dp
bottom controls 18–28dp

## Android 11+

Use WindowInsetsController.

Hide:
WindowInsets.Type.statusBars()
WindowInsets.Type.navigationBars()

Behavior:
BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

## Older Android

Use flags:

SYSTEM_UI_FLAG_FULLSCREEN
SYSTEM_UI_FLAG_HIDE_NAVIGATION
SYSTEM_UI_FLAG_IMMERSIVE_STICKY
SYSTEM_UI_FLAG_LAYOUT_STABLE
SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

## Native Plugin Contract

Package:
com.shahriar.game

Files:
native/android/MainActivity.java
native/android/ImmersiveModePlugin.java

JS:
setGameImmersiveMode(true)
setGameImmersiveMode(false)

## Lifecycle

start Gameplay:
set immersive true

Pause overlay:
remain immersive

Task Encounter:
remain immersive

Victory cinematic:
remain immersive

Results transition:
set immersive false BEFORE Results becomes interactive

Manual Exit:
set immersive false

Time End:
set immersive false for Results

Return Home:
system bars visible

App background:
do not force changes while backgrounded

App foreground:
if active Match screen → reapply immersive
else → restore normal bars

## Android Back

Gameplay:
Back opens Pause / Exit confirmation.
Do not instantly leave app.

Task Encounter:
Back acts as Cancel only if pipeline state allows.

Results:
Back → Home with normal system bars.

Home:
normal Android back behavior.

## Focus Reapply

Some Android devices restore system bars after:

keyboard
notification shade
permission dialog
app switch
gesture reveal

When Gameplay regains focus:
reapply immersive if:
route == gameplay
match status == running
result not finalized

Never reapply immersive on Home/Results.

## Keyboard

Task editing screens:
system bars remain visible.

Task Encounter normally has no text editing keyboard.

If future gameplay input opens IME:
do not fight keyboard continuously.
Reapply immersive only after keyboard/IME closes and focus returns.

## Status Bar Styling

Outside Gameplay:

dark theme:
status bar dark background
light icons

Navigation bar:
dark background where supported.

No bright white flash between route transitions.

## Splash / Launch

Launch theme should visually match dark app theme.

Avoid white system bar flash.

After bootstrap:
Home
system bars visible.

## Gesture Navigation

Bottom controls inside Gameplay must not sit exactly at physical bottom edge.

Use internal bottom padding.

Joystick:
safe from gesture edge.

Action buttons:
safe from gesture edge.

Outside Gameplay:
bottom nav accounts for safe bottom inset.

## Orientation

Portrait only.

Do not rotate into landscape.

Gameplay remains portrait.

## QA

fresh launch Home with visible bars
Home top HUD not under status bar
Home bottom nav not under gesture area
Home CTA visible above nav
all five nav items visible
PreBattle uses normal bars
Gameplay hides system bars
Gameplay has no app bottom nav
swipe can temporarily reveal bars
focus returns and immersive reapplies during running Match
Task Encounter stays immersive
Pause stays immersive
Victory cinematic stays immersive
Results restores bars
Time End Results restores bars
Manual Exit restores bars
Home restore is idempotent
Back in Gameplay opens pause/exit flow
Back on Results returns Home
keyboard does not trigger immersive fight loop
360×800 layout passes
430×932 layout passes
portrait locked
no Energy
no Mana

## STEP 94

REAL ANDROID APP SHELL + CAPACITOR PROJECT STRUCTURE HARDENING

ساختار واقعی project، package، Capacitor config، Android manifests، permissions، build scripts و مسیر آماده GitHub/APK را production-ready می‌کنیم.
