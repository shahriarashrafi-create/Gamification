# STEP 92 — PERFORMANCE + 60FPS + MEMORY + MOBILE THERMAL OPTIMIZATION

این مرحله Gameplay را برای Android واقعی بهینه می‌کند تا Hero movement، Minions، Fog، Minimap، VFX و Asset Loading با مصرف کنترل‌شده CPU/GPU/RAM اجرا شوند.

## Performance Targets

Primary target:
60 FPS on capable devices

Graceful fallback:
30 FPS logic/render adaptation on weaker devices

Frame budget at 60 FPS:
16.67ms

Suggested budget:
Simulation 3.0ms
Hero/Minion movement 2.0ms
Fog/Minimap 2.5ms
Rendering/VFX 6.0ms
UI/HUD 1.5ms
Reserve 1.67ms

## Render Loop

Use requestAnimationFrame for visual frame pacing.

Do not attach game authority to frame count.

Game state:
delta-time based.

Clamp dt:
50ms max to avoid giant jumps after stall.

## Fixed Logic

Crowd/Minion logic can run at:
30Hz

Hero input/render:
60Hz where available.

Fog updates:
movement-threshold + throttled.

Minimap:
Hero marker ~90ms throttle
dynamic entity markers event/throttle driven.

## Visibility Culling

Do not render:
Fog-hidden Minions
far off-camera decorative effects
expired VFX
destroyed entity transient layers after settle

Authoritative simulation may continue where required.

## VFX Pooling

Projectile
impact
reward fly-up
hit flash
debris
smoke

Use reusable pools.

Avoid DOM/component creation every hit.

Pool release after effect end.

## Minion Pool

Max live Minions:
6

Visual shell pool:
6–8

Reuse visual nodes/sprites across waves.

Do not retain defeated Minion visual references indefinitely.

## Fog Optimization

Step81 logical grid:
30 × 65 = 1950 cells

Do not rebuild all DOM/canvas nodes every frame.

Only recompute Fog when Hero moved threshold.

Default:
10 world units

Throttle moving Fog update:
150ms

Use dirty-cell updates.

Persist reveal deltas, not full write every frame.

## Minimap Optimization

Static entities:
event driven

Hero marker:
throttled

Minions:
only currently visible and persisted

No full minimap rerender if no relevant change.

## Camera

Camera interpolation:
delta-time based

Do not use expensive layout reads inside render loop.

Keep world transform in one composited layer where possible.

## DOM / Layout

Avoid:
getBoundingClientRect every frame
large box-shadow animation
backdrop-filter on full gameplay continuously
layout-triggering top/left mutations for every entity

Prefer:
transform: translate3d(...)
opacity
will-change only on active moving elements

Do not overuse will-change globally.

## CSS Effects

High-cost effects should degrade on weaker devices:

large blur
multiple glowing shadows
full-screen backdrop-filter
heavy particle counts

Quality tiers:
high
balanced
battery

Default:
balanced

## Quality Tiers

### High
60 FPS target
full VFX
full fog softness
normal shadows

### Balanced
60 FPS target
reduced particles
lighter shadow count
reduced blur
recommended default

### Battery
30 FPS render cap
minimal particles
reduced glow
no continuous ambient particles
simplified Fog edge

Gameplay rules remain identical across tiers.

## Thermal Adaptation

Track rolling frame time.

If sustained poor performance/thermal pressure heuristic:

High → Balanced
Balanced → Battery

Never alter:
Task reward
Tower/Base damage
Timer authority
Wave interval
Rank/XP
objective rules

Only visual quality changes.

## Frame-Time Monitor

Sample recent frame durations.

Suggested:
window 120 frames

If average > 22ms for sustained period:
reduce quality one tier.

If average < 15ms for long stable period:
optional upgrade one tier, but avoid oscillation.

Cooldown:
30 seconds between quality tier changes.

## Memory

Hero assets:
only selected/current Hero critical set pinned.

Other Hero Hub images:
lazy load.

Battlefield:
preload core background/entities before Match.

Cosmetics:
load only equipped items.

Release:
Results-only VFX after leaving Results
previous screen decorative backgrounds when safe
expired projectiles/debris

## Asset Formats

Runtime:
WebP for raster
SVG for simple icons
compressed audio

Avoid oversized source assets in runtime package.

Use size variants:
512 / 1024 where appropriate.

## Audio

Reuse decoded buffers where supported.

Do not create repeated audio objects for rapid hit cues.

Respect muted buses.

## Background / Resume

On background:
stop RAF rendering
persist safe state
Step72 timer policy continues

On resume:
reconcile elapsed state
restart render loop once
no duplicate listeners
no duplicate scheduler

## Listener Hygiene

Every gameplay mount:
register once

Every gameplay unmount:
remove listeners

Important:
visibilitychange
resize
pointer events
Android focus callbacks

No listener multiplication after several Matches.

## Object Allocation

Avoid per-frame large arrays/objects where possible.

Reuse:
vectors
temporary arrays
VFX objects
Minion render models

At max 6 Minions this is easy to control.

## Device Safe Defaults

Target widths:
360–430 CSS px

Avoid rendering huge offscreen art surfaces.

Use devicePixelRatio cap where Canvas is used:
recommended max 2 for Gameplay.

Do not sacrifice UI text clarity.

## Battery

No constant vibration.

No unnecessary GPS/networking.

Core game remains local-first.

No background render loop.

## QA

60 FPS target on capable device
30 FPS graceful fallback
game rules unchanged by quality tier
frame dt clamped
Hero movement delta-time based
Minion crowd logic can run 30Hz
Fog only recomputes after threshold/throttle
Minimap does not full-rerender unnecessarily
hidden Minions are not rendered
VFX nodes/sprites reused
Minion visuals reused
background stops RAF
resume starts one RAF only
no duplicate event listeners after repeated Matches
no reward/damage/timer changes between quality tiers
DPR cap supported where Canvas is used
lazy loading defined
memory released after screen transitions
no Energy
no Mana

## STEP 93

ANDROID DEVICE SAFE-AREA + STATUS/NAV BAR + IMMERSIVE FINAL HARDENING

Samsung/Android notch، gesture navigation، status bar، system bar restore و Fullscreen Gameplay را روی ابعاد واقعی گوشی نهایی می‌کنیم.
