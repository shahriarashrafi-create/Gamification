# STEP 87 — LIVE WAVE SPAWN + REAL TASK MINION BATTLEFIELD INTEGRATION

این مرحله Wave Scheduler را به Task Reservation، Minion Spawn، Lane Path، Fog، Minimap و Encounter واقعی متصل می‌کند.

## Core Loop

Wave due
→ inspect spawn capacity
→ reserve eligible real Tasks
→ choose lanes
→ create Minion entities
→ persist Minions + reservations
→ spawn visually
→ follow lane paths
→ Fog visibility
→ Minimap visibility
→ Hero proximity
→ Task Encounter
→ Step66 transaction pipeline
→ defeat/defer/cancel outcome
→ despawn / wait
→ capacity freed

## No Fake Minions

هر Minion actionable باید دقیقاً یک Task Reservation معتبر داشته باشد.

اگر Task واجد شرایط وجود ندارد:
Minion ساخته نمی‌شود.

هیچ placeholder task یا fake objective ایجاد نمی‌شود.

## Wave Timing

Source:
Step72 WaveScheduler

Default interval:
45 seconds

New Match:
no forced instant wave.
First due wave at elapsed 45 seconds.

Recovery:
calculate due wave index from elapsed time.
Missed indexes collapse into safe spawn opportunity.
Never burst-spawn all missed waves.

## Spawn Caps

Global active Minions:
6

Per Lane:
2

Before reservation:
check capacity.

Do not reserve Tasks for spawn slots that cannot be created.

## Lane Assignment

Eligible lanes:
A
B
C

Prefer:
lane with available capacity
lane near current strategic recommendation
balanced distribution

Do not force Hero Lane.

## Task Reservation

Reservation occurs before entity creation.

Required:
reservationId
taskId
matchId
laneId
waveIndex
state reserved

No duplicate active reservation for same Task unless reusable recycling policy explicitly allows later.

## Minion Entity

Fields:
id
matchId
waveIndex
laneId
reservationId
taskId
position
pathId
pathProgress
movementState
visualState
fogState
spawnedAt
defeated
despawned

## Spawn Transaction

Wave spawn should be idempotent.

Suggested:
waveSpawnTxId = matchId + waveIndex

If transaction already committed:
do not create duplicate Minions.

Persist:
reservations
Minion entities
wave lastWaveIndex

atomically where practical.

## Path Following

After spawn:
Step64 lane path following.

No teleport.

Pause:
freezes Minion movement.

Task focus:
focused Minion stops.

## Fog

Minion visible in World/Minimap only when currently inside Hero vision.

Known stale Minion position is not shown.

## Minimap

Marker derives from persisted live Minion position.

No synthetic markers.
No tap-to-move.

## Encounter

When Hero enters interaction radius:
Step62 target acquisition.

Minion must have:
valid reservation
not defeated
not despawned
actionable Task

Then Step47/66 Task Encounter pipeline.

## Complete

Task commit
→ combat handoff Step86
→ Minion defeat commit
→ reward commit
→ reservation complete
→ despawn
→ capacity free

## Defer

No reward/damage.
Reservation:
deferred_current_match

Minion despawns.
Capacity free.

## Cancel

No reward/damage.
Reservation remains reserved.
Minion returns to waiting/path state according to pipeline.

## Recovery

Restore:
wave index
live persisted Minions
reservation states
path positions/progress
movement states
transaction stages

Do not respawn already committed wave.

If elapsed indicates missed waves:
collapse to one safe opportunity and respect caps.

## QA

first default wave due at 45 seconds
no instant fake wave
wave uses Step72 scheduler
capacity checked before reservation
global cap 6
lane cap 2
every actionable Minion has real Task reservation
no fake Task
same wave cannot spawn twice
same active reservation cannot duplicate
Minions use lane paths
Minions do not teleport
Pause freezes Minion movement
Fog hides non-visible Minions
Minimap shows only persisted visible Minions
Hero proximity opens real Task Encounter
Complete uses Step66 + Step86
Defer grants no reward
Cancel grants no reward
recovery restores Minion path state
missed waves do not burst
no Energy
no Mana

## STEP 88

LIVE MINION CROWD + PATH SEPARATION + COLLISION POLISH

چند Minion همزمان را روی سه Lane با spacing، separation، overlap prevention، spawn staggering و حرکت نرم production-ready می‌کنیم.
