# STEP 85 — TASK ENCOUNTER FINAL MOBILE UX POLISH

این مرحله Task Encounter را برای استفاده واقعی روی گوشی Android نهایی می‌کند.

## Goal

Task مهم‌ترین بخش تعامل بازی است.
متن فارسی Task باید مرکز توجه باشد و Battlefield همچنان در پس‌زمینه قابل تشخیص بماند.

## Sheet Layout

Battlefield remains visible.
Backdrop:
darkened
slight blur
target still recognizable

Task Sheet:
bottom anchored
RTL
safe-area aware
max width 430
adaptive height
never hides task action buttons

## Task Text

Task title:
Persian RTL
primary visual focus
large readable type

Rules:
word-break normal
overflow-wrap break-word only as safety
white-space normal
line-height 1.75
do not split Persian words arbitrarily
no single-line ellipsis for main Task

Long Task:
sheet grows until max height
then content area scrolls
actions remain sticky

## Reward Preview

Show:
XP
Gold
Diamond only if reward snapshot Diamond > 0

Preview is informational.
It cannot commit rewards.

No Energy.
No Mana.

## Buttons

Primary:
انجام شد

Secondary:
بعداً

Tertiary:
لغو

Minimum touch height:
48dp

Primary button receives strongest visual emphasis.

## Complete Flow

Tap انجام شد
→ disable all actions
→ show short committing state
→ authoritative Task commit
→ close sheet
→ Hero face target
→ attack
→ impact
→ damage/defeat commit
→ reward commit
→ resume

No reward on button press alone.

## Defer

بعداً:
current Match only

No Task completion
No attack
No damage
No reward

Reservation becomes deferred_current_match where applicable.

## Cancel

لغو:
closes encounter

No completion
No reward
No damage

Target remains valid according to existing pipeline rules.

## Double Tap Guard

First action locks controls immediately.

Duplicate Complete/Defer/Cancel:
ignored while action in flight.

## Timer

Default:
timerRunsDuringTask = true

Timer HUD remains visible enough to understand time continues.

If setting false:
existing MatchClock pause behavior applies.

## Keyboard

Task Encounter itself should not open keyboard.

If future editable note field exists:
use visualViewport/resize handling
keep action bar above IME
never let keyboard cover primary action.

## Android Safe Area

Sheet padding bottom:
max(16px, env(safe-area-inset-bottom))

Top content never overlaps status cutout when non-immersive preview.
Gameplay remains immersive.

## Orientation

Portrait only.

Target devices:
360×800
360×880
390×844
412×915
430×932

## Accessibility

48dp targets
high contrast
screen-reader labels
focus order:
Task title → Reward preview → انجام شد → بعداً → لغو

Reduce Motion:
remove blur transition/large scale motion
keep state feedback.

## Failure State

If Task commit fails:
sheet stays/reopens safely
actions unlock after recoverable state
no attack
no reward
no damage

Copy:
ثبت کار کامل نشد. دوباره تلاش کن.

## Recovery

If app backgrounds while sheet open:
persist encounter stage/reference
on return:
restore safely or reconcile committed transaction.

Never show completed Task as uncommitted.

## QA

Persian task wraps by complete words
long text scrolls without hiding buttons
RTL correct
primary task text visually dominant
buttons >=48dp
double tap ignored
Complete button alone does not grant reward
Task commit precedes attack
attack precedes damage/reward according to pipeline
Defer gives no reward
Cancel gives no reward
commit failure gives no attack
timer continues by default
safe area respected
keyboard cannot cover actions
Reduce Motion supported
360x800 usable
430x932 usable
no Energy
no Mana

## STEP 86

TASK ENCOUNTER MICRO-ANIMATION + COMBAT HANDOFF POLISH

Sheet خروج، Hero face-target، attack windup، projectile، impact و reward fly-up را به یک handoff سینمایی یکپارچه و production-ready تبدیل می‌کنیم.
