# SHAHRIAR GAME — STEP 23
## COMBAT FEEDBACK / TOWER & BASE DESTRUCTION BLUEPRINT

مرجع رسمی بازخورد Combat و تخریب Objectiveها.

## 1. هدف
کار واقعی باید به یک نتیجه‌ی بصری واضح، رضایت‌بخش و قابل‌فهم در Battlefield تبدیل شود؛ بدون شلوغی Arcade و بدون قطع ارتباط با Productivity.

## 2. Feedback Chain
Task Commit → Hero Attack → Projectile/Lunge → Impact → HP Change → Damage Stage → Reward → Objective State.

## 3. World-space HP
Minion: compact bar only when engaged.
Tower: bar above tower when within relevance radius.
Enemy Base: larger objective bar when active/focused.
Own Base: no distracting permanent bar unless gameplay later needs damage mechanics.

## 4. HP Semantics
Green/Gold/Cyan alone is not enough.
Bar + numeric/segment cue where useful.
Damage animation never changes logical HP.

## 5. Tower Defaults
HP 100.
Damage per completed task 34.
Approx:
100 → 66 → 32 → 0.

## 6. Tower Damage Stages
healthy: 67–100
damaged: 34–66
critical: 1–33
destroyed: 0

## 7. Tower Visual Stages
Healthy: stable rune core.
Damaged: cracks + intermittent sparks.
Critical: stronger cracks + smoke/arcane leakage.
Destroyed: collapse/energy discharge + disabled interaction.

## 8. Tower Warning
Separate from destruction state.
Danger ring is a VFX layer, not baked art.

## 9. Tower Hit
Projectile impact point fixed to tower core.
Short core flash.
HP tween.
Crack stage updates after logical damage commit.

## 10. Tower Destroy
On lethal hit:
lock target
impact flare
core overload
short shake if allowed
collapse/energy burst
debris/particles
objective marker removed
reward/bonus
lane path opens

## 11. Tower Destroy Timing
Impact 0ms
HP reaches zero ~220ms
overload 220–520ms
collapse 520–900ms
reward/objective update ~700–1050ms
resume ~1000–1200ms

## 12. Base Defaults
HP 100.
Damage per completed task 25.
100 → 75 → 50 → 25 → 0.

## 13. Enemy Base Stages
stable 76–100
unstable 51–75
critical 26–50
collapse-ready 1–25
destroyed 0

## 14. Base Visual Escalation
More visible than Tower but still readable.
Energy core becomes increasingly unstable.
Environment light may react subtly.

## 15. Base Lethal Sequence
Final task commit
Hero attack
impact
HP 0
input lock
base core implosion
expanding shockwave
camera pull/hold
VICTORY title
results transition

## 16. Victory Timing
final hit 0
HP zero 200ms
core implosion 300–700ms
shockwave 650–1100ms
camera hold 900–1500ms
VICTORY 1200–2200ms
results transition ~2200ms+

Editable during polish.

## 17. Reduced Motion
No strong camera shake.
Shockwave becomes light/radial fade.
Collapse simplified.
Timing remains understandable.

## 18. Projectile Families
arcane bolt
gold pulse
energy slash
short melee lunge

Visual-only per Hero archetype/cosmetic.
No damage advantage.

## 19. Projectile Speed
Presentation can vary slightly but logical completion/damage remains deterministic.
No Hero gains faster real progression.

## 20. Impact Families
minion_hit
tower_core_hit
base_core_hit
objective_destroy
victory_shockwave

## 21. Damage Number
Optional:
-34
-25
or compact percentage.
Must not imply combat stat system.

## 22. Reward Fly-up
Appears after damage commit.
Tower destruction bonus separately labeled.
Base victory bonus separately labeled.

## 23. Objective Marker
Destroyed objectives removed/faded from minimap and world objective routing.

## 24. Minimap
Tower icon changes state immediately after committed destruction.
Enemy Base destroyed → Victory sequence; no stale icon.

## 25. Camera
Normal hit: minimal focus.
Tower destroy: small cinematic focus.
Base destroy: strongest camera choreography.
No teleport.

## 26. Screen Shake
Normal hit: none/tiny.
Tower destroy: light.
Base destroy: medium.
All disabled by Reduce Motion.

## 27. Haptics
hit: light
tower destroy: medium/strong
base destroy: victory pattern
optional and settings-aware.

## 28. Audio
impact material-specific.
Tower overload.
Base core.
Victory sting.
No audio-only critical state.

## 29. Fog
Destroyed Tower area can become visually clearer.
Do not instantly reveal unrelated map regions unless game rules later specify it.

## 30. Collision
Destroyed Tower collision transitions to passable only after destruction state commits.
Visual collapse cannot desync logical collision.

## 31. Atomicity
Task reward and entity damage are part of one guarded transaction.
Destruction bonus transaction references entity destruction event.
Double destruction bonus forbidden.

## 32. Idempotency
entityDestroyedAt / destructionTransactionId prevent repeated bonuses after reload/retry.

## 33. Match End
Enemy Base destruction is authoritative Victory.
Timer reaching zero is Time End, not Victory.

## 34. Persistence
Persist entity HP/state as needed for active match recovery.
New match resets map entities according to match initialization.

## 35. Performance
Particle counts capped.
Prefer sprite sheets/simple GPU-friendly transforms.
No huge full-screen video explosion.

## 36. Mobile
Effects must remain readable at 360px width.
Do not cover task sheet/controls with destruction particles.

## 37. Accessibility
Flash intensity limited.
No rapid strobing.
Reduce Motion supported.
Text state labels remain available.

## 38. Prototype
Step23 concept simulates Tower and Base hits, stage transitions, destruction and Victory.

## 39. Failure Conditions
visual HP != logical HP
double bonus
destroyed tower still blocks path
reward before committed damage
Victory before Base HP=0
effects obscure controls
Hero power affects damage
teleport

## 40. Quality Gate
Combat feedback must feel premium while remaining a deterministic visualization of real-world task completion.

## STEP 24
MATCH RESULTS / VICTORY & TIME-END EXPERIENCE
Results hierarchy, earned rewards, task summary, destroyed objectives, XP/Level/Rank progression and return-to-Home flow.
