# STEP 86 — TASK ENCOUNTER → COMBAT HANDOFF CINEMATIC POLISH

این مرحله فاصله بین «ثبت موفق کار واقعی» و «ضربه داخل بازی» را به یک Sequence سینمایی یکپارچه تبدیل می‌کند.

## Golden Rule

Visuals never create state.

Task Commit
→ Combat Visual
→ Entity Commit
→ Reward Commit

انیمیشن، Projectile و Impact هیچ‌کدام authority برای Damage یا Reward نیستند.

## Sequence

TASK_COMMITTED
→ SHEET_EXIT
→ CAMERA_REFOCUS
→ HERO_FACE_TARGET
→ ATTACK_WINDUP
→ PROJECTILE_TRAVEL
→ IMPACT_FLASH
→ ENTITY_COMMIT
→ HP_FEEDBACK / DEFEAT
→ REWARD_COMMIT
→ REWARD_FLYUP
→ OBJECTIVE_REFRESH
→ MOVEMENT_RESUME

## Timing

Sheet exit: 140ms
Camera refocus: 160ms
Hero face: 80ms
Attack windup: 180ms
Projectile: 180–320ms based on screen distance
Impact: 120ms
HP tween: 220ms
Reward fly-up: 360ms
Resume: 150ms

## Camera

During Task sheet:
camera soft-frozen.

After successful commit:
sheet exits
camera gently refocuses target
no hard snap
no teleport
no large cinematic pan that loses Hero

## Hero Face Target

Facing derives from target world position.

No Hero position mutation.

Only orientation/animation state changes.

## Attack

Hero animation state:
attack

Attack visual begins only after Task commit success.

Duplicate attack transaction:
ignored.

## Projectile

Projectile start:
Hero attack anchor

Projectile end:
Target impact anchor

Travel duration:
clamp by screen distance

Projectile visual cannot:
damage target
commit reward
complete Task

## Impact

Impact VFX fires once per attack transaction.

Then authoritative entity pipeline commits:

Minion:
defeat commit

Tower:
damage commit

Base:
damage commit

Only after commit:
HP bar updates / destruction flow continues.

## Reward

Reward fly-up begins only after committed reward transaction.

XP / Gold
Diamond only if committed positive value.

No fake reward preview conversion.

## Movement Lock

From successful Task commit through combat handoff:
Hero movement input locked.

Joystick remains visually present but disabled/dimmed.

After safe pipeline completion:
movement resumes.

## Objective Refresh

After entity commit:
recompute objective state
recompute smart recommendation
refresh minimap marker
refresh HUD

Do not refresh before committed state.

## Failure

If entity commit fails after visual impact:
do not fake HP loss.

Show recoverable short state:
ثبت ضربه کامل نشد

Persist pipeline stage for recovery.

No duplicate Task reward.

## Recovery

Persist transaction stage at important boundaries.

On recovery:
never replay already committed damage/reward.

Visuals may resume or skip safely.

## Reduce Motion

Sheet closes instantly/short fade.
No camera refocus animation.
Projectile may become short beam/flash.
Impact remains readable.
Reward can appear without long fly-up.

## Haptics

Attack windup:
none

Impact:
light/normal single pulse

Tower destruction:
stronger existing cue

Victory:
existing victory cue

No continuous vibration.

## QA

attack starts only after Task commit
sheet closes before attack
camera does not teleport
Hero position unchanged during face-target
projectile is visual-only
impact is visual-only
damage comes from entity transaction
reward comes from reward transaction
Diamond only positive committed
movement locked during handoff
movement resumes after safe completion
objective refresh occurs after commit
duplicate impact ignored
duplicate reward ignored
commit failure does not fake HP loss
recovery does not duplicate damage
recovery does not duplicate reward
Reduce Motion supported
no Energy
no Mana

## STEP 87

LIVE WAVE SPAWN + REAL TASK MINION BATTLEFIELD INTEGRATION

Wave Scheduler را به Task Reservation، Minion Spawn، Path Following، Fog/Minimap و Encounter واقعی وصل می‌کنیم تا اولین موج واقعی بازی روی میدان حرکت کند.
