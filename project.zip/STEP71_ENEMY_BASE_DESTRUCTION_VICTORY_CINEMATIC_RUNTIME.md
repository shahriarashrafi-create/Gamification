# STEP 71 — ENEMY BASE DESTRUCTION + VICTORY CINEMATIC RUNTIME

این مرحله Victory Commit قدم 70 را به سینمای نهایی میدان و انتقال امن به Results وصل می‌کند.

## Authoritative Trigger

Cinematic فقط زمانی آغاز می‌شود که:
Enemy Base HP == 0
Base destruction committed
Victory committed
Match resultType == victory

Visual هرگز Victory ایجاد نمی‌کند.

## Final Sequence

BASE_DESTRUCTION_COMMITTED
→ CONTROL_LOCK
→ WAVE_SCHEDULER_STOP
→ BASE_CORE_OVERLOAD
→ SHIELD_IMPLOSION
→ STRUCTURE_FRACTURE
→ FINAL_COLLAPSE
→ SHOCKWAVE
→ DEBRIS_AND_SMOKE
→ HERO_VICTORY_STATE
→ VICTORY_BANNER
→ RESULT_SNAPSHOT_VERIFY
→ LEAVE_IMMERSIVE_PREP
→ ROUTE_RESULTS
→ DONE

## Timing

core overload: 220ms
shield implosion: 280ms
fracture: 180ms
collapse: 520ms
shockwave: 260ms
debris/smoke: 600ms
Hero victory pose: >=600ms
Victory banner: 900ms
route transition: 360ms

Target total:
~2.8–4.0 seconds

## Controls

Immediately after committed Base destruction:
Hero movement disabled
Joystick disabled
Context action disabled
new Task Encounter blocked
Wave scheduler stopped

Pause cannot undo Victory.

## Shield Implosion

Shield contracts inward toward Base core.
No gameplay collision change is sourced from VFX.
No damage is caused by visual implosion.

## Final Collapse

Base visual transitions:
destroyed → collapsing → ruins

Committed Base state remains destroyed throughout.

## Shockwave

Large radial gold/cyan pulse.
Screen flash capped.
Camera shake short and bounded.

Reduce Motion:
no camera shake
no large radial travel
use opacity/ring fade.

## Hero Victory

Hero animation state:
victory

Priority remains highest.

Hero cannot move during ceremony.

Hero visual does not grant reward.

## Victory Banner

Persian:
پیروزی

Subtitle:
بیس دشمن نابود شد

Banner appears only after Victory commit.

## Reward Presentation

Victory bonus already committed in Step70.

Ceremony only displays:
+400 XP
+150 Gold
+1 Diamond

It never writes wallet ledger.

## Result Verification

Before route Results:
Victory commit exists
result snapshot exists or is rebuilt idempotently
active Match is finalized
committed ledger aggregation succeeds

If result snapshot missing:
rebuild from committed ledger.

## Route

Gameplay remains immersive during cinematic.

Before Results:
prepare immersive exit
route Results
restore normal system UI according Results contract

No Home jump.

## Crash Recovery

Crash before Victory commit:
Step70 recovery owns transaction.

Crash after Victory commit before cinematic:
resume shortened cinematic or final banner.

Crash during collapse:
do not replay reward.

Crash after banner before Results:
route Results from committed snapshot.

Crash after Results route:
Results idempotency handles display only.

## Presentation Guard

victoryPresentationId unique per Match.

Shockwave once.
Victory banner once.
Reward fly-up once.
Route Results once.

## Audio/Haptics

Base overload: rising low tone
Implosion: compression cue
Collapse: strong impact
Victory: major cue
Haptic: strong at collapse, medium at banner

Feedback does not affect state.

## Reduce Motion

Core glow
short dissolve
small shockwave fade
static Hero victory pose
Victory banner fade

Gameplay state/timing authority unchanged.

## QA

cinematic requires committed Victory
visual cannot create Victory
controls lock before cinematic
scheduler stopped
reward presentation does not mutate wallet
Victory bonus not duplicated
Hero victory state highest priority
shockwave once
banner once
Results route once
missing result snapshot rebuilds safely
crash after Victory resumes without duplicate reward
Time End never uses Victory cinematic
Manual Exit never uses Victory cinematic
Reduce Motion supported
no teleport
no Energy

## STEP 72

MATCH TIMER + WAVE SCHEDULER FULL RUNTIME INTEGRATION

۳۰ دقیقه Timer، Wave هر ۴۵ ثانیه، Pause/Background و Time End را در runtime واحد می‌بندیم.
