# STEP 80 — MINIMAP + FOG + OBJECTIVE MARKER PRODUCTION RUNTIME

این مرحله Minimap را مستقیماً به مختصات واقعی World 1200×2600 وصل می‌کند.

## Projection
World → Minimap normalized projection:
nx = clamp(worldX / worldWidth, 0, 1)
ny = clamp(worldY / worldHeight, 0, 1)

RTL هیچ تغییری در مختصات World ایجاد نمی‌کند.

## Markers
Hero
Own Base
Enemy Base
Tower A1/A2/B1/B2/C1/C2
persisted valid Minions
recommended Objective

## Fog States
unseen
known
visible

unseen: marker hidden
known: marker dim
visible: marker normal

Own Hero always visible.

## Tower/Base State
Marker visuals derive from committed objective/entity state.
Destroyed Tower → destroyed/completed marker.
Locked Tower → dim locked marker.
Enemy Base locked → shield marker.
No HUD/minimap mutation may unlock objectives.

## Objective Marker
Objective recommendation comes from Step79 guidance.
World marker + minimap marker share the same objective id.

It is advisory only:
no teleport
no tap-to-move
no forced path
no task creation

## Minion Markers
Only persisted/valid Minions with valid reservation/entity state appear.
No synthetic Minion marker.

## Camera Viewport
Optional minimap viewport rectangle derives from camera world bounds.
Display only.

## Update Rate
Hero marker: throttled 60–120ms.
Entities: event-driven.
Fog: event-driven/throttled.
Do not rebuild full minimap every render frame.

## Recovery
On resume:
rebuild markers from committed world/objective state.
Fog uses persisted exploration state.
No reset to fully visible.

## QA
world projection clamps correctly
Hero marker matches real position
Tower/Base markers use committed state
locked objectives remain locked
destroyed Towers show completed state
unseen entities hidden
known entities dim
visible entities normal
Minions require valid persisted state
objective marker matches guidance id
minimap cannot move Hero
minimap cannot teleport Hero
minimap cannot mutate objectives
recovery restores fog
no Energy
no Mana

## STEP 81
FOG REVEAL + HERO VISION RADIUS + EXPLORATION PERSISTENCE
