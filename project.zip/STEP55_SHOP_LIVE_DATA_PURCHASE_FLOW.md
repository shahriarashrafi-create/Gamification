# STEP 55 — SHOP LIVE DATA & PURCHASE FLOW

در این مرحله فروشگاه از یک Module Shell به سیستم خرید و Claim واقعی متصل می‌شود.

## Currency Rules

Gold:
فقط برای Hero و Cosmetic.

Diamond:
فقط برای Real-Life Reward.

هیچ Hero یا Cosmetic با Diamond خریداری نمی‌شود.

هیچ Reward واقعی با Gold Claim نمی‌شود.

## Product Types

hero
cosmetic
real_reward

## Hero Purchase

Flow:
open Hero
→ validate item
→ validate not owned
→ validate Gold balance
→ create purchase transaction
→ debit Gold atomically
→ unlock Hero
→ persist ownership
→ purchase history
→ success state

## Cosmetic Purchase

Flow:
same as Hero.
Compatibility with selected Hero must be checked before equip.

Purchase and Equip are separate actions.

## Real-Life Reward Claim

Flow:
open Reward
→ validate available
→ validate Diamond balance
→ create claim transaction
→ debit Diamond atomically
→ create reward claim record
→ mark claim as pending/claimed
→ history

## Idempotency

purchaseTxId unique
claimTxId unique

Double tap cannot:
double debit
double unlock
double claim

## Failure

If wallet debit fails:
item remains locked.

If ownership write fails after debit:
transaction enters recoverable pending state and reconciliation must finish it.
Never debit twice.

If UI crashes after commit:
opening Shop reads ledger + ownership and reconstructs final state.

## Wallet Authority

Wallet values are ledger-derived committed Player State.
Shop UI never directly subtracts visual numbers.

## Selection

Owned Hero:
انتخاب

Selected Hero:
انتخاب‌شده

Locked Hero:
خرید

Cosmetic:
خرید
then equip if compatible.

## Real Reward

States:
available
pending_claim
claimed
paused

## Suggested Defaults

Hero prices:
1900–2800 Gold

Cosmetics:
250–1800 Gold

Real Rewards:
5–40 Diamond

## History

Purchase History:
type
item
price
currency
transactionId
date
status

## No Power

Hero and Cosmetic give visual identity only.
No stat boost.
No attack bonus.
No movement bonus.
No reward multiplier.

## Offline

Local-first.
Purchase/Claim works against local wallet ledger.
No cloud dependency required.

## QA

Gold cannot buy real rewards
Diamond cannot buy Hero
insufficient balance blocks transaction
double tap is idempotent
purchase and equip separate
wallet values come from ledger
crash recovery cannot double debit
Hero gives no gameplay power
no Energy

## STEP 56

HERO HUB LIVE OWNERSHIP & EQUIP FLOW

Hero Hub را به ownership واقعی Shop، selection، cosmetic loadout و Home Hero refresh وصل می‌کنیم.
