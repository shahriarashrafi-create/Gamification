# SHAHRIAR GAME — 100 STEP REBUILD
## STEP 01 — MASTER VISION & EXPERIENCE FOUNDATION

### وضعیت
این پروژه از صفر شروع شده است.
هیچ کدام از فایل‌ها و UIهای نسخه‌های قبلی به‌عنوان مبنای طراحی استفاده نشده‌اند.
این فایل، مرجع رسمی مرحله ۱ برای ادامه ۹۹ مرحله بعدی است.

---

# 1. تعریف محصول

Shahriar Game یک اپ گیمیفیکیشن فارسی و عمودی برای Android است که رشد فردی،
شبکه‌سازی، پیگیری، برنامه‌ریزی و انجام کارهای واقعی را به یک تجربه MOBA‌گونه تبدیل می‌کند.

کاربر یک Hero انتخاب می‌کند، Match را شروع می‌کند، از Base خود حرکت می‌کند،
به Minionها و Towerها می‌رسد و برای پیشروی در میدان، Taskهای واقعی زندگی را انجام می‌دهد.

این محصول To‑Do App با پوسته بازی نیست.
هسته تجربه باید واقعاً حس «بازی کردن برای پیشرفت واقعی» بدهد.

---

# 2. Player Fantasy

کاربر باید احساس کند:

- من فرمانده مسیر پیشرفت خودم هستم.
- هر اقدام واقعی من، روی میدان نبرد اثر می‌گذارد.
- نظم و دیسیپلین من قابل مشاهده و قابل اندازه‌گیری است.
- شبکه من یک قلمرو در حال گسترش است.
- برنامه‌ریزی من کنترل میدان است.
- تکمیل هدف‌ها واقعاً حس Level Up و Victory ایجاد می‌کند.

کل تجربه باید حول این پنج حس بچرخد:
قدرت • وقار • نظم • رشد • رهبری

---

# 3. Core Promise

«هر اقدام واقعی، یک حرکت رو به جلو در بازی است.»

Task واقعی → Combat Progress  
Networking Action → Network Growth  
Timesheet → Tactical Control  
Achievement → Identity Growth  
Vision Goal → Long-Term Campaign

---

# 4. Core Gameplay Vision

Match پیش‌فرض: ۳۰ دقیقه

Flow اصلی:
Own Base
→ حرکت طبیعی Hero
→ Minion Wave
→ باز شدن Real‑World Objective
→ انجام Task واقعی
→ Attack / Hit / Reward
→ ادامه Lane
→ Tower 1
→ Wave جدید / انتخاب مسیر
→ Tower 2
→ Enemy Base
→ Victory

ویژگی‌های کلیدی:
- Portrait gameplay
- Smooth slow hero movement
- Camera follow
- No teleport
- Real encounter radius
- Lane choice
- Moving minions
- Tower range/targeting
- Fog / vision
- Projectile / impact
- Cinematic real-world task overlay
- XP/Gold/Diamond reward feedback
- Dramatic base destruction
- Android immersive fullscreen فقط هنگام Gameplay

---

# 5. App Information Architecture

Bottom Navigation ثابت و نهایی:
1. خانه
2. کارها
3. آمار
4. تایم‌شیت
5. شبکه‌سازی

Home Secondary Modules:
- فروشگاه
- رویدادها
- آینده‌بینی
- دستاوردها
- Hero Selection
- Settings

قانون:
هر بار اپ از نو اجرا شود، Home باز شود.

---

# 6. Home Vision

Home باید یک Game Lobby واقعی باشد، نه Dashboard.

Must-have:
- Player profile
- Level + XP
- Gold
- Diamond
- Hero showcase
- Rank emblem
- Start Match CTA
- Shop
- Events
- Vision
- Achievements
- Settings

نباید:
- Friend List
- ماموریت اصلی
- کار بزرگ
- صفحه شلوغ با جدول و فرم
- طراحی Flat/Web-dashboard

---

# 7. Hero System Vision

Hero فقط هویت بصری و شخصیتی دارد و Power Advantage نمی‌دهد.

Male Archetypes:
- آقای جوان خوش‌تیپ
- آقای میان‌سال لاکچری
- آقای خوش‌برخورد
- آقای بادیسیپلین

Female Archetypes:
- خانم جوان شیک
- خانم میان‌سال لاکچری
- خانم خوش‌برخورد
- خانم بادیسیپلین

Customization:
- Outfit
- Aura
- Crown / Accessory
- Armor theme
- Lobby background
- Profile frame

Gold:
خرید Hero / Cosmetic / Visual Options

Diamond:
پاداش‌های واقعی زندگی

---

# 8. Tasks Vision

Tasks = Objective Library

CRUD:
- Add
- Edit
- Delete
- Search
- Filter
- Category
- Difficulty
- XP
- Gold
- Diamond
- Active in gameplay
- Note

در Gameplay:
Task حذف دائمی نمی‌شود.
فقط Complete / Defer / Cancel Current Encounter.

---

# 9. Stats Vision

صفحه «آمار» فقط Network Tree است.

هیچ Dashboard آماری شخصی در صفحه آمار نمایش داده نمی‌شود.

Tree:
- Root = Player
- Direct members
- Multi-generation branches
- Expand / Collapse
- Zoom / Pan
- Search
- Add / Edit member
- Name
- Rank / Level
- Status
- Sales
- GPV
- Goal
- Growth

---

# 10. Timesheet Vision

Tactical Weekly Planner

- هفته
- روزهای فارسی
- Add / Edit / Delete
- Start / End time
- Category
- Note
- Weekly recurring
- Complete / Revert
- Search
- Previous / Next week

---

# 11. Networking Vision

Action Types دقیق:
- ارتباط‌سازی
- پیش‌مشاوره
- دعوت
- معرفی کار
- فالوآپ

Fields:
- Prospect
- Referrer
- Advisor
- Type
- Date
- Time
- Result
- Next Action 1
- Next Action 2

CRUD کامل + Follow-up completion

---

# 12. Events Vision

- Event CRUD
- Date
- Location
- Target
- Metric
- Criteria
- Active
- Participant CRUD
- Qualified
- Near
- Follow-up
- Progress

---

# 13. Vision Board

- Year
- Category
- Value
- Unit
- Progress
- Icon
- Image
- Note
- Financial
- Lifestyle
- Growth
- Family

ظاهر: Fantasy Roadmap / Future Realm

---

# 14. Achievements

Periods:
- Daily
- Weekly
- Monthly
- Long-term

States:
- Locked
- Progress
- Ready
- Claimed

Rewards:
- XP
- Gold
- Diamond

---

# 15. Settings Vision

Editable in-app:
- Match duration
- Wave duration
- Tower damage
- Base damage
- Tower HP
- Base HP
- XP curve
- Rank names
- Task categories
- Player name
- Level
- Gold
- Diamond
- Achievement rules
- Team goals

اصل:
تا حد ممکن اعداد و قوانین Hard-code نشوند.

---

# 16. Art Direction

Design Identity:
Cinematic Fantasy Command Center

Visual Keywords:
- Deep Navy
- Obsidian Black
- Antique Gold
- Electric Cyan
- Emerald success
- Crimson danger
- Layered depth
- Glass + metal panels
- Ornate corners
- Runes
- Light shafts
- Volumetric fog
- Cinematic silhouettes
- Premium mobile game HUD

نباید شبیه:
- Admin dashboard
- Bootstrap panel
- ساده / Flat
- کارت سفید
- فرم وب معمولی

---

# 17. Motion Direction

Hero:
Idle / Walk / Run / Attack / Hit / Victory / Recall

Movement:
- Acceleration
- Deceleration
- Smooth direction change
- Natural camera follow
- No snap
- No teleport

UI:
- 180–260ms interactions
- 320–480ms panels
- 700ms+ cinematic reward moments

---

# 18. Android Behavior

Normal App:
Status bar / navigation behavior عادی

Gameplay:
- Full immersive
- Hide status bar
- Hide navigation bar
- Transient swipe reveal
- Reapply immersive after resume
- Portrait only

---

# 19. Quality Bar

هر صفحه قبل از تأیید باید این تست را پاس کند:

1. آیا شبیه یک Mobile Game واقعی است؟
2. آیا از نسخه قبلی واضحاً حرفه‌ای‌تر است؟
3. آیا در گوشی کشیده بدون بریدگی دیده می‌شود؟
4. آیا RTL و فارسی درست است؟
5. آیا هدف صفحه در ۳ ثانیه قابل فهم است؟
6. آیا Action اصلی صفحه واضح است؟
7. آیا طراحی با Home و Gameplay یک زبان بصری دارد؟
8. آیا هیچ عنصر Web-dashboard مانند باقی مانده؟
9. آیا تمام اطلاعات ضروری قابل ویرایش‌اند؟
10. آیا برای Android واقعی قابل پیاده‌سازی است؟

اگر پاسخ هر مورد «نه» باشد، Step تأیید نمی‌شود.

---

# 20. STEP 01 DECISION

Vision رسمی پروژه:

«یک بازی گیمیفیکیشن فارسی با کیفیت Premium Mobile Game و ساختار MOBA عمودی،
که کاربر با انجام کارهای واقعی، برنامه‌ریزی، شبکه‌سازی و رشد فردی در میدان نبرد پیشروی می‌کند.»

مرحله ۲:
CORE LOOP & 30-MINUTE MATCH ARCHITECTURE
