# STEP 50 — MATCH VICTORY / TIME END / MANUAL EXIT RESULTS INTEGRATION

این مرحله پایان Match را به Results واقعی و ذخیره‌شونده وصل می‌کند.

## End Types
victory
time_end
manual_exit

## Victory
Trigger:
Enemy Base HP = 0 only.

Flow:
controls lock
scheduler stop
Victory cinematic
Victory reward transaction once
Match snapshot finalize
Progression apply
Results screen
Return Home

## Time End
Timer reaches 00:00.

Important:
Time End شکست نیست.
هیچ XP/Gold ثبت‌شده‌ای حذف نمی‌شود.
هیچ Rank penalty وجود ندارد.

Flow:
controls lock
scheduler stop
finalize committed state
no Victory bonus
Results screen
Return Home

## Manual Exit
User exits through Pause.

Flow:
confirmation
controls lock
finalize committed rewards
no Victory bonus
Results screen optional summary
Return Home

## Results Screen
Sections:
Match Result
Time
Completed Tasks
Destroyed Towers
Lane Progress
XP earned
Gold earned
Diamond earned if >0
Rank RP earned
Level progress
Rank progress
Continue to Home

## No Stats Pollution
Results screen is Match-specific.
The main Stats page remains Network Tree only.

## Reward Authority
Results never calculate money/XP from visual effects.
Read committed transaction ledger + Match snapshot.

## Progression
XP can cause Level Up.
RP can cause Rank sub-level advance.
Overflow supported.

## Level Up
If Level threshold crossed:
show level-up celebration in Results.
No gameplay power.

## Rank Up
If RP threshold crossed:
show rank-up celebration.
No combat advantage.

## Diamond
Show only if Match committed Diamond >0.

## Home Return
Exit Results:
restore normal Android system bars
fresh Home shell
no gameplay bottom HUD
canonical five-item nav returns

## Resume Safety
Finished Match cannot resume.
activeMatch pointer cleared only after final snapshot succeeds.

## Persistence Order
stop gameplay
finalize result type
aggregate committed ledger
apply progression idempotently
persist final Match
clear active Match
route Results

## Idempotency
finalizeTxId unique.
Victory bonus unique.
Progression application unique.
Opening Results twice cannot duplicate anything.

## Back
Results Back behaves same as Continue Home.

## Reduce Motion
Victory/Level/Rank celebrations use simple fade.

## QA
Victory only base zero
Time End neutral
Manual Exit no penalty
committed rewards preserved
Victory bonus once
progression once
finished Match cannot resume
system bars restored on Home
Stats remains Tree only
no Energy

## STEP 51
RESULTS PRODUCTION VISUAL & PROGRESSION CEREMONY
ساخت ظاهر نهایی Results، Level Up، Rank Up، reward summary و transition سینمایی برگشت Home.
