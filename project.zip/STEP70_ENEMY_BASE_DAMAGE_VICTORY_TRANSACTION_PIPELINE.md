# STEP 70 — ENEMY BASE ENCOUNTER + DAMAGE + VICTORY TRANSACTION PIPELINE

این مرحله چرخه نهایی Objective را می‌بندد:
Task → Hero Attack → Base Damage → Base State → Destruction → Victory Commit.

## Core Flow

Enemy Base unlocked
→ Hero enters Base interaction radius
→ Base target acquired
→ Task Encounter opens
→ user taps Complete
→ Task completion commit
→ sheet exits
→ Hero faces Base
→ attack windup
→ projectile
→ impact
→ committed Base damage -25
→ Base HP state sync
→ Task reward commit
→ if HP > 0: resume
→ if HP == 0:
    Base destruction commit
    controls lock
    scheduler stop
    Victory bonus commit
    Victory commit
    result snapshot
    route Results

## Default Base

HP:
100

Damage per completed Task:
25

Default sequence:
100 → 75 → 50 → 25 → 0

Exactly 4 completed Base Tasks destroy the Enemy Base.

## Base Visual States

76–100:
stable

51–75:
unstable

26–50:
critical

1–25:
collapse_ready

0:
destroyed

Visual state is derived only from committed HP.

## Eligibility

Enemy Base interaction is valid only if:

Base unlocked
Base not destroyed
Match active
result not finalized
Base Gate released
current target is Enemy Base

Locked Base cannot open Encounter.

## Transaction IDs

taskCommitTxId
attackTxId
baseDamageTxId
taskRewardTxId
baseDestructionTxId
victoryBonusTxId
victoryCommitTxId
resultSnapshotTxId

All once-only.

## Damage Authority

Only committed baseDamageTx changes Base HP.

Projectile, Impact, VFX and animation never mutate HP.

Duplicate impact callback:
ignored.

## Reward

Task reward:
XP
Gold
Diamond only if Task snapshot > 0

Task reward is once-only.

## Victory Bonus

Default:
+400 XP
+150 Gold
+1 Diamond

Only after:
Enemy Base HP == 0
AND Base destruction committed

Victory Bonus is separate from Task reward.

## Victory Source

Victory can only be triggered by:
enemy_base_hp_zero_only

Not by:
Tower destruction
Lane completion
Time End
Manual Exit
Pause
App background

## Destruction

At Base HP 0:

Base state = destroyed
interaction disabled
controls locked
wave scheduler stopped
new encounters blocked

Then final destruction cinematic starts.

## Victory Commit

Victory commit:
once per Match

Sets:
match.resultType = victory
match.victoryCommitted = true
match.resumeAllowed = false
match.controlsLocked = true
match.schedulerStopped = true

## Result Snapshot

Snapshot uses committed ledger only.

Contains:
completed Tasks
destroyed Towers
completed Lanes
XP earned
Gold earned
Diamond earned
duration
level before/after
rank before/after

No visual counter can add reward.

## Defer

Base Task Defer:
no Task completion
no attack
no damage
no reward
Base remains targetable

## Cancel

Cancel:
no completion
no damage
no reward
Base remains objective

## Time End During Encounter

If timer reaches zero before Task commit:
Time End wins lifecycle
no Base damage
no Victory

If Task commit already persisted:
finish committed transaction safely,
then finalize according authoritative state.

If Base reaches HP 0 from that committed Task:
Victory may finalize.

## Crash Recovery

Crash after Base damage commit:
do not damage again.

Crash after Base destruction before Victory commit:
resume Victory commit.

Crash after Victory bonus:
do not grant again.

Crash after Victory commit before Results:
rebuild result snapshot and route Results.

## Persist After

TASK_COMMITTED
BASE_DAMAGE_COMMITTED
TASK_REWARD_COMMITTED
BASE_DESTRUCTION_COMMITTED
VICTORY_BONUS_COMMITTED
VICTORY_COMMITTED
RESULT_SNAPSHOT_COMMITTED

## QA

Base requires unlock
Base Gate must be released
damage exactly 25
100 → 75 → 50 → 25 → 0
HP clamp zero
visual state derives committed HP
duplicate damage ignored
duplicate reward ignored
Victory only Base HP zero
Victory bonus once
controls lock on destruction
scheduler stops on destruction
Time End not Victory
Manual Exit not Victory
crash recovery idempotent
Diamond Victory bonus exactly +1
no Hero power advantage
no Energy

## STEP 71

ENEMY BASE DESTRUCTION + VICTORY CINEMATIC RUNTIME

Base collapse، shield implosion، final shockwave، Victory banner و انتقال سینمایی به Results را کامل می‌کنیم.
