# SHAHRIAR GAME — STEP 17
## HERO HUB / SELECTION & CUSTOMIZATION

مرجع رسمی سیستم Hero.

### اصل کلیدی
Hero هویت بصری و شخصیتی بازیکن است، نه منبع قدرت. هیچ Hero، لباس یا Cosmetic مزیت Gameplay نمی‌دهد.

### Entry
- Tap روی Hero در Home
- Shortcut از Settings
- فروشگاه می‌تواند به آیتم Hero لینک دهد
- Hero در Bottom Nav نیست

### Roster پایه
مرد:
1. آقای جوان خوش‌تیپ — مدرن • جاه‌طلب • پرانرژی
2. آقای میان‌سال لاکچری — لوکس • موفق • باوقار
3. آقای خوش‌برخورد — اجتماعی • کاریزماتیک • صمیمی
4. آقای بادیسیپلین — منظم • جدی • رهبر

زن:
5. خانم جوان شیک — مدرن • بااعتمادبه‌نفس • پرانرژی
6. خانم میان‌سال لاکچری — حرفه‌ای • موفق • سطح بالا
7. خانم خوش‌برخورد — اجتماعی • صمیمی • کاریزماتیک
8. خانم بادیسیپلین — قدرتمند • منظم • مدیریتی

### Hero Model
id, name, gender, archetype, descriptor, rarityVisual, goldPrice, unlocked, selected, portraitAsset, fullBodyAsset.

### Unlock
- Gold only
- قیمت قابل ویرایش
- خرید Hero هیچ stat/power اضافه نمی‌کند
- Hero خریداری‌شده دائمی unlocked می‌ماند

### Customization Slots
- outfit
- accessory
- aura
- effect
- background
- frame
- title

هر Slot یک آیتم Equip شده دارد یا null.

### Cosmetic Model
id, slot, name, goldPrice, unlocked, equipped, compatibleHeroIds, assetRef.

### Loadout
Loadout برای Hero انتخاب‌شده ذخیره می‌شود.
تعویض Hero، Loadout Hero قبلی را پاک نمی‌کند.

### Preview
مرکز صفحه باید Full-body Hero باشد.
در نسخه نهایی CSS silhouette ممنوع است؛ این Step فقط layout/art-direction placeholder دارد و Asset pipeline بعداً تصویر حرفه‌ای را جایگزین می‌کند.

### Purchase Flow
Tap locked Hero/item → preview → price → validate Gold → confirm → atomic purchase → unlock → optional equip.

### Equip Flow
فقط آیتم unlocked و compatible قابل Equip است.
هر slot یک آیتم فعال.

### Selected Hero
فقط یک Hero selected.
Home Lobby فوراً Hero انتخاب‌شده را نشان می‌دهد.

### No Power
تمام فیلدهای combatPower, attackBonus, speedBonus و مشابه ممنوع‌اند مگر کاربر بعداً صریحاً تصمیم را تغییر دهد.

### Mobile
Portrait 360–430px.
Hero full body حدود 42–50% viewport، ولی CTA و controls باید قابل دسترسی بمانند.
Horizontal roster carousel + bottom customization drawer.

### Visual
Fantasy luxury showroom:
dark navy, gold trims, cyan light, cinematic pedestal, castle/armory atmosphere.

### Quality Gate
- 8 archetype پایه
- Male/Female
- Gold unlock
- Select Hero
- 7 customization slots
- Equip/Unequip
- per-Hero loadout
- purchase guard
- no gameplay power
- no Energy
- RTL
- mobile-safe

## STEP 18
ART DIRECTION & ASSET PIPELINE
Hero rendering، backgrounds، UI ornaments، iconography، VFX asset list و استاندارد کیفیت تصویری نهایی.
