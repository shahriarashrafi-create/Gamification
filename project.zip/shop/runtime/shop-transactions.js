export function canBuy(item,wallet){
  const currency=item.type==='real_reward'?'diamond':'gold';
  const balance=currency==='diamond'?wallet.diamonds:wallet.gold;
  return {currency,balance,allowed:balance>=item.price};
}
export function purchaseItem({item,wallet,ownership,txId,seen}){
  if(seen.has(txId)) return {duplicate:true,wallet,ownership};
  seen.add(txId);
  if(item.type==='real_reward') throw new Error('use_claim_reward');
  if(ownership.has(item.id)) return {alreadyOwned:true,wallet,ownership};
  if(wallet.gold<item.price) return {insufficient:true,wallet,ownership};
  wallet.gold-=item.price;
  ownership.add(item.id);
  return {duplicate:false,wallet,ownership,committed:true};
}
export function claimReward({item,wallet,claims,txId,seen}){
  if(seen.has(txId)) return {duplicate:true,wallet,claims};
  seen.add(txId);
  if(item.type!=='real_reward') throw new Error('invalid_reward_type');
  if(wallet.diamonds<item.price) return {insufficient:true,wallet,claims};
  wallet.diamonds-=item.price;
  claims.push({itemId:item.id,txId,status:'claimed'});
  return {duplicate:false,wallet,claims,committed:true};
}
