export const clamp=(v,min=0,max=1)=>Math.max(min,Math.min(max,v));

export function worldToMinimap({x,y}, world={width:1200,height:2600}){
  return {x:clamp(x/world.width), y:clamp(y/world.height)};
}

export function fogPresentation(state){
  if(state==='unseen') return {visible:false,opacity:0};
  if(state==='known') return {visible:true,opacity:.35};
  return {visible:true,opacity:1};
}

export function towerMarker(tower, fog='visible'){
  const fp=fogPresentation(fog);
  if(!fp.visible) return null;
  return {
    id:tower.id,
    kind:'tower',
    position:worldToMinimap(tower.position),
    state:tower.destroyed?'destroyed':tower.unlocked?'active':'locked',
    opacity:fp.opacity,
    actionable:!!tower.unlocked && !tower.destroyed
  };
}

export function baseMarker(base, fog='visible'){
  const fp=fogPresentation(fog);
  if(!fp.visible) return null;
  return {
    id:base.id,
    kind:'base',
    position:worldToMinimap(base.position),
    state:base.destroyed?'destroyed':base.unlocked?'active':'shield_locked',
    opacity:fp.opacity,
    actionable:!!base.unlocked && !base.destroyed
  };
}

export function minionMarkers(minions, fogById={}){
  return (minions||[])
    .filter(m=>m.persisted && m.reservationId && !m.defeated)
    .map(m=>{
      const fp=fogPresentation(fogById[m.id]||'unseen');
      if(!fp.visible) return null;
      return {id:m.id,kind:'minion',position:worldToMinimap(m.position),opacity:fp.opacity};
    }).filter(Boolean);
}

export function objectiveMarker(guidance, entityById){
  if(!guidance?.id) return null;
  const entity=entityById?.[guidance.id];
  if(!entity?.position) return null;
  return {
    id:guidance.id,
    position:worldToMinimap(entity.position),
    advisoryOnly:true,
    tapToMove:false,
    teleport:false
  };
}

export function buildMinimapState({hero,ownBase,enemyBase,towers,minions,fogById,guidance,entityById}){
  return {
    hero:{id:hero.id,kind:'hero',position:worldToMinimap(hero.position),opacity:1},
    ownBase:baseMarker({...ownBase,unlocked:true},'visible'),
    enemyBase:baseMarker(enemyBase,fogById?.[enemyBase.id]||'known'),
    towers:(towers||[]).map(t=>towerMarker(t,fogById?.[t.id]||'unseen')).filter(Boolean),
    minions:minionMarkers(minions,fogById),
    objective:objectiveMarker(guidance,entityById),
    displayOnly:true
  };
}
