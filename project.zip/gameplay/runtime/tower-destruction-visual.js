export const PHASES=['fracture','core_flash','collapse','debris','smoke','settled'];

export function canStartTowerDestruction(tower){
  return !!tower?.destroyed && tower?.destructionCommitted === true;
}

export function nextDestructionPhase(current){
  const i=PHASES.indexOf(current);
  if(i<0) return PHASES[0];
  return PHASES[Math.min(i+1,PHASES.length-1)];
}

export function markerAfterDestruction(tower){
  if(!tower?.destructionCommitted) return tower?.objectiveState || 'available';
  return 'completed';
}

export function canReleaseCollision(tower){
  return tower?.destructionCommitted === true &&
         tower?.collisionEnabled === true &&
         ['collapse','debris','smoke','settled'].includes(tower?.visualDestructionPhase);
}

export function commitCollisionRelease(tower,seenTx,txId){
  if(!tower?.destructionCommitted) return {ok:false,reason:'destruction_not_committed',tower};
  if(!seenTx || !txId) return {ok:false,reason:'tx_missing',tower};
  if(seenTx.has(txId)) return {ok:false,duplicate:true,tower};
  seenTx.add(txId);
  return {
    ok:true,
    tower:{
      ...tower,
      collisionEnabled:false,
      collisionReleasedAt:new Date().toISOString()
    }
  };
}

export function reduceMotionDestruction(){
  return {
    fractureFlash:true,
    coreFlash:true,
    largeCollapse:false,
    cameraPush:false,
    debrisScale:0.25,
    smokeFade:true
  };
}

export function recoverTowerDestruction(tower){
  if(!tower?.destructionCommitted) return {tower,action:'none'};
  if(tower.collisionEnabled){
    return {
      tower:{...tower,visualDestructionPhase:'settled'},
      action:'resume_collision_release'
    };
  }
  return {
    tower:{...tower,visualDestructionPhase:'settled'},
    action:'settled_no_replay'
  };
}
