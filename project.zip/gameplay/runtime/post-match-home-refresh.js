export async function returnHomeAfterResults({store,nativeUi,router,guard}){
  if(guard.homeTransition) return {duplicate:true};
  guard.homeTransition=true;
  await store.ensureFinalizationPersisted();
  await store.clearFinishedActiveMatch();
  await nativeUi.setGameImmersiveMode(false);
  router.replace('home');
  const player=await store.readCommittedPlayerState();
  return {duplicate:false,player};
}
export function buildHomeHUD(player){
 return {
  level:player.level,
  xp:player.currentXP,
  xpRequired:player.xpRequired,
  gold:player.gold,
  diamonds:player.diamonds,
  rankId:player.rankId,
  rankScore:player.rankScore,
  selectedHeroId:player.selectedHeroId
 };
}
