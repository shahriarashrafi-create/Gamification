export function acquireFinalizationLock(match,type,txId){
  if(match?.victoryCommitted && type!=='victory'){
    return {ok:false,reason:'victory_already_committed',winner:'victory',match};
  }
  if(match?.finalizationLock){
    return {ok:false,reason:'finalization_locked',winner:match.resultType,match};
  }
  return {
    ok:true,
    match:{
      ...match,
      finalizationLock:txId,
      resultType:type,
      newEncounterBlocked:true,
      controlsLocked:true,
      schedulerStopped:true
    }
  };
}

export function rewardTotals(ledger,matchId){
  const rows=(ledger||[]).filter(x=>x.committed && (!x.matchId || x.matchId===matchId));
  const sum=key=>rows.reduce((a,x)=>a+(x.reward?.[key]||0),0);
  return {xp:sum('xp'),gold:sum('gold'),diamond:sum('diamond')};
}

export function buildNeutralResultSnapshot({match,ledger,metrics,progression}){
  if(!['time_end','manual_exit'].includes(match?.resultType)){
    return {ok:false,reason:'not_neutral_result'};
  }
  const rewards=rewardTotals(ledger,match.id);
  return {
    ok:true,
    snapshot:{
      matchId:match.id,
      resultType:match.resultType,
      durationPlayed:metrics?.durationPlayed||0,
      tasksCompleted:metrics?.tasksCompleted||0,
      towersDestroyed:metrics?.towersDestroyed||0,
      lanesCompleted:metrics?.lanesCompleted||0,
      xpEarned:rewards.xp,
      goldEarned:rewards.gold,
      diamondEarned:rewards.diamond,
      levelBefore:progression?.levelBefore,
      levelAfter:progression?.levelAfter,
      rankBefore:progression?.rankBefore,
      rankAfter:progression?.rankAfter
    }
  };
}

export function manualExitEncounterPolicy(encounter){
  if(!encounter) return {action:'exit'};
  if(encounter.taskCommitted){
    return {action:'finish_committed_pipeline_then_exit'};
  }
  return {action:'cancel_uncommitted_encounter_then_exit'};
}

export function resultCopy(type){
  if(type==='victory') return {title:'پیروزی',tone:'victory'};
  if(type==='time_end') return {title:'زمان تمام شد',tone:'neutral'};
  if(type==='manual_exit') return {title:'بازی پایان داده شد',tone:'neutral'};
  return {title:'نتیجه بازی',tone:'neutral'};
}

export function recoverFinalizedMatch(match){
  if(!match?.resultType) return {action:'none'};
  if(match.resultSnapshotCommitted) return {action:'route_results_once'};
  return {action:'resume_result_finalization'};
}
