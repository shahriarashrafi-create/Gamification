export function finalizeMatch(match, ledger, endType, txId, seen){
  if(seen.has(txId)) return {duplicate:true,match};
  seen.add(txId);
  if(!['victory','time_end','manual_exit'].includes(endType)) throw new Error('invalid_end_type');
  if(endType==='victory' && match.enemyBaseHP!==0) throw new Error('victory_requires_base_zero');
  const sums=ledger.filter(x=>x.matchId===match.id && x.committed).reduce((a,x)=>{
    a.xp+=(x.xp||0);a.gold+=(x.gold||0);a.diamond+=(x.diamond||0);a.rp+=(x.rp||0);return a;
  },{xp:0,gold:0,diamond:0,rp:0});
  match.resultType=endType;
  match.rewards=sums;
  match.finished=true;
  match.resumeAllowed=false;
  return {duplicate:false,match};
}
