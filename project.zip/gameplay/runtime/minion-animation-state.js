export function resolveMinionVisualState(minion, tx={}){
  if(minion.state==='defeated' || minion.defeatCommitted) return 'defeated';
  if(tx.hitActive) return 'hit';
  if(minion.state==='focused' || minion.focused) return 'focused';
  const speed=Math.hypot(minion.velocity?.x||0,minion.velocity?.y||0);
  if(speed>0.10) return 'walk';
  return 'idle';
}
export function minionFacing(minion,hero,attackSource,last='N'){
  const state=resolveMinionVisualState(minion,{hitActive:minion.hitActive});
  let vx=0,vy=0;
  if(state==='focused' && hero){
    vx=hero.x-minion.position.x; vy=hero.y-minion.position.y;
  }else if(state==='hit' && attackSource){
    vx=attackSource.x-minion.position.x; vy=attackSource.y-minion.position.y;
  }else{
    vx=minion.velocity?.x||0; vy=minion.velocity?.y||0;
  }
  const speed=Math.hypot(vx,vy);
  if(speed<0.10) return last;
  const angle=(Math.atan2(vy,vx)*180/Math.PI+360)%360;
  const dirs=['E','SE','S','SW','W','NW','N','NE'];
  return dirs[Math.round(angle/45)%8];
}
export function animationMayMutateGameState(){
  return false;
}
export function resolveMinionAsset(state,registry){
  return registry[state] || registry.idle || registry.generic || null;
}
export function animationPolicy({reduceMotion=false,offCamera=false}={}){
  return {
    throttle:offCamera,
    recoil:!reduceMotion,
    dissolve:!reduceMotion,
    opacityScaleFade:reduceMotion
  };
}
