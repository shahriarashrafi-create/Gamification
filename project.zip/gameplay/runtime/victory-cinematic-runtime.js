export function canPlayVictoryCinematic(match,base){
  return base?.hp===0 &&
         base?.destroyed===true &&
         match?.victoryCommitted===true &&
         match?.resultType==='victory';
}

export function victoryPresentationKey(matchId){
  return `victory_presentation:${matchId}`;
}

export function lockForVictory(match){
  return {
    ...match,
    controlsLocked:true,
    schedulerStopped:true,
    newEncounterBlocked:true,
    resumeAllowed:false
  };
}

export function verifyResultSnapshot({match,ledger,snapshot}){
  if(match?.victoryCommitted!==true) return {ok:false,reason:'victory_not_committed'};
  if(snapshot?.resultType==='victory') return {ok:true,snapshot,reused:true};

  const committed=(ledger||[]).filter(x=>x.committed && (!x.matchId || x.matchId===match.id));
  const sum=key=>committed.reduce((a,x)=>a+(x.reward?.[key]||0),0);

  return {
    ok:true,
    rebuilt:true,
    snapshot:{
      matchId:match.id,
      resultType:'victory',
      xpEarned:sum('xp'),
      goldEarned:sum('gold'),
      diamondEarned:sum('diamond')
    }
  };
}

export function presentationEvent(seen,key){
  if(seen.has(key)) return false;
  seen.add(key);
  return true;
}

export function recoverVictoryPresentation({match,base,snapshot}){
  if(!canPlayVictoryCinematic(match,base)){
    return {action:'transaction_recovery'};
  }
  if(!snapshot){
    return {action:'rebuild_result_snapshot_then_short_ceremony'};
  }
  return {action:'short_final_banner_then_results'};
}

export function rewardPresentation(){
  return {
    displayOnly:true,
    xp:400,
    gold:150,
    diamond:1,
    mutateLedger:false
  };
}
