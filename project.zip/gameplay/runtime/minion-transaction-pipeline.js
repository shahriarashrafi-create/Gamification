export class MinionPipeline {
  constructor({match,target,reservation,taskSnapshot,seenTx=new Set(),ledger=[]}){
    this.match=match;
    this.target=target;
    this.reservation=reservation;
    this.taskSnapshot=taskSnapshot;
    this.seenTx=seenTx;
    this.ledger=ledger;
    this.stage='READY';
  }
  guard(){
    if(!this.match?.active) return {ok:false,reason:'match_inactive'};
    if(!this.target || this.target.state==='despawned') return {ok:false,reason:'target_invalid'};
    if(!this.reservation || this.reservation.state!=='reserved') return {ok:false,reason:'reservation_invalid'};
    if(!this.taskSnapshot?.id) return {ok:false,reason:'task_snapshot_invalid'};
    if(this.match.resultFinalized) return {ok:false,reason:'result_finalized'};
    return {ok:true};
  }
  once(txId){
    if(!txId || this.seenTx.has(txId)) return false;
    this.seenTx.add(txId);
    return true;
  }
  completeTask(txId){
    const g=this.guard(); if(!g.ok) return g;
    if(!this.once(txId)) return {ok:false,duplicate:true};
    this.stage='TASK_COMMITTED';
    this.taskCommitted=true;
    return {ok:true,stage:this.stage};
  }
  commitDefeat(txId){
    if(!this.taskCommitted) return {ok:false,reason:'task_not_committed'};
    if(!this.once(txId)) return {ok:false,duplicate:true};
    this.target={...this.target,state:'defeated',interactionEnabled:false,movementEnabled:false};
    this.stage='DEFEAT_COMMIT';
    return {ok:true,stage:this.stage};
  }
  commitReward(txId){
    if(this.target?.state!=='defeated') return {ok:false,reason:'defeat_not_committed'};
    if(!this.once(txId)) return {ok:false,duplicate:true};
    const reward={
      xp:Math.max(0,this.taskSnapshot.xp||0),
      gold:Math.max(0,this.taskSnapshot.gold||0),
      diamond:Math.max(0,this.taskSnapshot.diamond||0)
    };
    this.ledger.push({txId,type:'minion_reward',reward,committed:true});
    this.stage='REWARD_COMMIT';
    return {ok:true,reward,stage:this.stage};
  }
  completeReservation(txId){
    if(this.stage!=='REWARD_COMMIT') return {ok:false,reason:'reward_not_committed'};
    if(!this.once(txId)) return {ok:false,duplicate:true};
    this.reservation={...this.reservation,state:'completed'};
    this.stage='RESERVATION_COMPLETE';
    return {ok:true,stage:this.stage};
  }
  despawn(txId){
    if(!['RESERVATION_COMPLETE','FEEDBACK','DESPAWN'].includes(this.stage)) return {ok:false,reason:'not_ready'};
    if(!this.once(txId)) return {ok:false,duplicate:true};
    this.target={...this.target,state:'despawned'};
    this.stage='DESPAWN';
    return {ok:true,stage:this.stage};
  }
  finish(){
    this.stage='DONE';
    return {ok:true,stage:this.stage};
  }
  defer(matchId){
    const g=this.guard(); if(!g.ok) return g;
    this.reservation={...this.reservation,state:'deferred_current_match'};
    this.target={...this.target,state:'deferred',rewardAllowed:false};
    this.stage='DESPAWN';
    return {ok:true,reward:false,damage:false,matchId};
  }
  cancel(){
    const g=this.guard(); if(!g.ok) return g;
    this.target={...this.target,state:'waiting_for_player'};
    this.stage='READY';
    return {ok:true,reservation:this.reservation};
  }
}
