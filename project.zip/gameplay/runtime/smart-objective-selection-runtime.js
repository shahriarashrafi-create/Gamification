const clamp01=v=>Math.max(0,Math.min(1,v));

function distanceScore(hero,o){
  const d=Math.hypot(o.position.x-hero.x,o.position.y-hero.y);
  return clamp01(1-d/1200)*100;
}
function progressionScore(o){
  if(o.kind==='enemy_base') return 100;
  if(o.kind==='tower2') return 90;
  if(o.kind==='tower1') return 65;
  if(o.kind==='minion') return 60;
  return 0;
}
function taskScore(o){
  if(o.kind==='minion') return o.validReservation?100:0;
  return o.taskPathAvailable===false?0:80;
}
function laneScore(hero,o){
  return hero.currentLane && o.lane===hero.currentLane ? 100 : 40;
}
function fogScore(o){
  return o.fogState==='visible'?100:o.fogState==='known'?60:35;
}

export function eligibleObjective(o){
  if(!o || !o.position) return false;
  if(o.locked || o.destroyed || o.defeated) return false;
  if(o.kind==='minion' && !o.validReservation) return false;
  return !!o.unlocked || o.kind==='minion';
}

export function scoreObjective(hero,o,weights={
  distance:.30,progression:.25,taskAvailability:.20,laneContinuity:.15,fogFamiliarity:.10
}){
  if(!eligibleObjective(o)) return null;
  const parts={
    distance:distanceScore(hero,o),
    progression:progressionScore(o),
    taskAvailability:taskScore(o),
    laneContinuity:laneScore(hero,o),
    fogFamiliarity:fogScore(o)
  };
  const score=
    parts.distance*weights.distance+
    parts.progression*weights.progression+
    parts.taskAvailability*weights.taskAvailability+
    parts.laneContinuity*weights.laneContinuity+
    parts.fogFamiliarity*weights.fogFamiliarity;
  return {objective:o,score,parts};
}

export function recommendObjectives({hero,objectives,activeTarget,weights}){
  if(activeTarget?.actionable && eligibleObjective(activeTarget)){
    return {primary:activeTarget,alternatives:[],reason:'active_encounter'};
  }
  const ranked=(objectives||[])
    .map(o=>scoreObjective(hero,o,weights))
    .filter(Boolean)
    .sort((a,b)=>b.score-a.score);
  return {
    primary:ranked[0]?.objective||null,
    primaryScore:ranked[0]?.score??null,
    alternatives:ranked.slice(1,3).map(x=>x.objective),
    ranked
  };
}

export function shouldSwitchRecommendation({
  currentId,currentSince,now=Date.now(),currentValid,newCandidateScore,currentScore,switchThreshold=12,minimumHoldMs=2000
}){
  if(!currentValid) return true;
  if(now-currentSince<minimumHoldMs) return false;
  return (newCandidateScore-currentScore)>=switchThreshold;
}

export function recommendationReason(o,hero){
  if(!o) return 'حرکت آزاد';
  if(o.kind==='enemy_base') return 'بیس دشمن آماده حمله است';
  if(o.kind==='tower2') return 'این مسیر را کامل می‌کند';
  if(o.kind==='tower1') return 'راه ادامه این مسیر را باز می‌کند';
  if(o.kind==='minion' && o.validReservation) return 'کار آماده دارد';
  if(o.lane===hero.currentLane) return 'در مسیر فعلی توست';
  return 'هدف مناسب بعدی';
}
