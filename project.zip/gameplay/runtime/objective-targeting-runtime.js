function dist(a,b){return Math.hypot(a.x-b.x,a.y-b.y)}
export function interactionRadius(type){
  if(type==='minion_task') return 5.5;
  if(type==='tower') return 7.0;
  if(type==='enemy_base') return 7.5;
  return 0;
}
export function eligible(obj,state){
  if(obj.completed || obj.destroyed || obj.defeated) return false;
  if(obj.type==='tower' && obj.locked) return false;
  if(obj.type==='enemy_base' && state.enemyBaseLocked) return false;
  if(obj.type==='minion_task' && !obj.taskReservationId) return false;
  return true;
}
export function acquireTarget(hero,objects,state,currentTargetId){
  const current=objects.find(o=>o.id===currentTargetId);
  if(current && eligible(current,state) && dist(hero,current)<=interactionRadius(current.type)+1.5){
    return current;
  }
  const list=objects
    .filter(o=>eligible(o,state))
    .map(o=>({o,d:dist(hero,o)}))
    .filter(x=>x.d<=interactionRadius(x.o.type))
    .sort((a,b)=>{
      const p=o=>o.type==='minion_task'?1:o.type==='tower'?2:3;
      return p(a.o)-p(b.o) || a.d-b.d;
    });
  return list[0]?.o || null;
}
export function markerState(obj,state,targetId){
  if(obj.completed || obj.destroyed || obj.defeated) return 'completed';
  if((obj.type==='tower' && obj.locked)||(obj.type==='enemy_base'&&state.enemyBaseLocked)) return 'locked';
  if(obj.id===targetId) return 'focused';
  return 'available';
}
export function canOpenEncounter(target,encounterState){
  return !!target && !encounterState.active && !encounterState.sheetOpen;
}
