export function formatRemaining(ms){
  const safe=Math.max(0,Math.floor(ms||0));
  const total=Math.ceil(safe/1000);
  const m=Math.floor(total/60);
  const s=total%60;
  return `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
}

export function timerPresentation(remainingMs){
  const ms=Math.max(0,remainingMs||0);
  return {
    text:formatRemaining(ms),
    state:ms<=0?'zero':ms<=60000?'critical':ms<=300000?'warning':'normal'
  };
}

export function matchRewardDelta(ledger,matchId){
  const rows=(ledger||[]).filter(x=>x.committed && x.matchId===matchId);
  const sum=k=>rows.reduce((a,x)=>a+(x.reward?.[k]||0),0);
  return {xp:sum('xp'),gold:sum('gold'),diamond:sum('diamond')};
}

export function selectGuidance({activeTarget,minions,towers,enemyBase}){
  if(activeTarget?.actionable) return {type:'active_target',id:activeTarget.id,label:activeTarget.label};
  const minion=(minions||[]).find(x=>x.actionable);
  if(minion) return {type:'minion',id:minion.id,label:'کار نزدیک'};
  const tower=(towers||[]).find(x=>x.unlocked && !x.destroyed);
  if(tower) return {type:'tower',id:tower.id,label:tower.label||'تاور فعال'};
  if(enemyBase?.unlocked && !enemyBase.destroyed) return {type:'base',id:enemyBase.id,label:'بیس دشمن'};
  return {type:'free',id:null,label:'حرکت آزاد'};
}

export function targetHpView(target){
  if(!target) return null;
  const hp=Math.max(0,target.hp||0);
  const max=Math.max(1,target.maxHP||1);
  return {id:target.id,hp,maxHP:max,percent:Math.max(0,Math.min(100,(hp/max)*100)),source:'committed'};
}

export function buildHudState({match,clock,ledger,activeTarget,minions,towers,enemyBase}){
  return {
    timer:timerPresentation(clock?.remainingMs),
    rewards:matchRewardDelta(ledger,match.id),
    objective:selectGuidance({activeTarget,minions,towers,enemyBase}),
    target:targetHpView(activeTarget),
    paused:!!match.paused,
    resultType:match.resultType||null
  };
}
