const TYPE_PRIORITY={minion:3,tower:2,enemy_base:1};

export function interactionRadius(entity){
  if(entity.kind==='minion') return 5.5;
  if(entity.kind==='tower') return 7.0;
  if(entity.kind==='enemy_base') return 7.5;
  return 0;
}

export function targetEligible(entity,{hero,visible=true,forExisting=false}={}){
  if(!entity || !hero) return false;
  if(entity.defeated || entity.destroyed || entity.despawned || entity.locked) return false;
  if(entity.kind==='minion' && !entity.validReservation) return false;
  if(!forExisting && !visible) return false;

  const d=Math.hypot(entity.position.x-hero.x,entity.position.y-hero.y);
  const radius=interactionRadius(entity)+(forExisting?1.5:0);
  return d<=radius;
}

export function selectTarget({
  hero,candidates=[],activeEncounterTarget=null,stickyTarget=null,visibleIds=new Set()
}){
  if(activeEncounterTarget && targetEligible(activeEncounterTarget,{
    hero,visible:true,forExisting:true
  })) return activeEncounterTarget;

  if(stickyTarget && targetEligible(stickyTarget,{
    hero,visible:true,forExisting:true
  })) return stickyTarget;

  const valid=candidates.filter(e=>targetEligible(e,{
    hero,visible:visibleIds.has(e.id),forExisting:false
  }));

  valid.sort((a,b)=>{
    const pa=TYPE_PRIORITY[a.kind]||0, pb=TYPE_PRIORITY[b.kind]||0;
    if(pa!==pb) return pb-pa;
    const da=Math.hypot(a.position.x-hero.x,a.position.y-hero.y);
    const db=Math.hypot(b.position.x-hero.x,b.position.y-hero.y);
    if(Math.abs(da-db)>.0001) return da-db;
    return String(a.id).localeCompare(String(b.id));
  });

  return valid[0]||null;
}

export class EncounterLock {
  constructor(state=null){ this.state=state; }

  acquire({encounterId,targetId,targetType,now=Date.now()}){
    if(this.state?.state==='active')
      return {ok:false,reason:'encounter_already_active',lock:this.state};

    this.state={
      encounterId,targetId,targetType,openedAt:now,state:'active'
    };
    return {ok:true,lock:this.state};
  }

  release(reason='safe_release'){
    const previous=this.state;
    this.state=null;
    return {ok:true,previous,reason};
  }

  active(){ return this.state?.state==='active'; }
}

export function canReopenTarget({targetId,lastCancelledTargetId,lastCancelledAt,now=Date.now(),cooldownMs=700}){
  if(targetId!==lastCancelledTargetId) return true;
  return now-lastCancelledAt>=cooldownMs;
}

export function cancelEncounterState({targetId,now=Date.now()}){
  return {
    releaseLock:true,
    clearSticky:false,
    lastCancelledTargetId:targetId,
    lastCancelledAt:now,
    reward:false,
    damage:false
  };
}

export function deferEncounterState(){
  return {
    releaseLock:true,
    clearSticky:true,
    reward:false,
    damage:false,
    reservationState:'deferred_current_match'
  };
}

export function completeEncounterLockPolicy(){
  return {
    releaseOnCompleteTap:false,
    releaseAfter:'safe_combat_handoff',
    allowNewEncounter:false
  };
}
