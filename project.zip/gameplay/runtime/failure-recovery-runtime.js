export function txCommitted(journal, txId){
  return !!journal?.find(t=>t.txId===txId && t.committed===true);
}

export function safeRetry(journal, txId){
  return !txCommitted(journal, txId);
}

export function recoverPipeline({journal=[], ledger=[], entityState, txIds={}}){
  return {
    taskAlreadyCommitted: txCommitted(journal, txIds.taskCommitTxId),
    damageAlreadyCommitted: txCommitted(journal, txIds.damageTxId),
    rewardAlreadyCommitted:
      txCommitted(journal, txIds.rewardTxId) ||
      ledger.some(x=>x.txId===txIds.rewardTxId),
    destructionAlreadyCommitted: txCommitted(journal, txIds.destructionTxId),
    victoryAlreadyCommitted: txCommitted(journal, txIds.victoryTxId),
    entityState
  };
}

export function recoverTaskEncounter(state){
  if(state.taskAlreadyCommitted){
    return {reopenTask:false,next:'combat_or_safe_reconcile'};
  }
  return {reopenTask:true,next:'task_encounter'};
}

export function recoverDamage(state){
  if(state.damageAlreadyCommitted){
    return {applyDamage:false,useCommittedHP:true};
  }
  return {applyDamage:true,useCommittedHP:false};
}

export function recoverReward(state){
  if(state.rewardAlreadyCommitted){
    return {grant:false,displayOnlyFeedbackAllowed:true};
  }
  return {grant:true,displayOnlyFeedbackAllowed:false};
}

export function recoverWave({waveTxCommitted,persistedMinions=[]}){
  if(waveTxCommitted){
    return {spawnNew:false,hydrate:persistedMinions};
  }
  return {spawnNew:true,hydrate:persistedMinions};
}

export function recoverActiveMatchPointer({activeMatchId,match}){
  if(!activeMatchId) return {state:'none'};
  if(!match || match.id!==activeMatchId){
    return {
      state:'corrupt_pointer',
      quarantine:true,
      autoCreateReplacement:false,
      autoEnterGameplay:false
    };
  }
  return {
    state:'recoverable',
    autoEnterGameplay:false,
    showHomeRecoveryCard:true
  };
}

export class IdempotencyGate {
  constructor(committedIds=[]){ this.committed=new Set(committedIds); this.inFlight=new Set(); }
  begin(txId){
    if(this.committed.has(txId)) return {ok:false,reason:'already_committed'};
    if(this.inFlight.has(txId)) return {ok:false,reason:'already_in_flight'};
    this.inFlight.add(txId);
    return {ok:true};
  }
  commit(txId){
    this.inFlight.delete(txId);
    this.committed.add(txId);
  }
  fail(txId){ this.inFlight.delete(txId); }
}

export function storageFailureOutcome(){
  return {
    advanceAuthoritativeState:false,
    preservePreviousState:true,
    grantReward:false,
    fakeDamage:false,
    destructiveReset:false,
    recoverable:true
  };
}
