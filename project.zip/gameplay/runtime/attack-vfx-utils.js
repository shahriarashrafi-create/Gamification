export function clamp(v,min,max){return Math.max(min,Math.min(max,v))}
export function projectileDuration(distancePx){
  return Math.round(clamp(180 + distancePx * 0.28,180,320))
}
export function quadraticPoint(t,p0,p1,p2){
  const a=(1-t)*(1-t), b=2*(1-t)*t, c=t*t;
  return {x:a*p0.x+b*p1.x+c*p2.x,y:a*p0.y+b*p1.y+c*p2.y}
}
export function makeArc(start,end,arcHeight=30){
  return {
    p0:start,
    p1:{x:(start.x+end.x)/2,y:Math.min(start.y,end.y)-arcHeight},
    p2:end
  }
}
export function canPlayTransaction(id,seen){
  if(seen.has(id)) return false;
  seen.add(id);
  return true;
}
