export class MatchClock {
  constructor(snapshot){
    this.startedAt=snapshot.startedAt;
    this.durationMs=snapshot.durationMs;
    this.pausedAccumulatedMs=snapshot.pausedAccumulatedMs||0;
    this.pauseStartedAt=snapshot.pauseStartedAt||null;
    this.state=snapshot.state||'running';
  }

  elapsed(now=Date.now()){
    const start=Date.parse(this.startedAt);
    const activePause=this.pauseStartedAt ? now-Date.parse(this.pauseStartedAt) : 0;
    return Math.max(0,now-start-this.pausedAccumulatedMs-activePause);
  }

  remaining(now=Date.now()){
    return Math.max(0,this.durationMs-this.elapsed(now));
  }

  pause(nowIso=new Date().toISOString()){
    if(this.state!=='running') return false;
    this.state='paused'; this.pauseStartedAt=nowIso; return true;
  }

  resume(nowIso=new Date().toISOString()){
    if(this.state!=='paused' || !this.pauseStartedAt) return false;
    this.pausedAccumulatedMs += Date.parse(nowIso)-Date.parse(this.pauseStartedAt);
    this.pauseStartedAt=null; this.state='running'; return true;
  }
}

export class WaveScheduler {
  constructor({waveSeconds=45,lastWaveIndex=0,state='running'}={}){
    this.waveMs=waveSeconds*1000;
    this.lastWaveIndex=lastWaveIndex;
    this.state=state;
  }

  eligibleIndex(elapsedMs){
    return Math.floor(elapsedMs/this.waveMs);
  }

  reconcile(elapsedMs,{globalAlive,laneAlive}){
    if(this.state!=='running') return {spawn:false};
    const eligible=this.eligibleIndex(elapsedMs);
    if(eligible<=this.lastWaveIndex) return {spawn:false};
    this.lastWaveIndex=eligible; // skipped indexes are intentionally collapsed
    if(globalAlive>=6) return {spawn:false,reason:'global_cap'};
    if(laneAlive>=2) return {spawn:false,reason:'lane_cap'};
    return {spawn:true,waveIndex:eligible};
  }

  pause(){ if(this.state==='running') this.state='paused'; }
  resume(){ if(this.state==='paused') this.state='running'; }
  stop(){ this.state='stopped'; }
}

export function formatRemaining(ms){
  const total=Math.ceil(Math.max(0,ms)/1000);
  const m=Math.floor(total/60), s=total%60;
  return `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
}

export function timerPresentation(ms){
  const sec=Math.ceil(ms/1000);
  if(sec<=15) return 'critical';
  if(sec<=60) return 'warning';
  return 'normal';
}

export function requestFinalization(match,type,txId){
  if(match.finalizationLock) return {ok:false,reason:'finalization_locked',match};
  if(!['victory','time_end','manual_exit'].includes(type)) return {ok:false,reason:'invalid_result',match};
  return {
    ok:true,
    match:{
      ...match,
      finalizationLock:txId,
      resultType:type,
      schedulerStopped:true,
      newEncounterBlocked:true
    }
  };
}

export function resolveVictoryTimeEndRace({baseDestructionCommitted,timeEndLocked,baseDamageAlreadyCommitted}){
  if(baseDestructionCommitted) return 'victory';
  if(timeEndLocked && !baseDamageAlreadyCommitted) return 'time_end';
  if(baseDamageAlreadyCommitted) return 'finish_committed_pipeline';
  return 'time_end';
}
