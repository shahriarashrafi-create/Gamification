const TAU=Math.PI*2;

export function normalizeAngle(a){
  let x=a%TAU;
  if(x<0)x+=TAU;
  return x;
}

export function distanceBand(distance){
  if(distance<=80) return {id:'very_near',label:'خیلی نزدیک'};
  if(distance<=180) return {id:'near',label:'نزدیک'};
  if(distance<=420) return {id:'medium',label:'متوسط'};
  if(distance<=800) return {id:'far',label:'دور'};
  return {id:'very_far',label:'خیلی دور'};
}

export function directionSector(angleRad){
  const a=normalizeAngle(angleRad);
  const sectors=[
    'شرق','شمال‌شرق','شمال','شمال‌غرب',
    'غرب','جنوب‌غرب','جنوب','جنوب‌شرق'
  ];
  const idx=Math.round(a/(Math.PI/4))%8;
  return sectors[idx];
}

export function guidanceVector(hero,target){
  const dx=target.x-hero.x, dy=target.y-hero.y;
  const distance=Math.hypot(dx,dy);
  const angle=Math.atan2(-dy,dx); // world Y down -> visual north is negative Y
  return {
    dx,dy,distance,
    direction:directionSector(angle),
    distanceBand:distanceBand(distance)
  };
}

export function buildObjectiveGuidance({hero,objective,fogState,interactionRadius=7}){
  if(!hero || !objective?.position) return {mode:'none'};

  const v=guidanceVector(hero,objective.position);

  if(v.distance<=interactionRadius && objective.actionable){
    return {
      mode:'interaction',
      objectiveId:objective.id,
      label:objective.label,
      direction:v.direction,
      distanceBand:v.distanceBand,
      interactionReady:true
    };
  }

  if(fogState==='visible'){
    return {
      mode:'visible',
      objectiveId:objective.id,
      label:objective.label,
      direction:v.direction,
      distanceBand:v.distanceBand,
      exactPosition:{...objective.position},
      interactionReady:false
    };
  }

  if(fogState==='known'){
    return {
      mode:'known',
      objectiveId:objective.id,
      label:objective.label,
      direction:v.direction,
      distanceBand:v.distanceBand,
      exactPosition:{...objective.position},
      markerOpacity:.35
    };
  }

  return {
    mode:'unseen',
    objectiveId:objective.id,
    label:objective.label,
    direction:v.direction,
    distanceBand:v.distanceBand,
    exactPosition:null
  };
}

export function chooseNearestUnlocked(hero,objectives=[]){
  const candidates=objectives.filter(o=>o.unlocked && !o.destroyed && o.position);
  if(!candidates.length)return null;
  return candidates
    .map(o=>({o,d:Math.hypot(o.position.x-hero.x,o.position.y-hero.y)}))
    .sort((a,b)=>a.d-b.d)[0].o;
}
