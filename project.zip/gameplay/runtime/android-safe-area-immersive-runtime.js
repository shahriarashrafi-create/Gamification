export function desiredSystemUiMode({route,matchStatus,resultFinalized}){
  const gameplayActive =
    route==='gameplay' &&
    matchStatus==='running' &&
    !resultFinalized;

  return gameplayActive ? 'immersive' : 'normal';
}

export async function applySystemUiMode({
  mode,
  nativeBridge
}){
  if(!nativeBridge?.setGameImmersiveMode){
    return {ok:false,reason:'native_bridge_unavailable',mode};
  }

  if(mode==='immersive'){
    await nativeBridge.setGameImmersiveMode(true);
    return {ok:true,immersive:true};
  }

  await nativeBridge.setGameImmersiveMode(false);
  return {ok:true,immersive:false};
}

export async function syncSystemUi({
  route,
  matchStatus,
  resultFinalized,
  nativeBridge
}){
  const mode=desiredSystemUiMode({route,matchStatus,resultFinalized});
  return applySystemUiMode({mode,nativeBridge});
}

export function shouldReapplyImmersive({
  route,
  matchStatus,
  resultFinalized,
  documentVisible=true
}){
  return !!(
    documentVisible &&
    route==='gameplay' &&
    matchStatus==='running' &&
    !resultFinalized
  );
}

export class ImmersiveLifecycleController {
  constructor(nativeBridge){
    this.nativeBridge=nativeBridge;
    this.bound=false;
    this.handlers={};
  }

  bind(getState){
    if(this.bound) return false;
    this.bound=true;

    this.handlers.visibility=async()=>{
      const s=getState();
      if(document.visibilityState==='visible'){
        await syncSystemUi({...s,nativeBridge:this.nativeBridge});
      }
    };

    this.handlers.focus=async()=>{
      const s=getState();
      if(shouldReapplyImmersive({...s,documentVisible:true})){
        await applySystemUiMode({mode:'immersive',nativeBridge:this.nativeBridge});
      }
    };

    document.addEventListener('visibilitychange',this.handlers.visibility);
    window.addEventListener('focus',this.handlers.focus);
    return true;
  }

  unbind(){
    if(!this.bound) return false;
    document.removeEventListener('visibilitychange',this.handlers.visibility);
    window.removeEventListener('focus',this.handlers.focus);
    this.handlers={};
    this.bound=false;
    return true;
  }
}

export function gameplayBackAction({taskEncounterOpen,pauseOpen,combatHandoffLocked}){
  if(taskEncounterOpen){
    return combatHandoffLocked ? 'ignore_back' : 'cancel_task_encounter';
  }
  if(pauseOpen) return 'pause_sheet_back';
  return 'open_pause';
}
