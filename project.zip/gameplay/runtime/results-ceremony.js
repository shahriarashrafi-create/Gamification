export function buildCeremony(result){
 return {
  showLevelUp: result.levelAfter > result.levelBefore,
  showRankUp: result.rankAfter !== result.rankBefore,
  showDiamond: (result.diamondEarned||0) > 0,
  values:{
   xp:result.xpEarned||0,
   gold:result.goldEarned||0,
   diamond:result.diamondEarned||0,
   rp:result.rankRPEarned||0
  }
 };
}
export function visualCountUp(from,to,t){
 return Math.round(from+(to-from)*Math.max(0,Math.min(1,t)));
}
