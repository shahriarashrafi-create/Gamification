const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));

export function deterministicLaneOffset(minionId, offsets=[-8,0,8]){
  let h=0;
  for(let i=0;i<minionId.length;i++) h=(h*31+minionId.charCodeAt(i))>>>0;
  return offsets[h%offsets.length];
}

export function laneGroups(minions=[]){
  const groups={A:[],B:[],C:[]};
  for(const m of minions){
    if(m.defeated || m.despawned) continue;
    (groups[m.laneId] ||= []).push(m);
  }
  for(const lane of Object.keys(groups)){
    groups[lane].sort((a,b)=>(b.pathProgress??0)-(a.pathProgress??0));
  }
  return groups;
}

export function crowdSpeedFactor(gap,{preferredGap=42,minimumGap=28}={}){
  if(gap>=preferredGap) return 1.0;
  if(gap<=minimumGap) return 0.65;
  const t=(gap-minimumGap)/(preferredGap-minimumGap);
  return 0.65 + t*(1.0-0.65);
}

export function updateLaneCrowd(minions,{dt,paused=false,baseSpeed=2.4,preferredGap=42,minimumGap=28}={}){
  if(paused) return minions.map(m=>({...m}));
  const out=minions.map(m=>({...m}));
  const groups=laneGroups(out);

  for(const laneId of Object.keys(groups)){
    const lane=groups[laneId];
    for(let i=0;i<lane.length;i++){
      const m=lane[i];
      if(m.movementState==='focused') continue;

      let factor=1.0;
      const ahead=lane[i-1];

      if(ahead){
        const gap=(ahead.pathProgress??0)-(m.pathProgress??0);
        factor=crowdSpeedFactor(gap,{preferredGap,minimumGap});

        if(ahead.movementState==='focused' && gap<preferredGap){
          factor=Math.min(factor,0.55);
        }
      }

      const next=(m.pathProgress??0) + baseSpeed*factor*dt;
      if(ahead){
        const maxProgress=(ahead.pathProgress??0)-minimumGap;
        m.pathProgress=Math.min(next,maxProgress);
      }else{
        m.pathProgress=next;
      }

      m.speedFactor=factor;
      m.lateralOffsetWorld=
        m.lateralOffsetWorld ??
        deterministicLaneOffset(m.id);
    }
  }
  return out;
}

export function separationCorrection(a,b,{radius=34,maxCorrection=6}={}){
  const dx=(a.worldX??0)-(b.worldX??0);
  const dy=(a.worldY??0)-(b.worldY??0);
  const d=Math.hypot(dx,dy);
  if(!d || d>=radius) return {x:0,y:0};

  const strength=(1-d/radius)*maxCorrection;
  return {x:clamp(dx/d*strength,-maxCorrection,maxCorrection),y:0};
}

export function spawnDelay(indexSameLane, baseMs=220){
  return Math.max(0,indexSameLane)*baseMs;
}

export function repairLaneOverlaps(minions,{minimumGap=28}={}){
  const out=minions.map(m=>({...m}));
  const groups=laneGroups(out);

  for(const lane of Object.values(groups)){
    for(let i=1;i<lane.length;i++){
      const ahead=lane[i-1];
      const cur=lane[i];
      const maxProgress=(ahead.pathProgress??0)-minimumGap;
      if((cur.pathProgress??0)>maxProgress){
        cur.pathProgress=maxProgress;
        cur.recoveryOverlapRepaired=true;
      }
    }
  }
  return out;
}
