export function nextTowerState(hp){
  hp=Math.max(0,Math.min(100,hp));
  return hp===0?'destroyed':hp<=33?'critical':hp<=66?'damaged':'healthy';
}
export function destroyTower(state,towerId,txId,seen){
  if(seen.has(txId)) return {duplicate:true,state};
  seen.add(txId);
  const tower=state.towers[towerId];
  if(!tower || tower.hp!==0) return {invalid:true,state};
  tower.destroyed=true;
  tower.collision=false;
  if(tower.tier===1){
    const next=state.towers[tower.nextTowerId];
    if(next) next.locked=false;
    state.lanes[tower.lane].state='tower2_active';
  } else {
    state.lanes[tower.lane].state='complete';
  }
  state.enemyBase.locked=Object.values(state.lanes).filter(x=>x.state==='complete').length<1;
  return {duplicate:false,state};
}
export function destroyEnemyBase(state,txId,seen){
  if(seen.has(txId)) return {duplicate:true,victory:false,state};
  seen.add(txId);
  if(state.enemyBase.hp!==0) return {invalid:true,victory:false,state};
  state.enemyBase.destroyed=true;
  state.controlsLocked=true;
  state.schedulerStopped=true;
  state.victory=true;
  return {duplicate:false,victory:true,state};
}
