const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));

export function projectileDuration(screenDistance){
  return Math.round(clamp(180 + (screenDistance/700)*140,180,320));
}

export function faceTarget(hero,target){
  const dx=target.position.x-hero.position.x;
  const dy=target.position.y-hero.position.y;
  return {
    facingRadians:Math.atan2(dy,dx),
    heroPosition:{...hero.position},
    positionMutated:false
  };
}

export class CombatHandoff {
  constructor(){ this.inFlight=false; this.attackTxId=null; this.stage='idle'; }

  begin({taskCommit,attackTxId}){
    if(!taskCommit?.committed) return {ok:false,reason:'task_not_committed'};
    if(this.inFlight) return {ok:false,reason:'handoff_in_flight'};
    this.inFlight=true;
    this.attackTxId=attackTxId;
    this.stage='sheet_exit';
    return {ok:true,movementLocked:true};
  }

  visualImpact(){
    if(!this.inFlight) return {ok:false};
    this.stage='impact_flash';
    return {
      ok:true,
      mutatesHP:false,
      grantsReward:false,
      requiresEntityCommit:true
    };
  }

  entityCommitted(result){
    if(!result?.committed){
      this.stage='recoverable_entity_commit';
      return {
        ok:false,
        fakeHpLoss:false,
        message:'ثبت ضربه کامل نشد',
        persistForRecovery:true
      };
    }
    this.stage='entity_committed';
    return {ok:true,refreshHP:true};
  }

  rewardCommitted(result){
    if(!result?.committed){
      this.stage='entity_committed';
      return {ok:false,showReward:false};
    }
    this.stage='reward_committed';
    return {
      ok:true,
      showReward:true,
      reward:result.reward,
      showDiamond:(result.reward?.diamond||0)>0
    };
  }

  finish(){
    this.stage='done';
    this.inFlight=false;
    return {movementLocked:false,recomputeObjective:true,refreshHUD:true,refreshMinimap:true};
  }
}

export function reduceMotionHandoff(){
  return {
    sheetExit:'short_fade',
    cameraRefocus:'instant',
    projectile:'short_beam_or_flash',
    impact:'readable_static_flash',
    reward:'instant_readable'
  };
}
