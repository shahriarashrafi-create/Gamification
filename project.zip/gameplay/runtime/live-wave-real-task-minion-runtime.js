export function activeMinionCounts(minions=[]){
  const live=minions.filter(m=>!m.defeated && !m.despawned);
  const lanes={A:0,B:0,C:0};
  for(const m of live) lanes[m.laneId]=(lanes[m.laneId]||0)+1;
  return {global:live.length,lanes};
}

export function availableSpawnSlots(minions=[],globalCap=6,laneCap=2){
  const c=activeMinionCounts(minions);
  const lanes=['A','B','C'].map(id=>({
    laneId:id,
    available:Math.max(0,laneCap-(c.lanes[id]||0))
  }));
  return {global:Math.max(0,globalCap-c.global),lanes};
}

export function chooseSpawnLanes({minions=[],count=3,recommendedLane=null}){
  const slots=availableSpawnSlots(minions);
  let remaining=Math.min(count,slots.global);
  const out=[];
  const ordered=[...slots.lanes].sort((a,b)=>{
    if(a.laneId===recommendedLane) return -1;
    if(b.laneId===recommendedLane) return 1;
    return b.available-a.available;
  });
  while(remaining>0){
    let added=false;
    for(const lane of ordered){
      const used=out.filter(x=>x===lane.laneId).length;
      if(used<lane.available && remaining>0){
        out.push(lane.laneId); remaining--; added=true;
      }
    }
    if(!added) break;
  }
  return out;
}

export function buildWaveSpawnTxId(matchId,waveIndex){
  return `${matchId}:wave:${waveIndex}:spawn`;
}

export function planWaveSpawn({
  matchId,waveIndex,minions=[],eligibleTasks=[],existingWaveTxIds=[],
  recommendedLane=null,maxRequested=3
}){
  const txId=buildWaveSpawnTxId(matchId,waveIndex);
  if(existingWaveTxIds.includes(txId))
    return {ok:true,idempotent:true,txId,spawns:[]};

  const lanes=chooseSpawnLanes({minions,count:maxRequested,recommendedLane});
  const tasks=eligibleTasks.filter(t=>t.activeInGame && t.status==='active' && !t.activeReservationId);
  const count=Math.min(lanes.length,tasks.length);
  if(count===0) return {ok:true,txId,spawns:[],reason:'no_capacity_or_tasks'};

  const spawns=[];
  for(let i=0;i<count;i++){
    const task=tasks[i],laneId=lanes[i];
    const reservationId=`res_${matchId}_${waveIndex}_${i}_${task.taskId}`;
    const minionId=`minion_${matchId}_${waveIndex}_${i}`;
    spawns.push({
      reservation:{
        id:reservationId,taskId:task.taskId,matchId,waveIndex,laneId,state:'reserved'
      },
      minion:{
        id:minionId,matchId,waveIndex,laneId,reservationId,taskId:task.taskId,
        pathId:`lane_${laneId}`,pathProgress:0,movementState:'spawned',
        visualState:'idle',defeated:false,despawned:false,persisted:true
      }
    });
  }
  return {ok:true,idempotent:false,txId,spawns};
}

export function reconcileMissedWaves({elapsedMs,intervalMs,lastWaveIndex}){
  const due=Math.floor(elapsedMs/intervalMs);
  if(due<=lastWaveIndex) return {spawn:false,nextIndex:lastWaveIndex};
  return {spawn:true,nextIndex:due,collapsedMissedCount:Math.max(0,due-lastWaveIndex-1)};
}

export function minionEncounterEligible(minion,reservation){
  return !!(
    minion && reservation &&
    minion.persisted &&
    !minion.defeated &&
    !minion.despawned &&
    reservation.id===minion.reservationId &&
    reservation.state==='reserved'
  );
}
