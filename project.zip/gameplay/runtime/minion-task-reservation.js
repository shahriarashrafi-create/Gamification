export function eligibleTasks(tasks,reservations,matchId){
  const activeTaskIds=new Set(
    reservations.filter(r=>r.matchId===matchId && r.state==='reserved').map(r=>r.taskId)
  );
  return tasks.filter(t=>
    t.status==='active' &&
    t.activeInGame===true &&
    !t.deferredMatches?.includes(matchId) &&
    !activeTaskIds.has(t.id) &&
    !(t.repeatMode==='one_time' && t.completedCount>0)
  );
}
export function canSpawn(lane,activeMinions){
  const active=activeMinions.filter(m=>!['defeated','despawned'].includes(m.state));
  if(active.length>=6) return false;
  if(active.filter(m=>m.lane===lane).length>=2) return false;
  return true;
}
export function reserveTask({task,lane,matchId,reservationId,minionId}){
  return {
    reservation:{
      id:reservationId, taskId:task.id, minionId, lane, matchId,
      state:'reserved', createdAt:new Date().toISOString()
    },
    minion:{
      id:minionId, lane, taskId:task.id, reservationId,
      state:'spawning', actionable:true
    }
  };
}
export function deferReservation(reservation,task,matchId){
  if(reservation.state!=='reserved') return {ok:false,reason:'invalid_state'};
  return {
    ok:true,
    reservation:{...reservation,state:'deferred_current_match'},
    task:{...task,deferredMatches:[...(task.deferredMatches||[]),matchId]}
  };
}
export function cancelEncounter(reservation){
  return {ok:reservation.state==='reserved',reservation};
}
export function completeReservation(reservation,txSeen,txId){
  if(txSeen.has(txId)) return {ok:false,duplicate:true,reservation};
  if(reservation.state!=='reserved') return {ok:false,reason:'invalid_state',reservation};
  txSeen.add(txId);
  return {ok:true,reservation:{...reservation,state:'completed'}};
}
export function recoverOrphans(reservations,minions){
  const minionIds=new Set(minions.map(m=>m.id));
  const reservationIds=new Set(reservations.map(r=>r.id));
  return {
    reservations:reservations.map(r=>
      r.state==='reserved' && !minionIds.has(r.minionId) ? {...r,state:'released'} : r
    ),
    minions:minions.map(m=>
      !reservationIds.has(m.reservationId) ? {...m,state:'despawned',rewardAllowed:false} : m
    )
  };
}
