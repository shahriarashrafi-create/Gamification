export function laneCompleteCount(lanes){
  return Object.values(lanes || {}).filter(l=>l?.complete===true).length;
}

export function canCompleteLane(lane){
  return !!lane?.tower1Destroyed && !!lane?.tower2Destroyed && lane.complete!==true;
}

export function commitLaneComplete(state,laneId,seenTx,txId){
  if(!seenTx || !txId) return {ok:false,reason:'tx_missing',state};
  if(seenTx.has(txId)) return {ok:false,duplicate:true,state};

  const lane=state?.lanes?.[laneId];
  if(!lane) return {ok:false,reason:'lane_missing',state};
  if(!lane.tower1Destroyed || !lane.tower2Destroyed) return {ok:false,reason:'tower_progress_invalid',state};
  if(lane.complete) return {ok:false,alreadyComplete:true,state};

  seenTx.add(txId);
  const lanes={
    ...state.lanes,
    [laneId]:{...lane,complete:true,state:'complete'}
  };
  return {
    ok:true,
    state:{...state,lanes,completedLanes:laneCompleteCount(lanes)}
  };
}

export function shouldUnlockEnemyBase(state){
  return (state?.completedLanes || laneCompleteCount(state?.lanes)) >= 1 &&
         state?.enemyBase?.locked === true;
}

export function commitEnemyBaseUnlock(state,seenTx,txId){
  if(!shouldUnlockEnemyBase(state)) return {ok:false,reason:'unlock_condition_not_met',state};
  if(!seenTx || !txId) return {ok:false,reason:'tx_missing',state};
  if(seenTx.has(txId)) return {ok:false,duplicate:true,state};

  seenTx.add(txId);
  return {
    ok:true,
    state:{
      ...state,
      enemyBase:{
        ...state.enemyBase,
        locked:false,
        shieldState:'available',
        interactionEnabled:true,
        objectiveState:'available'
      }
    }
  };
}

export function releaseEnemyBaseGate(state,seenTx,txId){
  if(state?.enemyBase?.locked!==false) return {ok:false,reason:'base_still_locked',state};
  if(!seenTx || !txId) return {ok:false,reason:'tx_missing',state};
  if(seenTx.has(txId)) return {ok:false,duplicate:true,state};

  seenTx.add(txId);
  return {
    ok:true,
    state:{
      ...state,
      enemyBaseGate:{...state.enemyBaseGate,collisionEnabled:false}
    }
  };
}

export function nextObjectiveAfterLaneComplete(state,laneId){
  if(state?.enemyBase?.locked===false){
    return {type:'enemy_base',id:state.enemyBase.id,lane:laneId,forced:false};
  }
  return null;
}

export function recoverLaneBaseState(state){
  const completed=laneCompleteCount(state?.lanes);
  let next={...state,completedLanes:completed};
  if(completed>=1 && next?.enemyBase?.locked===true){
    return {state:next,action:'evaluate_base_unlock'};
  }
  if(next?.enemyBase?.locked===false && next?.enemyBaseGate?.collisionEnabled===true){
    return {state:next,action:'resume_gate_release'};
  }
  return {state:next,action:'settled'};
}
