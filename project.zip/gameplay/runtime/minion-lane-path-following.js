export function clamp(v,a,b){return Math.max(a,Math.min(b,v))}
export function distance(a,b){return Math.hypot(a.x-b.x,a.y-b.y)}
export function stepMinion(minion,path,dt){
  dt=Math.min(dt,0.05);
  if(['waiting_for_player','focused','defeated','deferred','despawned'].includes(minion.state)) return minion;
  const target=path[minion.segmentIndex+1];
  if(!target) return {...minion,state:'waiting_for_player',velocity:{x:0,y:0}};
  const pos=minion.position;
  const dx=target[0]-pos.x, dy=target[1]-pos.y, d=Math.hypot(dx,dy);
  if(d<=1.25){
    const nextIndex=minion.segmentIndex+1;
    if(nextIndex>=path.length-1) return {...minion,segmentIndex:nextIndex,state:'waiting_for_player',velocity:{x:0,y:0}};
    return {...minion,segmentIndex:nextIndex,pathProgress:0};
  }
  const speed=minion.state==='approaching'?1.1:2.4;
  const vx=dx/d*speed, vy=dy/d*speed;
  return {
    ...minion,
    position:{x:pos.x+vx*dt,y:pos.y+vy*dt},
    velocity:{x:vx,y:vy},
    pathProgress:clamp((minion.pathProgress||0)+(speed*dt/Math.max(d,0.001)),0,1)
  };
}
export function facing8(v,last='N'){
  const speed=Math.hypot(v.x,v.y);
  if(speed<0.1) return last;
  const angle=(Math.atan2(v.y,v.x)*180/Math.PI+360)%360;
  const dirs=['E','SE','S','SW','W','NW','N','NE'];
  return dirs[Math.round(angle/45)%8];
}
export function softSeparate(minion,others){
  let ox=0,oy=0;
  for(const o of others){
    if(o.id===minion.id) continue;
    const dx=minion.position.x-o.position.x,dy=minion.position.y-o.position.y,d=Math.hypot(dx,dy);
    if(d>0 && d<2.0){const push=(2.0-d)/2.0;ox+=dx/d*push;oy+=dy/d*push}
  }
  return {x:ox,y:oy};
}
export function cancelFocused(minion){
  return {...minion,state:'waiting_for_player',velocity:{x:0,y:0}};
}
export function deferMinion(minion){
  return {...minion,state:'deferred',rewardAllowed:false};
}
export function defeatMinion(minion){
  return {...minion,state:'defeated'};
}
