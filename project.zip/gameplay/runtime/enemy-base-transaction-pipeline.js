export function baseVisualState(hp){
  hp=Math.max(0,Math.min(100,hp));
  if(hp===0) return 'destroyed';
  if(hp<=25) return 'collapse_ready';
  if(hp<=50) return 'critical';
  if(hp<=75) return 'unstable';
  return 'stable';
}

export class EnemyBasePipeline{
  constructor({match,base,taskSnapshot,seenTx=new Set(),ledger=[]}){
    this.match=match;
    this.base={...base};
    this.taskSnapshot=taskSnapshot;
    this.seenTx=seenTx;
    this.ledger=ledger;
    this.stage='READY';
    this.taskCommitted=false;
  }

  guard(){
    if(!this.match?.active) return {ok:false,reason:'match_inactive'};
    if(this.match?.resultFinalized) return {ok:false,reason:'result_finalized'};
    if(!this.base || this.base.destroyed || this.base.hp<=0) return {ok:false,reason:'base_destroyed'};
    if(this.base.locked) return {ok:false,reason:'base_locked'};
    if(this.base.gateCollisionEnabled) return {ok:false,reason:'base_gate_locked'};
    if(!this.taskSnapshot?.id) return {ok:false,reason:'task_snapshot_invalid'};
    return {ok:true};
  }

  once(txId){
    if(!txId || this.seenTx.has(txId)) return false;
    this.seenTx.add(txId);
    return true;
  }

  commitTask(txId){
    const g=this.guard(); if(!g.ok) return g;
    if(!this.once(txId)) return {ok:false,duplicate:true};
    this.taskCommitted=true;
    this.stage='TASK_COMMITTED';
    return {ok:true};
  }

  commitDamage(txId,damage=25){
    if(!this.taskCommitted) return {ok:false,reason:'task_not_committed'};
    if(!this.once(txId)) return {ok:false,duplicate:true,hp:this.base.hp};
    const before=this.base.hp;
    const after=Math.max(0,before-damage);
    this.base={...this.base,hp:after,visualState:baseVisualState(after)};
    this.stage='BASE_DAMAGE_COMMITTED';
    return {ok:true,before,after,damageApplied:before-after,state:this.base.visualState};
  }

  commitTaskReward(txId){
    if(this.stage!=='BASE_DAMAGE_COMMITTED') return {ok:false,reason:'damage_not_committed'};
    if(!this.once(txId)) return {ok:false,duplicate:true};
    const reward={
      xp:Math.max(0,this.taskSnapshot.xp||0),
      gold:Math.max(0,this.taskSnapshot.gold||0),
      diamond:Math.max(0,this.taskSnapshot.diamond||0)
    };
    this.ledger.push({txId,type:'base_task_reward',reward,committed:true});
    this.stage='TASK_REWARD_COMMITTED';
    return {ok:true,reward};
  }

  commitDestruction(txId){
    if(this.base.hp!==0) return {ok:false,reason:'base_hp_not_zero'};
    if(!this.once(txId)) return {ok:false,duplicate:true};
    this.base={
      ...this.base,
      destroyed:true,
      interactionEnabled:false,
      objectiveState:'completed',
      visualState:'destroyed'
    };
    this.match={
      ...this.match,
      controlsLocked:true,
      schedulerStopped:true,
      newEncounterBlocked:true
    };
    this.stage='BASE_DESTRUCTION_COMMITTED';
    return {ok:true};
  }

  commitVictoryBonus(txId){
    if(!this.base.destroyed) return {ok:false,reason:'destruction_not_committed'};
    if(!this.once(txId)) return {ok:false,duplicate:true};
    const reward={xp:400,gold:150,diamond:1};
    this.ledger.push({txId,type:'victory_bonus',reward,committed:true});
    this.stage='VICTORY_BONUS_COMMITTED';
    return {ok:true,reward};
  }

  commitVictory(txId){
    if(!this.base.destroyed || this.base.hp!==0) return {ok:false,reason:'base_not_destroyed'};
    if(!this.once(txId)) return {ok:false,duplicate:true};
    this.match={
      ...this.match,
      resultType:'victory',
      victoryCommitted:true,
      resumeAllowed:false,
      controlsLocked:true,
      schedulerStopped:true
    };
    this.stage='VICTORY_COMMITTED';
    return {ok:true,match:this.match};
  }

  resultSnapshot(txId){
    if(!this.match?.victoryCommitted) return {ok:false,reason:'victory_not_committed'};
    if(!this.once(txId)) return {ok:false,duplicate:true};
    const committed=this.ledger.filter(x=>x.committed);
    const sum=(key)=>committed.reduce((a,x)=>a+(x.reward?.[key]||0),0);
    this.stage='RESULT_SNAPSHOT_COMMITTED';
    return {
      ok:true,
      snapshot:{
        resultType:'victory',
        xpEarned:sum('xp'),
        goldEarned:sum('gold'),
        diamondEarned:sum('diamond')
      }
    };
  }

  defer(){
    const g=this.guard(); if(!g.ok) return g;
    this.stage='READY';
    return {ok:true,damage:false,reward:false};
  }

  cancel(){
    const g=this.guard(); if(!g.ok) return g;
    this.stage='READY';
    return {ok:true,keepObjective:true,damage:false,reward:false};
  }
}
