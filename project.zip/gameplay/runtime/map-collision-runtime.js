export function pointInPolygon(point, polygon){
  let inside=false;
  for(let i=0,j=polygon.length-1;i<polygon.length;j=i++){
    const xi=polygon[i][0], yi=polygon[i][1], xj=polygon[j][0], yj=polygon[j][1];
    const intersect=((yi>point.y)!==(yj>point.y)) &&
      (point.x < (xj-xi)*(point.y-yi)/(yj-yi+Number.EPSILON)+xi);
    if(intersect) inside=!inside;
  }
  return inside;
}
export function isWalkable(point, polygons){
  return polygons.some(p=>pointInPolygon(point,p.points));
}
export function activeBlockers(map,state){
  const props=(map.blockers||[]).filter(b=>b.collision);
  const towers=(map.towerColliders||[]).filter(t=>!state.destroyedTowers?.has(t.id));
  const gate=state.enemyBaseLocked ? [map.enemyBaseGate] : [];
  return {props,towers,gate};
}
export function clampWorld(p,w=1200,h=2600){
  return {x:Math.max(0,Math.min(w,p.x)),y:Math.max(0,Math.min(h,p.y))};
}
export function nearestValidPoint(point, polygons, step=8, maxRadius=240){
  if(isWalkable(point,polygons)) return point;
  for(let r=step;r<=maxRadius;r+=step){
    for(let a=0;a<360;a+=15){
      const rad=a*Math.PI/180;
      const p={x:point.x+Math.cos(rad)*r,y:point.y+Math.sin(rad)*r};
      if(isWalkable(p,polygons)) return p;
    }
  }
  return null;
}
export function towerCollisionEnabled(towerId,state){
  return !state.destroyedTowers?.has(towerId);
}
export function enemyBaseGateEnabled(state){
  return state.completedLanes<1;
}
