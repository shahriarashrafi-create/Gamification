export const MATCH_PHASES = Object.freeze({
  HOME:'home',
  PREBATTLE:'prebattle',
  READY:'match_ready',
  RUNNING:'match_running',
  TASK:'task_encounter',
  COMBAT:'combat_handoff',
  ENDING:'match_ending',
  RESULTS:'results'
});

export function canStartFromHome({
  playerValid,heroValid,heroAssetReady,eligibleTaskCount,
  settingsValid,mapValid,blockingActiveMatch
}){
  if(!playerValid) return {ok:false,reason:'player_invalid'};
  if(!heroValid || !heroAssetReady) return {ok:false,reason:'hero_invalid'};
  if((eligibleTaskCount||0)<1) return {ok:false,reason:'no_tasks'};
  if(!settingsValid) return {ok:false,reason:'settings_invalid'};
  if(!mapValid) return {ok:false,reason:'map_invalid'};
  if(blockingActiveMatch) return {ok:false,reason:'active_match'};
  return {ok:true};
}

export function towerHpSequence(hp=100,damage=34){
  const out=[hp];
  while(hp>0){
    hp=Math.max(0,hp-damage);
    out.push(hp);
  }
  return out;
}

export function baseHpSequence(hp=100,damage=25){
  const out=[hp];
  while(hp>0){
    hp=Math.max(0,hp-damage);
    out.push(hp);
  }
  return out;
}

export function nextObjectiveState(match,towerId){
  const objective={...match.objective};
  const towers={...objective.towers};

  if(!towers[towerId]) return {ok:false,reason:'tower_missing'};

  towers[towerId]={...towers[towerId],destroyed:true,hp:0};

  const [lane,slot]=towerId.split('_').slice(-2);

  if(slot==='1'){
    const nextId=`tower_${lane}_2`;
    if(towers[nextId]) towers[nextId]={...towers[nextId],unlocked:true};
  }

  let completedLanes=objective.completedLanes||0;
  const lane2=`tower_${lane}_2`;

  if(slot==='2' && towers[lane2]?.destroyed){
    completedLanes=Math.max(completedLanes,1);
  }

  return {
    ok:true,
    objective:{
      ...objective,
      towers,
      completedLanes,
      enemyBase:{
        ...objective.enemyBase,
        unlocked:completedLanes>=1
      }
    }
  };
}

export function resolveTerminalRace({
  baseDestructionCommittedAt=null,
  timeEndLockAt=null,
  manualExitLockAt=null
}){
  const events=[
    baseDestructionCommittedAt && {type:'victory',at:baseDestructionCommittedAt},
    timeEndLockAt && {type:'time_end',at:timeEndLockAt},
    manualExitLockAt && {type:'manual_exit',at:manualExitLockAt}
  ].filter(Boolean).sort((a,b)=>a.at-b.at);

  return events[0]?.type||null;
}

export function buildPlayableLoopSnapshot({
  matchId,status,resultType=null,heroPosition,
  timerState,waveState,worldState,objectiveState,fogState,
  encounterLock,transactions
}){
  return {
    matchId,status,resultType,heroPosition,
    timerState,waveState,worldState,objectiveState,
    fogState,encounterLock,transactions,
    persistedAt:Date.now()
  };
}

export function homeAfterResults({resultFinalized,playerStateLoaded}){
  return {
    restoreSystemBars:true,
    immersive:false,
    clearFinalizedActiveMatch:!!resultFinalized,
    refreshPlayerState:!!playerStateLoaded,
    launchRoute:'home'
  };
}
