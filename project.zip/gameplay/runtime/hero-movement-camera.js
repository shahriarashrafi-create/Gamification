export const MOVEMENT={
  maxSpeed:6.6, acceleration:4.2, deceleration:5.4, deadZone:0.12,
  exponent:1.35, deltaClamp:0.05, radius:2.3
};
export function shapeJoystick(x,y){
  const mag=Math.hypot(x,y);
  if(mag<=MOVEMENT.deadZone) return {x:0,y:0,magnitude:0};
  const nx=x/mag, ny=y/mag;
  const t=(mag-MOVEMENT.deadZone)/(1-MOVEMENT.deadZone);
  const shaped=Math.pow(Math.max(0,Math.min(1,t)),MOVEMENT.exponent);
  return {x:nx*shaped,y:ny*shaped,magnitude:shaped};
}
export function moveVelocity(v,input,dt){
  dt=Math.min(dt,MOVEMENT.deltaClamp);
  const target={x:input.x*MOVEMENT.maxSpeed,y:input.y*MOVEMENT.maxSpeed};
  const hasInput=input.magnitude>0;
  const rate=hasInput?MOVEMENT.acceleration:MOVEMENT.deceleration;
  const k=Math.min(1,rate*dt);
  return {x:v.x+(target.x-v.x)*k,y:v.y+(target.y-v.y)*k};
}
export function integratePosition(p,v,dt){
  dt=Math.min(dt,MOVEMENT.deltaClamp);
  return {x:p.x+v.x*dt,y:p.y+v.y*dt};
}
export function slideResolve(next,collision){
  if(!collision) return next;
  return {x:collision.blockX?collision.safeX:next.x,y:collision.blockY?collision.safeY:next.y};
}
export function cameraTarget(hero,velocity,bounds){
  const look=Math.max(-0.055,Math.min(0.055,velocity.y/6.6*0.055));
  return {
    x:Math.max(bounds.minX,Math.min(bounds.maxX,hero.x)),
    y:Math.max(bounds.minY,Math.min(bounds.maxY,hero.y-look))
  };
}
