const PRIORITY=['victory','hit','attack','recall','run','walk','idle'];
export function locomotionState(speed){
 if(speed>=0.62)return 'run';
 if(speed>=0.18)return 'walk';
 return 'idle';
}
export function resolveHeroState(flags,speed){
 const candidates={
  victory:!!flags.victory,
  hit:!!flags.hit,
  attack:!!flags.attack,
  recall:!!flags.recall,
  run:locomotionState(speed)==='run',
  walk:locomotionState(speed)==='walk',
  idle:locomotionState(speed)==='idle'
 };
 return PRIORITY.find(s=>candidates[s])||'idle';
}
export function facing8(vx,vy,lastFacing='S'){
 if(Math.hypot(vx,vy)<0.18)return lastFacing;
 const angle=(Math.atan2(vy,vx)*180/Math.PI+360)%360;
 const dirs=['E','SE','S','SW','W','NW','N','NE'];
 return dirs[Math.round(angle/45)%8];
}
export function attackSequence(target){
 return ['movement_soft_lock','face_'+target,'attack','projectile','impact','resume_locomotion'];
}
