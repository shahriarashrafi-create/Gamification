export function resolveTowerState(hp){hp=Math.max(0,Math.min(100,hp));if(hp===0)return'destroyed';if(hp<=33)return'critical';if(hp<=66)return'damaged';return'healthy'}
export function resolveBaseState(hp){hp=Math.max(0,Math.min(100,hp));if(hp===0)return'destroyed';if(hp<=25)return'collapse_ready';if(hp<=50)return'critical';if(hp<=75)return'unstable';return'stable'}
export function applyCommittedDamage(entity,amount,txId,seen){
 if(seen.has(txId)) return {entity,duplicate:true};
 seen.add(txId);
 entity.hp=Math.max(0,entity.hp-amount);
 entity.visualState=entity.type==='tower'?resolveTowerState(entity.hp):resolveBaseState(entity.hp);
 return {entity,duplicate:false,destroyed:entity.hp===0};
}
