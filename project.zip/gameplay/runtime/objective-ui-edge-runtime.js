export function edgeIndicator({targetScreen,viewport,safeInsets={top:80,right:20,bottom:150,left:20}}){
  const safe={
    left:safeInsets.left,
    right:viewport.width-safeInsets.right,
    top:safeInsets.top,
    bottom:viewport.height-safeInsets.bottom
  };
  const onscreen=targetScreen.x>=safe.left && targetScreen.x<=safe.right &&
                 targetScreen.y>=safe.top && targetScreen.y<=safe.bottom;
  if(onscreen) return {visible:false};

  const cx=viewport.width/2, cy=viewport.height/2;
  const dx=targetScreen.x-cx, dy=targetScreen.y-cy;
  const mag=Math.hypot(dx,dy)||1;
  const ux=dx/mag, uy=dy/mag;

  const tx=ux>0?(safe.right-cx)/ux:ux<0?(safe.left-cx)/ux:Infinity;
  const ty=uy>0?(safe.bottom-cy)/uy:uy<0?(safe.top-cy)/uy:Infinity;
  const t=Math.max(0,Math.min(Math.abs(tx),Math.abs(ty)));

  return {
    visible:true,
    x:cx+ux*t,
    y:cy+uy*t,
    angleRadians:Math.atan2(dy,dx),
    clickable:false
  };
}

export function objectiveCardModel(recommendation, compass){
  if(!recommendation?.primary) return null;
  return {
    objectiveId:recommendation.primary.id,
    title:recommendation.primary.label,
    reason:recommendation.reason,
    direction:compass?.direction||null,
    distanceBand:compass?.distanceBand?.label||null,
    alternatives:(recommendation.alternatives||[]).slice(0,2).map(o=>({
      id:o.id,label:o.shortLabel||o.label
    }))
  };
}

export function chooseAlternative(current, alternativeId, now=Date.now()){
  return {
    ...current,
    playerPreference:{
      objectiveId:alternativeId,
      selectedAt:now,
      temporary:true
    }
  };
}

export function guidanceVisibility({taskEncounter,pause,resultType}){
  if(resultType) return {card:false,edge:false,freeze:false};
  if(taskEncounter) return {card:false,edge:false,freeze:false};
  if(pause) return {card:true,edge:true,freeze:true};
  return {card:true,edge:true,freeze:false};
}

export function switchTransition({reduceMotion=false}={}){
  return reduceMotion
    ? {outMs:0,inMs:0}
    : {outMs:120,inMs:180};
}
