export function taskEncounterView(task){
  return {
    title:task.title,
    rewards:{
      xp:Math.max(0,task.rewardSnapshot?.xp||0),
      gold:Math.max(0,task.rewardSnapshot?.gold||0),
      diamond:Math.max(0,task.rewardSnapshot?.diamond||0)
    },
    showDiamond:(task.rewardSnapshot?.diamond||0)>0,
    rtl:true
  };
}

export class TaskEncounterActionGuard {
  constructor(){ this.inFlight=false; this.action=null; }
  begin(action){
    if(this.inFlight) return {ok:false,reason:'action_in_flight'};
    this.inFlight=true; this.action=action;
    return {ok:true,action};
  }
  finish(){ this.inFlight=false; this.action=null; }
}

export function completeHandoff(taskCommitResult){
  if(!taskCommitResult?.committed){
    return {
      ok:false,
      keepSheet:true,
      unlockActions:true,
      attack:false,
      damage:false,
      reward:false,
      message:'ثبت کار کامل نشد. دوباره تلاش کن.'
    };
  }
  return {
    ok:true,
    keepSheet:false,
    sequence:[
      'sheet_exit','hero_face_target','attack_windup',
      'projectile','impact','authoritative_entity_commit',
      'reward_commit','feedback','resume'
    ]
  };
}

export function deferOutcome(){
  return {
    completed:false,attack:false,damage:false,reward:false,
    reservationState:'deferred_current_match'
  };
}

export function cancelOutcome(){
  return {
    completed:false,attack:false,damage:false,reward:false,
    closeEncounter:true
  };
}

export function rewardPreview(task){
  const r=task.rewardSnapshot||{};
  return {
    xp:Math.max(0,r.xp||0),
    gold:Math.max(0,r.gold||0),
    diamond:(r.diamond||0)>0?r.diamond:null,
    informationalOnly:true
  };
}
