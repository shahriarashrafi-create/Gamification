export function towerVisualState(hp){
  hp = Math.max(0, Math.min(100, hp));
  if (hp === 0) return 'destroyed';
  if (hp <= 33) return 'critical';
  if (hp <= 66) return 'damaged';
  return 'healthy';
}

export class TowerPipeline {
  constructor({match,tower,taskSnapshot,laneState,seenTx=new Set(),ledger=[]}){
    this.match=match;
    this.tower={...tower};
    this.taskSnapshot=taskSnapshot;
    this.laneState={...laneState};
    this.seenTx=seenTx;
    this.ledger=ledger;
    this.stage='READY';
    this.taskCommitted=false;
    this.rewardCommitted=false;
  }

  guard(){
    if(!this.match?.active) return {ok:false,reason:'match_inactive'};
    if(this.match.resultFinalized) return {ok:false,reason:'result_finalized'};
    if(!this.tower || this.tower.destroyed || this.tower.hp<=0) return {ok:false,reason:'tower_destroyed'};
    if(this.tower.locked) return {ok:false,reason:'tower_locked'};
    if(!this.taskSnapshot?.id) return {ok:false,reason:'task_snapshot_invalid'};
    return {ok:true};
  }

  once(txId){
    if(!txId || this.seenTx.has(txId)) return false;
    this.seenTx.add(txId);
    return true;
  }

  commitTask(txId){
    const g=this.guard();
    if(!g.ok) return g;
    if(!this.once(txId)) return {ok:false,duplicate:true};
    this.taskCommitted=true;
    this.stage='TASK_COMMITTED';
    return {ok:true,stage:this.stage};
  }

  commitDamage(txId,damage=34){
    if(!this.taskCommitted) return {ok:false,reason:'task_not_committed'};
    if(!this.once(txId)) return {ok:false,duplicate:true,hp:this.tower.hp};
    const before=this.tower.hp;
    const after=Math.max(0,before-damage);
    this.tower={...this.tower,hp:after,visualState:towerVisualState(after)};
    this.stage='DAMAGE_COMMIT';
    return {ok:true,before,after,damageApplied:before-after,state:this.tower.visualState};
  }

  commitReward(txId){
    if(this.stage!=='DAMAGE_COMMIT') return {ok:false,reason:'damage_not_committed'};
    if(!this.once(txId)) return {ok:false,duplicate:true};
    const reward={
      xp:Math.max(0,this.taskSnapshot.xp||0),
      gold:Math.max(0,this.taskSnapshot.gold||0),
      diamond:Math.max(0,this.taskSnapshot.diamond||0)
    };
    this.ledger.push({txId,type:'tower_task_reward',towerId:this.tower.id,reward,committed:true});
    this.rewardCommitted=true;
    this.stage='REWARD_COMMIT';
    return {ok:true,reward};
  }

  commitDestruction(txId){
    if(this.tower.hp!==0) return {ok:false,reason:'tower_hp_not_zero'};
    if(!this.once(txId)) return {ok:false,duplicate:true};
    this.tower={
      ...this.tower,
      destroyed:true,
      interactionEnabled:false,
      objectiveState:'completed',
      visualState:'destroyed'
    };
    this.stage='DESTRUCTION_COMMIT';
    return {ok:true};
  }

  commitDestructionBonus(txId){
    if(!this.tower.destroyed) return {ok:false,reason:'destruction_not_committed'};
    if(!this.once(txId)) return {ok:false,duplicate:true};
    const reward=this.tower.tier===1 ? {xp:150,gold:60,diamond:0} : {xp:220,gold:90,diamond:0};
    this.ledger.push({txId,type:'tower_destruction_bonus',towerId:this.tower.id,reward,committed:true});
    this.stage='DESTRUCTION_BONUS';
    return {ok:true,reward};
  }

  releaseCollision(txId){
    if(!this.tower.destroyed) return {ok:false,reason:'destruction_not_committed'};
    if(!this.once(txId)) return {ok:false,duplicate:true};
    this.tower={...this.tower,collisionEnabled:false};
    this.stage='COLLISION_RELEASE';
    return {ok:true};
  }

  commitLaneProgress(txId){
    if(!this.tower.destroyed) return {ok:false,reason:'destruction_not_committed'};
    if(!this.once(txId)) return {ok:false,duplicate:true};

    if(this.tower.tier===1){
      this.laneState={...this.laneState,tower1Destroyed:true,tower2Unlocked:true,state:'tower2_active'};
    }else{
      this.laneState={...this.laneState,tower2Destroyed:true,complete:true,state:'complete'};
    }

    this.stage='LANE_PROGRESS';
    return {ok:true,laneState:this.laneState};
  }

  defer(){
    const g=this.guard(); if(!g.ok) return g;
    this.stage='READY';
    return {ok:true,damage:false,reward:false,towerAvailable:true};
  }

  cancel(){
    const g=this.guard(); if(!g.ok) return g;
    this.stage='READY';
    return {ok:true,damage:false,reward:false,keepObjective:true};
  }
}
