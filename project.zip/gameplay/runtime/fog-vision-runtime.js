export function makeFogGrid({worldWidth=1200,worldHeight=2600,cellSize=40}={}){
  const cols=Math.ceil(worldWidth/cellSize), rows=Math.ceil(worldHeight/cellSize);
  return {
    cellSize, cols, rows,
    cells:Array.from({length:cols*rows},()=>({state:'unseen'}))
  };
}

function idx(grid,c,r){ return r*grid.cols+c; }

export function updateFog(grid, hero, radius=120, now=Date.now()){
  const r2=radius*radius, cs=grid.cellSize;
  const minC=Math.max(0,Math.floor((hero.x-radius)/cs));
  const maxC=Math.min(grid.cols-1,Math.floor((hero.x+radius)/cs));
  const minR=Math.max(0,Math.floor((hero.y-radius)/cs));
  const maxR=Math.min(grid.rows-1,Math.floor((hero.y+radius)/cs));

  const next={...grid,cells:grid.cells.map(c=>({...c}))};
  const dirty=[];

  for(let i=0;i<next.cells.length;i++){
    if(next.cells[i].state==='visible'){
      next.cells[i].state='known';
      dirty.push(i);
    }
  }

  for(let r=minR;r<=maxR;r++){
    for(let c=minC;c<=maxC;c++){
      const cx=c*cs+cs/2, cy=r*cs+cs/2;
      const dx=cx-hero.x, dy=cy-hero.y;
      if(dx*dx+dy*dy<=r2){
        const i=idx(next,c,r);
        if(next.cells[i].state!=='visible'){
          next.cells[i].state='visible';
          next.cells[i].discoveredAt=next.cells[i].discoveredAt||now;
          next.cells[i].lastVisibleAt=now;
          dirty.push(i);
        } else {
          next.cells[i].lastVisibleAt=now;
        }
      }
    }
  }
  return {grid:next,dirty:[...new Set(dirty)]};
}

export function fogAtWorld(grid,pos){
  const c=Math.max(0,Math.min(grid.cols-1,Math.floor(pos.x/grid.cellSize)));
  const r=Math.max(0,Math.min(grid.rows-1,Math.floor(pos.y/grid.cellSize)));
  return grid.cells[idx(grid,c,r)]?.state||'unseen';
}

export function entityFogPresentation(entity,grid){
  if(entity.kind==='hero' || entity.kind==='own_base') return {show:true,state:'visible',opacity:1};
  const state=fogAtWorld(grid,entity.position);

  if(entity.kind==='minion'){
    return {show:state==='visible',state,opacity:state==='visible'?1:0};
  }

  if(state==='unseen') return {show:false,state,opacity:0};
  if(state==='known') return {show:true,state,opacity:.35};
  return {show:true,state,opacity:1};
}

export function objectiveFogGuidance(objective,grid,hero){
  const state=fogAtWorld(grid,objective.position);
  if(state==='visible') return {mode:'exact',state,position:objective.position};
  if(state==='known') return {mode:'exact_dim',state,position:objective.position};

  const dx=objective.position.x-hero.x, dy=objective.position.y-hero.y;
  const angle=Math.atan2(dy,dx);
  return {mode:'direction_only',state:'unseen',angleRadians:angle,exactPosition:null};
}

export function shouldRecalculateVision(prevHero,hero,threshold=10){
  if(!prevHero) return true;
  const dx=hero.x-prevHero.x, dy=hero.y-prevHero.y;
  return dx*dx+dy*dy>=threshold*threshold;
}
