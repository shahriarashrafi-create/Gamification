const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));

export class FrameMonitor {
  constructor({
    sampleSize=120,
    degradeAverageMs=22,
    upgradeAverageMs=15,
    cooldownMs=30000,
    initialTier='balanced'
  }={}){
    this.samples=[];
    this.sampleSize=sampleSize;
    this.degradeAverageMs=degradeAverageMs;
    this.upgradeAverageMs=upgradeAverageMs;
    this.cooldownMs=cooldownMs;
    this.tier=initialTier;
    this.lastTierChangeAt=0;
  }

  push(frameMs,now=performance.now()){
    this.samples.push(frameMs);
    if(this.samples.length>this.sampleSize) this.samples.shift();
    if(this.samples.length<this.sampleSize) return this.tier;

    const avg=this.samples.reduce((a,b)=>a+b,0)/this.samples.length;
    if(now-this.lastTierChangeAt<this.cooldownMs) return this.tier;

    if(avg>this.degradeAverageMs){
      if(this.tier==='high') this.tier='balanced';
      else if(this.tier==='balanced') this.tier='battery';
      this.lastTierChangeAt=now;
    }else if(avg<this.upgradeAverageMs){
      if(this.tier==='battery') this.tier='balanced';
      else if(this.tier==='balanced') this.tier='high';
      this.lastTierChangeAt=now;
    }
    return this.tier;
  }

  average(){
    if(!this.samples.length) return 0;
    return this.samples.reduce((a,b)=>a+b,0)/this.samples.length;
  }
}

export function clampedDeltaSeconds(now,last,maxDeltaMs=50){
  const ms=clamp(now-last,0,maxDeltaMs);
  return ms/1000;
}

export class FixedStep {
  constructor(hz=30){
    this.step=1/hz;
    this.accumulator=0;
  }
  consume(dt,fn){
    this.accumulator+=dt;
    let steps=0;
    while(this.accumulator>=this.step && steps<4){
      fn(this.step);
      this.accumulator-=this.step;
      steps++;
    }
    return steps;
  }
}

export class ObjectPool {
  constructor(create,size=8){
    this.create=create;
    this.free=[];
    this.used=new Set();
    for(let i=0;i<size;i++) this.free.push(create(i));
  }
  acquire(){
    const item=this.free.pop() ?? this.create(Date.now());
    this.used.add(item);
    return item;
  }
  release(item){
    if(!this.used.has(item)) return;
    this.used.delete(item);
    this.free.push(item);
  }
}

export function shouldUpdateFog({hero,lastFogHero,threshold=10,lastUpdateAt,now,throttleMs=150}){
  if(!lastFogHero) return true;
  if(now-lastUpdateAt<throttleMs) return false;
  const d=Math.hypot(hero.x-lastFogHero.x,hero.y-lastFogHero.y);
  return d>=threshold;
}

export function shouldRenderMinion(minion){
  return !!(
    minion &&
    minion.persisted &&
    !minion.despawned &&
    !minion.defeated &&
    minion.fogState==='visible'
  );
}

export function qualityProfile(tier){
  if(tier==='high') return {
    targetFps:60,particleFactor:1,blur:true,ambientParticles:true,shadowFactor:1
  };
  if(tier==='battery') return {
    targetFps:30,particleFactor:.35,blur:false,ambientParticles:false,shadowFactor:.25
  };
  return {
    targetFps:60,particleFactor:.65,blur:false,ambientParticles:false,shadowFactor:.55
  };
}

export class RafLoop {
  constructor(update,render){
    this.update=update;
    this.render=render;
    this.running=false;
    this.rafId=null;
    this.last=0;
  }
  start(){
    if(this.running) return false;
    this.running=true;
    this.last=performance.now();

    const tick=(now)=>{
      if(!this.running) return;
      const dt=clampedDeltaSeconds(now,this.last,50);
      this.last=now;
      this.update(dt,now);
      this.render(dt,now);
      this.rafId=requestAnimationFrame(tick);
    };

    this.rafId=requestAnimationFrame(tick);
    return true;
  }
  stop(){
    if(!this.running) return false;
    this.running=false;
    if(this.rafId!=null) cancelAnimationFrame(this.rafId);
    this.rafId=null;
    return true;
  }
}

export function canvasBackingSize(cssWidth,cssHeight,dpr=window.devicePixelRatio||1){
  const capped=Math.min(dpr,2);
  return {
    width:Math.round(cssWidth*capped),
    height:Math.round(cssHeight*capped),
    dpr:capped
  };
}
