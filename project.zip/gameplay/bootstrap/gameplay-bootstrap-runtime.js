export function validateGameplayBootstrap(match, activeMatchId){
  if(!match || match.id!==activeMatchId) return {ok:false,reason:'active_match_mismatch'};
  if(!['ready','running'].includes(match.status)) return {ok:false,reason:'invalid_match_status'};
  const s=match.snapshots;
  if(!s?.settings || !s?.hero || !s?.taskPool?.length || !s?.map)
    return {ok:false,reason:'snapshot_invalid'};
  return {ok:true};
}

export function resolveInitialHeroPosition(match, nearestValid){
  const candidate = match.status==='running'
    ? match.worldState?.heroPosition
    : match.snapshots?.map?.heroSpawn;
  if(!candidate) return {ok:false,reason:'hero_position_missing'};
  return {ok:true,position:nearestValid(candidate),animatedTeleport:false};
}

export function initializeCamera(heroPosition){
  return {
    ready:true,
    heroPosition,
    screenTarget:{x:.50,y:.63},
    visibleAfterInit:true
  };
}

export function hydrateEntities(match){
  const towers=match.worldState?.towers||{};
  return {
    towers:Object.entries(towers).map(([id,hp])=>({id,hp,source:'committed_world_state'})),
    enemyBase:{id:'base_enemy',hp:match.worldState?.enemyBaseHP,source:'committed_world_state'},
    minions:(match.worldState?.minions||[]).filter(m=>m.persisted && m.reservationId)
  };
}

export function commitGameplayStart(match, nowIso=new Date().toISOString()){
  if(match.status==='running' && match.timerState?.startedAt){
    return {ok:true,idempotent:true,match};
  }
  if(match.status!=='ready') return {ok:false,reason:'match_not_ready'};
  const startedAt=match.timerState?.startedAt||nowIso;
  return {
    ok:true,
    match:{
      ...match,
      status:'running',
      bootstrapStartTxId:match.bootstrapStartTxId||`game_start_${match.id}`,
      timerState:{...match.timerState,state:'running',startedAt},
      waveState:{...match.waveState,state:'running',lastWaveIndex:match.waveState?.lastWaveIndex||0},
      controlsEnabled:false
    }
  };
}

export function firstPlayableFrameGate(state){
  const checks=[
    state.worldHydrated,state.heroVisible,state.heroPositionValid,state.cameraReady,
    state.collisionReady,state.hudBound,state.timerRunning,state.waveSchedulerRunning,
    state.surfaceReady
  ];
  if(checks.some(v=>!v)) return {ok:false,controlsEnabled:false};
  return {ok:true,controlsEnabled:true,firstPlayableFrame:true};
}

export function bootstrapFailure(match, reason){
  return {
    match:{...match,status:'recoverable',bootstrapError:reason,controlsEnabled:false},
    stopTimer:true,
    stopWaves:true,
    exitImmersive:true,
    grantRewards:false,
    route:'safe_recovery'
  };
}
