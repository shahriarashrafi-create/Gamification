# STEP 96 — PRIMARY MODULES PERSISTENT UI HARDENING

در این مرحله پنج بخش اصلی اپ از Shell اولیه خارج می‌شوند و قابل استفاده‌تر می‌شوند.

## 1. Tasks

قابلیت‌ها:

Add
Edit
Archive
Permanent Delete
Toggle activeInGame
Category
Difficulty
XP
Gold
Diamond
Search

Permanent Delete فقط داخل Tasks Management مجاز است.

Task Encounter هیچ حذف دائمی انجام نمی‌دهد.

## 2. Stats

فقط Network Tree.

قابلیت‌ها:

Add Member
Edit Member
Remove Member
Expand/Collapse
Search

Root حذف نمی‌شود.

## 3. Timesheet

Saturday-first weekly planner.

قابلیت‌ها:

Add entry
Delete entry
Mark complete
Date
Start
End
Category

## 4. Networking

CRM:

Prospects
Action log

Action types:

ارتباط‌سازی
پیش‌مشاوره
دعوت
معرفی کار
فالوآپ

قابلیت‌ها:

Add Prospect
Delete Prospect
Add Action
Timeline

## 5. Persistence

تمام تغییرات از AppStore می‌گذرند و persistent هستند.

## Step 97

SECONDARY MODULES REAL UI + SHOP / EVENTS / VISION / ACHIEVEMENTS / HERO HUB / SETTINGS
