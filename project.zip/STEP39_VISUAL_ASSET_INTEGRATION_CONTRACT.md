# SHAHRIAR GAME — STEP 39
## VISUAL ASSET INTEGRATION CONTRACT

مرجع رسمی ورود Assetهای واقعی به اپ و حذف Placeholderها.

## 1. Goal
Hero، Background، Minion، Tower، Base، Icon و VFX باید با قرارداد واحد وارد Runtime شوند تا ظاهر نهایی روی موبایل حرفه‌ای، سریع و بدون Crop/Jump باشد.

## 2. Production Rule
CSS human silhouettes, emoji icons and text glyph entities are prototype-only.
Production QA rejects them.

## 3. Asset Families
heroes
backgrounds
battlefield
entities
ui
icons
vfx

## 4. Hero Source
Master:
2048×3072 transparent PNG/WebP source.

Runtime preferred:
1024×1536 WebP
512×768 WebP fallback.

## 5. Hero Composition
Full body visible.
Transparent background.
Feet and floor contact preserved.
Consistent camera perspective across Hero catalog.

## 6. Hero Lobby Crop
Use object-fit contain.
Never cover/crop head or feet merely to fill stage.

## 7. Hero Safe Box
Hero art metadata includes:
visualBounds
footAnchor
headAnchor
recommendedScale
recommendedYOffset

## 8. Background Source
Master portrait:
1440×3200 or higher.

Runtime variants:
1080×2400
720×1600

## 9. Background Crop
Use cover only with authored safe region.
Important architecture must remain inside center safe zone.

## 10. Home Layers
background
atmosphere_back
hero_backlight
hero
foreground_pedestal
ui

## 11. Gameplay Layers
terrain
lane_marks
environment_props
entities
projectiles
vfx
fog
world_hud
screen_hud

## 12. Entity Assets
Minion:
idle/walk/hit/defeat where needed.

Tower:
healthy/damaged/critical/destroyed.

Base:
stable/unstable/critical/collapse_ready/destroyed.

## 13. Entity Anchors
Every entity manifest:
pivotX
pivotY
collisionRadius
interactionAnchor
healthBarAnchor
projectileHitAnchor

## 14. VFX
Task impact
projectile
tower hit
tower destroy
base implosion
victory shockwave
reward fly-up
rank flare
unlock reveal

## 15. VFX Format
Small sprite sequence/WebP/optimized texture sequence where practical.
Avoid huge full-screen videos.

## 16. Icons
SVG for simple UI icons.
Unified 24px optical grid.
No emoji in production.

## 17. Currency
Gold:
dedicated coin/crest asset.

Diamond:
dedicated cyan crystal asset.

XP:
dedicated progression sigil.

No Energy asset.

## 18. Naming
hero_<id>_<pose>_<size>.webp
bg_<screen>_<variant>_<size>.webp
entity_<type>_<id>_<state>.webp
icon_<name>_<state>.svg
vfx_<name>_<variant>.webp
ui_<component>_<variant>.svg

## 19. Manifest
Every runtime asset records:
id
family
path
width
height
format
required
fallbackId
preloadGroup
version
source/license metadata

## 20. Preload Groups
boot_critical
home_critical
match_critical
hero_hub
secondary_lazy
vfx_lazy

## 21. Boot Critical
Only minimum UI shell and required fonts/config.
Do not preload entire art catalog.

## 22. Home Critical
selected Hero
Home background
rank frame
currency icons
CTA ornaments
four module icons

## 23. Match Critical
battlefield
selected Hero gameplay asset
own/enemy base
tower states
actionable Minion
HUD icons
core impact/projectile VFX

## 24. Lazy Loading
Unselected Heroes
Shop cosmetics
future Event art
Vision images
noncritical VFX

## 25. Cache
Versioned asset keys.
Invalidate only changed asset versions where possible.

## 26. Placeholder Fallback
Development:
designed geometric placeholder allowed.

Production:
missing required Hero/background/entity blocks release QA.

## 27. Fallback Order
requested asset
declared fallback asset
designed generic production fallback
error state

Never emoji fallback.

## 28. Layout Reservation
Reserve image aspect ratio and stage bounds before decode.
No UI jump when image arrives.

## 29. Responsive Hero
360×800:
~34–38vh visual target.

390×844:
~37–41vh.

430×932:
~40–44vh.

CTA/module visibility wins over oversized Hero.

## 30. Density
Do not load source-resolution 2048px Hero when 512/1024 variant is enough.

## 31. Compression
WebP preferred for raster runtime.
Quality tuned visually.
Transparent Hero edges must remain clean.

## 32. Color
Do not bake UI labels into artwork.
UI text remains live Persian text.

## 33. Localization
Backgrounds and Hero art contain no language-dependent text.

## 34. Licensing
Each external/generated asset records origin, generation/source notes and usage rights status before final release.

## 35. Asset Validation
Check:
file exists
dimensions
format
alpha if required
manifest ID unique
fallback exists
production placeholder policy
file size threshold

## 36. Missing Critical Asset
Do not collapse layout.
Use designed fallback frame and log asset ID.
Match cannot begin if deterministic required entity asset policy marks it blocking.

## 37. Performance
Home critical visual payload target around <=3MB compressed where practical.
Lazy load secondary art.
Bound decoded textures.

## 38. Prototype
Step39 includes manifest examples and an Asset Integration Lab showing full-body contain vs bad crop, fallback chain and preload groups.

## 39. Failure Conditions
Hero head/feet cropped
giant source image loaded unnecessarily
emoji final icon
CSS silhouette ships
text baked into background
missing asset shifts CTA
all Heroes preload at boot
Energy icon appears

## 40. Quality Gate
Production visual build cannot pass until every required visual slot resolves to an approved real asset or approved production fallback.

## STEP 40
PRODUCTION ASSET GENERATION / HERO & HOME ART PACK
Create the first real visual pack: selected full-body Hero, Home fantasy citadel background, rank frame, module icons, currency icons and CTA ornament set.
