# SHAHRIAR GAME — STEP 30
## PAUSE / LIFECYCLE / ANDROID IMMERSIVE RECOVERY

مرجع رسمی Pause، Android Back، background/foreground، Immersive Mode و Active Match Recovery.

## 1. Goal
خروج موقت از اپ، خاموش شدن صفحه، تماس، notification یا Android Back نباید Match را خراب کند.

## 2. Pause States
active
pause_requested
paused
resume_requested
active

## 3. Pause Button
HUD Pause opens tactical Pause Sheet.
Movement and context action lock immediately.

## 4. Pause Sheet
ادامه بازی
تنظیمات سریع
خروج از Match

No Bottom Nav.

## 5. Timer During Manual Pause
Default: paused.
This is separate from timerRunsDuringTask.

## 6. Wave Scheduler During Pause
Paused.
No actionable Minion spawn while paused.

## 7. Encounter
If user pauses during ordinary Encounter before commit:
Encounter state preserved.
If atomic commit is running:
finish atomic commit first, then pause.

## 8. Android Back — Active Match
First Back opens Pause Sheet.
Never instantly exits app or Match.

## 9. Android Back — Pause
Back closes Pause Sheet and resumes.

## 10. Android Back — Result
Return Home.
Do not reopen stale destroyed battlefield.

## 11. Exit Match
Requires explicit confirmation:
«از Match خارج می‌شوی؟ پاداش‌های ثبت‌شده حفظ می‌شوند.»

## 12. Exit Rewards
Keep already committed rewards.
No Victory bonus.
No natural Match completion bonus unless final economy explicitly changes rule.

## 13. Background
On app background:
clear touch pointers
soft-stop Hero
persist active Match checkpoint
pause gameplay clock by default
release transient audio/haptics

## 14. Foreground
On return:
recompute viewport
restore active Match state
reapply immersive
camera clamps/follows Hero
controls remain neutral
show short Resume state
then resume timer.

## 15. Focus Loss
Never keep joystick pointer active.
No phantom movement after return.

## 16. Screen Lock
Handled like background.
Persist checkpoint.

## 17. Process Death
Persisted Match can be recovered.
Fresh app launch STILL opens Home.

## 18. Recovery Offer
Home may show compact:
«یک Match نیمه‌تمام داری»
ادامه
پایان Match

Never auto-enter gameplay.

## 19. Recovery Data
matchId
schemaVersion
state
heroPosition
camera-relevant state
timerRemaining
lane states
entity HP/states
task reservations
committed transactions
current encounter snapshot if safe
fog discovery
match settings snapshot
updatedAt

## 20. Recovery Validation
Reject/close corrupt incompatible checkpoint safely.
Never duplicate reward transaction.

## 21. Recovery Encounter
If encounter was open but no commit:
restore encounter safely if task/entity link valid.
If commit transaction already finalized:
restore post-commit state, not pre-commit button.

## 22. Atomic Commit
App lifecycle event cannot interrupt reward/damage consistency.
Persist transaction journal.

## 23. Immersive Scope
Only Pre-Battle transition + Match + Pause + Match Result.
Normal Home/modules restore system bars.

## 24. Android 11+
Use WindowInsetsController:
hide statusBars + navigationBars
systemBarsBehavior = transient bars by swipe.

## 25. Older Android
Use IMMERSIVE_STICKY fallback.

## 26. Reapply
Reapply immersive on:
window focus gained
visibility resume
app foreground
return from temporary system overlay

## 27. Exit Immersive
Before routing Home:
set immersive false
restore system bars
then Home layout recalculates safe areas.

## 28. System Swipe
Transient system bars may appear by swipe.
Gameplay must tolerate viewport inset changes without permanent layout shift.

## 29. Orientation
Portrait locked.
Lifecycle recovery does not rotate game.

## 30. Audio
Background: pause/mute battle audio.
Foreground: resume only after active state restored.
Respect user audio settings.

## 31. Haptics
No haptic loop in background.
No duplicate victory haptic after recovery.

## 32. Timer Integrity
Use monotonic session accounting + persisted remaining time.
Do not trust only setInterval ticks.

## 33. Background Time Rule
Default Match clock pauses while app is backgrounded.
Configurable later, but snapshot per Match.

## 34. Pause Abuse
This is a productivity game, not competitive multiplayer.
No punitive anti-pause system required.

## 35. Error Recovery
If native immersive call fails, gameplay remains functional.
Log failure and continue with safe viewport.

## 36. Mobile Safe Areas
After system bars restore/hide:
recompute 100dvh/insets.
CTA/joystick never trapped under gesture bar.

## 37. Prototype
Step30 concept simulates Active → Pause → Background → Foreground → Resume → Exit confirmation.

## 38. QA
Test:
Home→Match immersive
Back→Pause
Back→Resume
background→foreground
screen lock
system bar swipe
Result→Home
process recovery offer
no phantom joystick
no duplicated reward

## 39. Failure Conditions
Back exits Match instantly
timer continues unexpectedly in background
phantom movement
duplicate rewards
fresh launch auto-enters Match
Home stays immersive
camera jumps to origin
corrupt recovery crashes app

## 40. Quality Gate
Any lifecycle interruption must return the player to a deterministic, safe and reward-consistent state.

## STEP 31
APP NAVIGATION / ROUTE & STATE ARCHITECTURE
Canonical five-tab shell, secondary routes, gameplay route isolation, fresh-launch Home, back-stack rules and global app state.
