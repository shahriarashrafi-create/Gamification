# SHAHRIAR GAME — STEP 37
## AUDIO / HAPTICS / FEEDBACK SYSTEM

مرجع رسمی صدا، موسیقی، Haptic و بازخوردهای حسی کل اپ.

## 1. Goal
هر اقدام مهم باید حس واضح و باکیفیت داشته باشد، بدون شلوغی صوتی یا لرزش آزاردهنده.

## 2. Audio Buses
master
music
battle
ui
ambient

## 3. Default Volume
master 100
music 55
battle 80
ui 70
ambient 45

## 4. Home
Low-volume fantasy citadel ambience.
No aggressive battle loop.

## 5. Gameplay Music
Adaptive layers:
exploration
objective pressure
tower danger
final base
victory

Transitions crossfade smoothly.

## 6. Task Encounter
Open: subtle focus cue.
Complete commit: confirmation cue.
Attack: Hero attack sound.
Impact: target-specific impact.
Reward: compact reward chime.

## 7. Minion
Light impact.
Short defeat cue.
Never louder than Tower/Base.

## 8. Tower
Hit:
metal/arcane impact.
Critical:
low warning texture.
Destroy:
heavy collapse + arcane discharge.

## 9. Enemy Base
Final impact is strongest gameplay feedback.
Implosion
shockwave
victory rise

No strobing audio/visual spam.

## 10. Victory
Music resolves into short victory theme.
Do not replay after lifecycle recovery.

## 11. Time End
Neutral completion cue.
Never use defeat/failure sound.

## 12. UI Sounds
tap
confirm
back
open_sheet
close_sheet
purchase
unlock
achievement_ready
error_soft

## 13. Currency
Gold gain:
short metallic shimmer.
Diamond gain:
rare crystal tone only if Diamond > 0.

## 14. Rank Up
Distinct ceremonial cue.
Separate from Level Up.

## 15. Hero Unlock
Premium reveal sound.
No gameplay-power implication.

## 16. Haptic Families
tap_light
confirm_medium
task_complete
impact_light
tower_hit
tower_destroy
base_destroy
reward
rank_up
error
warning

## 17. Haptic Intensity
User setting:
off
light
normal
strong

Default normal.

## 18. Joystick
No continuous vibration.
Optional tiny haptic only on meaningful contextual state, not movement.

## 19. Task Complete Haptic
One confirmation pulse.
Impact may add separate short pulse after animation timing.

## 20. Tower Destroy Haptic
Strong but short pattern.
Reduce Haptics setting respected.

## 21. Base Victory Haptic
Strongest allowed pattern, still brief.
Never loop.

## 22. Error Haptic
Short restrained pulse.
No harsh repeated buzz.

## 23. Background
Pause/mute battle and music when app backgrounds.
No haptic while backgrounded.

## 24. Foreground
Resume audio only after lifecycle state restored.
Avoid duplicate start cue.

## 25. Pause
Battle music ducks/fades.
Ambient can remain very low.
Resume crossfades.

## 26. Encounter
Battle mix ducks under Task Sheet.
Task readability and concentration take priority.

## 27. Audio Focus
Respect Android audio focus.
Incoming call/media interruption pauses or ducks appropriately.

## 28. Silent Mode
Haptics and sound respect user/system behavior where platform policy applies.

## 29. Settings
Master Sound
Music
Battle SFX
UI SFX
Ambient
Haptics
Haptic Intensity

## 30. Quick Pause Settings
Allow:
music
sound
haptics
No deterministic Match rules.

## 31. Accessibility
No essential information conveyed only by sound/haptic.
Visual/text state always exists.

## 32. Reduce Motion
Does not automatically disable audio.
Separate controls remain.

## 33. Asset Format
Prefer compressed mobile-friendly audio.
Short SFX preloaded.
Long ambience/music streamed/decoded efficiently as platform permits.

## 34. Concurrency
Cap simultaneous impact SFX.
Prevent six Minions from producing clipping/noise burst.

## 35. Cooldown
Repeated UI taps use tiny cooldown/dedup.
Transaction reward sound plays once per committed transaction.

## 36. Persistence
Audio/Haptic settings persist.
Match lifecycle remembers current music layer but recovery restarts safely without duplicate stinger.

## 37. Prototype
Step37 concept simulates buses, haptic intensity and event feedback timeline.

## 38. QA
No joystick vibration loop
Diamond cue only if earned
Time End not defeat sound
Victory cue no duplicate after recovery
background silent
pause ducking
settings persist
audio not required for state comprehension

## 39. Failure Conditions
sound spam
clipping
haptic loop
Victory stinger repeats
Diamond sound at zero
background audio continues unexpectedly
UI feedback ignores mute
audio implies Hero combat power

## 40. Quality Gate
Audio and haptics reinforce real task → combat → reward while remaining restrained, configurable and lifecycle-safe.

## STEP 38
ANIMATION / MOTION / TRANSITION SYSTEM
App transitions, Hero lobby motion, battlefield micro-animation, reward choreography, reduced-motion variants and frame-budget rules.
