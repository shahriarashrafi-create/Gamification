# STEP 63 — MINION TASK RESERVATION + SPAWN RUNTIME INTEGRATION

این مرحله Wave System را به Task Pool واقعی وصل می‌کند.

## Core Rule

هر Minion actionable دقیقاً یک Task reservation معتبر دارد.

Minion بدون Task reservation:
visual-only نیست و به عنوان objective spawn نمی‌شود.

## Wave Timing

Default:
هر 45 ثانیه

Scheduler:
wave_1
wave_2
wave_3
...

Spawn فقط وقتی Match active باشد.

Pause:
scheduler متوقف می‌شود.

Background:
scheduler به‌صورت امن persist می‌شود.

## Lane Spawn

Lane A
Lane B
Lane C

Spawn cap:
حداکثر 6 Minion actionable در کل Match
حداکثر 2 Minion actionable در هر Lane

## Task Pool

Eligible Task:
active
activeInGame = true
not deferred_current_match
not cancelled_current_encounter
not reserved by another active Minion
not already completed if one-time

## Reservation States

available
reserved
completed
deferred_current_match
released
expired

## Reservation Flow

Task available
→ reserve with reservationId
→ create Minion
→ bind minionId + taskId + reservationId
→ persist
→ spawn

## Duplicate Prevention

یک Task نمی‌تواند هم‌زمان به دو Minion فعال وصل باشد.

Unique guard:
taskId + active reservation

## Reuse

Reusable Tasks:
فقط وقتی تمام Taskهای unused تمام شدند، می‌توانند recycle شوند.

One-time Tasks:
هیچ‌وقت recycle نمی‌شوند.

## Defer

وقتی کار Minion روی «بعداً» می‌رود:

reservation state = deferred_current_match
Minion objective invalidates
Minion از encounter خارج می‌شود
Task تا پایان همین Match دوباره assign نمی‌شود
Minion بعد از feedback despawn می‌شود

## Cancel Encounter

Cancel:
reservation آزاد نمی‌شود
Task حذف نمی‌شود
Minion باقی می‌ماند
encounter cooldown کوتاه می‌گیرد
دوباره قابل approach است

## Complete

Task completion committed
→ Minion defeated
→ reward committed
→ reservation completed
→ task released according to repeat mode
→ Minion despawn after feedback

## Spawn Position

Spawn point:
در walkable lane mesh معتبر

Minion نباید:
داخل Tower collider
داخل Base gate
داخل obstacle
روی Hero spawn
ظاهر شود.

## Lane Affinity

Wave scheduler lane انتخاب می‌کند بر اساس:
active minions per lane
lane progress
nearest open spawn slot

No forced teleport.

## Despawn

defeated
deferred
invalid reservation
match end

Despawn visual بعد از feedback.
Data cleanup بعد از committed state.

## Recovery

App restart:
active reservations بازسازی می‌شوند.

Orphan reservation:
اگر Minion وجود ندارد، safe release.

Orphan Minion:
اگر reservation معتبر ندارد، despawn بدون reward.

## Atomicity

reservation commit
قبل از spawn visual.

اگر spawn visual fail شود:
reservation rollback/release.

## QA

one Task cannot bind to two active Minions
each actionable Minion has exactly one real Task
max 6 active Minions globally
max 2 per lane
deferred Task never returns in same Match
cancel keeps reservation
complete commits once
one-time Task never recycled
reusable Task recycles only after unused pool exhausted
orphan reservation safely released
orphan Minion no reward
no fake task
no Energy

## STEP 64

MINION MOVEMENT + LANE PATH FOLLOWING

Minionها را از Spawn Point روی Lane path حرکت می‌دهیم و به Objective encounter position می‌رسانیم.
