# STEP 89 — MULTI-TARGET PRIORITY + STICKY TARGET + ENCOUNTER LOCK

وقتی چند Minion، Tower یا Base همزمان نزدیک Hero باشند، فقط یک Target معتبر انتخاب می‌شود و فقط یک Task Encounter می‌تواند باز باشد.

## Goal

No multi-sheet.
No target flicker.
No accidental Tower selection behind a closer actionable Minion.
No duplicate encounter transaction.

## Candidate Eligibility

Minion:
persisted
valid reservation
not defeated
not despawned
inside interaction eligibility

Tower:
unlocked
not destroyed
inside interaction eligibility

Enemy Base:
unlocked
not destroyed
inside interaction eligibility

Locked/invalid entities:
never candidate.

## Interaction Radii

Minion:
5.5 world units

Tower:
7.0

Enemy Base:
7.5

Exit hysteresis:
+1.5 world units

## Priority

1. Existing active encounter target
2. Existing sticky target while still valid
3. Actionable Minion in radius
4. Unlocked Tower in radius
5. Unlocked Enemy Base in radius

Within same type:
nearest target wins.

Tie:
stable entity ID ordering.

## Sticky Target

Once selected:
keep target until:

target becomes invalid
Hero exits exitRadius
target defeated/destroyed/despawned
reservation invalidated
encounter completes/deferred
explicit target clear

A slightly closer new entity does not steal focus.

## Hysteresis

Acquire radius:
entity interaction radius.

Release radius:
interaction radius + 1.5.

This prevents edge flicker.

## Encounter Lock

Global Match-level lock:

encounterLock = {
  encounterId
  targetId
  targetType
  openedAt
  state
}

Only one encounter lock may be active.

Opening another sheet while lock exists:
rejected.

## Open Flow

target selected
→ acquire encounter lock
→ validate target again
→ snapshot Task/reward
→ freeze target interaction state
→ open Task Sheet

If validation fails after lock:
release lock safely.

## Complete

Task pipeline owns lock until combat handoff reaches safe release point.

Do not release immediately on Complete tap.

This prevents another nearby entity from opening during attack animation.

## Defer

Apply defer transaction
→ close sheet
→ release encounter lock
→ clear sticky target
→ recompute target

## Cancel

Close sheet
→ release encounter lock
→ sticky target may remain if still valid

Short cooldown prevents immediate reopen loop.

Default cancel reopen cooldown:
700ms.

## Reopen Cooldown

Per target:
700ms after Cancel.

No cooldown required after Defeat/Destruction because target becomes invalid.

## Target Indicator

Only selected target gets:

outline/ring
name/type label
interaction cue

Other nearby candidates remain visually secondary.

## Task Sheet

Only selected target may open Task Sheet.

No stacked sheets.
No simultaneous modal.

## Pause

Pause:
target remains selected
encounter lock persists
no new target acquisition.

## Fog

Hidden entity cannot be newly acquired.

Existing focused encounter target remains logically owned while Task Sheet is open.

## Recovery

Persist active encounter lock + transaction stage.

On recovery:
validate lock target and pipeline.

If committed transaction exists:
reconcile.

If stale uncommitted lock:
release safely and recompute.

Never open two encounters after recovery.

## QA

only one selected target
only one encounter lock
only one Task Sheet
active encounter has highest priority
sticky valid target is preserved
actionable Minion beats Tower
Tower beats Base when both equally eligible by type priority
nearest same-type target wins
tie uses stable ID
hysteresis prevents boundary flicker
invalid target releases
defeated Minion releases
destroyed Tower releases
Cancel has 700ms reopen cooldown
Defer clears sticky target
Complete keeps lock through combat handoff
Pause prevents new acquisition
hidden entity cannot be newly acquired
recovery cannot duplicate encounter
no teleport
no Energy
no Mana

## STEP 90

FULL PLAYABLE MATCH LOOP INTEGRATION TEST

Home → PreBattle → Gameplay → Wave → Minion Task → Tower → Lane Complete → Base → Victory/TimeEnd → Results → Home را به عنوان یک End-to-End playable loop یکپارچه و QA می‌کنیم.
