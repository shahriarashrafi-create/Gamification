# SHAHRIAR GAME — 100 STEP REBUILD
## STEP 05 — REAL-WORLD TASK ENCOUNTER SYSTEM

این سند مرجع رسمی اتصال Task واقعی به Combat است.

---

# 1. اصل سیستم

هر Encounter باید این قانون را اجرا کند:

**Approach Target → Real Task → Confirm Action → Combat Feedback → Reward → Resume**

Task فقط یک Popup نیست.
Task همان «قدرت حمله» بازیکن در بازی است.

---

# 2. Encounter Trigger

Encounter فقط وقتی فعال می‌شود که:

- Hero داخل Trigger Radius باشد
- Entity زنده باشد
- Entity Unlock باشد
- Encounter دیگری باز نباشد
- Task معتبر وجود داشته باشد

State:
EXPLORE → NEAR_OBJECTIVE → ENCOUNTER

---

# 3. Encounter Priority

اگر چند Target نزدیک باشند:

1. داخل Trigger Radius
2. Alive
3. Unlocked
4. نزدیک‌ترین Entity
5. Entity Lane فعلی
6. Objective Progress بالاتر
7. Tower / Base در صورت فعال بودن مرحله

هدف:
هیچ Encounter اشتباه یا دوگانه باز نشود.

---

# 4. Task Pool

Task Pool فقط از Taskهای معتبر می‌آید.

Task Eligible:

- activeInGame = true
- deleted = false
- completedInCurrentMatch = false
- deferredInCurrentMatch = false
- category allowed
- difficulty allowed
- not locked by another encounter

---

# 5. Task Selection Strategy

نسخه پایه:

Priority Score:

- نزدیک به Difficulty موردنیاز Entity
- Task قدیمی‌تر
- Task با Priority بالاتر
- Taskی که در Match هنوز استفاده نشده

در آینده:
- Lane preference
- Category bias
- Time remaining
- Networking linked task

---

# 6. Duplicate Prevention

هر Task در یک Match فقط یک‌بار Active Encounter می‌شود.

Match Task State:

- unused
- active
- completed
- deferred
- cancelled_current

قانون:
Cancel Current Encounter باعث حذف دائمی Task نمی‌شود.

---

# 7. Cinematic Encounter UI

وقتی Encounter باز می‌شود:

Battlefield:
- حذف نمی‌شود
- brightness کمتر
- saturation کمتر
- blur بسیار کم
- Camera روی Hero + Target freeze نرم

Foreground:
Cinematic Objective Sheet

Panel شامل:

- Entity Type
- Objective Label
- Task Name
- Category
- Difficulty
- Note
- XP
- Gold
- Diamond
- Estimated effort optional
- Complete
- Defer
- Cancel

---

# 8. Encounter Visual Hierarchy

اولویت دیداری:

1. Task Name
2. Action اصلی
3. Reward
4. Difficulty
5. Category
6. Note

نباید:
Form شلوغ
Table
Admin dashboard
Text wall

---

# 9. Complete Flow

Complete:

1. User taps Complete
2. Button Lock
3. Encounter state = TASK_COMPLETE
4. Panel fades
5. Camera re-focus
6. Hero turns to Target
7. Attack animation
8. Projectile / melee hit
9. Target hit state
10. HP/Progress update
11. Reward animation
12. XP/Gold/Diamond applied
13. Task state = completed
14. Entity state update
15. Control resumes
16. Next objective HUD updates

---

# 10. Defer Flow

Defer:

- Task state = deferredInCurrentMatch
- هیچ Reward داده نمی‌شود
- هیچ Damage اجرا نمی‌شود
- Entity زنده می‌ماند
- Task در این Match دوباره انتخاب نمی‌شود
- در Match بعدی دوباره می‌تواند Eligible باشد
- Control resumes

هدف:
کاربر مجبور به انجام Task نامناسب در آن لحظه نشود.

---

# 11. Cancel Current Encounter

Cancel:

- فقط Encounter بسته می‌شود
- Task حذف نمی‌شود
- Task Permanent State تغییر نمی‌کند
- Entity آسیب نمی‌بیند
- می‌توان Task را بعداً دوباره Encounter کرد

تفاوت با Defer:

Defer:
Task در Match جاری کنار گذاشته می‌شود.

Cancel:
فقط این برخورد فعلی لغو می‌شود.

---

# 12. Task Lock

هنگام Encounter:

Task:
lockedByEncounterId

تا:
- Complete
- Defer
- Cancel
- Match End

این مانع باز شدن همزمان همان Task برای دو Entity می‌شود.

---

# 13. Entity Task Demand

Minion:
1 Task

Tower:
چند Task / Hit

Base:
چند Task / Hit

Default:

Minion:
1

Tower:
3

Base:
4

قابل ویرایش از Settings.

---

# 14. Difficulty Mapping

پیشنهاد:

Minion:
Easy / Normal

Tower 1:
Normal / Important

Tower 2:
Important / Hard

Enemy Base:
Important / Hard / Strategic

اما کاربر نباید به خاطر نبود Task Hard قفل شود.

Fallback:
Taskهای فعال دیگر با Reward Scaling محدود.

---

# 15. Reward Mapping

Reward از خود Task می‌آید.

Task Fields:

- xp
- gold
- diamond

Entity می‌تواند Multiplier داشته باشد.

Default:

Minion:
1.0x

Tower:
1.1x visual milestone bonus

Base:
1.2x final push bonus

اما همه Multiplierها قابل ویرایش باشند.

---

# 16. XP Apply

پس از Hit:

XP:
- به Player XP اضافه شود
- اگر Threshold رد شد:
  Level Up
- Level Up animation بعد از Reward
- Multiple level-up supported

XP نباید قبل از Combat feedback اعمال بصری شود.

---

# 17. Gold Apply

Gold:
- HUD counter increment
- Fly-to-HUD effect
- Shop balance update

---

# 18. Diamond Apply

Diamond:
- rare visual emphasis
- stronger sparkle
- separate HUD fly

Diamond = real-life reward currency

---

# 19. Task Completion Persistence

Complete باید Permanent Task Record را Update کند:

- completedCount
- lastCompletedAt
- totalXPGenerated
- totalGoldGenerated
- totalDiamondGenerated

در آینده:
streak / category analytics

---

# 20. Gameplay Delete Rule

داخل Gameplay:
Permanent Delete ممنوع

Allowed:
- Complete
- Defer
- Cancel

Permanent Delete فقط Tasks Management.

---

# 21. Encounter Time

Task Encounter تایمر اجباری ندارد.

چون Task واقعی ممکن است:
- 2 دقیقه
- 10 دقیقه
- بیشتر

Match Timer policy در Step Match Lifecycle دقیق‌تر قفل می‌شود.

---

# 22. Match Timer During Task

پیشنهاد پایه:

Timer continues.

دلیل:
۳۰ دقیقه Focus Session است.

اما:
Settings آینده می‌تواند حالت Pause-on-task داشته باشد.

Default:
Continue

---

# 23. Encounter Safety

برای جلوگیری از Double Complete:

Complete button بعد از اولین Tap:
Disabled

Transaction flag:
`processing = true`

تا Combat handoff تمام شود.

---

# 24. Reward Transaction

Reward Apply باید Atomic باشد.

Sequence:

validate task
→ validate encounter
→ mark processing
→ apply entity damage
→ apply rewards
→ persist task completion
→ persist match stats
→ unlock task
→ close encounter

اگر وسط Sequence خطا شد:
داده نباید دوبار Reward بدهد.

---

# 25. Match Task State

هر Match:

```text
taskUsage = {
  taskId: {
    state,
    encounterCount,
    completedAt,
    entityId
  }
}
```

---

# 26. Encounter Object

Encounter:

- id
- entityId
- taskId
- openedAt
- state
- processing
- lane
- entityType
- rewardPreview

---

# 27. Entity Progress

Minion:
alive / defeated

Tower:
hp / maxHp / hitCount

Base:
hp / maxHp / hitCount

Task Complete:
فقط Entity مربوط به Encounter را تغییر می‌دهد.

---

# 28. No Auto Damage

Hero نزدیک Target شود:
هیچ Damage خودکار اجرا نمی‌شود.

Damage فقط بعد از:
Real Task Complete

---

# 29. Objective HUD After Encounter

Complete:
«مسیر آزاد شد» یا Objective بعدی

Defer:
«Task دیگری پیدا کن»

Cancel:
«برخورد لغو شد»

Tower Partial Hit:
«Tower: 66% HP»

Base Partial Hit:
«Enemy Core: 75% HP»

---

# 30. Encounter Re-entry Cooldown

برای جلوگیری از Popup فوری بعد از Cancel:

Entity cooldown:
1.2–2.0 sec

یا Hero باید کمی از Radius خارج و دوباره وارد شود.

پیشنهاد:
Exit Radius required

---

# 31. Radius Hysteresis

Trigger In:
مثلاً 5.5

Trigger Out:
مثلاً 7.0

این تفاوت جلوی Flicker را می‌گیرد.

---

# 32. Camera During Complete

Panel fade:
220ms

Attack prepare:
100–180ms

Attack:
400–600ms

Hit:
در impact frame

Reward:
بعد impact

Control resume:
بعد 900–1400ms کل Sequence

---

# 33. Task Panel Motion

Open:
- 320ms
- upward sheet
- opacity
- slight scale

Close:
- 220ms

Complete:
- gold/cyan highlight
- panel dissolves to battlefield

---

# 34. Entity Context Styling

Minion Encounter:
Cyan neutral

Tower Encounter:
Gold warning

Base Encounter:
Crimson + gold

همه داخل یک Design System.

---

# 35. Empty Task Pool

اگر هیچ Task فعال وجود نداشت:

Encounter باز نمی‌شود.

HUD:
«برای ادامه، یک کار فعال به بازی اضافه کن.»

CTA:
رفتن به Tasks

Match نباید Crash یا Soft-lock شود.

---

# 36. All Tasks Deferred

اگر همه Taskها در Match جاری Deferred شدند:

HUD:
«کار فعالی برای این Match باقی نمانده.»

Options:
- ادامه Explore
- End Match
- Re-enable Deferred Tasks (future setting)

---

# 37. Task Editing During Match

نسخه پایه:
Task Editing داخل Gameplay ممنوع.

دلیل:
Focus حفظ شود.

از Tasks Page قبل/بعد Match قابل ویرایش.

---

# 38. Reward Preview

Reward قبل Complete نمایش داده می‌شود.

مثال:

+120 XP
+35 Gold
+1 Diamond

اما تا Complete:
هیچ Reward اعمال نشده.

---

# 39. Anti-Farming Principle

Task Completion واقعی باید Meaningful باشد.

نسخه اولیه اعتمادمحور است.

در آینده:
- cooldown
- repeated task diminishing
- verification optional

فعلاً:
پیچیدگی اضافه نمی‌کنیم.

---

# 40. STEP 05 DEFAULTS

Trigger Radius:
Minion 5.5
Tower 7.0
Base 7.5

Exit Radius:
Trigger + 1.5

Re-entry:
Exit required

Minion Task Demand:
1

Tower Task Demand:
3

Base Task Demand:
4

Timer:
continues during Task

Permanent delete in Gameplay:
false

---

# 41. Quality Gate

سیستم Encounter فقط PASS است اگر:

- Task تکراری در Match باز نشود
- Double Complete Reward ندهد
- Cancel Task را حذف نکند
- Defer Task را فقط در Match کنار بگذارد
- Task Complete واقعاً Combat را Trigger کند
- بدون Task بازی Soft-lock نشود
- Battlefield هنگام Panel هنوز قابل تشخیص باشد
- UI سریع و بدون فرم شلوغ باشد
- Reward قبل از Hit اعمال بصری نشود
- Control بعد Sequence درست برگردد

---

# STEP 06

REWARD / XP / LEVEL / RANK ECONOMY

در قدم ۶:
- XP Curve
- Level Up
- Gold economy
- Diamond economy
- Rank ladder
- reward balancing
- progression feedback
- editable economy rules
طراحی می‌شود.
