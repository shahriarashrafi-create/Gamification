# SHAHRIAR GAME — STEP 31
## APP NAVIGATION / ROUTE & STATE ARCHITECTURE

مرجع رسمی مسیریابی کل اپ، App Shell، Back Stack و Global State.

## 1. Fresh Launch
Every cold launch starts at:
home

No auto-resume into Match.
If an active recoverable Match exists, Home may show a compact resume card.

## 2. Canonical Bottom Navigation
Exactly five items:
خانه
کارها
آمار
تایم‌شیت
شبکه‌سازی

Never add a sixth tab.

## 3. Bottom Nav Routes
home
tasks
stats
timesheet
networking

## 4. Stats Rule
stats route shows Network Tree only.
No match charts, KPI dashboard, win/loss dashboard or session stats.

## 5. Secondary Routes
Opened from Home/cards/actions, not Bottom Nav:
shop
events
vision
achievements
heroHub
settings

## 6. Gameplay Routes
preBattle
match
pause overlay
result

Gameplay is isolated from normal App Shell.

## 7. Bottom Nav Visibility
Visible:
home
tasks
stats
timesheet
networking

Hidden:
shop optional depending final shell decision
events optional
vision optional
achievements optional
heroHub optional
settings optional
preBattle
match
result

Default locked choice:
secondary modules keep normal system bars and may show a top back control.
Canonical Bottom Nav remains only for five main tabs.

## 8. Home Entry Points
Hero tap → heroHub
Settings gear → settings
Shop card → shop
Events card → events
Vision card → vision
Achievements card → achievements
Start CTA → preBattle

## 9. Main Tab Switching
Switching between five main tabs replaces current main-tab route.
Do not build an endlessly deep stack from repeated tab taps.

## 10. Tab State Preservation
Optional local scroll/filter state can be retained per tab.
Critical game state stays in global stores.

## 11. Secondary Back
Back from secondary route returns to the route that opened it.
If parent reference is missing/corrupt, fallback Home.

## 12. Settings Back
Normally returns to Home if opened from Home.
If opened from Pause quick settings in future, returns to Pause without exposing Bottom Nav.

## 13. Hero Hub Back
Returns Home by default.
Selected Hero persists globally.

## 14. Pre-Battle Back
Before Match commit:
return Home
restore normal system bars
no Match transaction created if initialization not persisted.

## 15. Match Back
Android Back:
open Pause overlay.

## 16. Pause Back
Back:
resume Match.

## 17. Result Back
Back:
Home
restore normal system UI.

## 18. Route Families
MAIN_SHELL
SECONDARY
GAMEPLAY
OVERLAY

## 19. Main Shell
Owns:
Top-level page frame
canonical Bottom Nav
safe-area behavior
main route state

## 20. Gameplay Shell
Owns:
immersive state
game HUD
camera/world
game controls
encounter overlays
pause/result transitions

No Bottom Nav.

## 21. Overlay
Encounter
Pause
Confirm dialogs
Toast
Bottom sheets

Overlays do not become normal history entries unless explicitly required.

## 22. Global App State Domains
player
wallet
progression
tasks
networkTree
timesheet
networkingCRM
shop
events
vision
achievements
heroes
settings
activeMatch
routeSession

## 23. Player Domain
name
level
xp
rank
selectedHero
profile visual

## 24. Wallet Domain
gold
diamonds
transaction ledger

## 25. Active Match Domain
Only active/recoverable session data.
Cleared/archived safely after close/result persistence.

## 26. Route State
currentRoute
previousRoute
routeFamily
openedFrom
overlayStack
tabState
transitionState

## 27. Deep Links
Not required for first production build.
Future deep links must never bypass gameplay initialization/transaction guards.

## 28. Route Guard
match requires valid initialized Match.
result requires finalized MatchResult.
heroHub/settings/modules require loaded app state.
stats always resolves to tree view.

## 29. Corrupt Route Recovery
Unknown route → Home.
Missing entity detail target → parent route.
Invalid active Match route → Home with safe recovery notice.

## 30. Persistence
Persist user/domain data.
Do not persist raw visual route stack as authoritative launch state.

## 31. Launch Bootstrap
load schema
migrate data
load settings/player
check recoverable Match metadata
route Home
render shell

## 32. Navigation Transition
Main tab: fast 140–220ms.
Secondary: slide/fade 220ms.
Gameplay entry: cinematic 360–600ms.
Reduced Motion: fade only.

## 33. System UI
MAIN_SHELL + SECONDARY:
system bars visible

GAMEPLAY:
immersive according to Step30.

## 34. Safe Area
Navigation and CTA reserve:
env(safe-area-inset-top)
env(safe-area-inset-bottom)
100dvh

## 35. Home CTA
Must stay above Bottom Nav.
No overlap on 360×800.

## 36. Back Stack Examples
Home → Shop → Back = Home
Home → Hero Hub → Back = Home
Tasks → Home = tab switch, not stack chain
Home → PreBattle → Match → Pause → Resume
Match → Result → Home
Home → Resume Card → recovered Match

## 37. Recovery Card
If recoverable Match exists:
continue Match
end Match
No automatic battlefield entry.

## 38. Prototype
Step31 concept simulates five-tab shell, secondary modules, gameplay isolation, Back behavior and recovery fallback.

## 39. Failure Conditions
sixth Bottom Nav item
Stats becomes dashboard
fresh launch restores last random page
Match shows Bottom Nav
Back exits active Match
secondary route traps user
unknown route crashes app
Home CTA under nav
system bars stay hidden after Home

## 40. Quality Gate
At any moment the user must know whether they are in normal app navigation or inside Match, and Back must behave predictably.

## STEP 32
GLOBAL DATA MODEL / STORAGE & SCHEMA MIGRATION
Persistent local data, entity schemas, transaction ledger, versioning, migration, backup/export and safe reset.
