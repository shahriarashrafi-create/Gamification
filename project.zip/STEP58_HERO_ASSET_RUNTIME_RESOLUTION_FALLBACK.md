# STEP 58 — HERO ASSET RUNTIME RESOLUTION & FALLBACK

این مرحله یک Resolver واحد برای Hero Asset در Home، Hero Hub، Pre-Battle و Match تعریف می‌کند.

## Goal
یک Hero انتخاب‌شده باید در تمام App از یک Asset Contract واحد استفاده کند.

## Surfaces
home
hero_hub
pre_battle
match
results

## Runtime Asset
Preferred:
transparent WebP
full body
no baked text
consistent foot anchor
consistent visual bounds

## Variants
lobby
hub
battle_idle
battle_walk
battle_attack
victory

## Resolution Order
requested hero + requested variant
→ requested hero + default compatible variant
→ declared production fallback hero
→ explicit asset error state

هرگز:
CSS human silhouette
emoji person
random unrelated Hero

## Registry
Each Hero:
id
gender
owned state elsewhere
assets
visualBounds
footAnchor
headAnchor
recommendedScale
yOffset
fallbackHeroId

## Preload
Home:
selected Hero lobby

Hero Hub:
selected Hero hub + visible gallery thumbnails

Pre-Battle:
selected Hero battle_idle

Match:
battle_idle / walk / attack critical

Results:
victory lazy-preload before end ceremony when possible

## Crop Safety
object-fit contain
never cover
head/feet must remain inside visual viewport
use metadata anchors

## Missing Variant
If attack missing:
fallback to battle_idle + VFX
do not block Match if core Hero asset exists.

If core battle asset missing:
Pre-Battle blocks Match with recoverable asset error.

## Cache
Asset key:
heroId:variant:version

## Hero Change
Changing selectedHeroId:
invalidate only selected-Hero surface binding
do not purge global cache.

## Active Match
Hero asset set is snapshotted at Match init.
Hero Hub changes do not mutate active Match.

## Production Gate
Reference contact-sheet crops are not final transparent runtime cuts.
They remain reference-only until approved runtime files exist.

## QA
same selected Hero resolves consistently
no CSS human fallback
no emoji fallback
Home preloads lobby
Match critical variants preload
missing attack can use idle + VFX
missing core battle blocks Pre-Battle
no head/feet crop
active Match asset snapshot stable
no Energy

## STEP 59
GAMEPLAY HERO ANIMATION STATE MACHINE
Hero runtime asset resolver را به Idle/Walk/Run/Attack/Hit/Victory animation state واقعی Match وصل می‌کنیم.
