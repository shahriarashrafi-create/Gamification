# STEP 69 — TOWER2 + LANE COMPLETE + ENEMY BASE UNLOCK PRESENTATION

این مرحله تخریب Tower2 را به Lane Complete و بازشدن Enemy Base متصل می‌کند.

## Core Flow

Tower2 HP reaches 0
→ Tower2 destruction commit
→ Tower2 collision release
→ lane progression commit
→ Lane state = complete
→ Lane Complete presentation
→ completedLanes count refresh
→ if completedLanes >= 1:
    Enemy Base shield unlock commit
    Base objective becomes available
    Enemy Base gate opens
    Base minimap marker changes locked → available
    objective routing updates
→ Hero remains free to backtrack or switch lane

## Lane States

locked
tower1_active
tower2_active
complete

## Tower2 Rule

Tower2 can only be destroyed if:
Tower1 same lane destroyed
Tower2 unlocked
Tower2 HP reaches 0 via committed damage

## Lane Complete

Lane completion is a committed progression fact.

Presentation cannot:
complete lane
unlock Base
grant reward
modify Tower state

## Presentation

Short cinematic:
gold/cyan lane flare
Lane name reveal
"مسیر کامل شد"
Tower2 completed marker
camera emphasis toward lane
minimap lane highlight

Duration target:
700–1100ms

## Enemy Base Unlock

Base unlock condition:
completedLanes >= 1

Default:
1 completed Lane required.

Unlock stages:
shield_locked
unlocking
available

## Base Gate

Enemy Base Gate remains closed while Base locked.

On committed Base unlock:
gate collision disabled
base interaction enabled
base objective marker available

## Base Shield Visual

Locked:
strong cyan/red shield layer
locked marker

Unlocking:
fracture/rune dissolve
short flare

Available:
shield removed
gold/cyan objective ring
HP bar visible when focused

## Objective Routing

After Lane Complete:
current objective can become Enemy Base.

But no forced teleport.
No forced Hero movement.
No automatic lane switch.

Player may:
continue toward Base
backtrack
switch lane
destroy other Towers

## Minimap

Completed Lane:
subtle gold/cyan path highlight

Destroyed Tower2:
completed icon

Enemy Base:
locked → available marker

Minimap stays display-only.
No tap teleport.

## Reward

Lane Complete presentation gives no automatic wallet reward.

Any Tower2 destruction bonus already comes from Step67 transaction pipeline.

Enemy Base unlock gives no XP/Gold/Diamond.

## First-Lane Unlock

Only first completed Lane triggers Base unlock transaction.

Completing second or third Lane:
must not duplicate Base unlock event.

## Recovery

Crash after Lane Progress commit:
rebuild Lane complete.

Crash before Base unlock commit:
resume Base unlock evaluation.

Crash after Base unlock:
do not replay unlock transaction.

Visual presentation may replay shortened state,
but no wallet or progression duplicate.

## Idempotency

laneCompleteTxId unique
baseUnlockTxId unique
baseGateReleaseTxId unique
basePresentationTxId visual-only

## QA

Tower2 requires Tower1 destroyed
Tower2 destruction completes same Lane only
completedLanes increments once
one completed Lane unlocks Base
Base unlock happens once
Base Gate closes while locked
Base Gate opens after commit
Base marker locked → available
minimap remains display-only
player can backtrack/switch lane after completion
no forced movement
no reward from Lane Complete
no reward from Base unlock
no teleport
no Energy

## STEP 70

ENEMY BASE ENCOUNTER + DAMAGE TRANSACTION PIPELINE

Task → Hero Attack → Base Damage -25 → Base state → Victory commit را یکپارچه می‌کنیم.
