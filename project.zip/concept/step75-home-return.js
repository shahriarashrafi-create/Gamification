const $=x=>document.getElementById(x);
let queue=[
 {title:'رتبه جدید',value:'اسطوره‌ای I'},
 {title:'سطح جدید',value:'Level 29'}
];
async function playQueue(){
 for(const item of queue){
   $('cTitle').textContent=item.title;$('cValue').textContent=item.value;
   $('celebration').classList.add('on');
   await new Promise(r=>setTimeout(r,850));
   $('celebration').classList.remove('on');
   await new Promise(r=>setTimeout(r,180));
 }
}
$('start').onclick=()=>{$('log').textContent='Start Guard OK → PreBattle با Match ID جدید'};
setTimeout(playQueue,350);
