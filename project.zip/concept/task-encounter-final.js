const $=id=>document.getElementById(id), sleep=ms=>new Promise(r=>setTimeout(r,ms));
let busy=false,hp=100;
const damage={minion:100,tower:34,base:25}, names={minion:'MINION',tower:'TOWER',base:'ENEMY BASE'};
function state(s){$('state').textContent=s;$('log').textContent=s.replaceAll('_',' → ')}
function resetTarget(){hp=100;$('hp').style.width='100%';$('target').style.opacity=1;$('targetName').textContent=names[$('type').value];$('sheet').classList.remove('hide');$('complete').disabled=false;state('READY')}
$('type').onchange=resetTarget;
$('complete').onclick=async()=>{if(busy)return;busy=true;$('complete').disabled=true;state('COMMITTING');await sleep(140);$('sheet').classList.add('hide');state('SHEET_EXIT');await sleep(160);state('HERO_FACE_TARGET');await sleep(80);state('ATTACK_WINDUP');await sleep(180);state('PROJECTILE');$('projectile').classList.add('go');await sleep(280);$('projectile').classList.remove('go');state('HIT');$('burst').classList.add('go');await sleep(120);$('burst').classList.remove('go');state('DAMAGE_APPLY');hp=Math.max(0,hp-damage[$('type').value]);$('hp').style.width=hp+'%';await sleep(220);state('REWARD_COMMIT');$('fly').classList.add('go');await sleep(360);$('fly').classList.remove('go');if(hp===0)$('target').style.opacity=.35;state('FEEDBACK');await sleep(150);state('RESUME');await sleep(180);if(hp>0){$('sheet').classList.remove('hide');$('complete').disabled=false;state('READY')}busy=false};
$('defer').onclick=()=>{if(busy)return;$('sheet').classList.add('hide');state('DEFER_CURRENT_MATCH');setTimeout(()=>state('RESUME'),220)};
$('cancel').onclick=()=>{if(busy)return;$('sheet').classList.add('hide');state('CANCEL_CLOSE_ONLY');setTimeout(()=>state('RESUME'),220)};
resetTarget();