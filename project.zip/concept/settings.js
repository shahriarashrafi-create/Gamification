const fa=n=>Number(n).toLocaleString('fa-IR');
const toast=t=>{const e=document.getElementById('toast');e.textContent=t;e.classList.remove('show');void e.offsetWidth;e.classList.add('show')};
document.querySelectorAll('#tabs button').forEach(b=>b.onclick=()=>{document.querySelectorAll('#tabs button').forEach(x=>x.classList.remove('on'));document.querySelectorAll('.panel').forEach(x=>x.classList.remove('on'));b.classList.add('on');document.querySelector(`[data-panel="${b.dataset.tab}"]`).classList.add('on')});
function preview(){document.getElementById('previewName').textContent=document.getElementById('name').value||'بازیکن';document.getElementById('previewLevel').textContent=fa(document.getElementById('level').value||1);document.getElementById('previewMinutes').textContent=fa(document.getElementById('minutes').value||30)}
['name','level','minutes'].forEach(id=>document.getElementById(id).addEventListener('input',preview));
document.getElementById('save').onclick=()=>{const m=+document.getElementById('minutes').value,w=+document.getElementById('wave').value,g=+document.getElementById('growth').value;if(m<10||m>90)return toast('مدت Match باید بین ۱۰ تا ۹۰ باشد');if(w<10)return toast('Wave حداقل ۱۰ ثانیه');if(g<0||g>100)return toast('XP Growth نامعتبر است');toast('تنظیمات ذخیره شد')};
document.getElementById('reset').onclick=()=>toast('Reset Section در Prototype شبیه‌سازی شد');
document.querySelector('.hero').onclick=()=>toast('Hero Hub در Step 17 طراحی می‌شود');
preview();