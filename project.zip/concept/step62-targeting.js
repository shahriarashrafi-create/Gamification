const $=x=>document.getElementById(x);let target=null,baseUnlocked=false,encounter=false;
const objs=[...document.querySelectorAll('.obj')];
function setTarget(id){
  target=objs.find(o=>o.dataset.id===id)||null;
  objs.forEach(o=>o.classList.remove('focus'));
  if(target)target.classList.add('focus');
  $('targetName').textContent=target?target.dataset.id:'NONE';
  $('targetState').textContent=target?'FOCUSED':'IDLE';
  $('radius').textContent=target?.classList.contains('minion')?'5.5':target?.classList.contains('tower')?'7.0':target?'7.5':'—';
}
$('nearMinion').onclick=()=>{setTarget('minion_1');$('hero').style.left='33%';$('hero').style.bottom='24%'};
$('nearTower').onclick=()=>{setTarget('tower_b_1');$('hero').style.left='51%';$('hero').style.bottom='38%'};
$('unlockBase').onclick=()=>{baseUnlocked=true;const b=document.querySelector('[data-id="base_enemy"]');b.classList.remove('locked');b.querySelector('i').textContent='AVAILABLE';setTarget('base_enemy');toast('Base آزاد شد')};
$('action').onclick=()=>{if(!target){toast('هدف فعالی نیست');return}if(target.classList.contains('locked')){toast('این هدف هنوز قفل است');return}if(encounter)return;encounter=true;$('sheet').classList.add('open');$('sheetTitle').textContent=target.classList.contains('minion')?'کار واقعی Minion را انجام بده':target.classList.contains('tower')?'یک کار واقعی برای ضربه به Tower انجام بده':'یک کار واقعی برای حمله به Base انجام بده'};
function close(msg){encounter=false;$('sheet').classList.remove('open');toast(msg)}
$('done').onclick=()=>{if(!target)return;target.querySelector('i').textContent=target.classList.contains('minion')?'DEFEATED':'DAMAGE COMMITTED';if(target.classList.contains('minion'))target.classList.remove('focus');close('Task commit شد — Attack sequence اجرا می‌شود')};
$('defer').onclick=()=>close('بعداً — بدون Damage و Reward');
$('cancel').onclick=()=>close('لغو — بدون Damage و Reward');
function toast(t){$('toast').textContent=t;$('toast').classList.add('show');setTimeout(()=>$('toast').classList.remove('show'),900)}
