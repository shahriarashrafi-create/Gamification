const toast=document.getElementById('toast');
function showToast(t){
 toast.textContent=t;
 toast.classList.remove('show');
 void toast.offsetWidth;
 toast.classList.add('show');
}
document.getElementById('heroStage').addEventListener('click',()=>showToast('Hero Hub — انتخاب و شخصی‌سازی'));
document.getElementById('start').addEventListener('click',()=>showToast('شروع Match ۳۰ دقیقه‌ای'));
document.querySelectorAll('.modules button').forEach(btn=>{
 btn.addEventListener('click',()=>showToast(btn.querySelector('b').textContent));
});
