let battery=false;
document.getElementById('stress').onclick=()=>{
 battery=!battery;
 document.getElementById('frame').textContent=battery?'28.6ms':'16.4ms';
 document.getElementById('fps').textContent=battery?'30':'60';
 document.getElementById('quality').textContent=battery?'صرفه‌جویی':'متعادل';
 document.getElementById('bar').style.width=battery?'92%':'55%';
 document.querySelectorAll('.m').forEach((m,i)=>m.style.opacity=battery && i>1?'.25':'1');
};