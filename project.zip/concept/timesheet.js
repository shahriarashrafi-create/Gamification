const dayNames=['شنبه','یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنجشنبه','جمعه'];

let weekOffset=0;
let selectedDay=0;
let editId=null, deleteId=null;

const entries=[
 {id:'1',day:0,title:'فالوآپ با ۳ پراسپکت',start:'10:00',end:'11:00',category:'شبکه‌سازی',linkedTaskId:'t1',note:'نتیجه هر سه تماس ثبت شود.',completed:false,recurring:true},
 {id:'2',day:0,title:'مرور برنامه هفتگی فروش',start:'12:00',end:'12:30',category:'برنامه‌ریزی',linkedTaskId:'',note:'سه اولویت اصلی هفته.',completed:true,recurring:false},
 {id:'3',day:0,title:'مطالعه محصول',start:'18:00',end:'18:45',category:'یادگیری',linkedTaskId:'t3',note:'فصل جدید و نکات کلیدی.',completed:false,recurring:false},
 {id:'4',day:1,title:'جلسه تیم',start:'09:30',end:'10:30',category:'جلسه',linkedTaskId:'',note:'مرور اهداف تیم.',completed:false,recurring:true},
 {id:'5',day:2,title:'تماس با مشتریان پیگیری',start:'14:00',end:'15:00',category:'فروش',linkedTaskId:'t2',note:'لیست پیگیری آماده شود.',completed:false,recurring:false}
];

const taskLabels={t1:'فالوآپ امروز',t2:'تماس با سه نفر',t3:'مطالعه محصول'};

function pseudoDate(day,offset){
 const base=7 + offset*7 + day;
 return base;
}
function renderDays(){
 const wrap=document.getElementById('days');
 wrap.innerHTML=dayNames.map((name,i)=>{
   const dayEntries=entries.filter(e=>e.day===i);
   const done=dayEntries.filter(e=>e.completed).length;
   return `<button class="day ${i===selectedDay?'active':''} ${weekOffset===0&&i===0?'today':''}" data-day="${i}">
     <b>${name}</b><strong>${pseudoDate(i,weekOffset)}</strong><small>${done}/${dayEntries.length}</small>
   </button>`;
 }).join('');
 document.querySelectorAll('[data-day]').forEach(b=>b.onclick=()=>{selectedDay=Number(b.dataset.day);render()});
 document.getElementById('weekLabel').textContent=weekOffset===0?'هفته جاری':weekOffset>0?`${weekOffset} هفته بعد`:`${Math.abs(weekOffset)} هفته قبل`;
}

function filtered(){
 const q=document.getElementById('searchInput').value.trim().toLowerCase();
 return entries.filter(e=>e.day===selectedDay && (!q||`${e.title} ${e.category} ${e.note}`.toLowerCase().includes(q))).sort((a,b)=>a.start.localeCompare(b.start));
}
function renderTimeline(){
 const data=filtered();
 const all=entries.filter(e=>e.day===selectedDay);
 document.getElementById('countAll').textContent=all.length;
 document.getElementById('countDone').textContent=all.filter(e=>e.completed).length;
 document.getElementById('countPending').textContent=all.filter(e=>!e.completed).length;
 const el=document.getElementById('timeline');
 if(!data.length){
   el.innerHTML=`<div class="empty"><i>▦</i><b>برای این روز برنامه‌ای نیست</b><span>یک برنامه جدید اضافه کن.</span></div>`;
   return;
 }
 el.innerHTML=data.map(e=>`
 <article class="entry">
   <div class="time"><b>${e.start}</b><small>${e.end}</small></div>
   <div class="entry-card ${e.completed?'completed':''}">
     <div class="entry-head"><b class="entry-title">${e.title}</b><span>${e.completed?'✓':''}</span></div>
     <div class="badges"><span>${e.category}</span>${e.linkedTaskId?`<span class="linked">⚔ ${taskLabels[e.linkedTaskId]||'Task'}</span>`:''}${e.recurring?'<span class="repeat">↻ هفتگی</span>':''}</div>
     <div class="entry-note">${e.note||'بدون یادداشت'}</div>
     <div class="actions">
       <button class="complete" data-complete="${e.id}">${e.completed?'بازگردانی':'✓ انجام شد'}</button>
       <button data-edit="${e.id}">ویرایش</button>
       <button class="delete" data-delete="${e.id}">حذف</button>
     </div>
   </div>
 </article>`).join('');

 document.querySelectorAll('[data-complete]').forEach(b=>b.onclick=()=>{
   const e=entries.find(x=>x.id===b.dataset.complete);e.completed=!e.completed;render();
 });
 document.querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>openEdit(b.dataset.edit));
 document.querySelectorAll('[data-delete]').forEach(b=>b.onclick=()=>{deleteId=b.dataset.delete;document.getElementById('confirmWrap').classList.add('show')});
}
function render(){renderDays();renderTimeline()}

document.getElementById('prevWeek').onclick=()=>{weekOffset--;render()};
document.getElementById('nextWeek').onclick=()=>{weekOffset++;render()};
document.getElementById('todayBtn').onclick=()=>{weekOffset=0;selectedDay=0;render()};
document.getElementById('searchInput').addEventListener('input',renderTimeline);
document.getElementById('clearSearch').onclick=()=>{document.getElementById('searchInput').value='';renderTimeline()};

function resetForm(){
 document.getElementById('entryForm').reset();
 document.getElementById('startField').value='10:00';
 document.getElementById('endField').value='11:00';
 document.getElementById('timeError').textContent='';
}
function openNew(){
 editId=null;resetForm();
 document.getElementById('modalTitle').textContent='برنامه جدید';
 document.getElementById('modalWrap').classList.add('show');
}
function openEdit(id){
 const e=entries.find(x=>x.id===id);editId=id;
 document.getElementById('modalTitle').textContent='ویرایش برنامه';
 document.getElementById('titleField').value=e.title;
 document.getElementById('startField').value=e.start;
 document.getElementById('endField').value=e.end;
 document.getElementById('categoryField').value=e.category;
 document.getElementById('taskField').value=e.linkedTaskId;
 document.getElementById('repeatField').checked=e.recurring;
 document.getElementById('noteField').value=e.note;
 document.getElementById('timeError').textContent='';
 document.getElementById('modalWrap').classList.add('show');
}
function closeModal(){document.getElementById('modalWrap').classList.remove('show')}
document.getElementById('addBtn').onclick=openNew;
document.getElementById('closeModal').onclick=closeModal;
document.getElementById('cancelModal').onclick=closeModal;

document.getElementById('entryForm').addEventListener('submit',ev=>{
 ev.preventDefault();
 const start=document.getElementById('startField').value;
 const end=document.getElementById('endField').value;
 if(end<=start){
   document.getElementById('timeError').textContent='زمان پایان باید بعد از زمان شروع باشد.';
   return;
 }
 const data={
  day:selectedDay,
  title:document.getElementById('titleField').value.trim(),
  start,end,
  category:document.getElementById('categoryField').value,
  linkedTaskId:document.getElementById('taskField').value,
  recurring:document.getElementById('repeatField').checked,
  note:document.getElementById('noteField').value.trim()
 };
 if(editId)Object.assign(entries.find(x=>x.id===editId),data);
 else entries.push({id:crypto.randomUUID?crypto.randomUUID():Date.now().toString(),completed:false,...data});
 closeModal();render();
});

document.getElementById('noDelete').onclick=()=>{deleteId=null;document.getElementById('confirmWrap').classList.remove('show')};
document.getElementById('yesDelete').onclick=()=>{
 const i=entries.findIndex(x=>x.id===deleteId);if(i>=0)entries.splice(i,1);
 deleteId=null;document.getElementById('confirmWrap').classList.remove('show');render();
};

render();
