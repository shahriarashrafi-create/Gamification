const $=x=>document.getElementById(x);
let destructionCommitted=false,collisionReleased=false,reduce=false,busy=false;
const wait=ms=>new Promise(r=>setTimeout(r,ms));
function phase(p){$('phase').textContent=p.toUpperCase()}
async function destroy(){
 if(busy||destructionCommitted){$('log').textContent='Duplicate destruction ignored';return}
 busy=true;destructionCommitted=true;
 $('objective').textContent='COMPLETED';$('marker').textContent='COMPLETED';$('marker').classList.add('done');
 phase('fracture');$('tower').classList.add('fracture');await wait(140);
 phase('core_flash');$('tower').classList.add('flash');await wait(120);
 $('tower').classList.remove('flash');
 phase('collapse');
 if(!reduce)$('tower').classList.add('collapse');
 await wait(reduce?120:420);
 phase('debris');
 if(!reduce){$('debris').classList.remove('on');void $('debris').offsetWidth;$('debris').classList.add('on')}
 await wait(reduce?80:260);
 phase('smoke');$('smoke').classList.remove('on');void $('smoke').offsetWidth;$('smoke').classList.add('on');
 await wait(reduce?180:700);
 $('tower').classList.add('settled');phase('settled');$('marker').style.opacity='0';
 $('log').textContent='Destruction committed است؛ Collision هنوز تا commit بعدی ON می‌ماند.';
 busy=false;
}
function release(){
 if(!destructionCommitted){$('log').textContent='اول Destruction Commit لازم است';return}
 if(collisionReleased){$('log').textContent='Duplicate collision release ignored';return}
 collisionReleased=true;$('collision').textContent='OFF';$('next').textContent='TOWER B2 UNLOCKED';$('next').classList.add('open');$('log').textContent='Collision Release committed — مسیر باز شد و Tower B2 نمایش داده شد.';
}
$('destroy').onclick=destroy;
$('release').onclick=release;
$('reduce').onclick=()=>{reduce=!reduce;$('reduce').textContent=reduce?'Reduce Motion: ON':'Reduce Motion';$('log').textContent=reduce?'Collapse بزرگ و camera push حذف می‌شوند.':'Motion کامل فعال است.'};
