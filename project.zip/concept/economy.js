const levelEl=document.getElementById('level');
const xpText=document.getElementById('xpText');
const xpFill=document.getElementById('xpFill');
const rankText=document.getElementById('rankText');
const rankFill=document.getElementById('rankFill');
const xpEarned=document.getElementById('xpEarned');
const goldEl=document.getElementById('gold');
const diaEl=document.getElementById('diamond');
const claim=document.getElementById('claim');
const feedback=document.getElementById('feedback');

let player={level:28,xp:6240,need:8000,gold:2437,dia:12,rp:72,totalEarned:0};
let selected={xp:120,gold:35,dia:0,rp:2};

document.querySelectorAll('.task-select button').forEach(btn=>{
 btn.addEventListener('click',()=>{
  document.querySelectorAll('.task-select button').forEach(x=>x.classList.remove('active'));
  btn.classList.add('active');
  selected={
   xp:Number(btn.dataset.xp),
   gold:Number(btn.dataset.gold),
   dia:Number(btn.dataset.dia),
   rp:Number(btn.dataset.rp)
  };
 });
});

function render(){
 levelEl.textContent=player.level;
 xpText.textContent=`${player.xp} / ${player.need} XP`;
 xpFill.style.width=Math.min(100,player.xp/player.need*100)+'%';
 rankText.textContent=`${player.rp} / 100 RP`;
 rankFill.style.width=Math.min(100,player.rp)+'%';
 xpEarned.textContent='+'+player.totalEarned;
 goldEl.textContent=player.gold;
 diaEl.textContent=player.dia;
}

function nextNeed(current){
 return Math.round(current*1.16);
}

claim.addEventListener('click',()=>{
 claim.disabled=true;

 player.xp+=selected.xp;
 player.gold+=selected.gold;
 player.dia+=selected.dia;
 player.rp+=selected.rp;
 player.totalEarned+=selected.xp;

 let messages=[`+${selected.xp} XP`,`+${selected.gold} Gold`];
 if(selected.dia) messages.push(`+${selected.dia} Diamond`);

 let leveled=0;
 while(player.xp>=player.need){
   player.xp-=player.need;
   player.level++;
   player.need=nextNeed(player.need);
   leveled++;
 }

 let ranked=0;
 while(player.rp>=100){
   player.rp-=100;
   ranked++;
 }

 render();
 feedback.textContent=messages.join(' • ')+(leveled?` • LEVEL UP ×${leveled}`:'')+(ranked?` • RANK UP ×${ranked}`:'');
 feedback.classList.remove('show'); void feedback.offsetWidth; feedback.classList.add('show');

 setTimeout(()=>claim.disabled=false,700);
});

render();
