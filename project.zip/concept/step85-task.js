const buttons=[...document.querySelectorAll('.actions button')],state=document.getElementById('state'),sheet=document.getElementById('sheet');
function lock(){buttons.forEach(b=>b.disabled=true)}
document.getElementById('done').onclick=()=>{lock();state.textContent='در حال ثبت...';setTimeout(()=>{state.textContent='ثبت شد — انتقال به حمله';sheet.style.transform='translateY(110%)';sheet.style.transition='.22s ease'},650)};
document.getElementById('later').onclick=()=>{lock();state.textContent='برای همین بازی به بعد موکول شد';setTimeout(()=>sheet.style.transform='translateY(110%)',450)};
document.getElementById('cancel').onclick=()=>{lock();state.textContent='ماموریت بسته شد؛ پاداشی ثبت نشد';setTimeout(()=>sheet.style.transform='translateY(110%)',450)};