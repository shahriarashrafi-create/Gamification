const $=x=>document.getElementById(x);let encounter=false,busy=false,hp=100,xp=0,gold=0,seen=new Set(),secs=1782;
function wait(ms){return new Promise(r=>setTimeout(r,ms))}function state(s){$('state').textContent=s}function toast(t){$('toast').textContent=t;$('toast').classList.add('show');setTimeout(()=>$('toast').classList.remove('show'),900)}
setInterval(()=>{if(secs<=0)return;secs--;let m=Math.floor(secs/60),s=secs%60;$('timer').textContent=`${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`},1000);
$('action').onclick=()=>{if(busy)return;encounter=true;$('world').classList.add('encounter-active');$('encounter').classList.remove('hidden');state('READY')};
$('cancel').onclick=()=>{if(busy)return;$('encounter').classList.add('hidden');$('world').classList.remove('encounter-active');encounter=false;toast('Encounter لغو شد • بدون Reward')};
$('defer').onclick=()=>{if(busy)return;$('encounter').classList.add('hidden');$('world').classList.remove('encounter-active');encounter=false;toast('برای این Match به بعد موکول شد')};
$('complete').onclick=async()=>{if(busy)return;busy=true;let tx='task-'+Date.now();if(seen.has(tx))return;seen.add(tx);document.querySelectorAll('.buttons button').forEach(b=>b.disabled=true);
 state('COMMITTING');await wait(180);state('SHEET_EXIT');$('encounter').classList.add('hidden');$('world').classList.remove('encounter-active');await wait(140);
 state('HERO_FACE_TARGET');$('hero').style.transform='translateY(-5px)';await wait(80);state('ATTACK_WINDUP');await wait(180);
 state('PROJECTILE');$('projectile').classList.remove('hidden');requestAnimationFrame(()=>$('projectile').classList.add('fly'));await wait(280);$('projectile').classList.add('hidden');$('projectile').classList.remove('fly');
 state('HIT');$('impact').classList.remove('hidden');await wait(120);$('impact').classList.add('hidden');
 state('DAMAGE_APPLY');hp=Math.max(0,hp-34);$('hp').style.width=hp+'%';await wait(220);
 state('REWARD_COMMIT');xp+=140;gold+=35;$('xp').textContent=xp;$('gold').textContent=gold;$('reward').classList.remove('hidden');await wait(360);$('reward').classList.add('hidden');
 state('FEEDBACK');toast('Task ثبت شد • Tower '+hp+' HP');await wait(180);state('RESUME');$('hero').style.transform='';document.querySelectorAll('.buttons button').forEach(b=>b.disabled=false);busy=false;encounter=false;
};