const $=x=>document.getElementById(x);
const data={
 victory:{title:'پیروزی',subtitle:'بیس دشمن نابود شد',xp:840,gold:370,diamond:1},
 time_end:{title:'زمان تمام شد',subtitle:'پاداش‌های ثبت‌شده حفظ شدند',xp:440,gold:160,diamond:0},
 manual_exit:{title:'بازی پایان داده شد',subtitle:'پاداش‌های ثبت‌شده حفظ شدند',xp:260,gold:95,diamond:0}
};
document.querySelectorAll('[data-type]').forEach(b=>b.onclick=()=>{
 const d=data[b.dataset.type];$('title').textContent=d.title;$('subtitle').textContent=d.subtitle;
 $('xp').textContent='+'+d.xp;$('gold').textContent='+'+d.gold;$('diamond').textContent='+'+d.diamond;
 $('diamondCard').className=d.diamond>0?'positive':'';
 $('log').textContent='Result type: '+b.dataset.type+' — نمایش فقط از Snapshot.';
});
$('home').onclick=()=>{$('log').textContent='Restore system bars → Refresh Player State → Home'};
$('replay').onclick=()=>{$('log').textContent='New Match ID → PreBattle — هیچ Reward تکرار نمی‌شود'};
$('diamondCard').classList.add('positive');
