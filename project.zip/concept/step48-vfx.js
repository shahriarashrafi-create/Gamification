const $=id=>document.getElementById(id);let hp=100,busy=false,seen=new Set();const wait=ms=>new Promise(r=>setTimeout(r,ms));
function state(s){$('state').textContent=s}
function pos(el){const r=el.getBoundingClientRect();return{x:r.left+r.width/2,y:r.top+r.height/2}}
function q(t,p0,p1,p2){const a=(1-t)*(1-t),b=2*(1-t)*t,c=t*t;return{x:a*p0.x+b*p1.x+c*p2.x,y:a*p0.y+b*p1.y+c*p2.y}}
function towerState(v){return v===0?'destroyed':v<=33?'critical':v<=66?'damaged':'healthy'}
function burst(x,y){
 const box=$('particles');
 for(let i=0;i<12;i++){const p=document.createElement('i');const a=(Math.PI*2*i)/12,d=18+Math.random()*28;p.style.left=x+'px';p.style.top=y+'px';p.style.setProperty('--dx',Math.cos(a)*d+'px');p.style.setProperty('--dy',Math.sin(a)*d+'px');box.appendChild(p);setTimeout(()=>p.remove(),360)}
}
function reward(text){const c=document.createElement('div');c.className='reward-chip';c.textContent=text;$('rewardStack').appendChild(c);setTimeout(()=>c.remove(),500)}
async function animateProjectile(){
 const reduce=$('reduceMotion').checked,start=pos($('muzzle')),end=pos($('crystal')),proj=$('projectile');
 proj.classList.remove('hidden');
 if(reduce){proj.style.left=end.x-7+'px';proj.style.top=end.y-7+'px';proj.style.opacity='0';await wait(90);proj.style.opacity='1';return}
 const dist=Math.hypot(end.x-start.x,end.y-start.y),dur=Math.max(180,Math.min(320,180+dist*.28)),p1={x:(start.x+end.x)/2,y:Math.min(start.y,end.y)-32},t0=performance.now();
 await new Promise(resolve=>{function f(now){let t=Math.min(1,(now-t0)/dur),p=q(t,start,p1,end);proj.style.left=p.x-7+'px';proj.style.top=p.y-7+'px';if(t<1)requestAnimationFrame(f);else resolve()}requestAnimationFrame(f)})
}
$('attack').onclick=async()=>{
 if(busy)return;busy=true;const tx='atk-'+Date.now();if(seen.has(tx))return;seen.add(tx);
 state('ATTACK_WINDUP');$('hero').classList.add('windup');await wait(180);$('hero').classList.remove('windup');
 state('PROJECTILE_TRAVEL');await animateProjectile();$('projectile').classList.add('hidden');
 const hit=pos($('crystal'));$('impact').style.left=hit.x-10+'px';$('impact').style.top=hit.y-10+'px';$('impact').classList.remove('hidden');$('impact').classList.add('play');burst(hit.x,hit.y);state('IMPACT');await wait(120);$('impact').classList.add('hidden');$('impact').classList.remove('play');
 state('HP_TWEEN');hp=Math.max(0,hp-34);$('towerHp').style.transition='width .22s ease';$('towerHp').style.width=hp+'%';await wait(220);
 state('ENTITY_STATE_SYNC');$('towerState').textContent=towerState(hp);await wait(100);
 state('REWARD_FLYUP');reward('+140 XP');setTimeout(()=>reward('+35 Gold'),70);await wait(360);
 state('RESUME');await wait(150);state('READY');busy=false;
};