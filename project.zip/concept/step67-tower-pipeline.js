const $=x=>document.getElementById(x);
const stages=['READY','TASK_COMMITTED','ATTACK_WINDUP','PROJECTILE','IMPACT','DAMAGE_COMMIT','HP_SYNC','REWARD_COMMIT','CHECK_DESTROYED','DESTRUCTION_COMMIT','COLLISION_RELEASE','LANE_PROGRESS','RESUME','DONE'];
$('pipeline').innerHTML=stages.map(s=>`<span class="chip" data-s="${s}">${s}</span>`).join('');
let hp=100,busy=false,destroyed=false,rewardCount=0,damageTx=0;
const wait=ms=>new Promise(r=>setTimeout(r,ms));
function setStage(s){$('state').textContent=s;document.querySelectorAll('.chip').forEach(c=>c.classList.toggle('on',c.dataset.s===s))}
function visual(){
 const state=hp===0?'destroyed':hp<=33?'critical':hp<=66?'damaged':'healthy';
 $('hp').textContent=hp+' / 100';$('towerLabel').textContent=state.toUpperCase();$('tower').className='tower '+state;$('bar').style.width=hp+'%';
}
async function complete(){
 if(busy||destroyed){$('log').textContent='Duplicate/invalid Complete ignored';return}
 busy=true;setStage('TASK_COMMITTED');await wait(130);setStage('ATTACK_WINDUP');await wait(180);
 setStage('PROJECTILE');$('projectile').classList.remove('fire');void $('projectile').offsetWidth;$('projectile').classList.add('fire');await wait(280);
 setStage('IMPACT');$('impact').classList.remove('on');void $('impact').offsetWidth;$('impact').classList.add('on');await wait(120);
 setStage('DAMAGE_COMMIT');damageTx++;hp=Math.max(0,hp-34);visual();await wait(180);
 setStage('HP_SYNC');await wait(130);setStage('REWARD_COMMIT');rewardCount++;await wait(130);setStage('CHECK_DESTROYED');
 if(hp===0){
  setStage('DESTRUCTION_COMMIT');destroyed=true;await wait(220);setStage('COLLISION_RELEASE');await wait(180);setStage('LANE_PROGRESS');
  $('lane').textContent='T2 UNLOCKED';$('gate').textContent='TOWER B2 UNLOCKED';$('gate').classList.add('open');$('log').textContent='Tower B1 destroyed — collision released — B2 unlocked';
 }else{$('log').textContent='Damage 34 committed — Reward committed once'}
 await wait(180);setStage('RESUME');await wait(100);setStage('DONE');busy=false;
}
$('complete').onclick=complete;
$('defer').onclick=()=>{if(busy||destroyed)return;setStage('READY');$('log').textContent='Defer — بدون Damage و Reward'};
$('cancel').onclick=()=>{if(busy||destroyed)return;setStage('READY');$('log').textContent='Cancel — Tower objective حفظ شد'};
visual();setStage('READY');
