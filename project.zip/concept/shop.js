let wallet={gold:2437,diamond:12};
let currentTab='heroes';
let rewardEditId=null;
let pendingConfirm=null;

const heroes=[
 {id:'h1',name:'آقای بادیسیپلین',priceGold:0,owned:true,selected:true,desc:'منظم • جدی • رهبر'},
 {id:'h2',name:'آقای جوان خوش‌تیپ',priceGold:2200,owned:false,selected:false,desc:'مدرن • جاه‌طلب • پرانرژی'},
 {id:'h3',name:'خانم جوان شیک',priceGold:2600,owned:false,selected:false,desc:'مدرن • بااعتمادبه‌نفس • پرانرژی'},
 {id:'h4',name:'آقای میان‌سال لاکچری',priceGold:3400,owned:false,selected:false,desc:'لوکس • موفق • باوقار'}
];

const cosmetics=[
 {id:'c1',type:'aura',name:'Aura آبی سلطنتی',priceGold:650,owned:false,equipped:false},
 {id:'c2',type:'frame',name:'قاب حماسی طلایی',priceGold:900,owned:true,equipped:true},
 {id:'c3',type:'background',name:'قلعه مه‌آلود',priceGold:1500,owned:false,equipped:false},
 {id:'c4',type:'outfit',name:'لباس فرمانده شب',priceGold:1200,owned:false,equipped:false}
];

let rewards=[
 {id:'r1',title:'قهوه موردعلاقه',diamondCost:5,note:'یک قهوه به انتخاب خودت',active:true,claimedCount:1,icon:'☕'},
 {id:'r2',title:'غذای ویژه',diamondCost:12,note:'یک وعده خاص به عنوان پاداش',active:true,claimedCount:0,icon:'✦'},
 {id:'r3',title:'سینما',diamondCost:18,note:'یک فیلم در سینما',active:true,claimedCount:0,icon:'◈'}
];

const history=[
 {id:'tx1',type:'claim',title:'قهوه موردعلاقه',cost:5,currency:'Diamond',at:'2026-08-28 18:20'}
];

function uid(){return crypto.randomUUID?crypto.randomUUID():Date.now().toString()+Math.random()}
function showToast(t){
 const el=document.getElementById('toast');el.textContent=t;el.classList.remove('show');void el.offsetWidth;el.classList.add('show');
}
function renderWallet(){
 document.getElementById('goldBalance').textContent=wallet.gold;
 document.getElementById('diamondBalance').textContent=wallet.diamond;
}
function render(){
 renderWallet();
 document.querySelectorAll('#tabs button').forEach(b=>b.classList.toggle('active',b.dataset.tab===currentTab));
 const content=document.getElementById('content');

 if(currentTab==='heroes'){
   content.innerHTML=`<div class="section-head"><div><small>HERO ARMORY</small><b>Heroهای قابل انتخاب</b></div></div>
   <section class="grid">${heroes.map(h=>`
    <article class="product ${h.selected?'selected':''}">
      <div class="visual"><div class="silhouette"></div></div>
      <h3>${h.name}</h3><p>${h.desc}</p>
      <div class="price"><span>${h.priceGold===0?'FREE':'● '+h.priceGold}</span>
        <button class="${h.owned?'owned':''}" data-hero="${h.id}">${h.selected?'انتخاب‌شده':h.owned?'انتخاب':'خرید'}</button>
      </div>
    </article>`).join('')}</section>`;
   document.querySelectorAll('[data-hero]').forEach(b=>b.onclick=()=>handleHero(b.dataset.hero));
 }

 if(currentTab==='cosmetics'){
   content.innerHTML=`<div class="section-head"><div><small>COSMETIC FORGE</small><b>ظاهر و شخصی‌سازی</b></div></div>
   <section class="grid">${cosmetics.map(c=>`
    <article class="product ${c.equipped?'selected':''}">
      <div class="visual"><div class="aura"></div></div>
      <h3>${c.name}</h3><p>${c.type}</p>
      <div class="price"><span>● ${c.priceGold}</span>
        <button class="${c.owned?'owned':''}" data-cosmetic="${c.id}">${c.equipped?'مجهز':c.owned?'Equip':'خرید'}</button>
      </div>
    </article>`).join('')}</section>`;
   document.querySelectorAll('[data-cosmetic]').forEach(b=>b.onclick=()=>handleCosmetic(b.dataset.cosmetic));
 }

 if(currentTab==='rewards'){
   const active=rewards.filter(r=>r.active);
   content.innerHTML=`<div class="section-head"><div><small>REAL-LIFE REWARDS</small><b>پاداش‌های Diamond</b></div><button id="addReward">＋ پاداش</button></div>
   <section class="rewards">${active.length?active.map(r=>`
    <article class="reward">
      <div class="reward-head">
        <div class="reward-title"><span class="reward-icon">${r.icon||'◆'}</span><div><b>${r.title}</b><small>Claimed ${r.claimedCount}×</small></div></div>
        <span class="claim-cost">◆ ${r.diamondCost}</span>
      </div>
      <p>${r.note||'بدون یادداشت'}</p>
      <div class="reward-actions">
        <button data-edit-reward="${r.id}">ویرایش</button>
        <button class="delete" data-delete-reward="${r.id}">حذف</button>
        <button class="claim" data-claim="${r.id}">Claim</button>
      </div>
    </article>`).join(''):`<div class="empty"><i>◆</i><b>پاداشی تعریف نشده</b><span>اولین پاداش واقعی را بساز.</span></div>`}</section>`;
   document.getElementById('addReward').onclick=()=>openRewardForm();
   document.querySelectorAll('[data-edit-reward]').forEach(b=>b.onclick=()=>openRewardForm(b.dataset.editReward));
   document.querySelectorAll('[data-delete-reward]').forEach(b=>b.onclick=()=>confirmDeleteReward(b.dataset.deleteReward));
   document.querySelectorAll('[data-claim]').forEach(b=>b.onclick=()=>confirmClaim(b.dataset.claim));
 }

 if(currentTab==='history'){
   content.innerHTML=`<div class="section-head"><div><small>TRANSACTION HISTORY</small><b>تاریخچه خرید و Claim</b></div></div>
   <section class="history-list">${history.length?history.slice().reverse().map(h=>`
    <article class="history-item"><div><b>${h.title}</b><span>${h.currency==='Gold'?'●':'◆'} ${h.cost}</span></div><small>${h.type==='purchase'?'Gold Purchase':'Diamond Claim'} • ${h.at}</small></article>`).join(''):`<div class="empty"><i>◇</i><b>تراکنشی نیست</b></div>`}</section>`;
 }
}

function buyGoldItem(item,itemType){
 if(wallet.gold<item.priceGold){showToast('Gold کافی نیست');return}
 pendingConfirm={kind:'goldBuy',item,itemType};
 openConfirm('خرید با Gold؟',`${item.priceGold} Gold برای «${item.name}» خرج می‌شود.`);
}
function handleHero(id){
 const h=heroes.find(x=>x.id===id);
 if(!h.owned){buyGoldItem(h,'hero');return}
 heroes.forEach(x=>x.selected=false);h.selected=true;showToast('Hero انتخاب شد');render();
}
function handleCosmetic(id){
 const c=cosmetics.find(x=>x.id===id);
 if(!c.owned){buyGoldItem(c,'cosmetic');return}
 cosmetics.filter(x=>x.type===c.type).forEach(x=>x.equipped=false);
 c.equipped=true;showToast('Cosmetic مجهز شد');render();
}

function confirmClaim(id){
 const r=rewards.find(x=>x.id===id);
 if(wallet.diamond<r.diamondCost){showToast('Diamond کافی نیست');return}
 pendingConfirm={kind:'claim',reward:r};
 openConfirm('Claim این پاداش؟',`${r.diamondCost} Diamond برای «${r.title}» خرج می‌شود.`);
}
function confirmDeleteReward(id){
 const r=rewards.find(x=>x.id===id);
 pendingConfirm={kind:'deleteReward',reward:r};
 openConfirm('حذف پاداش؟','History قبلی حفظ می‌شود.');
}
function openConfirm(title,text){
 document.getElementById('confirmTitle').textContent=title;
 document.getElementById('confirmText').textContent=text;
 document.getElementById('confirmWrap').classList.add('show');
}
document.getElementById('confirmNo').onclick=()=>{pendingConfirm=null;document.getElementById('confirmWrap').classList.remove('show')};
document.getElementById('confirmYes').onclick=()=>{
 if(!pendingConfirm)return;
 if(pendingConfirm.kind==='goldBuy'){
   const {item,itemType}=pendingConfirm;
   if(item.owned){showToast('قبلاً خریداری شده');}
   else if(wallet.gold>=item.priceGold){
     wallet.gold-=item.priceGold;item.owned=true;
     history.push({id:uid(),type:'purchase',title:item.name,cost:item.priceGold,currency:'Gold',at:new Date().toLocaleString('fa-IR')});
     showToast('خرید انجام شد');
   }
 }
 if(pendingConfirm.kind==='claim'){
   const r=pendingConfirm.reward;
   if(wallet.diamond>=r.diamondCost){
     wallet.diamond-=r.diamondCost;r.claimedCount++;
     history.push({id:uid(),type:'claim',title:r.title,cost:r.diamondCost,currency:'Diamond',at:new Date().toLocaleString('fa-IR')});
     showToast('پاداش Claim شد');
   }
 }
 if(pendingConfirm.kind==='deleteReward'){
   pendingConfirm.reward.active=false;
   showToast('پاداش از لیست فعال حذف شد');
 }
 pendingConfirm=null;document.getElementById('confirmWrap').classList.remove('show');render();
};

function openRewardForm(id=null){
 rewardEditId=id;
 document.getElementById('rewardForm').reset();
 document.getElementById('rewardCostField').value=5;
 document.getElementById('rewardActiveField').checked=true;
 if(id){
  const r=rewards.find(x=>x.id===id);
  document.getElementById('rewardFormTitle').textContent='ویرایش پاداش';
  document.getElementById('rewardTitleField').value=r.title;
  document.getElementById('rewardCostField').value=r.diamondCost;
  document.getElementById('rewardNoteField').value=r.note;
  document.getElementById('rewardActiveField').checked=r.active;
 }else document.getElementById('rewardFormTitle').textContent='پاداش جدید';
 document.getElementById('rewardFormWrap').classList.add('show');
}
document.getElementById('closeRewardForm').onclick=()=>document.getElementById('rewardFormWrap').classList.remove('show');
document.getElementById('cancelRewardForm').onclick=()=>document.getElementById('rewardFormWrap').classList.remove('show');
document.getElementById('rewardForm').addEventListener('submit',e=>{
 e.preventDefault();
 const data={
  title:document.getElementById('rewardTitleField').value.trim(),
  diamondCost:Math.max(1,Number(document.getElementById('rewardCostField').value)||1),
  note:document.getElementById('rewardNoteField').value.trim(),
  active:document.getElementById('rewardActiveField').checked
 };
 if(rewardEditId)Object.assign(rewards.find(x=>x.id===rewardEditId),data);
 else rewards.unshift({id:uid(),claimedCount:0,icon:'◆',...data});
 document.getElementById('rewardFormWrap').classList.remove('show');render();
});

document.querySelectorAll('#tabs button').forEach(btn=>btn.onclick=()=>{currentTab=btn.dataset.tab;render()});
render();
