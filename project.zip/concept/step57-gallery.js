const $=x=>document.getElementById(x);
const heroes=[
{id:'young_stylish',name:'آقای جوان خوش‌تیپ',desc:'مدرن • جاه‌طلب • پرانرژی',state:'selected'},
{id:'young_stylish_f',name:'خانم جوان شیک',desc:'مدرن • بااعتمادبه‌نفس • پرانرژی',state:'owned'},
{id:'luxury_mature_m',name:'آقای میان‌سال لاکچری',desc:'لوکس • موفق • باوقار',state:'locked'},
{id:'disciplined_f',name:'خانم بادیسیپلین',desc:'قدرتمند • منظم • مدیریتی',state:'locked'}
];let current=heroes[0];
const slotNames=['outfit','accessory','aura','effect','background','frame','title'];
function render(){
 $('gallery').innerHTML=heroes.map(h=>`<article class="heroCard ${h.state}" data-id="${h.id}"><div class="portrait">ASSET<br>${h.id}</div><b>${h.name}</b><small>${h.state.toUpperCase()}</small></article>`).join('');
 document.querySelectorAll('[data-id]').forEach(c=>c.onclick=()=>{current=heroes.find(h=>h.id===c.dataset.id);show()});
 $('slots').innerHTML=slotNames.map((s,i)=>`<div class="slot"><small>${s}</small><b>${i===2&&current.state!=='locked'?'طلایی':'—'}</b></div>`).join('');
}
function show(){
 $('name').textContent=current.name;$('desc').textContent=current.desc;$('state').textContent=current.state==='selected'?'SELECTED HERO':current.state==='owned'?'OWNED HERO':'LOCKED HERO';$('heroAsset').innerHTML='<span>FULL-BODY<br>'+current.id.toUpperCase()+'</span>';
 $('primary').textContent=current.state==='selected'?'انتخاب‌شده':current.state==='owned'?'انتخاب':'رفتن به فروشگاه';$('primary').classList.toggle('shop',current.state==='locked');render();
}
$('primary').onclick=()=>{if(current.state==='locked')toast('ورود به فروشگاه');else if(current.state==='owned'){heroes.forEach(h=>{if(h.state==='selected')h.state='owned'});current.state='selected';toast('Hero انتخاب شد');show()}};
function toast(t){$('toast').textContent=t;$('toast').classList.add('show');setTimeout(()=>$('toast').classList.remove('show'),900)}
show();
