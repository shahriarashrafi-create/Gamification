const $=x=>document.getElementById(x);
let sec=1800,hp=100,xp=0,gold=0;
setInterval(()=>{sec=Math.max(0,sec-1);const m=Math.floor(sec/60),s=sec%60;$('timer').textContent=String(m).padStart(2,'0')+':'+String(s).padStart(2,'0')},1000);
$('commit').onclick=()=>{
 if(hp<=0)return;
 hp=Math.max(0,hp-34);xp+=120;gold+=35;
 $('hp').style.width=hp+'%';$('targetHp').style.width=hp+'%';$('hpText').textContent=hp+' / 100';
 $('xp').textContent='+'+xp;$('gold').textContent='+'+gold;
 if(hp===0){$('objective').textContent='تاور دوم مسیر B';document.querySelector('.marker').textContent='NEXT OBJECTIVE'}
};
