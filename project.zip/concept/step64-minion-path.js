const $=x=>document.getElementById(x);let running=false,paused=false,state='moving',y=8,last=performance.now();
function renderState(s){state=s;$('state').textContent=s.toUpperCase();$('minion').classList.toggle('focused',s==='focused');$('minion').classList.toggle('dead',['deferred','defeated'].includes(s))}
function loop(now){let dt=Math.min((now-last)/1000,.05);last=now;if(running&&!paused&&state==='moving'){y+=18*dt;if(y>=72){y=72;renderState('waiting_for_player');running=false;$('log').textContent='Minion به staging point رسید و منتظر Hero است.'}$('minion').style.bottom=y+'%'}requestAnimationFrame(loop)}requestAnimationFrame(loop);
$('start').onclick=()=>{if(['deferred','defeated'].includes(state)){y=8;$('minion').style.bottom='8%'}renderState('moving');running=true;paused=false;$('log').textContent='حرکت deterministic روی Lane B'};
$('focus').onclick=()=>{running=false;renderState('focused');$('log').textContent='Hero نزدیک شد — Minion متوقف شد'};
$('cancel').onclick=()=>{running=false;renderState('waiting_for_player');$('log').textContent='Cancel — reservation حفظ شد'};
$('defer').onclick=()=>{running=false;renderState('deferred');$('log').textContent='Defer — بدون Reward و سپس Despawn'};
$('defeat').onclick=()=>{running=false;renderState('defeated');$('log').textContent='Complete committed — defeat feedback سپس Despawn'};
$('pause').onclick=()=>{paused=!paused;$('pause').textContent=paused?'Resume':'Pause';$('log').textContent=paused?'Path progress فریز شد':'Path progress ادامه پیدا کرد'};
renderState('moving');
