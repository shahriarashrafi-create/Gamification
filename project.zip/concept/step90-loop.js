const phases=[
['آماده‌سازی','PREBATTLE','اعتبارسنجی Hero، Task و Settings'],
['میدان','MATCH','Match Persist شد؛ Timer و کنترل فعال'],
['موج واقعی','WAVE','Task واقعی Reserve و Minion Spawn شد'],
['ماموریت','TASK','Task Encounter باز شد'],
['تاور','TOWER','Task Commit → Attack → Tower Damage'],
['بیس دشمن','BASE','Lane کامل شد؛ Enemy Base باز شد'],
['پیروزی','RESULT','Base نابود شد؛ Results آماده است'],
['خانه','HOME','Player State تازه‌سازی شد']
];let i=0;
document.getElementById('next').onclick=()=>{const p=phases[i%phases.length];document.getElementById('phase').textContent=p[0];document.getElementById('objective').textContent=p[1];document.getElementById('copy').textContent=p[2];document.getElementById('bar').style.width=((i+1)/phases.length*100)+'%';i++;};