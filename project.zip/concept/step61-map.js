const $=x=>document.getElementById(x);let towerDestroyed=false,laneComplete=false;
function render(){
 $('towerState').textContent=towerDestroyed?'COLLISION OFF':'COLLISION ON';
 document.querySelector('.t1').classList.toggle('off',towerDestroyed);
 $('gateState').textContent=laneComplete?'OPEN':'LOCKED';
 $('gate').textContent=laneComplete?'GATE OPEN':'LOCKED GATE';
 $('gate').classList.toggle('open',laneComplete);
}
$('destroy').onclick=()=>{towerDestroyed=true;render()};
$('complete').onclick=()=>{towerDestroyed=true;laneComplete=true;render()};
$('reset').onclick=()=>{towerDestroyed=false;laneComplete=false;render()};render();
