const $=x=>document.getElementById(x);let speed=0,state='idle',victory=false;
function locomotion(){return speed>=.62?'run':speed>=.18?'walk':'idle'}
function setState(s){if(victory&&s!=='victory')return;state=s;$('state').textContent=s.toUpperCase();$('tState').textContent=s;$('hero').className='hero '+s}
function resume(){if(!victory)setState(locomotion())}
document.querySelectorAll('[data-speed]').forEach(b=>b.onclick=()=>{speed=+b.dataset.speed;$('speed').textContent=speed.toFixed(2);resume()});
$('attack').onclick=()=>{if(victory)return;setState('attack');$('facing').textContent='NW';$('tFacing').textContent='NW';$('projectile').classList.remove('fire');void $('projectile').offsetWidth;$('projectile').classList.add('fire');$('note').textContent='Attack visual only • HP از transaction جداست';setTimeout(resume,420)};
$('hit').onclick=()=>{if(victory)return;setState('hit');$('note').textContent='Hit feedback • بدون mutation';setTimeout(resume,180)};
$('victory').onclick=()=>{victory=true;setState('victory');$('note').textContent='Victory lock • فقط بعد از Base destruction commit'};
setState('idle');
