const encounter=document.getElementById('encounter'),toast=document.getElementById('toast');
const say=t=>{toast.textContent=t;toast.classList.remove('show');void toast.offsetWidth;toast.classList.add('show')};
document.getElementById('action').onclick=()=>encounter.classList.add('show');
document.getElementById('cancel').onclick=()=>{encounter.classList.remove('show');say('Encounter بسته شد')};
document.getElementById('defer').onclick=()=>{encounter.classList.remove('show');say('برای این Match به تعویق افتاد')};
document.getElementById('complete').onclick=()=>{encounter.classList.remove('show');say('Task کامل شد • Attack → Hit → Reward')};
document.getElementById('pause').onclick=()=>say('Pause Sheet • Resume / Audio / Exit');
const size=document.getElementById('size');function q(){size.textContent=innerWidth+' × '+innerHeight}addEventListener('resize',q);q();
let sec=1800;setInterval(()=>{if(sec<=0)return;sec--;let m=Math.floor(sec/60),s=sec%60;document.getElementById('timer').textContent=String(m).padStart(2,'0')+':'+String(s).padStart(2,'0')},1000);