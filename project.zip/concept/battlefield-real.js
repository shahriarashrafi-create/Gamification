const hero=document.getElementById('hero'),joy=document.getElementById('joy'),stick=document.getElementById('stick'),mm=document.getElementById('mmHero'),toast=document.getElementById('toast');let x=0,y=0,vx=0,vy=0,inputX=0,inputY=0,active=false,paused=false,secs=1800,hp=100,gold=0,xp=0;
function msg(t){toast.textContent=t;toast.classList.add('show');setTimeout(()=>toast.classList.remove('show'),700)}
function point(e){let r=joy.getBoundingClientRect(),p=e.touches?e.touches[0]:e;let dx=p.clientX-(r.left+r.width/2),dy=p.clientY-(r.top+r.height/2),max=37,d=Math.hypot(dx,dy)||1,s=Math.min(1,max/d);inputX=dx/max*s;inputY=dy/max*s;stick.style.transform=`translate(${dx*s}px,${dy*s}px)`}
joy.addEventListener('pointerdown',e=>{active=true;joy.setPointerCapture(e.pointerId);point(e)});
joy.addEventListener('pointermove',e=>{if(active)point(e)});
joy.addEventListener('pointerup',()=>{active=false;inputX=inputY=0;stick.style.transform=''});
function frame(){if(!paused){vx+=(inputX*2.4-vx)*.13;vy+=(inputY*2.4-vy)*.13;x=Math.max(-120,Math.min(120,x+vx));y=Math.max(-190,Math.min(110,y+vy));hero.style.transform=`translate(${x}px,${y}px)`;mm.style.transform=`translate(${x*.12}px,${y*.12}px)`}requestAnimationFrame(frame)}frame();
setInterval(()=>{if(paused||secs<=0)return;secs--;let m=Math.floor(secs/60),s=secs%60;document.getElementById('timer').textContent=`${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`},1000);
document.getElementById('action').onclick=()=>{if(paused)return;hp=Math.max(0,hp-34);document.getElementById('hpbar').style.width=hp+'%';gold+=15;xp+=35;document.querySelectorAll('.gain b')[0].textContent=xp;document.querySelectorAll('.gain b')[1].textContent=gold;msg(hp?`Task Commit → Tower B1 ${hp} HP`:'Tower B1 Destroyed');if(!hp){document.getElementById('objective').textContent='Tower B2';hp=100;setTimeout(()=>document.getElementById('hpbar').style.width='100%',450)}};
document.getElementById('pause').onclick=()=>{paused=true;document.getElementById('pauseSheet').classList.remove('hidden')};
document.getElementById('resume').onclick=()=>{paused=false;document.getElementById('pauseSheet').classList.add('hidden')};
document.getElementById('exit').onclick=()=>msg('Exit confirmation → Home');
document.getElementById('minimap').onclick=()=>msg('Minimap: display only • no teleport');
