const $=x=>document.getElementById(x);
const stages=['READY','TASK_COMMITTED','SHEET_EXIT','FACE_TARGET','ATTACK_WINDUP','PROJECTILE','IMPACT','DEFEAT_COMMIT','REWARD_COMMIT','RESERVATION_COMPLETE','FEEDBACK','DESPAWN','DONE'];
let busy=false,stage='READY',reservation='RESERVED',rewarded=false;
$('pipeline').innerHTML=stages.map(s=>`<span class="chip" data-s="${s}">${s}</span>`).join('');
function setStage(s){stage=s;$('stage').textContent=s;document.querySelectorAll('.chip').forEach(c=>c.classList.toggle('on',c.dataset.s===s))}
const wait=ms=>new Promise(r=>setTimeout(r,ms));
async function complete(){
 if(busy||stage!=='READY'){ $('log').textContent='Duplicate Complete ignored'; return}
 busy=true;
 setStage('TASK_COMMITTED');$('log').textContent='Task commit ثبت شد';await wait(180);
 for(const s of ['SHEET_EXIT','FACE_TARGET','ATTACK_WINDUP']){setStage(s);await wait(120)}
 setStage('PROJECTILE');$('projectile').classList.remove('fire');void $('projectile').offsetWidth;$('projectile').classList.add('fire');await wait(280);
 setStage('IMPACT');$('impact').classList.remove('on');void $('impact').offsetWidth;$('impact').classList.add('on');$('minion').classList.add('hit');await wait(140);
 setStage('DEFEAT_COMMIT');$('minionState').textContent='DEFEATED';$('minion').classList.add('dead');await wait(180);
 setStage('REWARD_COMMIT');if(!rewarded){rewarded=true;$('reward').textContent='120 XP / 35 G'}await wait(180);
 setStage('RESERVATION_COMPLETE');reservation='COMPLETED';$('reservation').textContent=reservation;await wait(140);
 setStage('FEEDBACK');await wait(180);setStage('DESPAWN');await wait(180);setStage('DONE');$('log').textContent='Reward و Reservation فقط یک بار Commit شدند';busy=false;
}
$('complete').onclick=complete;
$('defer').onclick=()=>{if(busy)return;reservation='DEFERRED';$('reservation').textContent=reservation;$('minionState').textContent='DEFERRED';$('minion').classList.add('dead');setStage('DESPAWN');$('log').textContent='Defer — بدون Attack و Reward'};
$('cancel').onclick=()=>{if(busy)return;reservation='RESERVED';$('reservation').textContent=reservation;$('minionState').textContent='WAITING';$('minion').classList.remove('hit','dead');setStage('READY');$('log').textContent='Cancel — Reservation حفظ شد'};
setStage('READY');
