const $=x=>document.getElementById(x);
let played=false,reduce=false;
const wait=ms=>new Promise(r=>setTimeout(r,ms));
const phase=x=>$('phase').textContent=x;
$('play').onclick=async()=>{
 if(played){$('log').textContent='Victory Presentation دوباره اجرا نمی‌شود.';return}
 played=true;$('log').textContent='Controls locked — Scheduler stopped';
 phase('CORE OVERLOAD');$('base').classList.add('overload');await wait(220);
 phase('SHIELD IMPLOSION');$('base').classList.add('implode');await wait(280);
 phase('FRACTURE');$('base').classList.add('fracture');await wait(180);
 phase('FINAL COLLAPSE');if(!reduce)$('base').classList.add('collapse');else $('base').style.opacity='.18';await wait(reduce?180:520);
 phase('SHOCKWAVE');if(!reduce){$('shock').classList.remove('on');void $('shock').offsetWidth;$('shock').classList.add('on')}await wait(260);
 phase('SMOKE');$('smoke').classList.remove('on');void $('smoke').offsetWidth;$('smoke').classList.add('on');await wait(reduce?220:600);
 phase('HERO VICTORY');$('hero').classList.add('win');await wait(600);
 phase('VICTORY');$('victory').classList.add('on');await wait(900);
 phase('RESULTS');$('route').textContent='RESULTS';$('log').textContent='Result snapshot verified — Route Results once';
};
$('reduce').onclick=()=>{reduce=!reduce;$('reduce').textContent=reduce?'Reduce Motion: ON':'Reduce Motion';};
