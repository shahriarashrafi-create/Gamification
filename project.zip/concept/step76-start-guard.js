const $=x=>document.getElementById(x);
let recoverable=false,tasks=8,starting=false;
function render(){
 $('recover').className='recover'+(recoverable?' on':'');
 $('tasks').textContent=tasks;
 $('start').textContent=recoverable?'ادامه بازی':'شروع بازی — ۳۰ دقیقه';
}
$('start').onclick=async()=>{
 if(starting)return;
 if(recoverable){$('log').textContent='Recoverable Match validation → Timer/Waves/Entities reconcile';return}
 if(tasks<=0){$('log').textContent='برای شروع بازی حداقل یک کار فعال لازم است.';return}
 starting=true;$('start').textContent='در حال بررسی...';$('log').textContent='Player → Hero → Tasks → Active Match → PreBattle';
 await new Promise(r=>setTimeout(r,700));
 $('log').textContent='Guard OK → PreBattle request ساخته شد؛ Match هنوز اینجا ساخته نشده.';
 starting=false;render();
};
$('toggleRecover').onclick=()=>{recoverable=!recoverable;render();$('log').textContent=recoverable?'بازی نیمه‌کاره پیدا شد؛ شروع Match جدید Block شد.':'Recoverable Match حذف نمایشی شد.'};
$('zeroTasks').onclick=()=>{tasks=tasks?0:8;render();};
$('resume').onclick=()=>{$('log').textContent='Resume validation موفق → ورود Immersive Match'};
$('end').onclick=()=>{$('log').textContent='Confirmation → Manual Exit flow → Rewardهای commit‌شده حفظ می‌شوند'};
render();
