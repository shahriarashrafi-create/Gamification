const $=x=>document.getElementById(x);
let elapsed=0,duration=1800,waveEvery=45,lastWave=0,paused=false,minions=0;
function fmt(s){s=Math.max(0,Math.ceil(s));return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0')}
function render(){
 const rem=Math.max(0,duration-elapsed);$('timer').textContent=fmt(rem);
 $('timer').className=rem<=15?'critical':rem<=60?'warning':'';
 $('state').textContent=paused?'PAUSED':rem<=0?'ENDED':'RUNNING';
 $('wave').textContent=lastWave;$('minions').textContent=minions+' / 6';
 const next=(lastWave+1)*waveEvery-elapsed;$('waveNext').textContent=fmt(Math.max(0,next));
 if(rem<=0){$('timeend').classList.add('on');$('log').textContent='Time End — Rewardهای Commit‌شده حفظ می‌شوند.'}
}
function reconcile(){
 if(paused||elapsed>=duration)return;
 const eligible=Math.floor(elapsed/waveEvery);
 if(eligible>lastWave){
   lastWave=eligible;
   if(minions<6){minions++;const m=document.createElement('div');m.className='minion';m.textContent='W'+eligible;m.style.left=(18+(eligible%3)*26)+'%';m.style.top=(15+(minions*8)%60)+'%';$('units').appendChild(m)}
 }
}
$('tick').onclick=()=>{if(!paused){elapsed+=45;reconcile();render()}};
$('pause').onclick=()=>{paused=!paused;$('pause').textContent=paused?'Resume':'Pause';render()};
$('background').onclick=()=>{if(!paused){elapsed+=180;reconcile();$('log').textContent='۳ دقیقه Background reconcile شد؛ Waveها Burst نشدند.';render()}};
render();
