const $=x=>document.getElementById(x);let surface='home',missingAttack=false,missingCore=false;
const variants={home:'lobby',hero_hub:'hub',pre_battle:'battle_idle',match:'battle_attack',results:'victory'};
function render(){
 const v=variants[surface];let source='requested_variant',file='hero_young_stylish_'+v+'.webp',detail='transparent WebP • object-fit: contain';
 if(surface==='match'&&missingAttack){source='battle_idle_plus_vfx';file='hero_young_stylish_battle_idle.webp'}
 if((surface==='match'||surface==='pre_battle')&&missingCore){source='RECOVERABLE ASSET ERROR';file='MATCH ENTRY BLOCKED';detail='core battle asset missing • no fake Hero fallback'}
 $('asset').textContent=file;$('status').textContent=source;$('detail').textContent=detail;
 $('surface').innerHTML=['Home','Hub','Pre','Match','Results'].map(x=>'<span>'+x+'</span>').join('');
}
document.querySelectorAll('[data-surface]').forEach(b=>b.onclick=()=>{surface=b.dataset.surface;render()});
$('missingAttack').onclick=()=>{missingAttack=true;missingCore=false;surface='match';render()};
$('missingCore').onclick=()=>{missingCore=true;missingAttack=false;surface='pre_battle';render()};
$('restore').onclick=()=>{missingCore=false;missingAttack=false;render()};render();
