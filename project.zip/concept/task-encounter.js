const battle=document.getElementById('battle');
const encounter=document.getElementById('encounter');
const approach=document.getElementById('approach');
const complete=document.getElementById('complete');
const defer=document.getElementById('defer');
const cancel=document.getElementById('cancel');
const projectile=document.getElementById('projectile');
const impact=document.getElementById('impact');
const reward=document.getElementById('rewardFly');
const toast=document.getElementById('toast');
const minion=document.getElementById('minion');
const state=document.getElementById('state');
const taskState=document.getElementById('taskState');
const entityState=document.getElementById('entityState');

let processing=false;
let task='unused';
let entity='alive';
let cancelled=false;

function showToast(text){
 toast.textContent=text;
 toast.classList.remove('show');
 void toast.offsetWidth;
 toast.classList.add('show');
}
function openEncounter(){
 if(processing||entity!=='alive'||task==='completed'||task==='deferred')return;
 battle.classList.add('dim');
 encounter.classList.add('active');
 state.textContent='ENCOUNTER';
 taskState.textContent='ACTIVE';
 approach.style.opacity='.25';
}
function closeEncounter(){
 encounter.classList.remove('active');
 battle.classList.remove('dim');
 state.textContent='EXPLORE';
 approach.style.opacity='1';
}
approach.addEventListener('click',openEncounter);

cancel.addEventListener('click',()=>{
 if(processing)return;
 task='unused';
 taskState.textContent='UNUSED';
 closeEncounter();
 showToast('برخورد لغو شد؛ Task حذف نشد');
});

defer.addEventListener('click',()=>{
 if(processing)return;
 task='deferred';
 taskState.textContent='DEFERRED';
 closeEncounter();
 showToast('Task فقط برای این Match کنار گذاشته شد');
 approach.disabled=true;
 approach.textContent='Task در این Match Deferred شده';
});

complete.addEventListener('click',()=>{
 if(processing||task==='completed')return;
 processing=true;
 complete.disabled=true;
 task='processing';
 taskState.textContent='PROCESSING';
 state.textContent='TASK COMPLETE';

 setTimeout(()=>{
   encounter.classList.remove('active');
   battle.classList.remove('dim');
   state.textContent='ATTACK';
   projectile.classList.add('fire');
 },220);

 setTimeout(()=>{
   impact.classList.add('show');
   minion.style.transform='translate(-50%,-50%) scale(.82)';
   minion.style.opacity='.35';
   entity='defeated';
   entityState.textContent='DEFEATED';
   state.textContent='REWARD';
 },560);

 setTimeout(()=>{
   reward.classList.add('show');
   task='completed';
   taskState.textContent='COMPLETED';
 },700);

 setTimeout(()=>{
   state.textContent='EXPLORE';
   projectile.classList.remove('fire');
   impact.classList.remove('show');
   reward.classList.remove('show');
   approach.textContent='Objective انجام شد';
   approach.disabled=true;
   processing=false;
 },1600);
});
