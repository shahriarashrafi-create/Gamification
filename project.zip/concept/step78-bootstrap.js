const $=x=>document.getElementById(x);
const phases=['Match verified','Hero assets resolved','World hydrated','Entities hydrated','Camera initialized','Collision ready','HUD bound','Immersive requested','Match start committed','Timer + Waves running'];
(async()=>{
 for(const p of phases){
   $('phase').textContent=p;
   if(p==='Camera initialized') $('hero').classList.add('on');
   await new Promise(r=>setTimeout(r,260));
 }
 $('loading').classList.add('off');
 $('joy').classList.remove('disabled');
 $('action').classList.remove('disabled');
 $('status').textContent='FIRST PLAYABLE FRAME — Controls Unlocked';
})();
