let goals=[
 {id:'g1',title:'خرید خانه شخصی',year:2028,category:'دارایی',targetValue:15000000000,currentValue:3200000000,unit:'تومان',imageUrl:'',note:'خانه‌ای آرام با فضای کاری مستقل.',status:'active',priority:'core'},
 {id:'g2',title:'سفر اروپا',year:2027,category:'سفر',targetValue:100,currentValue:40,unit:'درصد',imageUrl:'',note:'یک سفر کامل و بدون عجله.',status:'active',priority:'high'},
 {id:'g3',title:'ساخت شبکه ۱۰۰ نفره',year:2027,category:'شبکه',targetValue:100,currentValue:34,unit:'نفر',imageUrl:'',note:'شبکه‌ای فعال، سالم و قابل رشد.',status:'active',priority:'core'},
 {id:'g4',title:'درآمد ماهانه هدف',year:2026,category:'مالی',targetValue:500000000,currentValue:220000000,unit:'تومان',imageUrl:'',note:'با ثبات و قابل تکرار.',status:'planned',priority:'high'}
];

let selectedYear='all', selectedGoal=null, editId=null;
const statusLabels={planned:'برنامه‌ریزی‌شده',active:'فعال',achieved:'تحقق‌یافته',paused:'متوقف'};
const priorityWeight={core:4,high:3,medium:2,low:1};

function uid(){return crypto.randomUUID?crypto.randomUUID():Date.now().toString()+Math.random()}
function progress(g){
 if(g.status==='achieved')return 100;
 if(!g.targetValue)return 0;
 return Math.round((g.currentValue||0)/g.targetValue*100);
}
function renderYears(){
 const years=[...new Set(goals.map(g=>g.year))].sort();
 const wrap=document.getElementById('years');
 wrap.innerHTML=`<button class="${selectedYear==='all'?'active':''}" data-year="all">همه</button>`+
 years.map(y=>`<button class="${selectedYear===y?'active':''}" data-year="${y}">${y}</button>`).join('');
 document.querySelectorAll('[data-year]').forEach(b=>b.onclick=()=>{selectedYear=b.dataset.year==='all'?'all':Number(b.dataset.year);render()});
}
function visible(){
 const q=document.getElementById('searchInput').value.trim().toLowerCase();
 const cat=document.getElementById('categoryFilter').value;
 return goals.filter(g=>{
  const yearOk=selectedYear==='all'||g.year===selectedYear;
  const catOk=cat==='all'||g.category===cat;
  const textOk=!q||`${g.title} ${g.category} ${g.note}`.toLowerCase().includes(q);
  return yearOk&&catOk&&textOk;
 }).sort((a,b)=>(priorityWeight[b.priority]-priorityWeight[a.priority])||(progress(b)-progress(a)));
}
function renderList(){
 const list=document.getElementById('goalList');
 const data=visible();
 if(!data.length){
  list.innerHTML=`<div class="empty"><i>◈</i><b>Vision پیدا نشد</b><span>سال، دسته یا جستجو را تغییر بده.</span></div>`;
  return;
 }
 list.innerHTML=data.map(g=>{
  const p=progress(g), clamp=Math.min(100,p);
  const style=g.imageUrl?`style="background-image:url('${g.imageUrl.replace(/'/g,"")}')"`:'';
  return `<article class="goal" data-open="${g.id}">
    <div class="goal-visual ${g.imageUrl?'has-image':''}" ${style}></div>
    <div class="goal-body">
      <div class="goal-head"><b>${g.title}</b><span>${g.year}</span></div>
      <div class="meta"><span>${g.category}</span><span>${statusLabels[g.status]}</span><span>${g.priority}</span></div>
      <div class="progress"><div><span>${g.currentValue||0} / ${g.targetValue||0} ${g.unit}</span><b>${p}%</b></div><i><em style="width:${clamp}%"></em></i></div>
      <div class="goal-note">${g.note||'بدون یادداشت'}</div>
    </div>
  </article>`;
 }).join('');
 document.querySelectorAll('[data-open]').forEach(el=>el.onclick=()=>openDetail(el.dataset.open));
}
function render(){renderYears();renderList()}
document.getElementById('searchInput').addEventListener('input',renderList);
document.getElementById('categoryFilter').addEventListener('change',renderList);

function openDetail(id){
 selectedGoal=id;const g=goals.find(x=>x.id===id);const p=progress(g);
 document.getElementById('detailTitle').textContent=g.title;
 document.getElementById('detailYear').textContent=g.year;
 document.getElementById('detailCategory').textContent=g.category;
 document.getElementById('detailStatus').textContent=statusLabels[g.status];
 document.getElementById('detailTarget').textContent=`${g.currentValue||0} / ${g.targetValue||0} ${g.unit}`;
 document.getElementById('detailProgress').textContent=p+'%';
 document.getElementById('detailBar').style.width=Math.min(100,p)+'%';
 document.getElementById('detailNote').textContent=g.note||'بدون یادداشت';
 document.getElementById('detailVisual').style.backgroundImage=g.imageUrl?`url("${g.imageUrl}")`:'';
 document.getElementById('togglePause').textContent=g.status==='paused'?'فعال‌کردن':'توقف';
 document.getElementById('detailWrap').classList.add('show');
}
document.getElementById('closeDetail').onclick=()=>document.getElementById('detailWrap').classList.remove('show');
document.getElementById('editGoal').onclick=()=>{document.getElementById('detailWrap').classList.remove('show');openForm(selectedGoal)};
document.getElementById('togglePause').onclick=()=>{
 const g=goals.find(x=>x.id===selectedGoal);
 g.status=g.status==='paused'?'active':'paused';
 document.getElementById('detailWrap').classList.remove('show');render();openDetail(selectedGoal);
};
document.getElementById('achieveGoal').onclick=()=>{
 const g=goals.find(x=>x.id===selectedGoal);g.status='achieved';g.currentValue=g.targetValue||g.currentValue;
 document.getElementById('detailWrap').classList.remove('show');render();
};
document.getElementById('deleteGoal').onclick=()=>document.getElementById('confirmWrap').classList.add('show');

function openForm(id=null){
 editId=id;document.getElementById('goalForm').reset();
 document.getElementById('yearField').value=2027;
 document.getElementById('targetField').value=100;
 document.getElementById('currentField').value=0;
 document.getElementById('unitField').value='درصد';
 if(id){
  const g=goals.find(x=>x.id===id);
  document.getElementById('goalFormTitle').textContent='ویرایش Vision';
  document.getElementById('titleField').value=g.title;
  document.getElementById('yearField').value=g.year;
  document.getElementById('categoryField').value=g.category;
  document.getElementById('targetField').value=g.targetValue||0;
  document.getElementById('currentField').value=g.currentValue||0;
  document.getElementById('unitField').value=g.unit;
  document.getElementById('priorityField').value=g.priority;
  document.getElementById('imageField').value=g.imageUrl||'';
  document.getElementById('noteField').value=g.note||'';
 }else document.getElementById('goalFormTitle').textContent='Vision جدید';
 document.getElementById('goalFormWrap').classList.add('show');
}
document.getElementById('addGoal').onclick=()=>openForm();
document.getElementById('closeGoalForm').onclick=()=>document.getElementById('goalFormWrap').classList.remove('show');
document.getElementById('cancelGoalForm').onclick=()=>document.getElementById('goalFormWrap').classList.remove('show');
document.getElementById('goalForm').addEventListener('submit',e=>{
 e.preventDefault();
 const data={
  title:document.getElementById('titleField').value.trim(),
  year:Math.max(2026,Number(document.getElementById('yearField').value)||2026),
  category:document.getElementById('categoryField').value,
  targetValue:Math.max(0,Number(document.getElementById('targetField').value)||0),
  currentValue:Math.max(0,Number(document.getElementById('currentField').value)||0),
  unit:document.getElementById('unitField').value.trim(),
  priority:document.getElementById('priorityField').value,
  imageUrl:document.getElementById('imageField').value.trim(),
  note:document.getElementById('noteField').value.trim(),
  status:'active'
 };
 if(editId){
  const old=goals.find(x=>x.id===editId);data.status=old.status;Object.assign(old,data);
 } else goals.unshift({id:uid(),...data});
 document.getElementById('goalFormWrap').classList.remove('show');render();
});
document.getElementById('confirmNo').onclick=()=>document.getElementById('confirmWrap').classList.remove('show');
document.getElementById('confirmYes').onclick=()=>{
 const i=goals.findIndex(x=>x.id===selectedGoal);if(i>=0)goals.splice(i,1);
 document.getElementById('confirmWrap').classList.remove('show');
 document.getElementById('detailWrap').classList.remove('show');
 render();
};

render();
