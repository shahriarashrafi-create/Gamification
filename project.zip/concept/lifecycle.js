let state='active',events=[];const $=id=>document.getElementById(id);
function add(t){events.unshift(t);$('timeline').innerHTML=events.slice(0,6).map(x=>'<div class="event">'+x+'</div>').join('')}
function set(s,label){state=s;$('state').textContent=label}
function pause(){set('paused','PAUSED');$('sheet').classList.add('show');add('<b>PAUSE</b> • Timer + Waves paused • controls locked')}
function resume(){set('active','ACTIVE MATCH');$('sheet').classList.remove('show');add('<b>RESUME</b> • controls reset neutral → active')}
$('pause').onclick=pause;$('resume').onclick=resume;
$('back').onclick=()=>state==='paused'?resume():pause();
$('bg').onclick=()=>{set('background','BACKGROUND');$('sheet').classList.remove('show');$('saved').textContent='Checkpoint: persisted';add('<b>BACKGROUND</b> • pointer cleared • Hero soft-stop • checkpoint saved')};
$('fg').onclick=()=>{set('resume','RESUME REQUESTED');add('<b>FOREGROUND</b> • viewport recompute • immersive reapplied • camera→Hero');setTimeout(()=>{set('active','ACTIVE MATCH');add('<b>ACTIVE</b> • neutral controls • timer resumed')},600)};
$('exit').onclick=()=>{$('confirm').classList.add('show')};$('stay').onclick=()=>{$('confirm').classList.remove('show')};$('leave').onclick=()=>{$('confirm').classList.remove('show');$('sheet').classList.remove('show');set('home','HOME • SYSTEM BARS RESTORED');add('<b>HOME</b> • committed rewards kept • immersive OFF')};
add('<b>ACTIVE</b> • immersive ON • Match checkpoint valid');