const $=x=>document.getElementById(x);
let tower2Destroyed=false,laneComplete=false,baseUnlocked=false;
const wait=ms=>new Promise(r=>setTimeout(r,ms));
$('destroy').onclick=async()=>{
 if(tower2Destroyed){$('log').textContent='Duplicate Tower2 destruction ignored';return}
 tower2Destroyed=true;laneComplete=true;
 $('tower2').classList.add('dead');$('laneState').textContent='COMPLETE';$('count').textContent='1';
 $('ceremony').classList.add('on');$('log').textContent='Lane Complete committed شد.';
 await wait(900);$('ceremony').classList.remove('on');
};
$('unlock').onclick=async()=>{
 if(!laneComplete){$('log').textContent='اول Lane باید Complete شود';return}
 if(baseUnlocked){$('log').textContent='Duplicate Base unlock ignored';return}
 baseUnlocked=true;$('baseState').textContent='AVAILABLE';$('baseLabel').textContent='OBJECTIVE AVAILABLE';
 $('base').classList.remove('locked');$('base').classList.add('available');$('gate').textContent='BASE GATE OPEN';$('gate').classList.add('open');
 $('log').textContent='Enemy Base unlock committed — Shield و Gate باز شدند.';
};
$('route').onclick=()=>{
 $('log').textContent=baseUnlocked?'Objective پیشنهادی: Enemy Base — بدون Teleport و حرکت اجباری':'Base هنوز Locked است.';
};
