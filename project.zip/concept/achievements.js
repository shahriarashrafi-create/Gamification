let wallet={xp:6240,gold:2437,diamond:12};
let achievements=[
 {id:'a1',title:'شروع قدرتمند',description:'۳ Task را امروز کامل کن',period:'daily',metricType:'tasks_completed',targetValue:3,currentValue:3,state:'ready',rewardXP:120,rewardGold:60,rewardDiamond:0,badgeIcon:'✦',priority:'medium',active:true},
 {id:'a2',title:'فرمانده پیگیری',description:'۱۰ Follow-up در هفته',period:'weekly',metricType:'followups',targetValue:10,currentValue:8,state:'progress',rewardXP:150,rewardGold:80,rewardDiamond:0,badgeIcon:'◎',priority:'high',active:true},
 {id:'a3',title:'هفته منظم',description:'۵ Match کامل در هفته',period:'weekly',metricType:'matches_completed',targetValue:5,currentValue:5,state:'claimed',rewardXP:200,rewardGold:120,rewardDiamond:0,badgeIcon:'◇',priority:'medium',active:true},
 {id:'a4',title:'ماه شبکه‌ساز',description:'۵۰ Action شبکه‌سازی در ماه',period:'monthly',metricType:'networking_actions',targetValue:50,currentValue:31,state:'progress',rewardXP:400,rewardGold:250,rewardDiamond:1,badgeIcon:'♟',priority:'high',active:true},
 {id:'a5',title:'اسطوره مسیر',description:'به Level 50 برس',period:'long_term',metricType:'level',targetValue:50,currentValue:28,state:'progress',rewardXP:1000,rewardGold:700,rewardDiamond:5,badgeIcon:'♛',priority:'core',active:true},
 {id:'a6',title:'قفل افتخار',description:'بعد از Level 30 باز می‌شود',period:'long_term',metricType:'custom_manual',targetValue:1,currentValue:0,state:'locked',rewardXP:500,rewardGold:300,rewardDiamond:2,badgeIcon:'⌾',priority:'high',active:true}
];
let claims=[];
let period='daily', editId=null, pendingConfirm=null;

const stateLabels={locked:'قفل',progress:'در حال پیشرفت',ready:'آماده دریافت',claimed:'دریافت‌شده'};
const priorityWeight={core:4,high:3,medium:2,low:1};

function uid(){return crypto.randomUUID?crypto.randomUUID():Date.now().toString()+Math.random()}
function pct(a){return a.targetValue?Math.round(a.currentValue/a.targetValue*100):0}
function normalizeState(a){
 if(a.state==='claimed'||a.state==='locked')return;
 if(a.currentValue>=a.targetValue)a.state='ready';
 else a.state='progress';
}
function showToast(t){
 const el=document.getElementById('toast');el.textContent=t;el.classList.remove('show');void el.offsetWidth;el.classList.add('show');
}
function renderWallet(){
 document.getElementById('xpWallet').textContent=wallet.xp;
 document.getElementById('goldWallet').textContent=wallet.gold;
 document.getElementById('diamondWallet').textContent=wallet.diamond;
}
function visible(){
 const q=document.getElementById('searchInput').value.trim().toLowerCase();
 const sf=document.getElementById('stateFilter').value;
 achievements.forEach(normalizeState);
 return achievements.filter(a=>{
   if(!a.active||a.period!==period)return false;
   if(sf!=='all'&&a.state!==sf)return false;
   return !q||`${a.title} ${a.description} ${a.metricType}`.toLowerCase().includes(q);
 }).sort((a,b)=>{
   const order={ready:4,progress:3,locked:2,claimed:1};
   return order[b.state]-order[a.state] || pct(b)-pct(a) || priorityWeight[b.priority]-priorityWeight[a.priority];
 });
}
function render(){
 renderWallet();
 document.querySelectorAll('#periodTabs button').forEach(b=>b.classList.toggle('active',b.dataset.period===period));
 const list=document.getElementById('achievementList'),data=visible();
 if(!data.length){
   list.innerHTML=`<div class="empty"><i>♛</i><b>دستاوردی در این بخش نیست</b><span>یک Achievement جدید بساز.</span></div>`;
   return;
 }
 list.innerHTML=data.map(a=>{
   const p=pct(a),clamp=Math.min(100,p);
   return `<article class="achievement ${a.state}">
    <div class="ahead">
      <div class="badge">${a.badgeIcon||'✦'}</div>
      <div class="aname"><b>${a.title}</b><span>${a.description}</span></div>
      <button class="state">${stateLabels[a.state]}</button>
    </div>
    <div class="progress"><div><span>${a.currentValue} / ${a.targetValue}</span><b>${p}%</b></div><i><em style="width:${clamp}%"></em></i></div>
    <div class="rewards"><span>XP +${a.rewardXP}</span><span class="gold">● +${a.rewardGold}</span><span class="diamond">◆ +${a.rewardDiamond}</span></div>
    <div class="actions">
      ${a.state==='ready'?`<button class="claim" data-claim="${a.id}">دریافت پاداش</button>`:''}
      <button data-edit="${a.id}">ویرایش</button>
      <button class="danger" data-delete="${a.id}">حذف</button>
    </div>
   </article>`;
 }).join('');
 document.querySelectorAll('[data-claim]').forEach(b=>b.onclick=()=>askClaim(b.dataset.claim));
 document.querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>openForm(b.dataset.edit));
 document.querySelectorAll('[data-delete]').forEach(b=>b.onclick=()=>askDelete(b.dataset.delete));
}
document.querySelectorAll('#periodTabs button').forEach(b=>b.onclick=()=>{period=b.dataset.period;render()});
document.getElementById('searchInput').addEventListener('input',render);
document.getElementById('stateFilter').addEventListener('change',render);

function askClaim(id){
 const a=achievements.find(x=>x.id===id);
 if(!a||a.state!=='ready'){showToast('این دستاورد آماده Claim نیست');return}
 pendingConfirm={kind:'claim',id};
 document.getElementById('confirmTitle').textContent='دریافت پاداش؟';
 document.getElementById('confirmText').textContent=`${a.rewardXP} XP + ${a.rewardGold} Gold + ${a.rewardDiamond} Diamond دریافت می‌شود.`;
 document.getElementById('confirmWrap').classList.add('show');
}
function askDelete(id){
 pendingConfirm={kind:'delete',id};
 document.getElementById('confirmTitle').textContent='حذف Achievement؟';
 document.getElementById('confirmText').textContent='Claim history قبلی در معماری نهایی حفظ می‌شود.';
 document.getElementById('confirmWrap').classList.add('show');
}
document.getElementById('confirmNo').onclick=()=>{pendingConfirm=null;document.getElementById('confirmWrap').classList.remove('show')};
document.getElementById('confirmYes').onclick=()=>{
 if(!pendingConfirm)return;
 if(pendingConfirm.kind==='claim'){
   const a=achievements.find(x=>x.id===pendingConfirm.id);
   if(a && a.state==='ready'){
     wallet.xp+=a.rewardXP;wallet.gold+=a.rewardGold;wallet.diamond+=a.rewardDiamond;
     claims.push({
       id:uid(),achievementId:a.id,titleSnapshot:a.title,
       rewardSnapshot:{xp:a.rewardXP,gold:a.rewardGold,diamond:a.rewardDiamond},
       claimedAt:new Date().toLocaleString('fa-IR')
     });
     a.state='claimed';
     showToast('پاداش دریافت شد');
   }else showToast('Claim دوباره مجاز نیست');
 }
 if(pendingConfirm.kind==='delete'){
   const i=achievements.findIndex(x=>x.id===pendingConfirm.id);
   if(i>=0)achievements.splice(i,1);
 }
 pendingConfirm=null;document.getElementById('confirmWrap').classList.remove('show');render();
};

function openForm(id=null){
 editId=id;document.getElementById('achievementForm').reset();
 document.getElementById('targetField').value=3;
 document.getElementById('currentField').value=0;
 document.getElementById('xpField').value=100;
 document.getElementById('goldField').value=50;
 document.getElementById('diamondField').value=0;
 document.getElementById('periodField').value=period;
 if(id){
   const a=achievements.find(x=>x.id===id);
   document.getElementById('formTitle').textContent='ویرایش Achievement';
   document.getElementById('titleField').value=a.title;
   document.getElementById('descriptionField').value=a.description;
   document.getElementById('periodField').value=a.period;
   document.getElementById('metricField').value=a.metricType;
   document.getElementById('targetField').value=a.targetValue;
   document.getElementById('currentField').value=a.currentValue;
   document.getElementById('xpField').value=a.rewardXP;
   document.getElementById('goldField').value=a.rewardGold;
   document.getElementById('diamondField').value=a.rewardDiamond;
   document.getElementById('stateField').value=a.state;
 } else document.getElementById('formTitle').textContent='دستاورد جدید';
 document.getElementById('formWrap').classList.add('show');
}
document.getElementById('addAchievement').onclick=()=>openForm();
document.getElementById('closeForm').onclick=()=>document.getElementById('formWrap').classList.remove('show');
document.getElementById('cancelForm').onclick=()=>document.getElementById('formWrap').classList.remove('show');
document.getElementById('achievementForm').addEventListener('submit',e=>{
 e.preventDefault();
 const data={
  title:document.getElementById('titleField').value.trim(),
  description:document.getElementById('descriptionField').value.trim(),
  period:document.getElementById('periodField').value,
  metricType:document.getElementById('metricField').value.trim(),
  targetValue:Math.max(0,Number(document.getElementById('targetField').value)||0),
  currentValue:Math.max(0,Number(document.getElementById('currentField').value)||0),
  rewardXP:Math.max(0,Number(document.getElementById('xpField').value)||0),
  rewardGold:Math.max(0,Number(document.getElementById('goldField').value)||0),
  rewardDiamond:Math.max(0,Number(document.getElementById('diamondField').value)||0),
  state:document.getElementById('stateField').value,
  badgeIcon:'✦',priority:'medium',active:true
 };
 if(data.state!=='locked'&&data.state!=='claimed')data.state=data.currentValue>=data.targetValue?'ready':'progress';
 if(editId)Object.assign(achievements.find(x=>x.id===editId),data);
 else achievements.unshift({id:uid(),...data});
 period=data.period;
 document.getElementById('formWrap').classList.remove('show');render();
});

render();
