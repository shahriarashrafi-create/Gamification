const $=id=>document.getElementById(id);
let hasTasks=true, assetsOk=true, activeMatch=false, busy=false;
const stages=['بررسی Hero','آماده‌سازی کارها','ساخت میدان','ذخیره Match','ورود به میدان'];
function refresh(){
  const taskCard=$('taskCard');
  taskCard.classList.toggle('ready',hasTasks);
  taskCard.classList.toggle('blocked',!hasTasks);
  $('taskCount').textContent=hasTasks?'۱۲ کار فعال':'۰ کار فعال';
  $('taskMeta').textContent=hasTasks?'۵ دسته • آماده':'Task Pool مسدود';
  $('toggleTasks').textContent='Tasks '+(hasTasks?'ON':'OFF');
  $('toggleAsset').textContent='Assets '+(assetsOk?'OK':'ERROR');
  $('toggleMatch').textContent=activeMatch?'Active Match':'No Active Match';
}
function showError(title,text){
  $('errorTitle').textContent=title;
  $('errorText').textContent=text;
  $('errorBox').classList.remove('hidden');
}
function clearError(){$('errorBox').classList.add('hidden')}
$('toggleTasks').onclick=()=>{if(busy)return;hasTasks=!hasTasks;refresh();clearError()};
$('toggleAsset').onclick=()=>{if(busy)return;assetsOk=!assetsOk;refresh();clearError()};
$('toggleMatch').onclick=()=>{if(busy)return;activeMatch=!activeMatch;refresh();clearError()};
$('back').onclick=()=>{if(!busy)$('status').textContent='HOME ←'};
$('enterBattle').onclick=async()=>{
  if(busy)return;
  clearError();
  if(activeMatch){showError('Match فعال وجود دارد','اول Match نیمه‌تمام را از Home ادامه بده یا پایان بده.');return}
  if(!hasTasks){showError('کار فعال لازم است','برای شروع بازی حداقل یک کار فعال لازم است.');return}
  if(!assetsOk){showError('Asset حیاتی آماده نیست','Battlefield یا Entityهای لازم کامل بارگذاری نشده‌اند.');return}
  busy=true;
  $('enterBattle').disabled=true;
  $('stageBox').classList.remove('hidden');
  $('status').textContent='INIT';
  for(const s of stages){
    $('stageText').textContent=s;
    await new Promise(r=>setTimeout(r,430));
  }
  $('stageText').textContent='Match ذخیره شد • Immersive Ready';
  $('status').textContent='READY';
  await new Promise(r=>setTimeout(r,500));
  $('status').textContent='BATTLE →';
  $('enterBattle').disabled=false;
  busy=false;
};
refresh();
