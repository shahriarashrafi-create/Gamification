let gold=2437,diamond=12,xp=6240,applied=false,migrated=false;const $=id=>document.getElementById(id);
function render(){$('gold').textContent=gold;$('diamond').textContent=diamond;$('xp').textContent=xp}
$('reward').onclick=()=>{if(applied){$('ledger').textContent='BLOCKED • transactionId already exists';return}applied=true;gold+=35;xp+=120;render();$('ledger').textContent='COMMIT • tx_match_demo_task_001 • wallet + progression updated atomically'};
$('duplicate').onclick=()=>{$('ledger').textContent=applied?'BLOCKED • duplicate transactionId → no wallet mutation':'No original transaction exists yet.'};
$('migrate').onclick=()=>{if(migrated){$('migrationLog').textContent='IDEMPOTENT • migration already applied • no duplicate changes';return}migrated=true;$('migrationLog').textContent='COMMIT • ledger created • wallet normalized • repeatMode + schema metadata added'};
render();