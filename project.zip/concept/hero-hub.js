let gold=2437;
let heroes=[{"id": "young_stylish", "name": "آقای جوان خوش‌تیپ", "gender": "male", "desc": "مدرن • جاه‌طلب • پرانرژی", "price": 0, "unlocked": true}, {"id": "luxury_mature_m", "name": "آقای میان‌سال لاکچری", "gender": "male", "desc": "لوکس • موفق • باوقار", "price": 2400, "unlocked": false}, {"id": "charismatic_m", "name": "آقای خوش‌برخورد", "gender": "male", "desc": "اجتماعی • کاریزماتیک • صمیمی", "price": 1900, "unlocked": false}, {"id": "disciplined_m", "name": "آقای بادیسیپلین", "gender": "male", "desc": "منظم • جدی • رهبر", "price": 2800, "unlocked": false}, {"id": "young_stylish_f", "name": "خانم جوان شیک", "gender": "female", "desc": "مدرن • بااعتمادبه‌نفس • پرانرژی", "price": 0, "unlocked": true}, {"id": "luxury_mature_f", "name": "خانم میان‌سال لاکچری", "gender": "female", "desc": "حرفه‌ای • موفق • سطح بالا", "price": 2400, "unlocked": false}, {"id": "charismatic_f", "name": "خانم خوش‌برخورد", "gender": "female", "desc": "اجتماعی • صمیمی • کاریزماتیک", "price": 1900, "unlocked": false}, {"id": "disciplined_f", "name": "خانم بادیسیپلین", "gender": "female", "desc": "قدرتمند • منظم • مدیریتی", "price": 2800, "unlocked": false}];
let selected='young_stylish', viewing=selected, gender='all', slot='outfit', pending=null;
const slots=['outfit','accessory','aura','effect','background','frame','title'];
const slotFa={outfit:'لباس',accessory:'اکسسوری',aura:'Aura',effect:'Effect',background:'پس‌زمینه',frame:'قاب',title:'عنوان'};
let loadouts={};
let items=[
{id:'classic',slot:'outfit',name:'لباس کلاسیک',price:0,unlocked:true},
{id:'executive',slot:'outfit',name:'Executive Gold',price:650,unlocked:false},
{id:'midnight',slot:'outfit',name:'Midnight',price:480,unlocked:false},
{id:'watch',slot:'accessory',name:'ساعت لوکس',price:320,unlocked:false},
{id:'cyan_aura',slot:'aura',name:'Cyan Aura',price:550,unlocked:false},
{id:'castle',slot:'background',name:'قلعه شب',price:900,unlocked:false}
];
const toast=t=>{let e=document.getElementById('toast');e.textContent=t;e.classList.remove('show');void e.offsetWidth;e.classList.add('show')};
function hero(){return heroes.find(h=>h.id===viewing)}
function render(){
 document.getElementById('gold').textContent=gold;
 const h=hero();document.getElementById('heroName').textContent=h.name;document.getElementById('heroDesc').textContent=h.desc;document.getElementById('gender').textContent=h.gender==='male'?'MALE HERO':'FEMALE HERO';
 let sb=document.getElementById('selectBtn');
 if(viewing===selected){sb.textContent='انتخاب‌شده';sb.disabled=true}else if(h.unlocked){sb.textContent='انتخاب Hero';sb.disabled=false}else{sb.textContent='بازکردن با '+h.price+' Gold';sb.disabled=false}
 document.getElementById('roster').innerHTML=heroes.filter(x=>gender==='all'||x.gender===gender).map(x=>`<button class="hero-card ${x.id===viewing?'on':''}" data-hero="${x.id}"><span class="avatar">${x.gender==='male'?'◆':'◇'}</span><b>${x.name}</b><small>${x.unlocked?'باز':'● '+x.price}</small></button>`).join('');
 document.querySelectorAll('[data-hero]').forEach(b=>b.onclick=()=>{viewing=b.dataset.hero;render()});
 document.getElementById('slots').innerHTML=slots.map(s=>`<button class="slot ${s===slot?'on':''}" data-slot="${s}">${slotFa[s]}</button>`).join('');
 document.querySelectorAll('[data-slot]').forEach(b=>b.onclick=()=>{slot=b.dataset.slot;render()});
 const list=items.filter(i=>i.slot===slot);
 document.getElementById('items').innerHTML=(list.length?list:[{id:'none',slot,name:'آیتمی ثبت نشده',price:0,unlocked:true}]).map(i=>{
  let eq=(loadouts[viewing]||{})[slot]===i.id;
  return `<button class="item ${eq?'equipped':''}" data-item="${i.id}"><b>${i.name}</b>${eq?'Equipped':i.unlocked?'Equip':'● '+i.price+' Gold'}</button>`
 }).join('');
 document.querySelectorAll('[data-item]').forEach(b=>b.onclick=()=>itemAction(b.dataset.item));
}
document.querySelectorAll('.filter').forEach(b=>b.onclick=()=>{document.querySelectorAll('.filter').forEach(x=>x.classList.remove('on'));b.classList.add('on');gender=b.dataset.gender;render()});
document.getElementById('selectBtn').onclick=()=>{let h=hero();if(h.unlocked){selected=h.id;toast('Hero انتخاب شد');render()}else openBuy({type:'hero',id:h.id,name:h.name,price:h.price})};
function itemAction(id){if(id==='none')return;let i=items.find(x=>x.id===id);if(!i.unlocked)return openBuy({type:'item',id:i.id,name:i.name,price:i.price});loadouts[viewing]??={};if(loadouts[viewing][slot]===id){delete loadouts[viewing][slot];toast('Unequip شد')}else{loadouts[viewing][slot]=id;toast('Equip شد')}render()}
function openBuy(x){pending=x;document.getElementById('buyTitle').textContent=x.name;document.getElementById('buyDesc').textContent=x.type==='hero'?'Hero فقط ظاهر و هویت را تغییر می‌دهد؛ قدرت اضافه نمی‌کند.':'این آیتم Cosmetic است و قدرت Gameplay اضافه نمی‌کند.';document.getElementById('buyPrice').textContent=x.price;document.getElementById('buyWrap').classList.add('show')}
document.getElementById('cancelBuy').onclick=()=>{pending=null;document.getElementById('buyWrap').classList.remove('show')};
document.getElementById('confirmBuy').onclick=()=>{if(!pending)return;if(gold<pending.price)return toast('Gold کافی نیست');gold-=pending.price;if(pending.type==='hero'){let h=heroes.find(x=>x.id===pending.id);h.unlocked=true;selected=h.id}else{let i=items.find(x=>x.id===pending.id);i.unlocked=true;loadouts[viewing]??={};loadouts[viewing][i.slot]=i.id}document.getElementById('buyWrap').classList.remove('show');pending=null;toast('خرید انجام شد');render()};
render();