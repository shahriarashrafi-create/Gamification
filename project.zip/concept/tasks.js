const tasks=[
 {id:'1',title:'فالوآپ با پراسپکت امروز',category:'شبکه‌سازی',difficulty:'normal',xp:120,gold:35,diamond:1,activeInGame:true,note:'نتیجه و اقدام بعدی را ثبت کن.'},
 {id:'2',title:'تماس با سه نفر از لیست ارتباط‌سازی',category:'شبکه‌سازی',difficulty:'important',xp:180,gold:50,diamond:0,activeInGame:true,note:'سه تماس با کیفیت و ثبت نتیجه.'},
 {id:'3',title:'۳۰ دقیقه مطالعه محصول',category:'یادگیری',difficulty:'easy',xp:80,gold:20,diamond:0,activeInGame:false,note:'نکات کلیدی را یادداشت کن.'},
 {id:'4',title:'برنامه هفتگی فروش را نهایی کن',category:'برنامه‌ریزی',difficulty:'hard',xp:260,gold:70,diamond:0,activeInGame:true,note:'اهداف و اقدام‌های اصلی هفته مشخص شوند.'}
];

let currentFilter='all', editingId=null, deleteId=null;
const list=document.getElementById('taskList');
const search=document.getElementById('searchInput');
const modalWrap=document.getElementById('modalWrap');
const form=document.getElementById('taskForm');
const confirmWrap=document.getElementById('confirmWrap');

const diffLabels={easy:'آسان',normal:'متوسط',important:'مهم',hard:'سخت',strategic:'استراتژیک'};

function escapeHtml(s=''){
 return s.replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}
function visibleTasks(){
 const q=search.value.trim().toLowerCase();
 return tasks.filter(t=>{
   const hit=!q||`${t.title} ${t.category} ${t.note}`.toLowerCase().includes(q);
   if(!hit)return false;
   if(currentFilter==='active'&&!t.activeInGame)return false;
   if(currentFilter==='hard'&&!['hard','strategic'].includes(t.difficulty))return false;
   if(currentFilter==='diamond'&&t.diamond<=0)return false;
   return true;
 });
}
function render(){
 const data=visibleTasks();
 document.getElementById('totalCount').textContent=tasks.length;
 document.getElementById('activeCount').textContent=tasks.filter(t=>t.activeInGame).length;
 document.getElementById('diamondCount').textContent=tasks.filter(t=>t.diamond>0).length;

 if(!data.length){
   list.innerHTML=`<div class="empty"><i>◇</i><b>Objective پیدا نشد</b><span>فیلتر یا جستجو را تغییر بده.</span></div>`;
   return;
 }
 list.innerHTML=data.map(t=>`
 <article class="task ${t.difficulty}">
   <div class="task-head">
     <div class="task-title">
       <b>${escapeHtml(t.title)}</b>
       <span>${escapeHtml(t.category)} • ${diffLabels[t.difficulty]}</span>
     </div>
     <button class="status ${t.activeInGame?'':'off'}" data-toggle="${t.id}">${t.activeInGame?'فعال در بازی':'غیرفعال'}</button>
   </div>
   <div class="meta"><span>${diffLabels[t.difficulty]}</span><span>${escapeHtml(t.category)}</span>${t.diamond?'<span>◆ Rare Reward</span>':''}</div>
   <div class="rewards"><b class="rxp">✦ +${t.xp} XP</b><b class="rgold">● +${t.gold} Gold</b><b class="rdia">◆ +${t.diamond}</b></div>
   <div class="task-foot">
     <span class="note">${escapeHtml(t.note||'بدون یادداشت')}</span>
     <div class="task-actions"><button data-edit="${t.id}">ویرایش</button><button class="delete" data-delete="${t.id}">حذف</button></div>
   </div>
 </article>`).join('');

 document.querySelectorAll('[data-toggle]').forEach(b=>b.onclick=()=>{
   const t=tasks.find(x=>x.id===b.dataset.toggle);t.activeInGame=!t.activeInGame;render();
 });
 document.querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>openEdit(b.dataset.edit));
 document.querySelectorAll('[data-delete]').forEach(b=>b.onclick=()=>askDelete(b.dataset.delete));
}

document.querySelectorAll('#filters button').forEach(btn=>btn.onclick=()=>{
 document.querySelectorAll('#filters button').forEach(x=>x.classList.remove('active'));
 btn.classList.add('active');currentFilter=btn.dataset.filter;render();
});
search.addEventListener('input',render);
document.getElementById('clearSearch').onclick=()=>{search.value='';render()};

function openNew(){
 editingId=null;
 document.getElementById('modalTitle').textContent='افزودن کار';
 form.reset();
 document.getElementById('xpField').value=120;
 document.getElementById('goldField').value=35;
 document.getElementById('diamondField').value=0;
 document.getElementById('activeField').checked=true;
 modalWrap.classList.add('show');
}
function openEdit(id){
 const t=tasks.find(x=>x.id===id);editingId=id;
 document.getElementById('modalTitle').textContent='ویرایش کار';
 document.getElementById('titleField').value=t.title;
 document.getElementById('categoryField').value=t.category;
 document.getElementById('difficultyField').value=t.difficulty;
 document.getElementById('xpField').value=t.xp;
 document.getElementById('goldField').value=t.gold;
 document.getElementById('diamondField').value=t.diamond;
 document.getElementById('activeField').checked=t.activeInGame;
 document.getElementById('noteField').value=t.note;
 modalWrap.classList.add('show');
}
function closeModal(){modalWrap.classList.remove('show')}
document.getElementById('addBtn').onclick=openNew;
document.getElementById('closeModal').onclick=closeModal;
document.getElementById('cancelModal').onclick=closeModal;

form.addEventListener('submit',e=>{
 e.preventDefault();
 const obj={
   title:document.getElementById('titleField').value.trim(),
   category:document.getElementById('categoryField').value,
   difficulty:document.getElementById('difficultyField').value,
   xp:Math.max(0,Number(document.getElementById('xpField').value)||0),
   gold:Math.max(0,Number(document.getElementById('goldField').value)||0),
   diamond:Math.max(0,Number(document.getElementById('diamondField').value)||0),
   activeInGame:document.getElementById('activeField').checked,
   note:document.getElementById('noteField').value.trim()
 };
 if(editingId){Object.assign(tasks.find(x=>x.id===editingId),obj)}
 else tasks.unshift({id:crypto.randomUUID?crypto.randomUUID():Date.now().toString(),...obj});
 closeModal();render();
});

function askDelete(id){deleteId=id;confirmWrap.classList.add('show')}
document.getElementById('noDelete').onclick=()=>{deleteId=null;confirmWrap.classList.remove('show')};
document.getElementById('yesDelete').onclick=()=>{
 const i=tasks.findIndex(x=>x.id===deleteId);
 if(i>=0)tasks.splice(i,1);
 deleteId=null;confirmWrap.classList.remove('show');render();
};

render();
