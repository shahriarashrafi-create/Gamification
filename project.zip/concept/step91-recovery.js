let committed=false;
document.getElementById('run').onclick=()=>{
 const result=document.getElementById('result'),copy=document.getElementById('copy');
 if(!committed){
   document.getElementById('task').textContent='1';
   document.getElementById('damage').textContent='1';
   document.getElementById('reward').textContent='1';
   committed=true;
   result.textContent='CRASH!';
   copy.textContent='Transactionها Commit شده‌اند؛ برنامه بسته شد...';
   setTimeout(()=>{result.textContent='RECOVERED';copy.textContent='همه Commitها پیدا شدند؛ هیچ‌کدام دوباره اجرا نشدند.'},700);
 } else {
   result.textContent='IDEMPOTENCY PASS';
   copy.textContent='Task ×1 • Damage ×1 • Reward ×1 — بدون Duplicate';
 }
};