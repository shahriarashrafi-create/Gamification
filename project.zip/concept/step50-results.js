const $=x=>document.getElementById(x);let diamondOn=true;
const states={
 victory:{title:'پیروزی',sub:'پایگاه دشمن نابود شد',time:'24:18',tasks:7,towers:2,lanes:1,xp:980,gold:310,diamond:1,rp:34},
 time_end:{title:'پایان زمان',sub:'Rewardهای ثبت‌شده حفظ شدند',time:'30:00',tasks:5,towers:1,lanes:0,xp:620,gold:195,diamond:0,rp:18},
 manual_exit:{title:'پایان Match',sub:'خروج دستی • بدون جریمه',time:'12:46',tasks:3,towers:0,lanes:0,xp:340,gold:100,diamond:0,rp:9}
};
function render(type){const s=states[type];$('title').textContent=s.title;$('subtitle').textContent=s.sub;$('time').textContent=s.time;$('tasks').textContent=s.tasks;$('towers').textContent=s.towers;$('lanes').textContent=s.lanes;$('xp').textContent='+'+s.xp;$('gold').textContent='+'+s.gold;$('diamond').textContent='+'+s.diamond;$('rp').textContent='+'+s.rp;$('diamondCard').classList.toggle('hidden',!(diamondOn&&s.diamond>0));$('ceremony').classList.toggle('hidden',type!=='victory')}
document.querySelectorAll('[data-result]').forEach(b=>b.onclick=()=>render(b.dataset.result));
$('toggleDiamond').onclick=e=>{diamondOn=!diamondOn;e.currentTarget.textContent='Diamond '+(diamondOn?'ON':'OFF');render($('title').textContent==='پیروزی'?'victory':$('title').textContent==='پایان زمان'?'time_end':'manual_exit')};
$('home').onclick=()=>{$('subtitle').textContent='System bars restored → Home • 5-item nav'};
render('victory');
