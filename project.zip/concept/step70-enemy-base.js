const $=x=>document.getElementById(x);
let hp=100,busy=false,victory=false,rewardTx=0;
const wait=ms=>new Promise(r=>setTimeout(r,ms));
function visual(){
 const s=hp===0?'destroyed':hp<=25?'collapse_ready':hp<=50?'critical':hp<=75?'unstable':'stable';
 $('hp').textContent=hp+' / 100';$('state').textContent=s.toUpperCase();$('baseLabel').textContent=s.toUpperCase();$('base').className='base '+s;$('bar').style.width=hp+'%';
}
async function complete(){
 if(busy||victory){$('log').textContent='Duplicate/invalid Complete ignored';return}
 busy=true;$('log').textContent='Task committed → Hero attack';
 $('projectile').classList.remove('fire');void $('projectile').offsetWidth;$('projectile').classList.add('fire');await wait(300);
 $('impact').classList.remove('on');void $('impact').offsetWidth;$('impact').classList.add('on');await wait(120);
 hp=Math.max(0,hp-25);visual();rewardTx++;$('log').textContent='Base Damage -25 committed — Task Reward once';await wait(260);
 if(hp===0){
  victory=true;$('result').textContent='VICTORY';$('victory').classList.add('on');$('log').textContent='Base destruction + Victory Bonus +400 XP / +150 Gold / +1 Diamond committed once';
 }
 busy=false;
}
$('complete').onclick=complete;
$('defer').onclick=()=>{if(busy||victory)return;$('log').textContent='Defer — بدون Damage و Reward'};
$('cancel').onclick=()=>{if(busy||victory)return;$('log').textContent='Cancel — Enemy Base objective حفظ شد'};
visual();
