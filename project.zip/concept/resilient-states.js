const $=id=>document.getElementById(id);let state='ready';
const views={
ready:`<section class="state"><div class="sigil"></div><h1>سیستم آماده است</h1><p>داده‌های محلی بارگذاری شده‌اند و اپ آماده استفاده است.</p><button>ادامه</button></section>`,
empty:`<section class="state"><div class="sigil"></div><h1>هنوز کاری نداری</h1><p>برای ورود Taskها به میدان بازی، اولین کار را بساز.</p><button>ساخت اولین کار</button></section>`,
loading:`<section class="state"><div class="skeleton"><i></i><i></i><i></i><i></i></div><h1>در حال آماده‌سازی</h1><p>Skeleton ساختار صفحه را حفظ می‌کند؛ Spinner بی‌پایان نداریم.</p></section>`,
offline:`<section class="state"><div class="sigil"></div><h1>حالت آفلاین</h1><p>Taskها، درختواره، تایم‌شیت، CRM و Match محلی همچنان قابل استفاده‌اند.</p><button>ادامه آفلاین</button></section>`,
error:`<section class="state danger"><div class="sigil"></div><h1>بارگذاری کامل نشد</h1><p>می‌توانی دوباره تلاش کنی. Retry نباید هیچ داده‌ای را دوبار ثبت کند.</p><button id="retry">تلاش دوباره</button></section>`,
corrupt:`<section class="state danger"><div class="sigil"></div><h1>Match قابل بازیابی نبود</h1><p>Match ناسالم قرنطینه می‌شود؛ Rewardهای ثبت‌شده دست‌نخورده باقی می‌مانند.</p><button>بازگشت به خانه</button></section>`
};
function render(){document.querySelectorAll('[data-state]').forEach(b=>b.classList.toggle('on',b.dataset.state===state));$('title').textContent=state.toUpperCase();$('view').innerHTML=views[state];$('offline').classList.toggle('show',state==='offline');let r=$('retry');if(r)r.onclick=()=>{r.textContent='Retry Safe • No Duplicate';setTimeout(()=>{state='ready';render()},700)}}
document.querySelectorAll('[data-state]').forEach(b=>b.onclick=()=>{state=b.dataset.state;render()});render();