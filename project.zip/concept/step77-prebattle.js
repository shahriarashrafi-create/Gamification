const $=x=>document.getElementById(x);
let busy=false;
$('bootstrap').onclick=async()=>{
 if(busy)return; busy=true;
 const steps=['Validation کامل شد','Snapshotها ساخته شدند','Match ID جدید ساخته شد','Match به‌صورت Atomic ذخیره شد','Read-back Verification موفق بود','activeMatchId ثبت شد','Gameplay Route مجاز شد'];
 for(const s of steps){
   $('log').textContent=s;
   await new Promise(r=>setTimeout(r,380));
 }
 $('bootstrap').textContent='ورود به میدان';
 $('log').textContent='Timer هنوز شروع نشده؛ شروع آن در اولین Gameplay commit است.';
 busy=false;
};
