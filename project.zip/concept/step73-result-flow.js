const $=x=>document.getElementById(x);
let finalized=false;
function ceremony(type){
 if(finalized){$('log').textContent='Finalization Lock فعال است؛ Result دوم ساخته نمی‌شود.';return}
 finalized=true;$('sheet').classList.remove('on');
 $('ceremonyTitle').textContent=type==='time_end'?'زمان تمام شد':'بازی پایان داده شد';
 $('ceremony').classList.add('on');
 $('log').textContent='Committed rewards preserved → Result snapshot → Results';
}
$('timeEnd').onclick=()=>ceremony('time_end');
$('manualExit').onclick=()=>{if(finalized)return;$('sheet').classList.add('on');$('log').textContent='Manual Exit confirmation باز شد.'};
$('stay').onclick=()=>{$('sheet').classList.remove('on');$('log').textContent='Match ادامه پیدا می‌کند.'};
$('confirmExit').onclick=()=>ceremony('manual_exit');
