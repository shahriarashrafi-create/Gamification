const $=x=>document.getElementById(x);const wait=t=>new Promise(r=>setTimeout(r,t));
$('run').onclick=async()=>{$('run').disabled=true;$('phase').textContent='SHEET EXIT';$('sheet').style.transform='translateY(120%)';await wait(180);
$('phase').textContent='FACE TARGET / ATTACK';$('hero').style.boxShadow='0 0 28px #82e0e7';await wait(220);
$('phase').textContent='PROJECTILE';$('projectile').style.opacity='1';$('projectile').style.transition='.25s linear';$('projectile').style.bottom='64%';await wait(260);
$('projectile').style.opacity='0';$('phase').textContent='IMPACT';$('impact').style.opacity='1';$('impact').style.transform='translate(-50%,-50%) scale(2.4)';$('impact').style.transition='.12s';await wait(130);
$('impact').style.opacity='0';$('phase').textContent='ENTITY COMMIT';$('hp').style.width='66%';await wait(240);
$('phase').textContent='REWARD COMMIT';$('reward').style.opacity='1';$('reward').style.transition='.3s';$('reward').style.top='34%';await wait(380);
$('phase').textContent='RESUME';$('joy').style.opacity='1';$('joy').textContent='READY';$('run').disabled=false};