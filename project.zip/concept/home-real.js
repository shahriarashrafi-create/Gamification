const toast=document.getElementById('routeToast');let timer;
function routeTo(route){
  clearTimeout(timer);
  toast.textContent='Route → '+route+(route==='preBattle'?' • Match Initialization':'');
  toast.classList.add('show');
  timer=setTimeout(()=>toast.classList.remove('show'),1100);
}
document.querySelectorAll('[data-route]').forEach(el=>{
  el.addEventListener('click',()=>routeTo(el.dataset.route));
});
