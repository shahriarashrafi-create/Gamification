const $=x=>document.getElementById(x);
const heroes=[
{id:'young_stylish',name:'آقای جوان خوش‌تیپ',gender:'male'},
{id:'luxury_mature_m',name:'آقای میان‌سال لاکچری',gender:'male'},
{id:'young_stylish_f',name:'خانم جوان شیک',gender:'female'},
{id:'disciplined_f',name:'خانم بادیسیپلین',gender:'female'}
];
let ownership=new Set(['young_stylish','young_stylish_f']),selected='young_stylish';
let cosmeticOwnership=new Set(['aura_gold','frame_cyan']);
const cosmetics=[
{id:'aura_gold',name:'هاله طلایی',slot:'aura',compatibility:'all_heroes'},
{id:'frame_cyan',name:'فریم کریستالی',slot:'frame',compatibility:'all_heroes'}
];
let loadouts={young_stylish:{aura:'aura_gold',frame:null}};
function toast(t){$('toast').textContent=t;$('toast').classList.add('show');setTimeout(()=>$('toast').classList.remove('show'),900)}
function selectedHero(){return heroes.find(h=>h.id===selected)}
function render(){
 const h=selectedHero();$('heroName').textContent=h.name;$('loadoutHero').textContent=h.name;$('heroArt').textContent=h.id.toUpperCase();
 $('gallery').innerHTML=heroes.map(x=>{const own=ownership.has(x.id),sel=x.id===selected;return `<article class="heroCard ${!own?'locked':''} ${sel?'selectedCard':''}"><div class="miniArt">${x.id.toUpperCase()}</div><b>${x.name}</b><small>${!own?'LOCKED':sel?'SELECTED':'OWNED'}</small><button data-hero="${x.id}" ${sel?'disabled':''}>${!own?'رفتن به فروشگاه':sel?'انتخاب‌شده':'انتخاب'}</button></article>`}).join('');
 document.querySelectorAll('[data-hero]').forEach(b=>b.onclick=()=>select(b.dataset.hero));
 const l=loadouts[selected]||{};
 $('slots').innerHTML=['outfit','accessory','aura','effect','background','frame','title'].map(slot=>{const id=l[slot],item=cosmetics.find(c=>c.id===id);return `<div class="slot"><small>${slot}</small><b>${item?item.name:'هیچ‌کدام'}</b><button data-slot="${slot}">${item?'حذف':'انتخاب'}</button></div>`}).join('');
 document.querySelectorAll('[data-slot]').forEach(b=>b.onclick=()=>slotAction(b.dataset.slot));
}
function select(id){if(!ownership.has(id)){toast('خرید Hero از فروشگاه انجام می‌شود');return}selected=id;$('homeSync').textContent='HOME HERO REFRESHED';toast('Hero انتخاب شد');render()}
function slotAction(slot){loadouts[selected]||={};if(loadouts[selected][slot]){loadouts[selected][slot]=null;toast('Cosmetic حذف شد');render();return}
 const item=cosmetics.find(c=>c.slot===slot&&cosmeticOwnership.has(c.id));if(!item){toast('Cosmetic خریداری‌شده‌ای برای این Slot نیست');return}loadouts[selected][slot]=item.id;toast('Cosmetic تجهیز شد');render()}
render();
