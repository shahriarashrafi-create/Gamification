const data={
victory:{eyebrow:'ENEMY BASE DESTROYED',title:'VICTORY',subtitle:'نبرد با موفقیت به پایان رسید',xp:'+2,140',gold:'+620',diamond:'+1',level:'28 → 29',rp:'72 → 91 RP',xpw:'83%',rpw:'91%'},
time_end:{eyebrow:'PROGRESS SAVED',title:'TIME END',subtitle:'زمان Match تمام شد؛ تمام پیشرفت ذخیره شد',xp:'+1,660',gold:'+470',diamond:'0',level:'28',rp:'72 → 84 RP',xpw:'76%',rpw:'84%'},
manual_exit:{eyebrow:'PROGRESS SAVED',title:'MATCH ENDED',subtitle:'پاداش‌های ثبت‌شده حفظ شدند',xp:'+980',gold:'+255',diamond:'0',level:'28',rp:'72 → 77 RP',xpw:'69%',rpw:'77%'}
};
const $=id=>document.getElementById(id);
function show(type){
 const d=data[type];
 $('eyebrow').textContent=d.eyebrow;$('title').textContent=d.title;$('subtitle').textContent=d.subtitle;
 $('xpTotal').textContent=d.xp;$('goldTotal').textContent=d.gold;$('diamondTotal').textContent=d.diamond;
 $('diamondCard').style.opacity=d.diamond==='0'?'.4':'1';$('levelText').textContent=d.level;$('rpLabel').textContent=d.rp;
 $('xpBar').style.width='0';$('rpBar').style.width='0';setTimeout(()=>{$('xpBar').style.width=d.xpw;$('rpBar').style.width=d.rpw},80)
}
document.querySelectorAll('[data-type]').forEach(b=>b.onclick=()=>{document.querySelectorAll('[data-type]').forEach(x=>x.classList.remove('on'));b.classList.add('on');show(b.dataset.type)});
document.querySelector('.home').onclick=()=>toast('Restore system UI → Home');
document.querySelector('.secondary').onclick=()=>toast('Default UX: Home first, then Start Match');
function toast(t){$('toast').textContent=t;$('toast').classList.remove('show');void $('toast').offsetWidth;$('toast').classList.add('show')}
show('victory');