const toast=document.getElementById('routeToast');
const sheet=document.getElementById('sheet'), sheetTitle=document.getElementById('sheetTitle'), sheetText=document.getElementById('sheetText'), sheetAction=document.getElementById('sheetAction');
const recovery=document.getElementById('recoveryCard'), start=document.getElementById('startGame');
let hasTasks=true, hasRecovery=false, busy=false, timer;
function showToast(t){clearTimeout(timer);toast.textContent=t;toast.classList.add('show');timer=setTimeout(()=>toast.classList.remove('show'),1100)}
function openSheet(title,text,action='بستن',cb=null){sheetTitle.textContent=title;sheetText.textContent=text;sheetAction.textContent=action;sheet.classList.remove('hidden');sheetAction.onclick=()=>{sheet.classList.add('hidden');if(cb)cb()}}
function routeTo(route){if(busy)return;busy=true;showToast('Route → '+route);setTimeout(()=>busy=false,220)}
document.querySelectorAll('[data-route]').forEach(el=>el.addEventListener('click',()=>routeTo(el.dataset.route)));
document.querySelector('.hero-stage').addEventListener('click',()=>routeTo('heroHub'));
document.getElementById('rankCard').onclick=()=>openSheet('حماسی III','Rank Points: 72 / 100\nمرحله بعد: حماسی II\nHero Power تغییر نمی‌کند.');
start.onclick=()=>{
 if(busy)return;
 if(hasRecovery){openSheet('Match فعال وجود دارد','قبل از ساخت Match جدید، Match نیمه‌تمام را ادامه بده یا پایان بده.');return}
 if(!hasTasks){start.classList.add('blocked');setTimeout(()=>start.classList.remove('blocked'),250);openSheet('کار فعال لازم است','برای شروع بازی حداقل یک کار فعال لازم است.','رفتن به کارها',()=>routeTo('tasks'));return}
 busy=true;start.classList.add('busy');showToast('Validating Hero + Task Pool…');
 setTimeout(()=>{showToast('Route → preBattle • SAFE');start.classList.remove('busy');busy=false},650)
};
document.getElementById('toggleTasks').onclick=e=>{hasTasks=!hasTasks;e.currentTarget.textContent='Tasks: '+(hasTasks?'ON':'OFF')};
document.getElementById('toggleRecovery').onclick=e=>{hasRecovery=!hasRecovery;recovery.classList.toggle('hidden',!hasRecovery);e.currentTarget.textContent='Recovery: '+(hasRecovery?'ON':'OFF')};
document.getElementById('resumeMatch').onclick=()=>{if(busy)return;busy=true;showToast('Validating checkpoint…');setTimeout(()=>{showToast('Resume Match → immersive');busy=false},650)};
document.getElementById('endMatch').onclick=()=>openSheet('پایان Match؟','Rewardهای ثبت‌شده حفظ می‌شوند و Victory Bonus داده نمی‌شود.','تأیید پایان',()=>{hasRecovery=false;recovery.classList.add('hidden');document.getElementById('toggleRecovery').textContent='Recovery: OFF';showToast('Match closed • rewards preserved')});
