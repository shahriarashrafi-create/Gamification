let permission=false,scheduled=false;const $=id=>document.getElementById(id);
$('permission').onclick=()=>{permission=true;$('permDot').style.background='#62c89a';$('permTitle').textContent='اعلان‌ها فعال شدند';$('permission').textContent='Permission Granted'};
$('schedule').onclick=()=>{if(!permission){$('scheduleStatus').textContent='ابتدا هنگام استفاده از این قابلیت Permission درخواست می‌شود.';return}scheduled=true;$('scheduleStatus').textContent='SCHEDULED • '+$('task').value+' • '+$('time').value+' • بدون اعلان تکراری'};
$('match').onclick=()=>{$('route').textContent='Tap → HOME • Recovery Card visible • Match auto-entry BLOCKED'};
$('quiet').onchange=e=>{$('quietState').textContent=e.target.checked?'فعال • اعلان غیرضروری تا 07:00 جابه‌جا می‌شود':'خاموش'};