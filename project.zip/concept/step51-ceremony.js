const $=x=>document.getElementById(x);let mode='victory';
const modes={victory:['پیروزی','پایگاه دشمن نابود شد'],time_end:['پایان زمان','Rewardهای ثبت‌شده حفظ شدند'],manual_exit:['پایان Match','خروج دستی • بدون جریمه']};
function count(){document.querySelectorAll('[data-count]').forEach(el=>{const target=+el.dataset.count,t0=performance.now(),dur=650;function f(now){let t=Math.min(1,(now-t0)/dur);el.textContent='+'+Math.round(target*t);if(t<1)requestAnimationFrame(f)}requestAnimationFrame(f)});setTimeout(()=>document.querySelector('.bar i').style.width='82%',80)}
function render(m){mode=m;const [a,b]=modes[m];$('screen').className='screen '+m;$('resultTitle').textContent=a;$('resultSub').textContent=b;$('level').classList.toggle('hidden',m!=='victory');$('rank').classList.toggle('hidden',m!=='victory');$('diamond').classList.toggle('hidden',m!=='victory');document.querySelector('.bar i').style.width='0';count()}
document.querySelectorAll('[data-mode]').forEach(b=>b.onclick=()=>render(b.dataset.mode));
$('continue').onclick=()=>{$('homeState').classList.remove('hidden')};
render('victory');
