const members=[
 {id:'root',parentId:null,name:'شهریار',rank:'حماسی III',level:28,status:'active',sales:1280,gpv:4300,goal:{target:5000,progress:4300},expanded:true},
 {id:'a',parentId:'root',name:'علی',rank:'حرفه‌ای II',level:21,status:'growing',sales:620,gpv:1840,goal:{target:2500,progress:1840},expanded:true},
 {id:'b',parentId:'root',name:'مریم',rank:'پیگیر III',level:15,status:'active',sales:510,gpv:1320,goal:{target:2000,progress:1320},expanded:true},
 {id:'c',parentId:'root',name:'رضا',rank:'تازه‌کار II',level:8,status:'follow_up',sales:180,gpv:420,goal:{target:1000,progress:420},expanded:true},
 {id:'a1',parentId:'a',name:'سارا',rank:'پیگیر I',level:10,status:'active',sales:240,gpv:710,goal:{target:1000,progress:710},expanded:true},
 {id:'a2',parentId:'a',name:'امیر',rank:'تازه‌کار III',level:7,status:'growing',sales:190,gpv:560,goal:{target:900,progress:560},expanded:true},
 {id:'b1',parentId:'b',name:'ندا',rank:'تازه‌کار II',level:6,status:'active',sales:160,gpv:480,goal:{target:800,progress:480},expanded:true},
 {id:'c1',parentId:'c',name:'حسین',rank:'تازه‌کار I',level:3,status:'inactive',sales:40,gpv:90,goal:{target:500,progress:90},expanded:true}
];

const statusLabel={active:'فعال',growing:'در حال رشد',follow_up:'نیازمند پیگیری',inactive:'غیرفعال'};
const viewport=document.getElementById('viewport'),world=document.getElementById('world'),nodesEl=document.getElementById('nodes'),lines=document.getElementById('lines');
let scale=0.82, panX=-335, panY=20, selectedId='root', formMode='add', parentForAdd='root';
let dragging=false,last={x:0,y:0};

function childrenOf(id){return members.filter(m=>m.parentId===id)}
function isVisible(m){
 if(m.parentId===null)return true;
 let p=members.find(x=>x.id===m.parentId);
 while(p){if(!p.expanded)return false;p=members.find(x=>x.id===p.parentId)}
 return true;
}
function generations(){
 const g={root:0};
 let changed=true;
 while(changed){
  changed=false;
  members.forEach(m=>{
    if(m.parentId && g[m.parentId]!=null && g[m.id]==null){g[m.id]=g[m.parentId]+1;changed=true}
  });
 }
 return g;
}
function layout(){
 const g=generations(), byGen={};
 members.filter(isVisible).forEach(m=>(byGen[g[m.id]]??=[]).push(m));
 const pos={};
 Object.entries(byGen).forEach(([gen,arr])=>{
   const y=90+Number(gen)*180;
   const spacing=Math.min(210,900/Math.max(1,arr.length));
   const start=550-((arr.length-1)*spacing)/2;
   arr.forEach((m,i)=>pos[m.id]={x:start+i*spacing,y});
 });
 return pos;
}
function render(){
 const pos=layout();
 lines.innerHTML='';
 nodesEl.innerHTML='';
 members.filter(isVisible).forEach(m=>{
   if(m.parentId && pos[m.parentId] && pos[m.id]){
     const a=pos[m.parentId],b=pos[m.id],mid=(a.y+b.y)/2;
     const p=document.createElementNS('http://www.w3.org/2000/svg','path');
     p.setAttribute('d',`M ${a.x} ${a.y+40} C ${a.x} ${mid}, ${b.x} ${mid}, ${b.x} ${b.y-40}`);
     if(m.parentId==='root')p.setAttribute('class','root-line');
     lines.appendChild(p);
   }
 });
 members.filter(isVisible).forEach(m=>{
   const p=pos[m.id],pct=m.goal.target?Math.min(100,Math.round(m.goal.progress/m.goal.target*100)):0;
   const el=document.createElement('article');
   el.className=`node ${m.status} ${m.id==='root'?'root':''}`;
   el.style.left=p.x+'px';el.style.top=p.y+'px';
   el.dataset.id=m.id;
   el.innerHTML=`
    <div class="node-head">
      <div class="node-name"><b>${m.name}</b><span>${m.rank} • LV ${m.level}</span></div>
      <i class="dot"></i>
    </div>
    <div class="metrics"><span>Sales ${m.sales}</span><span>GPV ${m.gpv}</span></div>
    <div class="goal"><div><span>${statusLabel[m.status]}</span><b>${pct}%</b></div><i><em style="width:${pct}%"></em></i></div>
    ${childrenOf(m.id).length?`<button class="toggle" data-toggle="${m.id}">${m.expanded?'−':'+'}</button>`:''}`;
   el.addEventListener('click',e=>{if(e.target.dataset.toggle)return;openDetail(m.id)});
   nodesEl.appendChild(el);
 });
 document.querySelectorAll('[data-toggle]').forEach(btn=>btn.onclick=e=>{
   e.stopPropagation();const m=members.find(x=>x.id===btn.dataset.toggle);m.expanded=!m.expanded;render();
 });
 applyTransform();
}
function applyTransform(){world.style.transform=`translate(${panX}px,${panY}px) scale(${scale})`}
viewport.addEventListener('pointerdown',e=>{dragging=true;last={x:e.clientX,y:e.clientY};viewport.setPointerCapture(e.pointerId)});
viewport.addEventListener('pointermove',e=>{if(!dragging)return;panX+=e.clientX-last.x;panY+=e.clientY-last.y;last={x:e.clientX,y:e.clientY};applyTransform()});
viewport.addEventListener('pointerup',()=>dragging=false);
viewport.addEventListener('pointercancel',()=>dragging=false);

document.getElementById('zoomIn').onclick=()=>{scale=Math.min(1.8,scale+.12);applyTransform()};
document.getElementById('zoomOut').onclick=()=>{scale=Math.max(.55,scale-.12);applyTransform()};
document.getElementById('reset').onclick=()=>{scale=.82;panX=-335;panY=20;applyTransform()};

function openDetail(id){
 selectedId=id;const m=members.find(x=>x.id===id);
 document.getElementById('detailName').textContent=m.name;
 document.getElementById('detailRank').textContent=m.rank;
 document.getElementById('detailLevel').textContent=m.level;
 document.getElementById('detailSales').textContent=m.sales;
 document.getElementById('detailGpv').textContent=m.gpv;
 const pct=m.goal.target?Math.min(100,Math.round(m.goal.progress/m.goal.target*100)):0;
 document.getElementById('detailGoal').textContent=`${m.goal.progress} / ${m.goal.target} (${pct}%)`;
 document.getElementById('detailGoalBar').style.width=pct+'%';
 document.getElementById('removeMember').style.display=id==='root'?'none':'block';
 document.getElementById('sheetWrap').classList.add('show');
}
document.getElementById('closeSheet').onclick=()=>document.getElementById('sheetWrap').classList.remove('show');

function openForm(mode,id){
 formMode=mode;
 const form=document.getElementById('formWrap');
 if(mode==='edit'){
   const m=members.find(x=>x.id===id);
   document.getElementById('formTitle').textContent='ویرایش عضو';
   document.getElementById('nameField').value=m.name;
   document.getElementById('rankField').value=m.rank;
   document.getElementById('levelField').value=m.level;
   document.getElementById('salesField').value=m.sales;
   document.getElementById('gpvField').value=m.gpv;
   document.getElementById('goalTargetField').value=m.goal.target;
   document.getElementById('goalProgressField').value=m.goal.progress;
   document.getElementById('statusField').value=m.status;
 }else{
   parentForAdd=id;
   document.getElementById('formTitle').textContent='افزودن زیرمجموعه';
   document.getElementById('memberForm').reset();
   document.getElementById('rankField').value='تازه‌کار I';
   document.getElementById('levelField').value=1;
   document.getElementById('goalTargetField').value=500;
   document.getElementById('goalProgressField').value=0;
 }
 form.classList.add('show');
}
document.getElementById('addChild').onclick=()=>{document.getElementById('sheetWrap').classList.remove('show');openForm('add',selectedId)};
document.getElementById('editMember').onclick=()=>{document.getElementById('sheetWrap').classList.remove('show');openForm('edit',selectedId)};
document.getElementById('addRoot').onclick=()=>openForm('add','root');
document.getElementById('closeForm').onclick=()=>document.getElementById('formWrap').classList.remove('show');
document.getElementById('cancelForm').onclick=()=>document.getElementById('formWrap').classList.remove('show');

document.getElementById('memberForm').addEventListener('submit',e=>{
 e.preventDefault();
 const data={
  name:document.getElementById('nameField').value.trim(),
  rank:document.getElementById('rankField').value.trim(),
  level:Math.max(1,Number(document.getElementById('levelField').value)||1),
  sales:Math.max(0,Number(document.getElementById('salesField').value)||0),
  gpv:Math.max(0,Number(document.getElementById('gpvField').value)||0),
  goal:{target:Math.max(0,Number(document.getElementById('goalTargetField').value)||0),progress:Math.max(0,Number(document.getElementById('goalProgressField').value)||0)},
  status:document.getElementById('statusField').value,
  expanded:true
 };
 if(formMode==='edit')Object.assign(members.find(x=>x.id===selectedId),data);
 else members.push({id:crypto.randomUUID?crypto.randomUUID():Date.now().toString(),parentId:parentForAdd,...data});
 document.getElementById('formWrap').classList.remove('show');render();
});

document.getElementById('removeMember').onclick=()=>{
 if(selectedId==='root')return;
 const m=members.find(x=>x.id===selectedId);
 const parent=m.parentId;
 members.filter(x=>x.parentId===selectedId).forEach(x=>x.parentId=parent);
 const idx=members.findIndex(x=>x.id===selectedId);members.splice(idx,1);
 document.getElementById('sheetWrap').classList.remove('show');render();
};

document.getElementById('search').addEventListener('input',e=>{
 document.querySelectorAll('.node').forEach(n=>n.classList.remove('highlight'));
 const q=e.target.value.trim();
 if(!q)return;
 const m=members.find(x=>x.name.includes(q)||x.rank.includes(q));
 if(m){
  members.forEach(x=>x.expanded=true);render();
  const node=document.querySelector(`.node[data-id="${m.id}"]`);
  if(node)node.classList.add('highlight');
 }
});

render();
