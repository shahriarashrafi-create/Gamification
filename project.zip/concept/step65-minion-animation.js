const minion=document.getElementById('minion'),stateEl=document.getElementById('state'),asset=document.getElementById('asset'),ring=document.getElementById('ring'),impact=document.getElementById('impact'),log=document.getElementById('log');let reduce=false;
function setState(s){
 minion.className='minion '+s;stateEl.textContent=s.toUpperCase();asset.textContent='minion_'+s;ring.classList.toggle('on',s==='focused');
 if(s==='hit'){impact.classList.remove('on');void impact.offsetWidth;impact.classList.add('on')}
 if(s==='defeated')log.textContent='Defeat committed visual — سپس Despawn';
 else log.textContent='Visual state فقط committed runtime را نمایش می‌دهد.';
}
document.querySelectorAll('[data-state]').forEach(b=>b.onclick=()=>setState(b.dataset.state));
document.getElementById('reduce').onclick=()=>{reduce=!reduce;document.getElementById('reduce').textContent=reduce?'Reduce Motion: ON':'Reduce Motion';log.textContent=reduce?'Recoil و dissolve بزرگ غیرفعال شدند.':'Motion کامل فعال است.'};
