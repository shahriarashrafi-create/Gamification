const $=x=>document.getElementById(x);let busy=false;
const info={
 shop:['فروشگاه','Hero • Cosmetic • Reward Armory'],
 events:['رویدادها','Active Events • Qualification Progress'],
 vision:['آینده‌بینی','Goals • Years • Future Progress'],
 achievements:['دستاوردها','Progress • Ready to Claim • History']
};
document.querySelectorAll('[data-module]').forEach(btn=>btn.onclick=async()=>{
 if(busy)return;busy=true;btn.disabled=true;
 const id=btn.dataset.module;$('toast').textContent='در حال بارگذاری '+info[id][0]+'...';$('toast').classList.add('show');
 await new Promise(r=>setTimeout(r,260));
 $('toast').classList.remove('show');$('home').classList.add('hidden');$('module').classList.remove('hidden');$('moduleTitle').textContent=info[id][0];$('moduleState').textContent='READY';$('moduleBody').textContent=info[id][1];btn.disabled=false;busy=false;
});
$('back').onclick=()=>{$('module').classList.add('hidden');$('home').classList.remove('hidden')};
