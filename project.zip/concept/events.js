let events=[
 {id:'e1',title:'Director Event پاییز',type:'Director Event',startDate:'2026-09-01',endDate:'2026-10-15',targetMetric:'GPV',targetValue:5000,note:'Qualification اصلی پاییز',active:true},
 {id:'e2',title:'Team Challenge شهریور',type:'Team Challenge',startDate:'2026-09-01',endDate:'2026-09-30',targetMetric:'Sales',targetValue:3000,note:'چالش فروش تیم',active:true}
];

let participants=[
 {id:'p1',eventId:'e1',name:'علی رضایی',currentValue:4200,targetValue:5000,status:'close',note:'با دو Follow-up دیگر می‌تواند برسد.'},
 {id:'p2',eventId:'e1',name:'مریم احمدی',currentValue:5200,targetValue:5000,status:'qualified',note:'Qualified شده.'},
 {id:'p3',eventId:'e1',name:'رضا کریمی',currentValue:2600,targetValue:5000,status:'should_reach',note:'این دوره باید به Qualification برسد.'},
 {id:'p4',eventId:'e1',name:'سارا محمدی',currentValue:1800,targetValue:5000,status:'tracking',note:'در حال پیشرفت.'},
 {id:'p5',eventId:'e2',name:'امیر اکبری',currentValue:1900,targetValue:3000,status:'tracking',note:'پیشرفت مناسب.'}
];

const labels={qualified:'واجد شرایط',close:'نزدیک به هدف',should_reach:'باید برسد',tracking:'در حال پیشرفت',not_started:'شروع نشده'};
let selectedEvent='e1', filter='all', editEventId=null, editParticipantId=null, deleteTarget=null;

function uid(){return crypto.randomUUID?crypto.randomUUID():Date.now().toString()+Math.random()}
function eventParticipants(){return participants.filter(p=>p.eventId===selectedEvent)}
function deriveStatus(p){
 const pct=p.targetValue? p.currentValue/p.targetValue*100 : 0;
 if(p.currentValue>=p.targetValue)return 'qualified';
 if(p.status==='should_reach')return 'should_reach';
 if(pct>=75)return 'close';
 if(p.currentValue===0)return 'not_started';
 return 'tracking';
}
function renderTabs(){
 const wrap=document.getElementById('eventTabs');
 wrap.innerHTML=events.filter(e=>e.active).map(e=>`<button class="event-tab ${e.id===selectedEvent?'active':''}" data-event="${e.id}"><b>${e.title}</b><small>${e.type} • ${e.targetMetric} ${e.targetValue}</small></button>`).join('');
 document.querySelectorAll('[data-event]').forEach(b=>b.onclick=()=>{selectedEvent=b.dataset.event;render()});
}
function renderSummary(){
 const ps=eventParticipants();
 document.getElementById('qualifiedCount').textContent=ps.filter(p=>deriveStatus(p)==='qualified').length;
 document.getElementById('closeCount').textContent=ps.filter(p=>deriveStatus(p)==='close').length;
 document.getElementById('shouldCount').textContent=ps.filter(p=>deriveStatus(p)==='should_reach').length;
}
function visibleParticipants(){
 const q=document.getElementById('searchInput').value.trim();
 return eventParticipants().filter(p=>{
   const st=deriveStatus(p);
   return (!q||p.name.includes(q)||p.note.includes(q)) && (filter==='all'||st===filter);
 }).sort((a,b)=>{
   const pa=a.targetValue?a.currentValue/a.targetValue:0;
   const pb=b.targetValue?b.currentValue/b.targetValue:0;
   return pb-pa;
 });
}
function renderList(){
 const list=document.getElementById('participantList');
 const data=visibleParticipants();
 list.innerHTML=data.length?data.map(p=>{
   const st=deriveStatus(p),raw=p.targetValue?Math.round(p.currentValue/p.targetValue*100):0,pct=Math.min(100,raw);
   return `<article class="participant ${st}">
    <div class="phead"><b>${p.name}</b><button class="badge">${labels[st]}</button></div>
    <div class="values"><span>${p.currentValue} / ${p.targetValue}</span><b>${raw}%</b></div>
    <i class="bar"><em style="width:${pct}%"></em></i>
    <p>${p.note||'بدون یادداشت'}</p>
    <div class="actions"><button data-edit-p="${p.id}">ویرایش</button><button class="danger" data-delete-p="${p.id}">حذف</button></div>
   </article>`;
 }).join(''):`<div class="participant"><p>شرکت‌کننده‌ای پیدا نشد.</p></div>`;
 document.querySelectorAll('[data-edit-p]').forEach(b=>b.onclick=()=>openParticipantForm(b.dataset.editP));
 document.querySelectorAll('[data-delete-p]').forEach(b=>b.onclick=()=>askDelete('participant',b.dataset.deleteP));
}
function render(){renderTabs();renderSummary();renderList()}
document.getElementById('searchInput').addEventListener('input',renderList);
document.querySelectorAll('#filters button').forEach(btn=>btn.onclick=()=>{
 document.querySelectorAll('#filters button').forEach(x=>x.classList.remove('active'));btn.classList.add('active');filter=btn.dataset.filter;renderList();
});

function openEventForm(id=null){
 editEventId=id;document.getElementById('eventForm').reset();document.getElementById('eventActiveField').checked=true;
 if(id){
  const e=events.find(x=>x.id===id);
  document.getElementById('eventFormTitle').textContent='ویرایش رویداد';
  document.getElementById('eventTitleField').value=e.title;
  document.getElementById('eventTypeField').value=e.type;
  document.getElementById('metricField').value=e.targetMetric;
  document.getElementById('startDateField').value=e.startDate;
  document.getElementById('endDateField').value=e.endDate;
  document.getElementById('eventTargetField').value=e.targetValue;
  document.getElementById('eventNoteField').value=e.note;
  document.getElementById('eventActiveField').checked=e.active;
 }else document.getElementById('eventFormTitle').textContent='رویداد جدید';
 document.getElementById('eventFormWrap').classList.add('show');
}
document.getElementById('addEvent').onclick=()=>openEventForm();
document.getElementById('closeEventForm').onclick=()=>document.getElementById('eventFormWrap').classList.remove('show');
document.getElementById('cancelEventForm').onclick=()=>document.getElementById('eventFormWrap').classList.remove('show');
document.getElementById('eventForm').addEventListener('submit',ev=>{
 ev.preventDefault();
 const data={
  title:document.getElementById('eventTitleField').value.trim(),
  type:document.getElementById('eventTypeField').value.trim(),
  targetMetric:document.getElementById('metricField').value.trim(),
  startDate:document.getElementById('startDateField').value,
  endDate:document.getElementById('endDateField').value,
  targetValue:Math.max(0,Number(document.getElementById('eventTargetField').value)||0),
  note:document.getElementById('eventNoteField').value.trim(),
  active:document.getElementById('eventActiveField').checked
 };
 if(editEventId)Object.assign(events.find(x=>x.id===editEventId),data);
 else {const id=uid();events.push({id,...data});selectedEvent=id;}
 document.getElementById('eventFormWrap').classList.remove('show');render();
});

function openParticipantForm(id=null){
 editParticipantId=id;document.getElementById('participantForm').reset();
 const e=events.find(x=>x.id===selectedEvent);document.getElementById('targetField').value=e?.targetValue||0;
 if(id){
  const p=participants.find(x=>x.id===id);
  document.getElementById('participantFormTitle').textContent='ویرایش شرکت‌کننده';
  document.getElementById('participantNameField').value=p.name;
  document.getElementById('currentField').value=p.currentValue;
  document.getElementById('targetField').value=p.targetValue;
  document.getElementById('participantStatusField').value=p.status;
  document.getElementById('participantNoteField').value=p.note;
 }else document.getElementById('participantFormTitle').textContent='شرکت‌کننده جدید';
 document.getElementById('participantFormWrap').classList.add('show');
}
document.getElementById('addParticipant').onclick=()=>openParticipantForm();
document.getElementById('closeParticipantForm').onclick=()=>document.getElementById('participantFormWrap').classList.remove('show');
document.getElementById('cancelParticipantForm').onclick=()=>document.getElementById('participantFormWrap').classList.remove('show');
document.getElementById('participantForm').addEventListener('submit',ev=>{
 ev.preventDefault();
 const data={
  eventId:selectedEvent,
  name:document.getElementById('participantNameField').value.trim(),
  currentValue:Math.max(0,Number(document.getElementById('currentField').value)||0),
  targetValue:Math.max(0,Number(document.getElementById('targetField').value)||0),
  status:document.getElementById('participantStatusField').value,
  note:document.getElementById('participantNoteField').value.trim()
 };
 if(editParticipantId)Object.assign(participants.find(x=>x.id===editParticipantId),data);
 else participants.push({id:uid(),...data});
 document.getElementById('participantFormWrap').classList.remove('show');render();
});

function askDelete(type,id){
 deleteTarget={type,id};
 document.getElementById('confirmTitle').textContent=type==='participant'?'حذف شرکت‌کننده؟':'حذف Event؟';
 document.getElementById('confirmText').textContent=type==='participant'?'این عضو از این رویداد حذف می‌شود.':'رویداد و شرکت‌کننده‌هایش حذف می‌شوند.';
 document.getElementById('confirmWrap').classList.add('show');
}
document.getElementById('confirmNo').onclick=()=>{deleteTarget=null;document.getElementById('confirmWrap').classList.remove('show')};
document.getElementById('confirmYes').onclick=()=>{
 if(deleteTarget?.type==='participant'){
   const i=participants.findIndex(x=>x.id===deleteTarget.id);if(i>=0)participants.splice(i,1);
 }
 deleteTarget=null;document.getElementById('confirmWrap').classList.remove('show');render();
};

render();
