const hero=document.getElementById('hero');
const miniHero=document.getElementById('miniHero');
const yInput=document.getElementById('heroY');
const coord=document.getElementById('coord');
let x=50,y=89;

function update(){
  hero.style.setProperty('--x',x);
  hero.style.setProperty('--y',y);
  miniHero.style.left=x+'%';
  miniHero.style.top=y+'%';
  coord.textContent=`X ${x} • Y ${y}`;
}
yInput.addEventListener('input',()=>{
  y=Number(yInput.value);
  update();
});
document.querySelectorAll('.lane-buttons button').forEach(btn=>{
  btn.addEventListener('click',()=>{
    document.querySelectorAll('.lane-buttons button').forEach(x=>x.classList.remove('active'));
    btn.classList.add('active');
    x=Number(btn.dataset.x);
    update();
  });
});
update();
