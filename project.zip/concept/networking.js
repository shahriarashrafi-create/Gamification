const prospects=[
 {id:'p1',name:'علی رضایی',referrerName:'محمد',consultantName:'شهریار',status:'follow_up',note:'علاقه‌مند به مدل کسب‌وکار'},
 {id:'p2',name:'مریم احمدی',referrerName:'سارا',consultantName:'شهریار',status:'active',note:'جلسه دوم انجام شده'},
 {id:'p3',name:'رضا کریمی',referrerName:'',consultantName:'شهریار',status:'new',note:'از اینستاگرام آشنا شد'}
];

const actions=[
 {id:'a1',prospectId:'p1',actionType:'دعوت',actionDate:'2026-09-01',actionTime:'09:30',result:'علاقه‌مند شد، نیاز به زمان دارد',nextAction1:'فالوآپ',nextAction2:'معرفی کار',nextActionDate:'2026-09-02',nextActionTime:'18:00',nextActionResult1:'',nextActionResult2:'',note:'پیگیری عصر فردا',completed:true},
 {id:'a2',prospectId:'p1',actionType:'ارتباط‌سازی',actionDate:'2026-08-29',actionTime:'17:00',result:'ارتباط اولیه خوب بود',nextAction1:'دعوت',nextAction2:'',nextActionDate:'2026-09-01',nextActionTime:'09:30',nextActionResult1:'دعوت انجام شد',nextActionResult2:'',note:'',completed:true},
 {id:'a3',prospectId:'p2',actionType:'پیش‌مشاوره',actionDate:'2026-08-31',actionTime:'14:00',result:'نیازها مشخص شد',nextAction1:'معرفی کار',nextAction2:'فالوآپ',nextActionDate:'2026-09-03',nextActionTime:'11:00',nextActionResult1:'',nextActionResult2:'',note:'',completed:true}
];

const statusLabels={new:'جدید',active:'فعال',follow_up:'نیازمند پیگیری',converted:'تبدیل‌شده',paused:'متوقف'};
let filterType='all', selectedProspect=null, prospectEditId=null, actionEditId=null, deleteTarget=null;

function lastAction(pid){
 return actions.filter(a=>a.prospectId===pid).sort((a,b)=>(b.actionDate+b.actionTime).localeCompare(a.actionDate+a.actionTime))[0];
}
function visible(){
 const q=document.getElementById('searchInput').value.trim().toLowerCase();
 return prospects.filter(p=>{
   const la=lastAction(p.id);
   const blob=[p.name,p.referrerName,p.consultantName,p.note,la?.result,la?.nextAction1,la?.nextAction2].join(' ').toLowerCase();
   if(q && !blob.includes(q)) return false;
   if(filterType!=='all' && la?.actionType!==filterType) return false;
   return true;
 });
}
function render(){
 const list=document.getElementById('prospectList');
 document.getElementById('totalCount').textContent=prospects.length;
 document.getElementById('followCount').textContent=prospects.filter(p=>p.status==='follow_up').length;
 document.getElementById('needCount').textContent=prospects.filter(p=>!lastAction(p.id)?.nextAction1).length;

 const data=visible();
 if(!data.length){
  list.innerHTML=`<div class="empty"><i>◎</i><b>Prospect پیدا نشد</b><span>فیلتر یا جستجو را تغییر بده.</span></div>`;
  return;
 }
 list.innerHTML=data.map(p=>{
  const la=lastAction(p.id);
  return `<article class="prospect ${p.status}" data-open="${p.id}">
    <div class="phead">
      <div class="pname"><b>${p.name}</b><span>معرف: ${p.referrerName||'—'} • مشاور: ${p.consultantName||'—'}</span></div>
      <button class="status">${statusLabels[p.status]}</button>
    </div>
    <div class="last-action">
      <div><small>LAST RESULT</small><b>${la?.result||'هنوز اقدامی ثبت نشده'}</b></div>
      <span class="action-tag">${la?.actionType||'NEW'}</span>
    </div>
    <div class="next">
      <div><small>NEXT ACTION</small><b>${la?.nextAction1||'اقدام بعدی تعیین نشده'}</b></div>
      <span class="due">${la?.nextActionDate ? la.nextActionDate+' • '+(la.nextActionTime||'') : 'بدون زمان'}</span>
    </div>
  </article>`;
 }).join('');
 document.querySelectorAll('[data-open]').forEach(el=>el.onclick=()=>openDetail(el.dataset.open));
}
document.querySelectorAll('#actionFilters button').forEach(btn=>btn.onclick=()=>{
 document.querySelectorAll('#actionFilters button').forEach(x=>x.classList.remove('active'));
 btn.classList.add('active');filterType=btn.dataset.type;render();
});
document.getElementById('searchInput').addEventListener('input',render);
document.getElementById('clearSearch').onclick=()=>{document.getElementById('searchInput').value='';render()};

function openDetail(id){
 selectedProspect=id;
 const p=prospects.find(x=>x.id===id);
 document.getElementById('detailName').textContent=p.name;
 document.getElementById('detailReferrer').textContent=p.referrerName||'—';
 document.getElementById('detailConsultant').textContent=p.consultantName||'—';
 document.getElementById('detailStatus').textContent=statusLabels[p.status];
 const h=document.getElementById('history');
 const rows=actions.filter(a=>a.prospectId===id).sort((a,b)=>(b.actionDate+b.actionTime).localeCompare(a.actionDate+a.actionTime));
 h.innerHTML=rows.length?rows.map(a=>`
   <article class="history-item">
    <div class="hhead"><b>${a.actionType}</b><span>${a.actionDate} • ${a.actionTime}</span></div>
    <p>${a.result||'بدون نتیجه'}</p>
    <div class="nexts">${a.nextAction1?`<span>بعدی ۱: ${a.nextAction1}</span>`:''}${a.nextAction2?`<span>بعدی ۲: ${a.nextAction2}</span>`:''}</div>
    <button class="hedit" data-edit-action="${a.id}">ویرایش اقدام</button>
   </article>`).join(''):`<div class="empty"><span>هنوز اقدامی ثبت نشده.</span></div>`;
 document.querySelectorAll('[data-edit-action]').forEach(b=>b.onclick=()=>{document.getElementById('detailWrap').classList.remove('show');openActionForm(b.dataset.editAction)});
 document.getElementById('detailWrap').classList.add('show');
}
document.getElementById('closeDetail').onclick=()=>document.getElementById('detailWrap').classList.remove('show');

function openProspectForm(id=null){
 prospectEditId=id;
 const f=document.getElementById('prospectForm');
 f.reset();
 if(id){
  const p=prospects.find(x=>x.id===id);
  document.getElementById('prospectFormTitle').textContent='ویرایش Prospect';
  document.getElementById('nameField').value=p.name;
  document.getElementById('referrerField').value=p.referrerName;
  document.getElementById('consultantField').value=p.consultantName;
  document.getElementById('statusField').value=p.status;
  document.getElementById('prospectNoteField').value=p.note;
 } else document.getElementById('prospectFormTitle').textContent='Prospect جدید';
 document.getElementById('prospectFormWrap').classList.add('show');
}
document.getElementById('addProspect').onclick=()=>openProspectForm();
document.getElementById('editProspect').onclick=()=>{document.getElementById('detailWrap').classList.remove('show');openProspectForm(selectedProspect)};
document.getElementById('closeProspectForm').onclick=()=>document.getElementById('prospectFormWrap').classList.remove('show');
document.getElementById('cancelProspectForm').onclick=()=>document.getElementById('prospectFormWrap').classList.remove('show');
document.getElementById('prospectForm').addEventListener('submit',e=>{
 e.preventDefault();
 const data={name:document.getElementById('nameField').value.trim(),referrerName:document.getElementById('referrerField').value.trim(),consultantName:document.getElementById('consultantField').value.trim(),status:document.getElementById('statusField').value,note:document.getElementById('prospectNoteField').value.trim()};
 if(prospectEditId)Object.assign(prospects.find(x=>x.id===prospectEditId),data);
 else prospects.unshift({id:crypto.randomUUID?crypto.randomUUID():Date.now().toString(),...data});
 document.getElementById('prospectFormWrap').classList.remove('show');render();
});

function openActionForm(id=null){
 actionEditId=id;
 document.getElementById('actionForm').reset();
 document.getElementById('actionDateField').value='2026-09-01';
 document.getElementById('actionTimeField').value='10:00';
 if(id){
  const a=actions.find(x=>x.id===id);
  document.getElementById('actionFormTitle').textContent='ویرایش اقدام';
  document.getElementById('actionTypeField').value=a.actionType;
  document.getElementById('actionDateField').value=a.actionDate;
  document.getElementById('actionTimeField').value=a.actionTime;
  document.getElementById('resultField').value=a.result;
  document.getElementById('next1Field').value=a.nextAction1;
  document.getElementById('next2Field').value=a.nextAction2;
  document.getElementById('nextDateField').value=a.nextActionDate||'';
  document.getElementById('nextTimeField').value=a.nextActionTime||'';
  document.getElementById('nextResult1Field').value=a.nextActionResult1||'';
  document.getElementById('nextResult2Field').value=a.nextActionResult2||'';
  document.getElementById('actionNoteField').value=a.note||'';
 } else document.getElementById('actionFormTitle').textContent='ثبت اقدام';
 document.getElementById('actionFormWrap').classList.add('show');
}
document.getElementById('addAction').onclick=()=>{document.getElementById('detailWrap').classList.remove('show');openActionForm()};
document.getElementById('closeActionForm').onclick=()=>document.getElementById('actionFormWrap').classList.remove('show');
document.getElementById('cancelActionForm').onclick=()=>document.getElementById('actionFormWrap').classList.remove('show');
document.getElementById('actionForm').addEventListener('submit',e=>{
 e.preventDefault();
 const data={
  prospectId:selectedProspect,
  actionType:document.getElementById('actionTypeField').value,
  actionDate:document.getElementById('actionDateField').value,
  actionTime:document.getElementById('actionTimeField').value,
  result:document.getElementById('resultField').value.trim(),
  nextAction1:document.getElementById('next1Field').value.trim(),
  nextAction2:document.getElementById('next2Field').value.trim(),
  nextActionDate:document.getElementById('nextDateField').value,
  nextActionTime:document.getElementById('nextTimeField').value,
  nextActionResult1:document.getElementById('nextResult1Field').value.trim(),
  nextActionResult2:document.getElementById('nextResult2Field').value.trim(),
  note:document.getElementById('actionNoteField').value.trim(),
  completed:true
 };
 if(actionEditId)Object.assign(actions.find(x=>x.id===actionEditId),data);
 else actions.unshift({id:crypto.randomUUID?crypto.randomUUID():Date.now().toString(),...data});
 document.getElementById('actionFormWrap').classList.remove('show');render();openDetail(selectedProspect);
});

document.getElementById('deleteProspect').onclick=()=>{
 deleteTarget={type:'prospect',id:selectedProspect};
 document.getElementById('confirmTitle').textContent='حذف Prospect؟';
 document.getElementById('confirmText').textContent='این Prospect و تاریخچه اقدام‌هایش حذف می‌شوند.';
 document.getElementById('confirmWrap').classList.add('show');
};
document.getElementById('noDelete').onclick=()=>{deleteTarget=null;document.getElementById('confirmWrap').classList.remove('show')};
document.getElementById('yesDelete').onclick=()=>{
 if(deleteTarget?.type==='prospect'){
  const pid=deleteTarget.id;
  for(let i=actions.length-1;i>=0;i--)if(actions[i].prospectId===pid)actions.splice(i,1);
  const pi=prospects.findIndex(x=>x.id===pid);if(pi>=0)prospects.splice(pi,1);
  document.getElementById('detailWrap').classList.remove('show');
 }
 deleteTarget=null;document.getElementById('confirmWrap').classList.remove('show');render();
};

render();
