const $=x=>document.getElementById(x);
let wave=0,seq=0;
const tasks=[
{id:'t1',title:'پیگیری سه نفر',state:'available'},
{id:'t2',title:'یک معرفی کار',state:'available'},
{id:'t3',title:'ارتباط‌سازی',state:'available'},
{id:'t4',title:'پیام فروش',state:'available'},
{id:'t5',title:'فالوآپ',state:'available'},
{id:'t6',title:'برنامه‌ریزی',state:'available'}
];
let minions=[];
function active(){return minions.filter(m=>m.state==='active')}
function render(){
 ['A','B','C'].forEach(l=>{$(l).innerHTML=minions.filter(m=>m.lane===l).map(m=>`<article class="minion ${m.state==='deferred'?'deferred':m.state==='completed'?'completed':''}"><b>${m.id}</b><small>${m.task.title}<br>${m.state.toUpperCase()}</small></article>`).join('')});
 $('tasks').innerHTML=tasks.map(t=>`<span class="task ${t.state==='reserved'?'reserved':''}">${t.title} • ${t.state}</span>`).join('');
 $('activeCount').textContent=active().length+' / 6';$('wave').textContent=wave;
}
function spawnWave(){
 wave++;
 for(const lane of ['A','B','C']){
  if(active().length>=6)break;
  if(active().filter(m=>m.lane===lane).length>=2)continue;
  const task=tasks.find(t=>t.state==='available');
  if(!task)break;
  task.state='reserved';seq++;
  minions.push({id:'M'+seq,lane,task,state:'active',reservationId:'R'+seq});
 }
 $('log').textContent='Wave '+wave+' — reservation قبل از spawn ثبت شد';render();
}
$('spawnWave').onclick=spawnWave;
$('defer').onclick=()=>{const m=active()[0];if(!m)return;m.state='deferred';m.task.state='deferred_current_match';$('log').textContent='Task تا پایان Match دوباره assign نمی‌شود';render()};
$('complete').onclick=()=>{const m=active()[0];if(!m)return;m.state='completed';m.task.state='completed';$('log').textContent='Completion commit شد — reward فقط یک بار';render()};
render();
