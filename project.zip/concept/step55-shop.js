const $=x=>document.getElementById(x);
let wallet={gold:2810,diamonds:13},owned=new Set(['young_stylish']),history=[],busy=false;
const data={
 heroes:[
  {id:'young_stylish',type:'hero',name:'آقای جوان خوش‌تیپ',price:0},
  {id:'luxury_mature_m',type:'hero',name:'آقای میان‌سال لاکچری',price:2400},
  {id:'disciplined_f',type:'hero',name:'خانم بادیسیپلین',price:2800}
 ],
 cosmetics:[
  {id:'aura_gold',type:'cosmetic',name:'هاله طلایی',price:700},
  {id:'frame_cyan',type:'cosmetic',name:'فریم کریستالی',price:450}
 ],
 rewards:[
  {id:'coffee',type:'real_reward',name:'قهوه',price:5},
  {id:'meal',type:'real_reward',name:'یک وعده غذای خوب',price:12},
  {id:'dayoff',type:'real_reward',name:'نیم‌روز استراحت',price:40}
 ]
};
function toast(t){$('toast').textContent=t;$('toast').classList.add('show');setTimeout(()=>$('toast').classList.remove('show'),1000)}
function walletUI(){$('gold').textContent=wallet.gold;$('diamond').textContent=wallet.diamonds}
function card(item){
 const isOwned=owned.has(item.id),cur=item.type==='real_reward'?'◇':'G';
 return `<article class="card"><div class="visual">${item.type.toUpperCase()}</div><small>${item.type==='real_reward'?'REAL-LIFE REWARD':'VISUAL ONLY'}</small><b>${item.name}</b><p>${item.type==='real_reward'?'پاداش واقعی با Diamond':'بدون قدرت اضافه در بازی'}</p><div class="price"><span>${cur} ${item.price}</span><button data-buy="${item.id}" data-type="${item.type}" class="${isOwned?'owned':''}">${isOwned?'خریداری‌شده':item.type==='real_reward'?'دریافت':'خرید'}</button></div></article>`
}
function render(tab='heroes'){
 document.querySelectorAll('.tabs button').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));
 if(tab==='history'){$('list').innerHTML=history.length?history.map(h=>`<div class="history">${h}</div>`).join(''):'<div class="history">هنوز تراکنشی ثبت نشده</div>';return}
 $('list').innerHTML=data[tab].map(card).join('');
 document.querySelectorAll('[data-buy]').forEach(b=>b.onclick=()=>buy(b.dataset.buy,b.dataset.type));
}
async function buy(id,type){
 if(busy)return;busy=true;
 const list=type==='hero'?data.heroes:type==='cosmetic'?data.cosmetics:data.rewards,item=list.find(x=>x.id===id);
 if(type!=='real_reward'&&owned.has(id)){toast('این مورد قبلاً خریداری شده');busy=false;return}
 const enough=type==='real_reward'?wallet.diamonds>=item.price:wallet.gold>=item.price;
 if(!enough){toast('موجودی کافی نیست');busy=false;return}
 await new Promise(r=>setTimeout(r,220));
 if(type==='real_reward'){wallet.diamonds-=item.price;history.unshift(`Claim • ${item.name} • ◇ ${item.price}`);toast('Reward ثبت شد')}
 else{wallet.gold-=item.price;owned.add(id);history.unshift(`Purchase • ${item.name} • G ${item.price}`);toast('خرید با موفقیت ثبت شد')}
 walletUI();render(type==='hero'?'heroes':type==='cosmetic'?'cosmetics':'rewards');busy=false;
}
document.querySelectorAll('.tabs button').forEach(b=>b.onclick=()=>render(b.dataset.tab));
walletUI();render();
