# SHAHRIAR GAME — STEP 19
## MASTER DESIGN SYSTEM / UI COMPONENT LIBRARY

مرجع رسمی UI کل محصول.

## 1. هدف
هر صفحه باید از یک زبان UI مشترک استفاده کند تا Home، Gameplay، Tasks، Tree، Timesheet، CRM و ماژول‌های ثانویه متعلق به یک بازی واحد باشند.

## 2. Core Tokens
Color, Typography, Spacing, Radius, Border, Shadow, Glow, Motion, Layer/Z-index و Safe Area باید Token-based باشند.

## 3. Color Roles
- bg.obsidian #02070C
- bg.midnight #071721
- surface.primary #0A222E
- surface.raised #0D2936
- gold.primary #C5A052
- gold.bright #F0D27B
- cyan.primary #42BCC8
- cyan.bright #82E0E7
- diamond #72DCE8
- success #62C89A
- warning #D5A856
- danger #C8645B
- text.primary #E7ECEA
- text.secondary #8DA4AA
- text.muted #607A83

## 4. Typography
Persian-first.
Scale:
Display 24
H1 20
H2 16
H3 13
Body 12–14
Caption 10–11
Micro Latin decorative 8–9

Production Persian font licensing must be checked before final packaging.

## 5. Spacing
Base 4dp:
4, 8, 12, 16, 20, 24, 32.

## 6. Radius
small 8
medium 12
large 16
sheet 20
pill 999

## 7. Touch
Interactive target >= 44dp wherever practical.
Tiny decorative labels are not touch targets.

## 8. Borders
Default 1px low-opacity blue-gray.
Premium gold border reserved for selected/primary/reward-ready states.

## 9. Shadows
Dark depth, subtle.
No generic bright Material card shadow.

## 10. Glow
Cyan = interactive/magical.
Gold = premium/reward/selection.
Red = danger only.

## 11. Buttons
Primary Gold
Secondary Cyan
Ghost
Danger
Icon
CTA Battle

## 12. CTA Battle
Large gold CTA used for Start Game / major confirmation.
Never hidden behind Bottom Nav.

## 13. Cards
Tactical Card
Objective Card
Member Node
Reward Card
Achievement Card
Hero Card

All share common surface/border/radius tokens.

## 14. Panels
Ornate Panel:
premium modules.
Utility Panel:
dense management.
HUD Panel:
compact transparent.

## 15. Inputs
Dark input surface.
Clear focus ring cyan.
RTL text.
Numbers remain readable.

## 16. Chips
Filter
Status
Category
Year/Period
Selected state = gold/cyan depending semantic context.

## 17. Modal
Mobile default = bottom sheet.
Critical confirmation may center.
Battle encounter modal preserves battlefield context.

## 18. Bottom Navigation
Canonical exactly five:
خانه | کارها | آمار | تایم‌شیت | شبکه‌سازی

No sixth item.

## 19. Bottom Nav Height
Target visual 64–72dp + safe area.
Content must reserve its space.

## 20. Top HUD
Player / Level / XP / Gold / Diamond / Settings.
No Energy.

## 21. Icon Rules
Final icons from unified icon asset family.
Emoji prohibited in production UI.

## 22. State Language
default
hover (desktop concept only)
pressed
focused
disabled
selected
danger
success
ready

## 23. Motion Tokens
instant 80ms
fast 140ms
normal 220ms
cinematic 360ms
major 600ms

Default easing:
cubic-bezier(.2,.8,.2,1)

## 24. Reduced Motion
Replace scale/slide with fade where possible.
No essential information depends on motion.

## 25. Layers
background 0
world 10
content 20
hud 40
nav 50
overlay 70
modal 80
toast 100
critical 120

## 26. Responsive
360–430 CSS px primary target.
Use 100dvh.
Safe-area env variables.
Avoid fixed giant min-height sections.

## 27. Home Rule
Hero 38–46% viewport target.
All four secondary modules + rank + CTA remain reachable/visible.
CTA above nav.

## 28. Dense Screens
Tasks/CRM/Timesheet:
single-column mobile.
Compact cards, not tiny multi-column dashboards.

## 29. Tree
Canvas may exceed viewport and pan/zoom.
Controls remain fixed/safe.

## 30. Gameplay
Bottom nav absent.
Immersive.
HUD uses same tokens but lower opacity.

## 31. Currency
Gold visual = gold.
Diamond = cyan crystal.
XP = cyan/gold progress.
Currency meaning never swapped.

## 32. Status Colors
Use text/icon + color.
Never color alone.

## 33. Empty State
Icon/illustration + short message + one CTA.
No giant empty dashboard.

## 34. Loading
Skeleton surface or subtle arcane pulse.
Avoid blocking spinner when local data is immediate.

## 35. Toast
Compact top/center safe zone.
Success/cyan, warning/gold, danger/red.

## 36. Confirmation
Destructive actions explicitly name object.
Default focus should not encourage delete.

## 37. RTL
Layout mirrors naturally.
Directional controls checked individually.
Numbers/currency remain stable.

## 38. Accessibility
Readable contrast.
44dp touch.
Focus state.
Reduced Motion.
No state conveyed only by color.

## 39. Component Naming
sg-button
sg-card
sg-panel
sg-chip
sg-input
sg-sheet
sg-hud
sg-bottom-nav
sg-progress
sg-toast

## 40. Quality Gate
PASS if every future screen can be composed from these tokens/components without inventing a new visual language.

## STEP 20
HOME LOBBY — FINAL RESPONSIVE VISUAL BLUEPRINT
Step20 applies Art Bible + Design System to the Home screen at 360/390/430 widths and locks exact responsive composition before production implementation.
