export function resultHeader(type){
  const map={
    victory:{title:'پیروزی',subtitle:'بیس دشمن نابود شد',tone:'victory'},
    time_end:{title:'زمان تمام شد',subtitle:'پاداش‌های ثبت‌شده حفظ شدند',tone:'neutral'},
    manual_exit:{title:'بازی پایان داده شد',subtitle:'پاداش‌های ثبت‌شده حفظ شدند',tone:'neutral'}
  };
  return map[type]||{title:'نتیجه بازی',subtitle:'',tone:'neutral'};
}

export function bindResults({snapshot,ledger,match,progression}){
  if(snapshot?.matchId===match?.id && snapshot?.resultType===match?.resultType){
    return {ok:true,snapshot,reused:true};
  }

  if(!match?.id || !match?.resultType){
    return {ok:false,recoverable:true,reason:'match_result_missing'};
  }

  const rows=(ledger||[]).filter(x=>x.committed && (!x.matchId || x.matchId===match.id));
  if(!rows.length && !snapshot){
    return {ok:false,recoverable:true,reason:'ledger_unavailable'};
  }

  const sum=key=>rows.reduce((a,x)=>a+(x.reward?.[key]||0),0);

  return {
    ok:true,
    rebuilt:true,
    snapshot:{
      matchId:match.id,
      resultType:match.resultType,
      durationPlayed:match.durationPlayed||0,
      tasksCompleted:match.metrics?.tasksCompleted||0,
      minionsDefeated:match.metrics?.minionsDefeated||0,
      towersDestroyed:match.metrics?.towersDestroyed||0,
      lanesCompleted:match.metrics?.lanesCompleted||0,
      xpEarned:sum('xp'),
      goldEarned:sum('gold'),
      diamondEarned:sum('diamond'),
      levelBefore:progression?.levelBefore,
      levelAfter:progression?.levelAfter,
      xpBefore:progression?.xpBefore,
      xpAfter:progression?.xpAfter,
      xpRequired:progression?.xpRequired,
      rankBefore:progression?.rankBefore,
      rankAfter:progression?.rankAfter,
      rankScoreBefore:progression?.rankScoreBefore,
      rankScoreAfter:progression?.rankScoreAfter
    }
  };
}

export function progressionPresentation(snapshot){
  return {
    levelUp:(snapshot.levelAfter||0)>(snapshot.levelBefore||0),
    rankUp:!!snapshot.rankAfter && snapshot.rankAfter!==snapshot.rankBefore,
    diamondHighlight:(snapshot.diamondEarned||0)>0,
    displayOnly:true
  };
}

export function homeReturn(match){
  return {
    route:'home',
    restoreSystemBars:true,
    clearActiveMatchPointer:true,
    refreshPlayerState:true,
    recalculateRewards:false,
    markResultsSeen:true,
    finalizedMatchId:match.id
  };
}

export function replayRequest(finalizedMatch){
  return {
    route:'prebattle',
    createNewMatch:true,
    previousMatchId:finalizedMatch.id,
    reuseMatchId:false,
    reuseRewardTransactions:false,
    reuseVictoryBonus:false
  };
}
