# STEP 75 — HOME POST-RESULT CELEBRATION + LIVE PROGRESSION REFRESH

این مرحله بازگشت از Results به Home را production-safe می‌کند.

## Goal

وقتی کاربر از Results روی «بازگشت به خانه» می‌زند:

Results
→ restore normal system UI
→ clear finalized active Match pointer
→ refresh committed Player State
→ Home rebinds XP / Level / Rank / Gold / Diamond
→ optional short celebration
→ Home becomes fully interactive

## Source of Truth

Home هیچ Reward تازه‌ای نمی‌سازد.

فقط از committed Player State می‌خواند:

level
xp
xpRequired
gold
diamonds
rankId
rankScore
selectedHeroId

Results فقط context می‌دهد که آیا Level/Rank/Reward تغییر کرده یا نه.

## Home Refresh Contract

Inputs:

finalizedMatchId
resultType
resultSnapshot
playerState
resultsSeenAt

Outputs:

updated HUD
updated XP bar
updated Rank card
updated wallet
updated Hero selection
optional celebration queue

## Celebration Rules

Celebration فقط وقتی لازم است:

Level Up
Rank Up
positive Diamond gain
Victory return

Priority:

rank_up
level_up
diamond_gain
victory_return

Maximum:
2 stacked celebration events per Home return

اگر بیشتر از 2 مورد باشد:
combine into one compact celebration.

## Celebration Does NOT

grant XP
grant Gold
grant Diamond
change Rank
change Level
replay Victory bonus
change Task state

## Suggested Home Presentation

Short top-center ribbon / medallion:

Rank Up:
رتبه جدید
{rankAfter}

Level Up:
سطح جدید
Level {levelAfter}

Diamond:
+{diamondEarned} الماس

Victory:
پیروزی ثبت شد

Duration:
700–1400ms

Non-blocking:
Home CTA should become usable immediately after Player State binding.
Celebration may continue without blocking Home.

## HUD Binding

Player header:
name
level

XP:
current committed XP / required XP

Gold:
committed wallet balance

Diamond:
committed reward balance

No Energy.

## Rank Card Binding

Rank card reads:
rankId
rankScore
rankRPRequired

If Rank Up happened:
brief glow / emblem reveal

No fake interpolation into permanent state.

## Hero Stage

Selected Hero is resolved from current Player State.

Post-Match does not auto-change Hero.

If Hero asset unavailable:
use existing Hero Asset Resolver contract.
Do not use final CSS human silhouette.

## Secondary Modules

فروشگاه
رویدادها
آینده‌بینی
دستاوردها

Rebind badges independently.

Failure in one module must not block Home.

## Start Game CTA

Available after:
Player State bound
no valid active Match
eligible Tasks exist
selected Hero valid

Finalized Match pointer must be cleared first.

## Active Match Pointer

After Results Home return:

activeMatchId = null

Finalized Match remains in history,
but cannot be resumed.

## Results Seen

resultsSeenAt persists before/while Home transition.

If app crashes after Results but before Home render:
fresh launch Home
Home loads committed Player State
no duplicate celebration/reward

Optional unseen-result marker may be resolved from persisted resultsSeenAt.

## Fresh Launch

Always Home.

No route stack restoration to Results or Match.

## System UI

Outside gameplay:
status bar visible
navigation bar normal
safe area active

Post-Result Home restores normal UI before final Home paint.

## Reduce Motion

Replace:
emblem burst
glow sweep
floating reward

With:
fade + static badge

## Failure Recovery

If Player State cannot load:
do not show fake zero wallet.

Show recoverable Home state:
«اطلاعات پیشرفت نیاز به بازیابی دارد»

Modules can still remain isolated if safe.

## QA

Home return restores normal system UI
finalized active Match pointer cleared
Home reads committed Player State only
no reward recalculation
no duplicate Victory bonus
Level Up celebration display-only
Rank Up celebration display-only
Diamond celebration positive-only
maximum two celebration events or combined
Home CTA unblocked after state bind
selected Hero preserved
secondary module failure isolated
fresh launch Home
no fake zero wallet
Stats remains tree-only
bottom nav remains exact five
no Energy

## STEP 76

HOME START GAME GUARD + RECOVERABLE MATCH FLOW

Start Game validation، active/recoverable Match card، duplicate-start protection و transition به PreBattle را production runtime می‌کنیم.
