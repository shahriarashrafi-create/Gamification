# STEP 73 — TIME END + MANUAL EXIT RESULT FLOW

این مرحله دو پایان غیر-Victory را production-safe می‌کند:
Time End
Manual Exit

هر دو:
Rewardهای Commit‌شده را حفظ می‌کنند
هیچ Penalty ندارند
هیچ Victory Bonus نمی‌دهند
به Results می‌روند

## Result Types

victory
time_end
manual_exit

Time End و Manual Exit هر دو معتبرند و defeat محسوب نمی‌شوند.

## Time End Flow

remainingMs <= 0
→ TIME_END_REQUEST
→ acquire finalization lock
→ block new encounters
→ stop wave scheduler
→ disable new objective transactions
→ if committed pipeline pending:
    finish safely
→ evaluate Victory race
→ if no Victory:
    finalize resultType = time_end
→ aggregate committed ledger
→ create result snapshot
→ show neutral Time End ceremony
→ prepare immersive exit
→ route Results

## Time End Ceremony

Title:
زمان تمام شد

Subtitle:
پاداش‌های ثبت‌شده حفظ شدند

Tone:
neutral / calm

Do not show:
شکست
باخت
Failure
Defeat

## Manual Exit Entry

Pause menu:
خروج از بازی

Tap:
open confirmation sheet

Confirmation:
می‌خواهی از این بازی خارج شوی؟

Support text:
تمام پاداش‌هایی که تا این لحظه ثبت شده‌اند حفظ می‌شوند.

Buttons:
ادامه بازی
خروج از بازی

## Manual Exit Flow

user confirms
→ MANUAL_EXIT_REQUEST
→ acquire finalization lock
→ block controls/new encounters
→ stop scheduler
→ preserve committed transactions
→ do not start new pending task
→ finalize resultType = manual_exit
→ ledger aggregation
→ result snapshot
→ neutral exit ceremony
→ leave immersive
→ route Results

## Manual Exit During Task Encounter

If Task not committed:
cancel encounter
no damage/reward

If Task already committed:
finish dependent committed pipeline safely
then exit.

## Manual Exit During Attack/VFX

VFX authority does not matter.

If damage/reward transaction already committed:
preserve it.

If not committed:
do not fabricate it.

## Manual Exit During Victory Transaction

If Base destruction/Victory commit already authoritative:
Victory wins.

Manual Exit cannot overwrite committed Victory.

## Single Finalization Lock

All result paths compete for one lock:

victory
time_end
manual_exit

First authoritative lock owner wins,
except an already-committed transaction may need deterministic completion.

No Match can have two final result types.

## Reward Policy

Committed XP:
preserved

Committed Gold:
preserved

Committed Diamond:
preserved

Tower destruction bonuses:
preserved if committed

Victory bonus:
only Victory

No exit penalty.

No Time End penalty.

## Result Snapshot

Result snapshot includes:

resultType
durationPlayed
tasksCompleted
towersDestroyed
lanesCompleted
xpEarned
goldEarned
diamondEarned
levelBefore
levelAfter
rankBefore
rankAfter

Snapshot derives from committed data only.

## Results Copy

Time End:
زمان تمام شد

Manual Exit:
بازی پایان داده شد

Victory:
پیروزی

All share the same Results architecture.

## Home CTA

Results → Home:
restores normal system bars
refreshes Player State from committed ledger
does not re-aggregate reward

## Back Button

During Manual Exit confirmation:
Back closes confirmation only.

During finalization:
Back ignored until safe Results route.

## Crash Recovery

Crash after Time End lock:
resume Time End finalization.

Crash after Manual Exit lock:
resume Manual Exit finalization.

Crash after snapshot before Results:
route Results.

Crash after result finalization:
never resume gameplay.

Fresh app launch:
Home only.

If finalized Match exists without Results seen:
Home may show "نتیجه بازی آماده است" recovery card.

## QA

Time End is neutral
Manual Exit is neutral
no defeat wording
committed rewards preserved
Victory bonus excluded from Time End
Victory bonus excluded from Manual Exit
no exit penalty
single finalization lock
Victory cannot be overwritten by Manual Exit
uncommitted Task gets no reward on exit
committed pipeline may finish safely
result snapshot committed-data only
Results route once
fresh launch Home
system bars restored outside gameplay
no Energy

## STEP 74

RESULTS SCREEN FULL PRODUCTION DATA BINDING

Victory / Time End / Manual Exit را به یک Results Screen نهایی با Progression، XP، Rank، Reward و CTAهای امن وصل می‌کنیم.
