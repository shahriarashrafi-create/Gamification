# SHAHRIAR GAME — 100 STEP REBUILD
## STEP 13 — EVENTS / QUALIFICATION WAR ROOM

این سند مرجع رسمی ماژول «رویدادها» است.

---

# 1. هویت ماژول

Events باید حس یک War Room حرفه‌ای برای رویدادها و Qualification بدهد.

نه تقویم ساده.
نه جدول اداری.

هدف:
کاربر سریع بفهمد:
- چه Eventهایی فعال‌اند
- چه کسی Qualified شده
- چه کسی باید برسد
- چه کسی نزدیک است
- هر نفر چقدر Progress دارد

---

# 2. Entry Point

Events:
از Home secondary module

نه Bottom Nav.

---

# 3. Event Model

Event:

- id
- title
- type
- startDate
- endDate
- targetMetric
- targetValue
- note
- active
- createdAt
- updatedAt

---

# 4. Event Types

Examples:

- Director Event
- Training Event
- Recognition Event
- Sales Qualification
- Team Challenge
- Custom

Type:
editable/customizable later.

---

# 5. Participant Model

Participant:

- id
- eventId
- memberId optional
- name
- currentValue
- targetValue
- status
- note
- createdAt
- updatedAt

---

# 6. Qualification Status

Canonical status:

- qualified
- close
- should_reach
- tracking
- not_started

Persian:

- واجد شرایط
- نزدیک به هدف
- باید برسد
- در حال پیشرفت
- شروع نشده

---

# 7. Qualified Rule

qualified if:

currentValue >= targetValue

Status may auto-sync with rule.

---

# 8. Close Rule

Suggested:

progress >= 75%
and < 100%

Label:
نزدیک به هدف

Threshold:
editable later.

---

# 9. Should Reach

Manual strategic marker:

کاربر می‌تواند فردی را علامت بزند:
«باید برسد»

این یک Priority label است، نه auto mathematical state.

---

# 10. Tracking

Default active state:
در حال پیشرفت

---

# 11. Progress

progressPercent:

currentValue / targetValue * 100

Clamp visual:
0–100%

Numeric overachievement may still show:
مثلاً 112%

---

# 12. Event Card

Event Card:

- Title
- Date Range
- Target
- Participant Count
- Qualified Count
- Close Count
- Open War Room CTA

---

# 13. Event CRUD

User can:

- Add
- Edit
- Delete
- Activate/Deactivate

Delete:
confirmation required.

---

# 14. Participant CRUD

Within Event:

- Add participant
- Edit participant
- Remove participant
- Update progress
- Change priority/status

---

# 15. Member Link

Participant can optionally link to Network Tree member.

memberId:
optional

If linked:
name can sync future.

---

# 16. Independent Participant

Event can also include a person not yet in Network Tree.

Therefore:
name required
memberId optional.

---

# 17. Target Metric

Examples:

- Sales
- GPV
- Recruit Count
- Attendance
- Custom Score

Event:
targetMetric

---

# 18. Individual Target

Participant can override event targetValue.

Default:
inherits event target.

---

# 19. Event Dashboard Rule

Allowed inside Event War Room:

compact operational summary

- Qualified
- Close
- Should Reach

But:
no unrelated analytics.

---

# 20. War Room Layout

Header:
Event title/date

Summary strip

Priority tabs:
- همه
- Qualified
- Close
- Should Reach

Participant cards

---

# 21. Participant Card

Card shows:

- Name
- Status
- current / target
- progress bar
- note
- edit

---

# 22. Qualified Visual

Gold/Green crest

No excessive celebration loop.

---

# 23. Close Visual

Amber glow

Copy:
«نزدیک به Qualification»

---

# 24. Should Reach Visual

Purple/Gold strategic marker

Priority icon.

---

# 25. Not Started

Muted steel

---

# 26. Update Progress

Quick action:
`+ Progress`

Or edit numeric field.

Future:
increment presets.

---

# 27. Overachievement

If current > target:
show value normally.

Visual progress bar max 100%.

Badge:
`+12% بالاتر از هدف`

optional.

---

# 28. Event Dates

Storage:
YYYY-MM-DD

Display:
Persian localized.

---

# 29. Active Event

active = true:
visible on Home Events module and main event list.

Inactive:
archived/hidden normal view.

---

# 30. Event Status

Derived:

upcoming
active
ended

based on dates.

Manual active field still controls visibility.

---

# 31. Search

Event list search:
title/type

Participant search:
name

---

# 32. Filters

Event:
active / ended / upcoming

Participant:
all / qualified / close / should reach

---

# 33. Sort Participants

Default:
closest to target descending

Alternative:
name
progress
status

---

# 34. Empty Event State

Copy:
«هنوز رویدادی تعریف نشده.»

CTA:
`اولین رویداد را بساز`

---

# 35. Empty Participants

Copy:
«هنوز شرکت‌کننده‌ای اضافه نشده.»

CTA:
`افزودن شرکت‌کننده`

---

# 36. Event Notes

Event:
general note

Participant:
individual note

---

# 37. Home Integration

Home Events module can show:

- number active events
- nearest event
- qualification alert

No large panel.

---

# 38. Achievement Integration

Future:
Qualified event participant can trigger Achievement.

Not automatic in Step 13.

---

# 39. Networking Integration

Future:
Participant can be linked to Prospect/Member.

No forced coupling.

---

# 40. Task Integration

Future:
Event target-related actions can create Tasks.

Not automatic.

---

# 41. Reward Rule

Event progress itself:
no direct Gold/Diamond reward by default.

Rewards only if event/achievement rule explicitly defines.

---

# 42. No Punishment

Failing Event target:
does not remove currency/rank.

---

# 43. Editable Thresholds

Settings future:

closeThresholdPercent = 75

qualifiedThresholdPercent = 100

---

# 44. Performance

100+ participants/event:
smooth list

No heavy effects per card.

---

# 45. Mobile

360px:
single-column participant cards

Summary:
3 compact blocks

---

# 46. RTL

All labels:
RTL

Progress numbers:
safe

Date:
localized

---

# 47. Step 13 Locked Structure

Event list

Event CRUD

War Room

Summary

Participant CRUD

Qualification status

Progress

Search/filter

---

# 48. Example Event

Title:
Director Event پاییز

Type:
Director Event

Target Metric:
GPV

Target:
5000

Start:
2026-09-01

End:
2026-10-15

---

# 49. Example Participant

Name:
علی رضایی

Current:
4200

Target:
5000

Progress:
84%

Status:
close

---

# 50. Quality Gate

Events PASS اگر:

- Event CRUD کامل باشد
- Participant CRUD کامل باشد
- Qualified مشخص باشد
- Close مشخص باشد
- Should Reach مشخص باشد
- Progress عددی/درصدی باشد
- Target قابل ویرایش باشد
- active/inactive باشد
- Search/Filter کار کند
- ظاهر War Room باشد نه جدول اداری
- هیچ Energy وجود نداشته باشد

---

# STEP 14

VISION / FUTURE REALM

در قدم ۱۴:
- Goal CRUD
- Year grouping
- Categories
- target value
- progress
- image URL
- note
- future assets/results
طراحی می‌شود.
