# STEP 82 — WORLD OBJECTIVE PROXIMITY + DIRECTIONAL COMPASS GUIDANCE

این مرحله Objective Guidance را به فاصله واقعی، جهت و Fog State متصل می‌کند.

## Goal

وقتی Objective هنوز کشف نشده:
مختصات دقیق آن روی Minimap لو نرود.

اما بازیکن بداند:
در چه جهت کلی حرکت کند
تقریباً چقدر دور است
چه زمانی به محدوده Objective نزدیک شده

## Guidance Modes

unseen:
direction_only

known:
direction + approximate distance + dim marker

visible:
exact marker + exact interaction guidance

## Direction

World vector:
dx = target.x - hero.x
dy = target.y - hero.y

angle = atan2(dy, dx)

Compass presents one of eight sectors:

شرق
شمال‌شرق
شمال
شمال‌غرب
غرب
جنوب‌غرب
جنوب
جنوب‌شرق

No RTL coordinate inversion.

## Distance Bands

Suggested:
very_near: <= 80 world units
near: <= 180
medium: <= 420
far: <= 800
very_far: > 800

Persian labels:
خیلی نزدیک
نزدیک
متوسط
دور
خیلی دور

Unseen objective:
distance band only
no exact meters/units

Known objective:
distance band + optional rounded coarse number

Visible objective:
exact interaction distance may be used internally.

## Proximity State

Outside discovery:
direction hint

Approaching:
compass pulse increases slightly

Within vision:
exact marker appears

Within interaction radius:
interaction UI takes priority

Priority:
active encounter > visible actionable objective > known objective > unseen strategic objective

## Smart Guidance

Guidance never:
teleports Hero
auto-paths Hero
forces lane
unlocks Tower/Base
creates Task
changes Fog
changes objective state

It reads authoritative state only.

## Objective Choice

Recommended objective follows Step79 rules:

active target
nearest actionable Minion
unlocked Tower
unlocked Enemy Base
free exploration

When multiple Towers are available:
prefer nearest unlocked objective,
but do not force a lane.

## Fog Privacy

unseen:
exact x/y not exposed to UI layer.

Runtime may use coordinates internally to calculate angle/band,
but UI receives:
direction sector
distance band
objective type
no exact position

known:
UI may receive dim marker position.

visible:
UI may receive exact marker.

## Compass UI

Top-center or near Minimap.

Compact chip:
هدف: تاور
شمال‌شرق
دور

For unseen objective:
no exact marker.

For known:
dim minimap marker + compass.

For visible:
normal marker + compass can fade.

## Directional Edge Hint

Optional:
screen edge arrow points toward target direction.

Arrow:
display-only
no click navigation
no drag path
no target lock.

## Smoothing

Compass direction should not jitter.

Use:
angle smoothing 140–220ms
sector hysteresis 6–10 degrees

## Update Rate

Hero/objective vector:
100–150ms while moving.

No heavy recompute every frame.

## Recovery

After recovery:
guidance reconstructs from Hero position + objective state + Fog grid.

No stored stale angle required.

## QA

unseen objective hides exact position
unseen objective provides direction only
distance uses bands
known objective can show dim marker
visible objective can show exact marker
interaction radius overrides compass
eight-direction sectors correct
RTL does not mirror world direction
no teleport
no auto-path
no forced lane
no objective mutation
guidance uses authoritative objective state
recovery recomputes guidance
no Energy
no Mana

## STEP 83

SMART OBJECTIVE SELECTION + LANE CHOICE ASSIST

چند Objective آزاد را بدون اجبار رتبه‌بندی می‌کنیم تا بازی هوشمندتر بگوید کدام مسیر سریع‌تر/بهتر است، ولی تصمیم نهایی با بازیکن بماند.
