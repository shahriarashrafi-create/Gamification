# STEP 59 — GAMEPLAY HERO ANIMATION STATE MACHINE

Hero داخل Match از حرکت خام به State Machine قطعی وصل می‌شود.

## States
idle
walk
run
attack
hit
victory
recall

## Priority
victory > hit > attack > recall > run > walk > idle

## Locomotion
speed < 0.18 → idle
0.18 تا کمتر از 0.62 → walk
>= 0.62 → run

State از velocity واقعی تعیین می‌شود، نه صرفاً joystick input.

## Facing
8-direction.
Facing فقط وقتی velocity از threshold عبور کند تغییر می‌کند.
هنگام Attack، Hero به Target می‌چرخد.

## Attack
Task completion committed
→ movement soft-lock
→ face target
→ attack state
→ projectile/VFX
→ impact
→ damage visible
→ return to locomotion

Attack animation خودش HP را تغییر نمی‌دهد.

## Hit
برای feedback بصری کوتاه.
Hit نمی‌تواند reward یا damage transaction ایجاد کند.

## Victory
Enemy Base destruction committed
→ controls locked
→ victory state
→ Results transition

Victory فقط یک بار در هر Match.

## Recall
Visual/navigation recovery state.
Teleport gameplay ممنوع است.

## Asset Resolver
هر animation state از Step58 resolver استفاده می‌کند.
اگر walk/run/attack variant موجود نباشد:
compatible fallback + VFX/motion layer.
Core battle idle باید موجود باشد.

## Animation Timing
idle loop
walk loop
run loop
attack 180ms windup + runtime clip
hit 120ms
victory 600ms+ ceremony handoff

## Reduce Motion
No camera shake
simpler state transitions
movement remains readable

## Active Match Snapshot
Hero ID + asset set + loadout snapshot در شروع Match ثابت است.

## QA
velocity drives locomotion
priority deterministic
attack faces target
attack animation cannot mutate HP
victory only after committed base destruction
victory once
missing non-core variant uses resolver fallback
no teleport
no combat stat advantage
no Energy

## STEP 60
GAMEPLAY HERO MOVEMENT + COLLISION PRODUCTION INTEGRATION
State Machine را به joystick physics، acceleration/deceleration، collision و camera follow واقعی وصل می‌کنیم.
