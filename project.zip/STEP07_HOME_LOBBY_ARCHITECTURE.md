# SHAHRIAR GAME — 100 STEP REBUILD
## STEP 07 — HOME / LOBBY EXPERIENCE ARCHITECTURE

این سند مرجع رسمی Home / Lobby است.

---

# 1. نقش Home

Home باید اولین برداشت بازی باشد.

قانون:
هر اجرای تازه App → Home

Home:
- Game Lobby
- Identity Center
- Progress Snapshot
- Match Launch Point

Home نباید:
- Dashboard اداری
- To-do list
- Friend list
- Mission strip
- جدول
- KPI grid شلوغ

باشد.

---

# 2. Primary Experience

کاربر در کمتر از ۳ ثانیه باید ببیند:

1. Hero خودش
2. Rank
3. Level / XP
4. Gold / Diamond
5. دکمه شروع بازی
6. دسترسی سریع به ماژول‌های مهم

---

# 3. Fixed Bottom Navigation

Bottom Nav دقیقاً ۵ آیتم:

- خانه
- کارها
- آمار
- تایم‌شیت
- شبکه‌سازی

هیچ آیتم ششمی اضافه نمی‌شود.

Hero / Shop / Events / Vision / Achievements / Settings
از Bottom Nav باز نمی‌شوند.

---

# 4. Top HUD

Top HUD:

Left/Right based RTL layout:
- Profile avatar
- Player name
- Level
- XP strip
- Gold
- Diamond
- Settings

ممنوع:
- Energy
- Stamina
- Hearts
- 8/10 meter

---

# 5. Hero Showcase

Hero:
مرکز بصری صفحه

باید:
- Full-body
- از سر تا پا قابل دیدن
- بدون Crop بد
- با background fantasy
- با stage / rune
- با subtle idle animation

Hero نباید:
تمام ارتفاع صفحه را اشغال کند.

Target:
تقریباً 38–46% viewport height

---

# 6. Hero Tap

Tap روی Hero:

Open Hero Hub

Hero Hub:
- Change Hero
- Outfit
- Aura
- Frame
- Background
- Cosmetic inventory

Hero Bottom Nav ندارد.

---

# 7. Rank Placement

Rank باید همیشه در Home قابل دیدن باشد.

Position:
Near Hero / lower hero area

Show:
- Emblem
- Rank Name
- Sub-rank
- RP progress

مثال:
حماسی III
72 / 100 RP

---

# 8. Start Match CTA

مهم‌ترین Action صفحه:

`⚔ شروع بازی — ۳۰ دقیقه`

ویژگی:
- بزرگ
- Gold
- بالای Bottom Nav
- همیشه داخل Viewport
- Safe Area aware
- با Hero و Rank overlap ندارد

مدت از Settings می‌آید.

اگر کاربر 45 دقیقه انتخاب کند:
CTA باید:
`شروع بازی — ۴۵ دقیقه`

---

# 9. Secondary Modules

چهار Module:

- فروشگاه
- رویدادها
- آینده‌بینی
- دستاوردها

Home placement:
compact side / lower utility grid

هدف:
همیشه قابل دسترسی
بدون اینکه Hero را کوچک یا CTA را پنهان کنند.

---

# 10. Shop Module

Label:
فروشگاه

Visual:
Armory / chest / crown icon

Purpose:
Hero cosmetics + real-life rewards

---

# 11. Events Module

Label:
رویدادها

Visual:
Banner / trophy / tournament emblem

Purpose:
Events + participant progress

---

# 12. Vision Module

Label:
آینده‌بینی

Visual:
Crystal / horizon / portal

Purpose:
Future goals / assets / roadmap

---

# 13. Achievements Module

Label:
دستاوردها

Visual:
Medal / crest / honor symbol

Purpose:
Daily / Weekly / Monthly / Long-term

---

# 14. Responsive Layout Principle

Home باید روی:

- 360×800
- 360×880
- 390×844
- 412×915
- 430×932

بدون بریدگی کار کند.

---

# 15. Vertical Budget

Home Viewport:

Top HUD:
10–12%

Hero Stage:
40–44%

Rank:
8–10%

Secondary Modules:
12–15%

CTA:
8–10%

Bottom Nav:
8–10%

فضاها باید با flex/grid توزیع شوند.

---

# 16. No Fixed Giant Hero Height

ممنوع:

`min-height: 600px` برای Hero

Hero Stage:
responsive clamp

پیشنهاد implementation:

`height: clamp(300px, 42dvh, 420px)`

اما تصمیم نهایی در Build Step.

---

# 17. Safe Area

Bottom Nav:

padding-bottom:
`env(safe-area-inset-bottom)`

CTA:
باید margin-bottom کافی قبل Nav داشته باشد.

Top HUD:
safe-area top aware

---

# 18. 100dvh Rule

Main shell:
100dvh

نه:
100vh قدیمی

هدف:
Android Chrome/WebView واقعی.

---

# 19. Overflow Rule

Home:
ترجیحاً بدون scroll برای کنترل‌های اصلی.

اگر دستگاه بسیار کوچک بود:
Hero stage کمی shrink شود.

CTA و Bottom Nav:
هرگز خارج Viewport نروند.

---

# 20. Hero Art Direction

Target:
Premium fantasy mobile game hero

Male/Female:
photorealistic / semi-real cinematic

Lighting:
- cool rim
- warm gold fill
- atmospheric background

Final quality به asset واقعی نیاز دارد.
CSS silhouette فقط برای layout prototype مجاز است.

---

# 21. Background

Lobby Background:

- Fantasy Citadel
- depth layers
- moon / sky
- distant castle
- fog
- floor rune
- particles

Background نباید Text را ناخوانا کند.

---

# 22. Visual Hierarchy

Order:
Hero
→ Start CTA
→ Rank
→ Profile Progress
→ Secondary Modules
→ Bottom Nav

---

# 23. Profile Card

Profile:
- Avatar
- Name
- Level

Tap:
Profile / edit player

Name:
Editable

---

# 24. XP Strip

Thin XP strip in top HUD

Not giant progress card.

Example:
LV 28
6240 / 8000

---

# 25. Currency Counters

Gold:
Warm gold coin

Diamond:
Cyan crystal

Compact counters

Tap Gold:
Shop / Gold section

Tap Diamond:
Real Rewards Shop

---

# 26. Settings

Settings icon:
top HUD

Tap:
System Control screen

---

# 27. Empty States

اگر Hero انتخاب نشده:
Default Hero selected

اگر Rank data missing:
Starter Rank

اگر currencies 0:
0 shown, no broken layout

---

# 28. Home Animation

Allowed:
- Hero idle
- rune rotate slow
- background fog
- module micro glow
- CTA shimmer subtle

Avoid:
- constant bouncing
- aggressive flashing
- too many particles

---

# 29. Home Performance

Hero artwork:
optimized

Background:
compressed

Particles:
limited

Avoid:
multiple heavy blur layers

---

# 30. Bottom Nav Visual

Active:
Gold/Cyan hybrid accent

Inactive:
Muted steel

Icons:
consistent game HUD style

Home active by default at app launch.

---

# 31. Home State

Home reads:

player
hero
rank
currencies
matchRules.matchMinutes
unread module indicators

Home does not own task data.

---

# 32. Fresh Launch Rule

App bootstrap:

Route forced to:
HOME

regardless of:
- previous screen
- last module
- last match result

unless an explicit Android deep-link exists in future.

---

# 33. Return from Match

Result → Home

System UI:
normal restored

Bottom Nav:
visible again

Hero:
back to Lobby state

---

# 34. Module Notification Badges

Allowed:
small badge

Examples:
- Event update
- Achievement ready

No spam / giant red dots.

---

# 35. Home Copy

Preferred CTA:
`شروع بازی`

Subcopy:
`۳۰ دقیقه تمرکز`

No:
“ماموریت اصلی”
“کار بزرگ”
“Focus Mission”

---

# 36. Rank Copy

Example:

حماسی III
۲۸ RP تا ارتقا

Compact.

---

# 37. Hero Identity Copy

Example:

آقای بادیسیپلین
منظم • جدی • رهبر

Visible but secondary.

---

# 38. Home Accessibility

- minimum touch 44dp
- contrast
- scalable Persian text
- reduce motion support later
- clear icon + text

---

# 39. RTL Integrity

Persian labels RTL

Numbers:
readable

Currency values:
icon placement consistent

No accidental LTR alignment in modules.

---

# 40. STEP 07 LOCKED LAYOUT

Top:
Profile + XP + Gold + Diamond + Settings

Center:
Hero Showcase

Beside/around:
4 Secondary Modules

Below Hero:
Rank

Bottom primary:
Start Match CTA

Persistent bottom:
خانه | کارها | آمار | تایم‌شیت | شبکه‌سازی

No Energy
No Friend List
No Mission Strip

---

# 41. Quality Gate

Home PASS اگر:

- CTA روی 360×800 دیده شود
- Bottom Nav چیزی را نپوشاند
- Hero full-body باشد
- Rank داخل viewport باشد
- 4 Module قابل دسترسی باشند
- Top HUD فشرده ولی خوانا باشد
- هیچ Energy وجود نداشته باشد
- هیچ Friend List وجود نداشته باشد
- هیچ Mission strip وجود نداشته باشد
- ظاهر Dashboard-like نباشد

---

# STEP 08

TASKS MANAGEMENT EXPERIENCE

در قدم ۸:
- Task library
- CRUD
- Search
- Filter
- Category
- Difficulty
- XP / Gold / Diamond
- activeInGame
- tactical visual design
طراحی می‌شود.
