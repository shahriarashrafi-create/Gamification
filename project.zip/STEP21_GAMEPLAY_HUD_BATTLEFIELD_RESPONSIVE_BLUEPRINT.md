# SHAHRIAR GAME — STEP 21
## GAMEPLAY HUD & BATTLEFIELD — FINAL RESPONSIVE BLUEPRINT

این مرحله ترکیب دقیق صفحه Match را برای Portrait Android قفل می‌کند.

## 1. Match Mode
Portrait only.
Gameplay immersive only.
Status bar + navigation bar hidden during Match.
Bottom Navigation app completely absent.

## 2. Battlefield
Three lanes:
A left
B center
C right

Own Base at bottom.
Enemy Base at top.
Two Towers per lane.
Minion/task waves along lanes.

## 3. Camera
Smooth follow.
Hero sits slightly below visual center so forward space is visible.
No teleport.

## 4. HUD Stack
Top-left/RTL logical:
Timer
Match objective state
Gold/XP gained this match
Minimap
Pause/Exit

HUD should not occupy central battlefield.

## 5. Timer
Default 30:00.
Prominent but compact.
Warning states:
<= 5 min gold warning
<= 1 min danger pulse, reduced-motion safe.

## 6. Minimap
Top corner.
Same normalized coordinates as Step03.
Own Base / Enemy Base / Hero / Towers / visible objectives.
Tap-to-teleport forbidden.
Future tap may only focus camera briefly if desired.

## 7. Joystick
Lower-left physical screen zone by default.
Left-hand mode may mirror control strategy later.
Touch diameter target ~112–132dp.
Visual opacity configurable.

## 8. Action / Context
Lower-right:
contextual attack/task/objective button.
No button spam.
When no actionable target, subdued state.

## 9. Encounter Trigger
Approach entity within trigger radius.
Hero soft-stops.
Camera focuses Hero + target.
Task overlay appears.

## 10. Task Overlay
Battlefield remains visible behind dark/blur focus layer.
Shows:
entity
task title
category/difficulty
note
XP/Gold/Diamond
Complete
Defer
Cancel

## 11. Complete
Task panel fades → hero faces target → projectile/attack → hit → HP update → reward → resume.

## 12. Defer
Current match only.
No damage/reward.

## 13. Cancel
Close current encounter.
No permanent task mutation.

## 14. Tower Warning
Entering danger/interaction radius:
ground ring
tower charge
HUD warning
No full-screen obstruction.

## 15. Tower HP
Compact world-space bar above Tower.
HUD can show target HP when focused.

## 16. Base HP
Enemy Base HP appears when Base is active objective.
Own Base remains visually readable.

## 17. Objective Marker
Use gold/cyan world marker.
Do not rely on arrow alone.

## 18. Fog / Vision
Peripheral vignette + fog.
Hero vision area remains readable.
Fog never hides task-interactable target after trigger.

## 19. Rewards
Small fly-up near target + compact HUD wallet increment.
No giant reward modal after every minion.

## 20. Victory
Enemy Base destruction:
impact
shockwave
brief camera hold
VICTORY transition
results screen.

## 21. Time End
Timer reaches zero:
finish current atomic reward transaction if already committed.
Then Time End results.
No currency penalty.

## 22. Pause
Pause button opens compact pause sheet:
Resume
Settings subset (audio/control)
Exit Match

Exit confirmation required.

## 23. Safe Zones
Top HUD below cutout.
Joystick/action above gesture edge.
Encounter CTA above bottom safe inset.

## 24. 360×800
Critical QA.
Minimap ~82–90px.
HUD single compact band.
Controls must not collide.

## 25. 390×844
Default balanced composition.

## 26. 430×932
May increase world visibility and control spacing; HUD does not scale excessively.

## 27. World Units
Visual map scales through camera; entity logical coordinates remain normalized/world-space.

## 28. Hero Screen Position
Target camera anchor around X .50 / Y .63 from Step04.

## 29. Lane Switching
Crossroads visually readable.
Player may move between lanes after/before objectives as allowed.
No forced teleport.

## 30. Touch Priority
Modal > encounter controls > pause > action > joystick > world.
Prevents accidental movement through modal.

## 31. Haptics
Task complete, tower hit, base victory.
Can be disabled in Settings.

## 32. Audio
Music/SFX settings respected.
Tower warning must also have visual cue.

## 33. Reduced Motion
Disable strong camera shake.
Shorten/replace shockwaves and scale bursts.
Keep state feedback.

## 34. Performance
No full-screen continuous heavy blur if device struggles.
Use layered gradients/textures fallback.

## 35. Bottom Navigation
Never visible during Match.

## 36. System Bars
Immersive re-applied on focus/visibility return.
Exit Match restores normal system UI.

## 37. Orientation
Portrait locked for gameplay architecture.

## 38. Failure Conditions
FAIL if:
controls overlap
minimap blocks timer
task overlay hides all battlefield context
Hero teleports
Bottom Nav appears
system UI remains unintentionally visible in active match
CTA enters gesture unsafe zone
Tower warning obscures target
360px layout clips controls

## 39. Prototype
Step21 interactive concept demonstrates HUD, three lanes, hero, minimap, joystick zones, tower warning and task encounter overlay.

## 40. Quality Gate
PASS if portrait gameplay remains readable and controllable from 360×800 through 430×932.

## STEP 22
TASK ENCOUNTER — FINAL CINEMATIC INTERACTION BLUEPRINT
Exact transition timing, task panel hierarchy, Complete/Defer/Cancel states, combat feedback and reward choreography.
