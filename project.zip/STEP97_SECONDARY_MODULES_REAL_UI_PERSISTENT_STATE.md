# STEP 97 — SECONDARY MODULES REAL UI + PERSISTENT STATE

این مرحله ماژول‌های فرعی Home را از Placeholder خارج می‌کند:

Shop
Events
Vision
Achievements
Hero Hub
Settings

## Shop

Gold:
Hero / Cosmetic

Diamond:
Real-life reward only

هیچ قدرت Gameplay فروخته نمی‌شود.

قابلیت‌ها:
Buy Hero
Select Hero
Claim Real Reward
Transaction History

## Events

Event:
title
startDate
endDate
targetValue
currentValue
status

Participant:
name
currentValue
targetValue
status

قابلیت‌ها:
Add Event
Delete Event
Progress update

## Vision

Goal:
title
year
category
targetValue
currentValue
progress
status

قابلیت‌ها:
Add Goal
Update Progress
Achieve
Delete

## Achievements

States:
locked
progress
ready
claimed

Claim:
atomic/idempotent

Rewards:
XP
Gold
Diamond

## Hero Hub

Hero:
visual identity only

No power.

Gold unlock.

Select Hero persists.

Default:
young_stylish

## Settings

Editable:

matchMinutes
waveSeconds
reduceMotion
qualityTier
leftHandMode

No Energy.
No Mana.

## Persistence

New domains:
shop
events
vision
achievements
heroes

All mutations through AppStore.

## STEP 98

LIVE MATCH ORCHESTRATOR + REAL GAMEPLAY ROUTE WIRING

Step66–90 contracts را داخل یک Coordinator واقعی به Router/Store/Gameplay route وصل می‌کنیم.
