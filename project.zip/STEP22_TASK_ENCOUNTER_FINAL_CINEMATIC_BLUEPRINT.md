# SHAHRIAR GAME — STEP 22
## TASK ENCOUNTER — FINAL CINEMATIC INTERACTION BLUEPRINT

مرجع رسمی choreography برخورد Hero با هدف واقعی.

## 1. Core Sequence
Approach → Detect → Soft Stop → Focus → Task Sheet → Decision → Combat Feedback → Reward → Resume.

## 2. Trigger
فقط وقتی Hero داخل trigger radius است، entity زنده/unlocked است، encounter دیگری باز نیست و Task معتبر وجود دارد.

## 3. Re-entry Guard
پس از بستن/تکمیل encounter، Hero باید از exit radius خارج شود تا همان target دوباره trigger شود.

## 4. Camera Focus
0–180ms: input soft-lock.
0–220ms: camera Hero+Target focus.
No teleport.

## 5. Battlefield Treatment
Battlefield visible.
Dark vignette + lightweight blur/gradient.
Hero and target remain recognizable.

## 6. Sheet Entry
~220ms.
Bottom sheet rises with opacity.
Reduced Motion: fade only.

## 7. Task Hierarchy
Entity type
Task title
Category + Difficulty
Note
Reward preview
Complete
Defer
Cancel

## 8. Reward Snapshot
At encounter open:
XP/Gold/Diamond + task identity + entity multiplier snapshot.
Edits outside encounter cannot change current reward.

## 9. Complete State Machine
READY
→ COMMITTING
→ SHEET_EXIT
→ HERO_FACE_TARGET
→ ATTACK_WINDUP
→ PROJECTILE/TRAVEL
→ HIT
→ DAMAGE_APPLY
→ REWARD_COMMIT
→ FEEDBACK
→ RESUME

## 10. Double Complete Guard
Button disables immediately at COMMITTING.
Transaction id unique.
Repeated taps ignored.

## 11. Suggested Timing
button lock 0ms
sheet exit 140ms
camera refocus 160ms
face target 80ms
attack windup 180ms
projectile 180–320ms distance dependent
hit burst 120ms
HP tween 220ms
reward fly-up 360ms
resume controls ~150ms

## 12. Minion
One completed task defeats minion by default.
Hit → defeat dissolve → reward.

## 13. Tower
Task completion damages tower.
Default 34 / 100.
Three tasks approximately destroy tower.
Tower remains if HP > 0.

## 14. Base
Default 25 / 100.
Four tasks approximately destroy Enemy Base.

## 15. Attack
Hero animation turns toward target.
Projectile originates from consistent hand/weapon anchor.
Melee Hero may use short lunge but never teleport.

## 16. Projectile
Arc/trail subtle.
Impact must visually connect attack to damage.

## 17. Hit
Short flash + particle burst + HP response.
Reduced Motion removes shake.

## 18. Damage Number
Optional compact world-space number.
Not giant arcade spam.

## 19. Reward
XP cyan/gold.
Gold coin.
Diamond only when reward > 0.
No fake Diamond animation for zero.

## 20. Reward Commit
Atomic:
validate transaction
apply reward
mark session task completed
apply entity damage
write history
persist

## 21. Defer
Marks task deferred_current_match.
No reward.
No damage.
Entity stays alive.
Resume movement after sheet exit.

## 22. Cancel
Only closes current encounter.
Master task unchanged.
No reward/damage.

## 23. Empty Task Pool
No encounter lock.
Show compact message and optional route to Tasks outside active combat flow.

## 24. Timer
Default continues during Task.
If Settings later enables pause-on-task, match-start settings snapshot controls behavior.

## 25. Tower Danger
Encounter focus supersedes tower warning UI.
Warning returns after encounter if still relevant.

## 26. Input Priority
Encounter sheet consumes touch.
Joystick/action disabled while open.
Pause may be disabled during COMMITTING atomic sequence.

## 27. Exit Match Safety
Cannot interrupt reward commit halfway.
Exit request waits until atomic transaction resolves.

## 28. Failure Recovery
If persistence fails:
do not duplicate reward.
Keep transaction recoverable/idempotent.
Show retry-safe feedback.

## 29. Haptic Choreography
open: subtle optional
complete tap: light
hit: medium
tower destroy: strong
base victory: strong pattern
all obey Settings.

## 30. Audio
sheet open cue
attack
impact
reward
tower destroy
victory
all obey master/SFX settings.

## 31. Accessibility
Reduced Motion.
No essential state by animation only.
Buttons >=44dp.
Readable Persian.

## 32. Mobile
360–430 width.
Sheet max height ~55–62% viewport.
Battlefield context remains above sheet.

## 33. Long Notes
Task note scrolls internally if necessary.
Actions stay sticky at sheet bottom.

## 34. Long Task Titles
Maximum visual 2 lines then ellipsis/expand detail.

## 35. Diamond
Rare.
Zero Diamond may be shown as 0 in detailed sheet, but no celebratory crystal effect.

## 36. Entity Death
Target interaction disabled immediately after lethal damage.

## 37. Resume
Camera returns to follow smoothly.
Joystick re-enabled after feedback completes.
Hero does not jump position.

## 38. Prototype
Interactive Step22 concept lets Complete/Defer/Cancel and target type simulate the choreography.

## 39. Failure Conditions
Double reward
teleport
reward before hit
damage without completed task
permanent deletion on Cancel/Defer
sheet hides all context
controls active behind modal
Diamond celebration at zero

## 40. Quality Gate
Encounter must make a real-world action feel directly connected to an in-game attack without sacrificing transaction correctness.

## STEP 23
COMBAT FEEDBACK / TOWER & BASE DESTRUCTION BLUEPRINT
World-space HP, projectile variants, impact, tower stages, base destruction, victory transition and reduced-motion variants.
