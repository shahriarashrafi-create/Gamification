# SHAHRIAR GAME — 100 STEP REBUILD
## STEP 04 — PLAYER / HERO CONTROL ARCHITECTURE

این سند مرجع رسمی کنترل Hero است.

## هدف
حرکت Hero باید نرم، طبیعی، قابل‌کنترل و مناسب یک MOBA عمودی موبایل باشد؛ بدون Teleport، بدون Snap و بدون تغییر ناگهانی سرعت.

## Joystick
- Lower-left و Safe-Area aware
- Input vector از -1 تا +1
- Dead Zone = 0.12
- Response Curve = pow(magnitude, 1.35)
- Pointer capture برای Multi-touch

## Movement
- Max Speed = 6.6 world units/sec
- Acceleration = 4.2
- Deceleration = 5.4
- حرکت Delta-Time based
- dt clamp = 0.05 sec
- Idle → Walk → Run با Threshold = 0.62

## Facing
Facing از Velocity واقعی Hero می‌آید، نه Input خام.
8 جهت: N, NE, E, SE, S, SW, W, NW
Facing فقط وقتی speed > 0.18 باشد تغییر می‌کند تا Twitch نداشته باشیم.

## Animation State Machine
Priority:
VICTORY > HIT > ATTACK > RECALL > RUN > WALK > IDLE

Timing اولیه:
- Idle: 2.5–4s breathing loop
- Walk: 0.72–0.90s
- Run: 0.48–0.65s
- Attack: 0.40–0.60s
- Hit: 0.25–0.40s
- Victory: 1.5–3s

## Collision
Hero = Circle radius 2.3
Tower/Base/Wall/Rock = Solid
Resolution = Slide Along Surface
Hero نباید با برخورد به مانع کامل متوقف یا Bounce شود؛ باید کنار Surface سر بخورد.

## Encounter Lock
وقتی Task Encounter باز می‌شود:
- Input ignore
- Velocity soft-zero
- Camera freeze نرم
- Hero = Idle
بعد از Complete: Attack sequence → Resume
بعد از Defer/Cancel: Resume بدون Teleport

## Camera Coupling
- Target Hero Y = 63% viewport
- Dead Zone X = ±8%
- Dead Zone Y = ±6%
- Look Ahead Y = 5.5%
- Smooth Follow
- Clamp to world
- Camera از Hero velocity جداست تا لرزش نداشته باشد.

## Mobile Controls
Joystick پایین چپ و Action پایین راست.
هیچ Control مهمی نباید داخل Android gesture area قرار بگیرد.
در آینده: Left-handed mode، Joystick size/opacity، camera sensitivity، reduce motion.

## Haptics
ویبره دائمی برای Joystick نداریم. فقط:
- Objective lock
- Task complete
- Tower impact
- Base final hit

## Resume Safety
در blur / visibilitychange / pointercancel:
- Input reset
- Joystick reset
- velocity کنترل‌شده
- بدون Jump پس از بازگشت App

## STEP 04 LOCKED DEFAULTS
Dead Zone: 0.12
Response exponent: 1.35
Max speed: 6.6
Acceleration: 4.2
Deceleration: 5.4
Walk/Run threshold: 0.62
Facing threshold: 0.18
Hero collision radius: 2.3
Camera target Y: 0.63
Camera look ahead: 0.055
Delta clamp: 0.05 sec

## Quality Gate
Step 04 فقط زمانی PASS است که:
- حرکت آهسته واقعاً ممکن باشد
- Hero فوراً Run نکند
- توقف طبیعی باشد
- Facing نلرزد
- برخورد باعث گیرکردن نشود
- Camera Follow نرم باشد
- روی 60/90/120Hz سرعت یکسان بماند
- Resume باعث جهش نشود

## STEP 05
REAL-WORLD OBJECTIVE / TASK ENCOUNTER SYSTEM
Task selection، encounter priority، cinematic overlay، complete/defer/cancel، reward mapping و combat handoff طراحی می‌شود.
