# STEP 84 — OBJECTIVE RECOMMENDATION UI + WORLD EDGE INDICATORS

این مرحله Recommendation هوشمند Step83 را به UI واقعی Gameplay وصل می‌کند.

## Components

1. Objective Card
2. World Edge Arrow
3. Alternative Objective Chips
4. Smooth Recommendation Switch
5. Fog-aware presentation

## Objective Card

Compact HUD card:
هدف پیشنهادی
نام Objective
Reason
Direction / Distance band when needed

Examples:
مسیر B — تاور دوم
این مسیر را کامل می‌کند
شمال • نزدیک

Card is informational only.

## World Edge Arrow

If recommended Objective is outside camera viewport:
show edge arrow.

Arrow:
points toward objective
clamped inside safe gameplay viewport
does not overlap top HUD / joystick / action button
display-only
not clickable by default

If Objective enters viewport:
edge arrow fades out
world marker becomes primary.

## Fog Rules

unseen:
edge arrow + direction + distance band
no exact minimap/world marker

known:
edge arrow allowed
dim exact minimap marker

visible:
normal world/minimap marker
edge arrow only if offscreen

## Alternatives

Up to two chips:
مسیر A
کار نزدیک

Tap alternative:
sets temporary player preference only.

It does NOT:
teleport
auto-path
unlock
force movement

Preference expires when:
objective invalid
encounter starts
user changes preference
optional timeout

## Smooth Switching

Recommendation UI changes only after Step83 switch policy approves.

Transition:
old card fade 120ms
content swap
new card rise/fade 180ms

Reduce Motion:
instant content swap.

No repeated pulse spam.

## Edge Projection

World target is transformed to screen space using camera transform.

If outside viewport:
normalize direction from screen center
intersect with safe inset rectangle
place arrow at edge

Safe Insets:
top HUD
bottom controls
left/right touch zones

## Interaction Priority

Active Task Encounter:
recommendation card dims/hides.

Active target:
takes priority.

Pause:
all guidance freezes visually.

Victory/TimeEnd:
guidance removed.

## Accessibility

High contrast text.
Direction available as text, not arrow-only.
Reduce Motion supported.

## QA

Objective card reflects Step83 primary recommendation
reason label matches recommendation
up to two alternatives
alternative tap creates preference only
no teleport
no auto-path
no forced lane
offscreen objective shows edge arrow
onscreen objective hides unnecessary edge arrow
unseen objective exact position not leaked
known objective dim marker allowed
visible objective normal marker
edge arrow respects safe control zones
switching follows anti-flicker policy
Task Encounter suppresses guidance
Pause freezes guidance
Results remove guidance
Reduce Motion supported
no Energy
no Mana

## STEP 85

GAMEPLAY TASK ENCOUNTER FINAL MOBILE UX POLISH

Task sheet، متن فارسی RTL، دکمه‌های انجام شد/بعداً/لغو، word wrapping، keyboard/safe-area و transitionهای نهایی را برای گوشی واقعی production-polish می‌کنیم.
