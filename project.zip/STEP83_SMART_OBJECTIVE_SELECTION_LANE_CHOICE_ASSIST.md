# STEP 83 — SMART OBJECTIVE SELECTION + LANE CHOICE ASSIST

این مرحله بین Objectiveهای آزاد یک پیشنهاد هوشمند می‌سازد، بدون اینکه اختیار بازیکن را بگیرد.

## Principle

Game recommends.
Player decides.

هیچ Auto-path، Teleport، Forced Lane یا Auto-Target اجباری وجود ندارد.

## Candidate Objectives

active actionable Minion
unlocked Tower1
unlocked Tower2
Enemy Base if unlocked

Locked objectives:
not candidates.

Destroyed/defeated objectives:
not candidates.

## Candidate Score

هر Candidate امتیاز پیشنهادی می‌گیرد:

distance score
progression value
task availability
fog familiarity
lane continuity
objective urgency

Suggested weights:

distance 30%
progression 25%
task availability 20%
lane continuity 15%
fog familiarity 10%

Urgency can temporarily override only for active encounter target.

## Distance

Closer objective generally scores higher.

But nearest is not always best:
Tower2 on a progressed Lane may beat a slightly closer fresh Tower1.

## Lane Continuity

If Hero is already on Lane B and B2 is unlocked:
small recommendation bonus.

This is convenience only.

No lane lock.

## Progression Value

Tower2:
high because it completes Lane.

Tower1:
medium because it unlocks Tower2.

Enemy Base:
highest when unlocked and user is pursuing Victory.

Minion:
high when actionable and nearby, but does not permanently block strategic objectives.

## Task Availability

Objective requiring Task interaction should only be recommended if a valid reservation/task path exists.

No fake Task.

## Fog Familiarity

Visible:
small confidence bonus.

Known:
neutral.

Unseen:
small penalty, but still recommendable through directional compass.

Fog never changes objective eligibility.

## Recommendation Output

Primary recommendation:
one objective.

Alternatives:
up to two.

UI copy example:

پیشنهاد بازی
مسیر B — تاور دوم
بهترین ادامه برای تکمیل این مسیر

Alternatives:
مسیر A
کار نزدیک

## Reason Labels

Possible reasons:

نزدیک‌تر است
این مسیر را کامل می‌کند
کار آماده دارد
در مسیر فعلی توست
راه بیس دشمن را باز می‌کند
بیس دشمن آماده حمله است

Do not expose numeric score to player by default.

## Player Override

Player can walk toward any other unlocked objective.

As Hero direction/location changes:
recommendation can update.

Do not constantly flicker:
minimum recommendation hold 2.0 sec
unless current recommendation becomes invalid.

## Sticky Recommendation

Hold recommendation if:
still valid
new candidate advantage is small

Switch only if:
current invalid
active encounter appears
new candidate score exceeds current by threshold

Suggested switch threshold:
12 score points.

## Active Encounter

Active target always takes temporary top priority.

After encounter resolves/cancels:
recompute strategic recommendation.

## Enemy Base

Once Base unlocked:
do not always force Base as recommendation.

If user is near Base / pursuing final push:
Base can become primary.

Player may still clear other Towers/Lanes.

## Recovery

Recommendation is recomputed from authoritative state after recovery.

Do not persist stale score.

Optional persist:
last recommended objective ID for presentation smoothing only.

## QA

locked objective never candidate
destroyed objective never candidate
defeated Minion never candidate
Task-less invalid Minion not recommended
Tower2 receives lane completion value
current lane receives continuity bonus
visible objective can receive confidence bonus
unseen objective can still be recommended directionally
active encounter has temporary priority
recommendation does not force movement
recommendation does not force lane
recommendation does not teleport
recommendation does not unlock objective
recommendation does not create Task
player can ignore recommendation
recommendation has anti-flicker hold
recovery recomputes score
no Energy
no Mana

## STEP 84

OBJECTIVE RECOMMENDATION UI + WORLD EDGE INDICATORS

پیشنهاد هوشمند را با HUD card، world edge arrow، alternative chips و تغییر نرم Objective به UI نهایی Gameplay وصل می‌کنیم.
