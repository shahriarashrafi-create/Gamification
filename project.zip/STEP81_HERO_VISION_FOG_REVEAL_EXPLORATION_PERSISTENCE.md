# STEP 81 — HERO VISION RADIUS + FOG REVEAL + EXPLORATION PERSISTENCE

این مرحله Fog of War را از یک نمایش ثابت به سیستم واقعی اکتشاف تبدیل می‌کند.

## Core Rule

Hero در اطراف موقعیت فعلی خود یک Vision Radius دارد.

هر نقطه از World یکی از سه حالت را دارد:

unseen
known
visible

visible:
در شعاع دید فعلی Hero است.

known:
قبلاً دیده شده اما الان خارج از شعاع دید است.

unseen:
تا این لحظه کشف نشده.

## Default Vision

Hero vision radius:
120 world units

Optional reduced radius in dense visual zones:
100

Objective special reveal:
Tower/Base فقط وقتی وارد دید شوند یا قبلاً کشف شده باشند روی Minimap ظاهر می‌شوند، مگر Own Base که همیشه visible است.

## Reveal Logic

For each update:

hero position
→ calculate current visible cells
→ mark visible
→ previous visible outside radius becomes known
→ persist newly discovered cells
→ update minimap fog
→ update entity marker visibility

No teleport reveal.

Fog reveal is driven by actual Hero movement.

## Fog Grid

Recommended logical grid:

worldWidth 1200
worldHeight 2600
cellSize 40

30 columns × 65 rows
1950 cells total

Each cell stores:
state
discoveredAt optional
lastVisibleAt optional

This is compact and persistence-friendly.

## Distance

Use squared distance for performance.

cell center within vision radius:
visible

No expensive sqrt required.

## Entity Visibility

Hero:
always visible.

Own Base:
always visible.

Enemy Base:
fog-aware.

Tower:
fog-aware.

Minion:
must be both:
valid persisted Minion
currently visible

Known Minions are NOT shown after they move away, because their position is dynamic/stale.

Known static objectives:
Tower/Base may remain dim on Minimap.

## Exploration Persistence

Persist:

fogGrid discovered/known cells
lastHeroPosition
mapVersion

Checkpoint:
on meaningful reveal delta
on pause
on background
on Match save
on app lifecycle checkpoint

Do not persist every render frame.

## Recovery

On Match Resume:

load fog grid
load Hero position
recalculate visible cells around current Hero
keep previous known cells
restore Minimap exploration

No reset to fully dark.
No reset to fully visible.

## Objective Guidance and Fog

Guidance may know strategic logic,
but World Marker should respect Fog.

If recommended Tower is unseen:
Minimap may show directional hint instead of exact marker.

If known:
show dim exact marker.

If visible:
show normal marker.

This prevents revealing full map too early.

## Directional Hint

For unseen recommended objective:
show edge compass hint / approximate direction.

No exact coordinate until discovered.

This hint:
does not move Hero
does not teleport
does not unlock objective

## Fog Visual

Battlefield:
soft dark overlay
feathered reveal around Hero
known areas darker than visible
unseen areas darkest

Reduce Motion:
no animated fog drift required.

## Performance

Fog recalculation:
when Hero moves more than 8–12 world units
or every 120–180ms while moving

No full-grid heavy recompute every frame.

Dirty cells only.

## Recovery Integrity

Fog is non-economic.

Corrupt fog data:
can rebuild conservative state from Hero/current objective/map defaults.

Do not affect rewards, HP, Task completion.

## QA

Hero has finite vision radius
Hero movement reveals map
visible becomes known after leaving radius
unseen stays hidden
previous exploration persists
Own Base always visible
Enemy Base fog-aware
Tower fog-aware
dynamic Minions shown only when currently visible
known dynamic Minion position not retained as current marker
fog updates are throttled
no full-map reveal
objective hint respects fog
unseen objective exact position not leaked
no teleport reveal
recovery restores known cells
fog corruption cannot affect rewards
no Energy
no Mana

## STEP 82

WORLD OBJECTIVE PROXIMITY + DIRECTIONAL COMPASS GUIDANCE

Objective unseen/known/visible states را به compass hint، distance band و smart guidance بدون لو دادن کامل Map وصل می‌کنیم.
