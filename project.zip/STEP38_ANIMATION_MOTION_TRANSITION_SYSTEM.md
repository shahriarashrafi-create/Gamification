# SHAHRIAR GAME — STEP 38
## ANIMATION / MOTION / TRANSITION SYSTEM

مرجع رسمی Motion، Transition، Hero Lobby Animation، Reward Choreography و Reduce Motion.

## 1. Goal
حرکت‌ها باید حس بازی پریمیوم بدهند، ولی هرگز باعث شلوغی، تاخیر یا افت فریم نشوند.

## 2. Motion Tiers
micro
standard
cinematic
major_event

## 3. Duration Tokens
instant 80ms
fast 140ms
normal 220ms
cinematic 360ms
major 600ms

## 4. Easing
Primary:
cubic-bezier(.2,.8,.2,1)

Exit:
cubic-bezier(.4,0,1,1)

## 5. App Navigation
Main tab:
fade/slide 140–220ms

Secondary module:
slide/fade 220ms

Gameplay entry:
cinematic 360–600ms

## 6. Home Lobby
Hero:
subtle breathing
tiny weight shift
cape/clothing idle if asset supports
soft floor shadow pulse
very slow ambient particles

No constant exaggerated bouncing.

## 7. Home Modules
Cards use small press scale.
No hover dependency on mobile.

## 8. CTA
Start Game:
press feedback
gold glow ramp
transition into Pre-Battle

## 9. Hero Hub
Hero switch:
old Hero fade/slide
new Hero reveal
pedestal light pulse
selection ring
No full-screen flash.

## 10. Shop
Purchase:
button commit state
currency update
unlock reveal
small celebration
No confetti storm.

## 11. Achievement
Ready:
subtle badge flare
Claim:
badge resolve + reward fly-up

## 12. Reward Fly-Up
XP toward XP indicator
Gold toward Gold wallet
Diamond toward Diamond wallet only if >0

## 13. Gameplay Movement
Hero animation state:
idle
walk
run
attack
hit
recall
victory

Priority from Step04 remains authoritative.

## 14. Animation Blend
Movement state transitions should blend smoothly.
No pose snapping except explicit hit/attack impact.

## 15. Camera Motion
Uses Step28 smooth damp.
No fake teleport transitions.

## 16. Encounter Open
soft stop
camera focus
background vignette
sheet rises/fades
controls dim

## 17. Encounter Close
sheet exits
camera refocus
hero faces target
attack starts

## 18. Attack Windup
~180ms default.
Can vary visually by Hero, but gameplay timing remains deterministic.

## 19. Projectile
180–320ms visual travel.
Logical hit timing remains authoritative.

## 20. Impact
Flash 120ms max
particle burst
HP tween ~220ms
optional micro shake

## 21. Tower Damage
Stage transitions:
healthy
damaged
critical
destroyed

Cracks/smoke/rune flicker progressively.

## 22. Tower Destroy
overload
collapse
debris
objective marker clear

## 23. Base Destroy
implosion
shockwave
camera hold
victory title

Strongest motion event in gameplay.

## 24. Victory
Hero victory pose
gold/cyan flare
result transition

Avoid long unskippable cinematic.

## 25. Time End
Neutral fade/settle.
No defeat animation.

## 26. Rank Up
Badge scale + ring sweep.
Short ceremonial motion.

## 27. Level Up
XP bar completes
level number transitions
small flare
Multiple level-ups sequence cleanly.

## 28. Bottom Sheets
Enter from bottom 220ms.
Exit 160ms.

## 29. Toast
Fade/slide 180ms.
Auto-dismiss without blocking input.

## 30. Skeleton
Motion subtle.
Disable shimmer under Reduce Motion if needed.

## 31. Reduce Motion
Replace:
large travel → fade
camera shake → none
parallax → none
particle burst → fewer/static
scale bounce → simple opacity
shockwave → radial fade

## 32. Reduce Motion Does NOT
disable essential feedback
disable all state change
disable audio automatically

## 33. Performance Budget
Target 60fps.
Frame budget ~16.7ms.
Avoid layout thrash.
Prefer transform + opacity.

## 34. DOM Motion
Never animate top/left for high-frequency movement if transform can be used.
Avoid expensive blur every frame.

## 35. Particle Caps
Minion impact:
small cap
Tower:
medium cap
Base Victory:
largest cap but bounded

## 36. Visibility
Pause offscreen/non-visible ambient animation when appropriate.

## 37. Lifecycle
Background:
pause nonessential animation.
Foreground:
resume from current state, not restart reward/victory sequences.

## 38. Prototype
Step38 concept simulates:
Lobby idle
Page transition
Reward fly-up
Tower hit
Victory
Reduce Motion toggle

## 39. Failure Conditions
Hero bouncing constantly
CTA hidden during transition
flashy strobe
animation blocks input too long
reward motion duplicates transaction
camera jump after foreground
60fps collapse from particles
Reduce Motion ignored

## 40. Quality Gate
Motion must make the app feel premium while preserving responsiveness, deterministic game timing and accessibility.

## STEP 39
VISUAL ASSET INTEGRATION CONTRACT
Exact runtime rules for Hero/background/tower/minion/VFX assets, fallback order, sizing, cropping, caching and final placeholder removal.
