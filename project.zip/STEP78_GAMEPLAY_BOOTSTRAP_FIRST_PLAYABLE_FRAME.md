# STEP 78 — GAMEPLAY BOOTSTRAP + FIRST PLAYABLE FRAME

هدف این مرحله تبدیل Match ذخیره‌شده و verified از PreBattle به اولین Frame واقعاً قابل بازی است.

## Authority Boundary

PreBattle:
Match را می‌سازد و persist می‌کند.

Gameplay Bootstrap:
فقط Match آماده و verified را hydrate و start می‌کند.

Gameplay Bootstrap هرگز Match جدید نمی‌سازد.

## Bootstrap Sequence

ROUTE_GAMEPLAY
→ load activeMatchId
→ load persisted Match
→ verify status == ready
→ verify snapshots
→ resolve Hero runtime assets
→ hydrate map/world
→ hydrate Tower/Base state
→ hydrate objective state
→ hydrate Task reservation runtime
→ initialize Camera
→ place Hero at persisted/spawn position
→ initialize collision
→ initialize HUD
→ initialize Timer/Wave runtime
→ request Android immersive
→ verify gameplay surface ready
→ commit Match start
→ set startedAt
→ status = running
→ start MatchClock
→ start WaveScheduler
→ unlock controls
→ FIRST_PLAYABLE_FRAME

## First Playable Frame Definition

اولین Frame قابل بازی فقط زمانی است که:

world hydrated
Hero visible
Hero position valid
Camera valid
collision ready
HUD bound
Timer committed running
Wave scheduler running
immersive requested/applied or safely degraded
controls enabled

قبل از آن:
joystick disabled
objective interaction disabled
Task Encounter disabled

## Hero Spawn

New Match:
mapSnapshot.heroSpawn

Recovery:
persisted Hero position

Hero هرگز برای bootstrap teleport animation ندارد.
قرارگیری اولیه قبل از اولین render انجام می‌شود.

Invalid persisted position:
nearest valid walkable recovery from Step61.

## Camera

Camera initializes directly around Hero before first visible gameplay frame.

No camera fly from 0,0.
No snap after Hero becomes visible.

Target:
x = .50
y = .63

## Entity Hydration

Tower HP from committed worldState.
Enemy Base HP from committed worldState.
Destroyed state from committed transaction/objective state.
Collision state derived from authoritative committed state.

Visual state cannot change HP.

## Minions

Bootstrap does not invent Minions.

New Match:
Wave scheduler creates due waves through Step63 reservation pipeline.

Recovered Match:
only persisted valid Minions/reservations are restored.

Orphan reservations:
reconcile safely.

## Timer Start Commit

New Match:
startedAt is committed once at gameplay start.

PreBattle duration is never charged.

Duplicate bootstrap:
must not reset startedAt.

Recovery:
uses existing startedAt/checkpoint.

## Wave Start

Wave Scheduler starts only after Match start commit.

First scheduled wave:
45 seconds elapsed by default.

No immediate fake wave required.

## Immersive

Gameplay requests:
status bar hidden
navigation bar hidden
IMMERSIVE_STICKY / WindowInsets equivalent

Focus regain:
reapply immersive.

If immersive call temporarily fails:
game state remains safe;
retry on focus.

Outside gameplay:
normal system UI.

## Control Unlock

Controls unlock last.

Joystick
objective targeting
interaction button

are disabled during bootstrap.

This prevents input before collision/world is ready.

## Bootstrap Failure

If critical hydration fails:

do not start Timer
do not start Waves
do not unlock controls

Persist Match as recoverable bootstrap error.

Exit immersive if already requested.

Route safe recovery/Home.

No reward mutation.

## Bootstrap Idempotency

bootstrapStartTxId unique per Match.

If Match already running:
do not run new-match start commit.

If startedAt exists:
never overwrite.

If Timer already running:
hydrate existing state.

## Loading Presentation

No fake percentage.

Allowed:
در حال آماده‌سازی میدان...

Then actual readiness states.

## Persistence Boundary

Persist immediately after:

Match start commit
startedAt
status running
Timer initial checkpoint
Wave initial state

Then unlock controls.

## QA

Gameplay cannot create new Match
requires persisted verified Match
Hero appears at valid spawn/persisted position
Camera initialized before visible playable frame
collision ready before controls
HUD bound before controls
Timer starts only after gameplay start commit
PreBattle time not deducted
startedAt written once
duplicate bootstrap cannot reset timer
Wave scheduler starts after Match start
first default wave due at 45 seconds
no fake Minion
recovery restores persisted Minions only
controls unlock last
bootstrap failure grants no rewards
bootstrap failure leaves Match recoverable
immersive gameplay only
fresh launch Home
no teleport animation at spawn
no Energy

## STEP 79

GAMEPLAY LIVE HUD + OBJECTIVE GUIDANCE RUNTIME

Timer، XP/Gold/Diamond session deltas، Objective marker، Tower/Base HP و Minimap guidance را به state واقعی Match وصل می‌کنیم.
