# STEP 64 — MINION MOVEMENT + LANE PATH FOLLOWING

این مرحله Minionهای رزروشده قدم 63 را روی Lane path واقعی حرکت می‌دهد.

## Movement Goal

Spawn
→ Path Follow
→ Approach
→ Interaction Ready
→ Focus/Encounter
→ Defeat/Defer
→ Despawn

هیچ Minionی teleport نمی‌شود.

## Lane Paths

Lane A / B / C هرکدام spline/waypoint path دارند.

Minion فقط روی path lane خودش حرکت می‌کند مگر اینکه طراحی آینده explicitly مسیر مشترک داشته باشد.

## Default Speed

Minion move speed:
2.4 world units/sec

Approach slow speed:
1.1 world units/sec

## Path Following

هر Minion:
pathId
segmentIndex
pathProgress
position
velocity
facing

حرکت با deltaTime انجام می‌شود.

delta clamp:
0.05 sec

## Waypoint Arrival

وقتی فاصله تا waypoint کمتر از 1.25 world unit شود:
segment بعدی فعال می‌شود.

## Interaction Stop

Minion وقتی به interaction staging point برسد:
state = waiting_for_player

Minion آنجا می‌ایستد تا Hero نزدیک شود.

No auto combat.
No passive damage.

## Player Proximity

وقتی Hero در encounter radius وارد شود:
Minion state = focused

movement = locked

Task Encounter باز می‌شود.

## Defeat

Task Complete committed
→ attack feedback
→ Minion state = defeated
→ death feedback
→ despawn delay
→ remove visual entity

## Defer

Task deferred_current_match
→ Minion state = deferred
→ short fade
→ despawn

No reward
No damage

## Cancel

Cancel Encounter:
Minion stays at staging point
reservation remains
short encounter cooldown
state returns waiting_for_player

## Spawn Safety

Minion spawn point:
walkable mesh valid
not inside blocker
not inside Tower collider
not overlapping another Minion too closely

minimum spawn spacing:
3.5 world units

## Separation

Active Minions have soft separation radius:
2.0 world units

Separation is visual/movement only.
It must not alter task ownership or objective state.

## Facing

Facing from velocity:
8-direction

If speed below 0.1:
keep last facing.

## Pause

Pause freezes:
movement
path progress
despawn timer

## Background / Resume

Persist:
pathId
segmentIndex
pathProgress
position
state

Resume:
rebuild exact path state
no jump.

## Recovery

Invalid path:
despawn safely
release reservation if objective never committed.

Invalid position:
nearest point on assigned lane path.

## Performance

Path interpolation once per frame.
No layout reads in simulation loop.
Target 60fps.

## QA

no teleport
Minion stays on assigned lane
path progress deterministic
waypoint advance works
interaction staging stop works
focused Minion stops moving
cancel keeps Minion
defer despawns without reward
complete despawns after feedback
spawn spacing enforced
soft separation works
pause freezes path
resume restores without jump
no auto combat
no Energy

## STEP 65

MINION VISUAL STATES + ANIMATION RUNTIME

idle / walk / focused / hit / defeated animation state را به Minion asset resolver و VFX واقعی وصل می‌کنیم.
