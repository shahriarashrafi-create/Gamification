# SHAHRIAR GAME — 100 STEP REBUILD
## STEP 12 — SHOP / REWARD ARMORY

این سند مرجع رسمی فروشگاه و سیستم پاداش‌های واقعی است.

---

# 1. هویت Shop

Shop باید مثل یک Premium Armory در بازی حس شود.

دو قلمرو کاملاً جدا:

1. Gold Armory
2. Diamond Rewards

---

# 2. Gold Armory

Gold برای:

- Hero Unlock
- Outfit
- Aura
- Frame
- Lobby Background
- Cosmetic Bundle

Gold نباید:
قدرت Gameplay بخرد.

---

# 3. Diamond Rewards

Diamond فقط برای:

- Real-life Rewards

مثال:
- قهوه
- غذای موردعلاقه
- سینما
- خرید شخصی
- تفریح
- استراحت برنامه‌ریزی‌شده
- جایزه سفارشی

---

# 4. No Currency Mixing

Gold:
Real-life reward نمی‌خرد.

Diamond:
Hero Power نمی‌خرد.

این جداسازی غیرقابل تغییر است مگر بعداً صریحاً تصمیم دیگری گرفته شود.

---

# 5. Shop Entry Point

Shop:
از Home secondary module

نه Bottom Nav.

---

# 6. Top Wallet

Shop Header:

- Gold
- Diamond
- Back
- Title

No Energy.

---

# 7. Shop Tabs

Tabs:

- Hero
- لباس
- افکت
- پس‌زمینه
- پاداش واقعی

---

# 8. Hero Product Model

Hero product:

- id
- name
- archetype
- priceGold
- owned
- selected
- imageAsset
- description
- active

---

# 9. Cosmetic Product Model

Cosmetic:

- id
- type
- name
- priceGold
- owned
- equipped
- heroCompatibility
- imageAsset
- active

Types:
- outfit
- aura
- frame
- background

---

# 10. Real Reward Model

Real Reward:

- id
- title
- diamondCost
- icon
- note
- active
- claimedCount
- createdAt
- updatedAt

---

# 11. Gold Product Card

Card:

- visual preview
- name
- type
- Gold price
- Owned / Buy / Equip

---

# 12. Diamond Reward Card

Card:

- icon/image
- title
- Diamond cost
- note
- Claim button
- claimed count optional

---

# 13. Purchase Validation — Gold

If gold < price:
blocked

Feedback:
«Gold کافی نیست»

If enough:
- subtract Gold
- mark owned
- purchase transaction
- success feedback

---

# 14. Equip Rule

Owned cosmetic:
can equip

No cost to re-equip.

---

# 15. Hero Select

Owned Hero:
select

Selected Hero:
Home showcase updates

No stat advantage.

---

# 16. Diamond Claim Validation

If diamonds < cost:
blocked

If enough:
- subtract Diamond
- create claim record
- increment claimedCount
- success feedback

---

# 17. Claim Does Not Auto-Fulfill Real World

Claim means:
user chose to redeem reward.

App records it.

Actual real-life fulfillment:
user-managed.

---

# 18. Claim History

Each claim:

- id
- rewardId
- titleSnapshot
- diamondCostSnapshot
- claimedAt

---

# 19. Gold Purchase History

Each purchase:

- id
- itemId
- itemType
- titleSnapshot
- goldCostSnapshot
- purchasedAt

---

# 20. Snapshot Principle

Transaction records keep snapshot data.

اگر بعداً قیمت تغییر کرد:
History تغییر نمی‌کند.

---

# 21. Real Reward CRUD

User can:

- Add
- Edit
- Delete
- Activate/Deactivate

---

# 22. Real Reward Add Form

Fields:

- title
- diamondCost
- icon optional
- note
- active

---

# 23. Edit Real Reward

Changes apply to:
future claims

Past history:
unchanged

---

# 24. Delete Reward

Delete:
confirmation

Claim history:
must remain.

Preferred final:
soft delete / archived reward.

---

# 25. Active Reward

active = false:

Reward hidden from normal claim list

but preserved in history.

---

# 26. Reward Cost

diamondCost:
integer >= 1

Zero-cost real reward:
not recommended

---

# 27. Suggested Default Costs

Coffee:
5

Meal:
12

Cinema:
18

Personal purchase:
25

Day-off reward:
40

All editable.

---

# 28. Gold Price Bands

Common cosmetic:
250–700

Premium cosmetic:
900–1800

Hero:
1800–5000

Background:
1200–3000

Editable later.

---

# 29. Hero Unlock Visual

Locked:
dark silhouette + Gold price

Owned:
clean border

Selected:
gold/cyan highlight

---

# 30. Cosmetic Preview

Tap:
large preview

Future:
try-on Hero

---

# 31. Purchase Animation

Gold:
coin fly + forge glow

Diamond claim:
crystal burst + reward seal

Avoid:
casino-like effects

---

# 32. Shop Economy Integrity

Every transaction:
unique id

Atomic:
- validate balance
- subtract
- persist ownership/claim
- record history

---

# 33. Double Purchase Guard

If owned:
Buy disabled

Cannot subtract twice.

---

# 34. Double Claim

Real reward:
can usually be claimed multiple times unless configured one-time.

Future field:
claimLimit

Default:
unlimited if affordable.

---

# 35. Inventory

Inventory owns:

- heroes
- outfits
- auras
- frames
- backgrounds

---

# 36. Equipped State

Per category:
one active item

Example:
one aura
one frame
one background

Outfit:
per selected hero

---

# 37. Default Hero

One Hero must be free/owned by default.

App must never open without selectable Hero.

---

# 38. Shop Search

Optional:
product search

Not needed for small catalog.

Real Rewards:
search helpful when many custom rewards exist.

---

# 39. Shop Filters

Gold:
Hero / Outfit / Aura / Frame / Background

Diamond:
All / Active / Affordable

---

# 40. Affordable Filter

Affordable:

Gold:
balance >= price

Diamond:
balance >= cost

---

# 41. Wallet Feedback

After purchase:
counter smoothly decrements

No page reload.

---

# 42. Real Reward Confirmation

Before Claim:
confirm

Copy:
«برای دریافت این پاداش، X Diamond خرج می‌شود.»

---

# 43. No Direct Money Purchase

Base product:
no real-money IAP defined.

Future optional:
separate design decision.

---

# 44. Accessibility

Price:
icon + number

State:
text + color

Touch:
44dp+

---

# 45. RTL

Product names:
RTL

Currency:
consistent icon placement

Tabs:
RTL scroll.

---

# 46. Mobile Layout

360px:
single or compact 2-column cards depending artwork.

Real rewards:
single-column preferred.

---

# 47. Empty Reward State

Copy:
«هنوز پاداش واقعی تعریف نکرده‌ای.»

CTA:
`اولین پاداش را بساز`

---

# 48. Step 12 Locked Structure

Header / Wallet

Tabs

Gold Armory

Diamond Rewards

Real Reward CRUD

Purchase/Claim Confirm

History

---

# 49. Example Prototype Wallet

Gold:
2437

Diamond:
12

---

# 50. Quality Gate

Shop PASS اگر:

- Gold و Diamond نقش جدا داشته باشند
- Gold فقط Hero/Cosmetic بخرد
- Diamond فقط Real Reward بخرد
- Hero power خریدنی نباشد
- ownership/equip کار کند
- real reward CRUD کار کند
- claim history حفظ شود
- transaction snapshot حفظ شود
- double purchase رخ ندهد
- balance validation صحیح باشد
- هیچ Energy وجود نداشته باشد

---

# STEP 13

EVENTS / QUALIFICATION WAR ROOM

در قدم ۱۳:
- Event CRUD
- Participants
- qualified
- should reach
- close to reach
- progress
- target
- event status
طراحی می‌شود.
