# SHAHRIAR GAME — STEP 18
## ART DIRECTION & ASSET PIPELINE

این سند استاندارد تصویری رسمی کل پروژه است.

## 1. هدف
تمام صفحات باید مثل بخش‌های مختلف یک بازی Premium واحد دیده شوند؛ نه مجموعه‌ای از Dashboardهای وب.

## 2. Art Pillars
1. Cinematic Fantasy Luxury
2. Dark Navy / Obsidian Depth
3. Royal Gold Structure
4. Cyan / Arcane Light
5. Full-body Hero Presence
6. Persian-first readable UI
7. Mobile-first portrait composition

## 3. Hero Quality
Hero نهایی باید:
- full-body
- realistic / premium game-render quality
- transparent PNG/WebP preferred
- readable silhouette
- consistent camera angle
- consistent floor contact/shadow
- no crude CSS human silhouette

Recommended master render:
2048×3072 transparent.
Runtime derivatives:
1024×1536 and 512×768.

## 4. Hero Camera
Front / subtle 3-quarter.
Eye level slightly above center.
Feet always visible in Lobby/Hero Hub.
No cropped knees unless intentionally in detail modal.

## 5. Hero Lighting
Key: warm gold
Rim: cool cyan
Fill: subtle navy
All hero archetypes use the same lighting grammar.

## 6. Environment Families
- Home Lobby: fantasy citadel / moon / command terrace
- Gameplay: three-lane arcane battlefield
- Hero Hub: premium armory/showroom
- Shop: reward armory/vault
- Events: war room
- Vision: future realm/horizon
- Achievements: honor hall
- Settings: system chamber
- Networking: command center
- Tree: strategic command tree
- Timesheet: tactical planner chamber

## 7. Background Master
Portrait master: 1440×3200.
Keep central subject-safe region clear.
Runtime WebP derivatives for 360–430px phones.

## 8. UI Ornament Family
Required:
- gold corner brackets
- thin engraved borders
- cyan rune separators
- premium panel headers
- rank medallion frame
- CTA frame
- modal crown/header ornament

Avoid over-decoration.

## 9. Iconography
One coherent icon family.
24px design grid.
2px optical stroke equivalent.
Gold for primary modules.
Cyan for utility/action.
Red only danger/destructive.
Do not mix emoji as final production icons.

## 10. Currency Icons
Gold:
coin / royal crest.
Diamond:
faceted cyan crystal.
XP:
arcane progress sigil.
No Energy icon exists.

## 11. VFX Families
- hero selection glow
- task encounter focus
- projectile trail
- hit burst
- tower charge warning
- reward fly-up
- rank promotion flare
- victory shockwave
- unlock reveal
- achievement claim flare

## 12. VFX Rule
Effects support feedback, not obscure content.
Max bright flash duration target: 120–220ms.
Reduced Motion setting disables/softens nonessential motion.

## 13. Battlefield Assets
Per lane:
ground tile, edge rocks, vegetation, rune markers, tower pads.
Entities:
minion variants, Tower 1, Tower 2, own base, enemy base.
All assets share top-down/3-quarter perspective.

## 14. Minion Readability
Minion must be recognizable at small portrait-screen size.
Strong silhouette.
Color/status cue without relying only on hue.

## 15. Tower Design
Tower 1 and Tower 2 visually related but escalating.
Enemy tower danger radius gets separate VFX asset, not baked into tower art.

## 16. Base
Enemy Base should read as final objective from distance.
Own Base should feel safe/royal.

## 17. UI Surface Materials
Primary:
obsidian glass
brushed dark metal
aged royal gold
cyan crystal light

No generic white cards.

## 18. Typography
Persian UI:
high readability first.
Production font licensing must be verified before packaging.
Fallback system font must remain usable.
Latin micro-labels are decorative secondary labels only.

## 19. Text Contrast
Body >= WCAG-inspired readable contrast.
Gold decorative text cannot replace readable body text.

## 20. Asset Naming
hero_<id>_<pose>_<size>.webp
bg_<screen>_<variant>_<size>.webp
icon_<name>_<state>.svg
vfx_<name>_<frame/variant>.webp
ui_<component>_<variant>.svg

Lowercase ASCII filenames.

## 21. Asset Folders
assets/
  heroes/
  backgrounds/
  battlefield/
  entities/
  ui/
  icons/
  vfx/
  audio/
  fonts/

## 22. Formats
WebP: raster runtime art.
PNG: transparency source/export when needed.
SVG: simple UI ornaments/icons.
Avoid huge JPEG UI assets.
Audio later: OGG/AAC based on Android pipeline.

## 23. Compression
Visual QA before compression.
Target no obvious banding around dark gradients.
Hero edges must remain clean.
Do not overcompress transparent art.

## 24. Density
Keep logical CSS/device layout independent of source pixel density.
Use responsive sizing; never hard-code art dimensions to one phone.

## 25. Safe Zones
Background key focal elements must not sit under:
- top status safe area
- bottom gesture/navigation area
- CTA
- canonical bottom nav

## 26. Home Composition
Hero target ~38–46% viewport height.
Side modules and Rank must remain visible.
Start CTA always above bottom nav.
This rule overrides “make hero bigger”.

## 27. Gameplay Composition
Hero/environment art cannot cover HUD readability.
Fog and vignette must preserve objective visibility.

## 28. Art Review Gate
Every asset reviewed for:
- style match
- perspective
- lighting
- silhouette
- mobile readability
- compression
- transparent edge quality
- safe-zone fit

## 29. Asset Status
planned → concept → generated/drawn → selected → processed → integrated → approved.

## 30. Placeholder Policy
CSS/emoji placeholders are allowed only during architecture prototypes.
They are forbidden in final visual QA.

## 31. Source Tracking
Every production asset needs:
id, sourceType, sourceRef, license/ownership note, generation prompt/version if generated, edit history, approval status.

## 32. Consistency
A single asset registry is the source of truth.

## 33. Performance Budgets
Initial Home critical visual payload target: <= ~3 MB compressed where practical.
Lazy-load secondary module art.
Do not preload every Hero full-resolution render.

## 34. Animation Assets
Prefer transform/opacity + sprite/VFX layers.
Avoid heavy full-screen video loops for core navigation.

## 35. Accessibility
Reduce Motion supported.
Important state never communicated only by animation.
Text never baked into reusable background art.

## 36. RTL
Ornaments must be mirror-safe where appropriate.
Directional arrows/actions must follow RTL meaning.

## 37. Professional Asset Production
Final photorealistic quality requires actual graphic assets. HTML/CSS alone cannot create the requested Mobile-game-level Hero and environment quality.

## 38. Asset Manifest
Step18 adds a machine-readable registry with IDs, dimensions, usage and status.

## 39. Visual Concept
Step18 concept is an Art Bible board: palette, materials, asset families, Hero lighting, environment families, VFX and production status.

## 40. Quality Gate
PASS if:
- one cohesive art language
- real asset pipeline defined
- Hero quality target defined
- environment families defined
- UI ornaments/icons defined
- VFX defined
- naming/folders/formats defined
- mobile safe zones defined
- performance strategy defined
- placeholder exit criteria defined
- no Energy concept

## STEP 19
DESIGN SYSTEM / UI COMPONENT LIBRARY
Colors, typography scale, spacing, radii, buttons, panels, cards, HUD, modal, nav, chips, inputs and motion tokens are locked into reusable components.
