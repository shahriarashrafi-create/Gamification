# STEP 60 — GAMEPLAY HERO MOVEMENT + COLLISION + CAMERA FOLLOW PRODUCTION INTEGRATION

این مرحله State Machine قدم 59 را به کنترل واقعی Match وصل می‌کند.

## Input
Virtual Joystick lower-left

dead zone: 0.12
response exponent: 1.35

Input vector:
normalized X/Y
magnitude 0–1

## Movement

maxSpeed: 6.6 world units/sec
acceleration: 4.2
deceleration: 5.4

Hero هیچ‌وقت teleport نمی‌شود.

Velocity با deltaTime به‌صورت smooth تغییر می‌کند.

## Delta Time

Frame delta clamp:
0.05 sec

برای جلوگیری از پرش Hero بعد از lag/background.

## Walk / Run

walk threshold:
0.18

run threshold:
0.62

State Machine Step59 از velocity واقعی تغذیه می‌شود.

## Collision

Hero collider:
circle radius 2.3 world units

Collision type:
slide-along-surface

اگر Hero به دیوار/مانع بخورد:
محور آزاد حرکت حفظ می‌شود.
Hero گیر نمی‌کند و از مانع عبور هم نمی‌کند.

## Walkable World

Hero فقط در:
lane polygons
crossroad corridors
base zones
objective approach zones

حرکت می‌کند.

No tap-to-move.
No minimap teleport.

## Camera

smooth follow

anchor:
X = 0.50
Y = 0.63

dead zone:
X = 0.08
Y = 0.06

lookAheadY:
0.055

Camera به جای Hero کمی فضای جلو را نشان می‌دهد.

## Camera Clamp

دوربین هرگز خارج از World Bounds نمی‌رود.

## Encounter Lock

وقتی Task Encounter باز می‌شود:

joystick input ignored
Hero soft-stop
velocity به صفر نزدیک می‌شود
camera soft freeze

پس از Resume:
control برمی‌گردد.

## Attack Integration

Attack:
movement soft-lock
Hero face target
Attack animation
Projectile
Impact
Resume movement

## Pause

Pause:
movement frozen
camera frozen
timer behavior طبق تنظیمات Match.

## Lifecycle Recovery

App background:
persist Hero position + velocity + facing + camera anchor.

Resume:
velocity به‌صورت امن restore/clamp.
هیچ displacement ناگهانی مجاز نیست.

## Performance

60fps target
transform/position updates only once/frame
no layout reads inside movement loop

## Accessibility

Left-Hand Mode:
joystick/right action controls mirrored.

Joystick:
size adjustable
opacity adjustable

Reduce Motion:
camera look-ahead reduced
no shake
movement physics unchanged

## QA

no teleport
smooth acceleration
smooth deceleration
collision slide
cannot cross blocked geometry
camera clamp
camera dead-zone
encounter locks movement
pause freezes movement
lag delta clamp prevents jump
left-hand mode works
no Energy

## STEP 61

GAMEPLAY MAP COLLISION GEOMETRY & WALKABLE LANE MESH

سه Lane، Crossroadها، Base zoneها و obstacle geometry را به collision map واقعی وصل می‌کنیم.
