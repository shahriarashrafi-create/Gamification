# STEP 76 — HOME START GAME GUARD + RECOVERABLE MATCH FLOW

این مرحله Start Game روی Home را production-safe می‌کند.

## Goal

شروع بازی فقط وقتی مجاز است که:

Player State معتبر باشد
Hero انتخاب‌شده معتبر باشد
حداقل یک Task قابل استفاده وجود داشته باشد
هیچ Active Match معتبر دیگری وجود نداشته باشد
هیچ Start transaction دیگری در حال اجرا نباشد

## Home Start Flow

Tap:
شروع بازی — {minutes} دقیقه

→ START_REQUEST
→ acquire start lock
→ bind/check Player State
→ validate selected Hero
→ count eligible Tasks
→ inspect active Match pointer
→ if valid recoverable Match exists:
    do not start new Match
    show recoverable Match card
→ if stale/invalid active pointer:
    quarantine/clear pointer safely
→ create PreBattle request
→ release Home interaction lock
→ route PreBattle

Home Start NEVER directly enters gameplay.

## Duplicate Tap Guard

Double tap / rapid tap:
only first request wins.

startRequestId is unique.

Repeated request while starting:
ignored.

Button state:
ready
validating
blocked
routing

## Eligible Tasks

Start requires eligibleTaskCount > 0.

If zero:
block start

Persian copy:
برای شروع بازی حداقل یک کار فعال لازم است.

CTA:
رفتن به کارها

No fake generated Task.

## Hero Validation

Selected Hero must:
exist
be owned/unlocked
have core runtime asset available for Battle

If invalid:
block start

Copy:
قهرمان انتخاب‌شده آماده بازی نیست.

CTA:
انتخاب قهرمان

## Active Match

At most one active Match.

Possible pointer states:

none
valid_active
recoverable
stale_pointer
corrupt_active
finalized_pointer

### valid_active / recoverable

Home shows card:
بازی نیمه‌کاره

Details:
remaining time
selected Hero
last known objective
savedAt

Actions:
ادامه بازی
پایان دادن بازی

Do not auto-enter Match.

## Recoverable Match Resume

Tap ادامه بازی:

validate saved Match
validate snapshot
validate Hero runtime asset
reconcile Timer
reconcile Wave scheduler
reconcile entity/pipeline transactions
persist recovered state
enter immersive
route Match

If any critical validation fails:
do not resume
show recoverable error
offer safe finalization or Home

## End Recoverable Match

Tap پایان دادن بازی:

confirmation required

Copy:
می‌خواهی این بازی نیمه‌کاره را پایان بدهی؟

Committed rewards are preserved.

Result:
manual_exit

Uses same Step73 finalization path.

## Stale Pointer

If activeMatchId points to missing/finalized Match:

do not block forever.

Clear stale pointer only after verification.

Then Start can continue.

## Corrupt Active Match

Never guess state.

Show:
بازی ذخیره‌شده نیاز به بازیابی دارد

Actions:
تلاش دوباره
پایان امن بازی

No automatic delete.

## Fresh Launch

Fresh launch always Home.

If recoverable Match exists:
Home shows recoverable Match card.

No automatic Match route.

## Start Game CTA Availability

Enabled only if:

playerBound
heroValid
eligibleTaskCount > 0
no active/recoverable Match
not starting

If recoverable Match exists:
primary Home CTA can become:
ادامه بازی

but must still route through validation.

## PreBattle Request

Carries only intent/context:

requestedDuration
selectedHeroId
eligibleTaskCount
startRequestId

Actual Match creation remains Step25/43 PreBattle authority.

## Start Lock

startLock is Home-only transient lock.

It is not Match finalization lock.

If app crashes while validating:
no Match should exist unless PreBattle already committed one.

## Back / Route Safety

While validating:
Back may cancel Home validation if no Match creation committed.

While routing PreBattle:
route guard prevents duplicate transition.

## QA

Start requires valid Player State
Start requires valid Hero
Start requires eligible Task
zero Task blocks start
no fake Task generated
double tap creates one request
Home never directly enters Match
recoverable Match blocks new Match creation
fresh launch still Home
recoverable Match does not auto-open
Resume validates Timer/Waves/entities
End recoverable Match uses Manual Exit flow
stale pointer can be safely cleared
corrupt Match is never guessed/deleted automatically
PreBattle remains Match creation authority
bottom nav exact five
Stats tree-only
no Energy

## STEP 77

PREBATTLE VALIDATION + MATCH SNAPSHOT HARDENING

Hero/Task/Settings/Map snapshot، Match ID creation و immutable Match bootstrap را production-grade می‌کنیم.
