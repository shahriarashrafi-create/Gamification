# SHAHRIAR GAME — STEP 28
## CAMERA / FOG / MINIMAP — FINAL GAMEPLAY SYSTEM

مرجع رسمی Camera Follow، Fog of War و Minimap.

## 1. Camera Goal
Hero control باید نرم و قابل پیش‌بینی باشد و فضای بیشتری در جهت حرکت/پیشروی دیده شود؛ بدون پرش دوربین.

## 2. Camera Anchor
Default target:
X = 0.50
Y = 0.63
Hero slightly below center.

## 3. Dead Zone
X = 0.08 viewport
Y = 0.06 viewport
حرکت‌های کوچک Hero نباید Camera jitter ایجاد کنند.

## 4. Look Ahead
Default forward look-ahead Y = 0.055.
Direction-sensitive and smoothly interpolated.

## 5. Follow
Smooth damped follow.
No hard snapping except recovery from invalid camera state.

## 6. Bounds
Camera is clamped to world bounds.
No view outside designed battlefield.

## 7. Hero Movement
Camera never teleports Hero.
Camera transform and world position remain independent.

## 8. Encounter
When encounter triggers:
soft focus Hero + target.
Camera input/follow temporarily cinematic.
After encounter, smoothly returns to follow anchor.

## 9. Tower Destroy
Small focus/hold.
No excessive zoom.

## 10. Base Victory
Strongest camera choreography:
focus → pull/hold → shockwave → Results.
Reduced Motion simplifies this.

## 11. Fog Philosophy
Fog improves world readability and progression atmosphere.
It must never hide the actionable target after encounter trigger.

## 12. Vision
Hero-centered reveal radius.
Known major objectives may retain silhouette/marker beyond current vision.

## 13. Fog Layers
unseen
known-but-not-currently-visible
visible

## 14. Unseen
Dark/navy fog.
No detailed enemy/task information.

## 15. Known
Muted silhouette/structure marker.
No hidden Task title leak.

## 16. Visible
Normal environment/entity rendering.

## 17. Objective Visibility
Own Base always known.
Enemy Base location known but locked state respected.
Towers known as structural objectives.
Actionable Minion visibility respects Hero vision/relevance.

## 18. Encounter Override
Once a valid encounter is triggered, target remains visually legible until encounter closes.

## 19. Fog Reveal Persistence
Map terrain discovery may persist within current Match.
Entity visibility remains dynamic.

## 20. Minimap Projection
World normalized coordinates map directly into minimap local bounds:
miniX = worldX / worldWidth
miniY = worldY / worldHeight

## 21. Minimap Orientation
Top = Enemy Base.
Bottom = Own Base.
Never rotates with Hero.

## 22. Minimap Size
Target:
360×800: ~82–88px wide
390×844: ~88–94px
430×932: ~94–102px
Keep touch/UI safe.

## 23. Minimap Content
Hero
Own Base
Enemy Base
Tower states
relevant visible Minions
lane/crossroad geometry
recommended objective cue

## 24. Minimap Tower States
locked
alive
destroyed
Each uses icon/state cue + color, not color alone.

## 25. Hero Marker
High contrast cyan/white center marker.
Small direction wedge optional.

## 26. Recommended Objective
Gold ring/pulse.
Reduce Motion: static gold ring.

## 27. Tap Behavior
No tap-to-teleport.
Default minimap is informational.
Future optional tap can temporarily focus camera only.

## 28. Zoom
Gameplay camera zoom is controlled by design, not pinch by default.
Tree page pan/zoom rules are unrelated.

## 29. HUD Collision
Minimap must not overlap Timer/objective HUD/cutout.
Top safe area respected.

## 30. Joystick Collision
Minimap remains top region.
Never drifts into joystick/action controls.

## 31. Fog Performance
Prefer mask/gradient/render texture strategy appropriate to final engine.
Avoid expensive full-screen DOM blur loops.

## 32. Camera Performance
Delta-time clamp.
Smooth interpolation.
Avoid allocations per frame.

## 33. Resume Focus
On Android app focus return:
reapply immersive
recompute viewport
camera remains on Hero
no jump to map origin.

## 34. Resize
Use actual dynamic viewport.
Safe after navigation bar/keyboard/system UI changes.

## 35. Accessibility
Reduce Motion:
lower camera easing travel
disable strong shake
static objective cue
Fog contrast remains readable.

## 36. Mobile QA
360×800
360×880
390×844
412×915
430×932

## 37. Recovery
Recovered active Match restores Hero world position, camera follows Hero from valid clamped target, fog discovery snapshot if stored.

## 38. Prototype
Step28 concept demonstrates Hero movement, smooth camera viewport, fog reveal and normalized minimap projection.

## 39. Failure Conditions
camera jitter
view outside world
minimap rotates
tap teleports Hero
fog hides triggered target
camera jumps after encounter
minimap overlaps HUD
Hero marker differs from world position

## 40. Quality Gate
World, camera and minimap must always agree on Hero/objective positions while preserving smooth portrait gameplay.

## STEP 29
GAMEPLAY CONTROL POLISH / JOYSTICK & INTERACTION SYSTEM
Joystick response curve, acceleration/deceleration, action target selection, touch priority, left-hand mode and control accessibility.
