# SHAHRIAR GAME — STEP 36
## APP-WIDE EMPTY / LOADING / ERROR / OFFLINE STATES

مرجع رسمی حالت‌های خالی، Loading، Error، Offline و Recovery در تمام اپ.

## 1. Goal
هیچ صفحه‌ای نباید در نبود داده، خطا یا قطع اینترنت به صفحه سفید، Spinner بی‌پایان یا وضعیت مبهم تبدیل شود.

## 2. Local-First Rule
Core features remain usable offline:
Tasks
Network Tree
Timesheet
CRM
Heroes owned state
Settings
Active Match
Match recovery

## 3. State Families
ready
empty
loading
saving
offline
error
recoverable_error
corrupt_data
permission_blocked

## 4. Empty State
Must explain:
what is empty
why it matters
one clear next action

## 5. Tasks Empty
Title:
«هنوز کاری نداری»
CTA:
«ساخت اولین کار»

If no activeInGame tasks:
«برای شروع بازی حداقل یک کار فعال لازم است»

## 6. Network Tree Empty
Root player remains.
CTA:
«اضافه کردن اولین عضو»

Stats is still Tree only.

## 7. Timesheet Empty
«برای این روز برنامه‌ای ثبت نشده»
CTA:
«افزودن برنامه»

## 8. CRM Empty
«هنوز مخاطبی ثبت نشده»
CTA:
«افزودن مخاطب»

## 9. Events Empty
«رویداد فعالی نداری»
CTA:
«ساخت رویداد»

## 10. Vision Empty
«اولین هدف آینده‌ات را بساز»
CTA:
«افزودن هدف»

## 11. Achievements Empty
System-defined achievements normally exist.
If none loaded due configuration issue, use recoverable error, not fake empty achievement.

## 12. Shop Empty
If catalog unavailable:
show recoverable catalog error.
Do not invent products.

## 13. Hero Hub Empty
Selected/default Hero asset failure uses fallback visual state and retry.
Do not silently remove Hero Hub.

## 14. Loading
Use skeleton/structured placeholder for normal pages.
Avoid full-screen spinner for local data that should load quickly.

## 15. Bootstrap Loading
Short branded loading state only while:
schema load
migration
critical player/settings hydration

Then route Home.

## 16. Saving
Buttons show saving state.
Prevent duplicate submit.
Do not block unrelated navigation longer than necessary.

## 17. Offline
Persistent small banner:
«آفلاین — اطلاعات روی دستگاه ذخیره می‌شود»

Do not show Offline as fatal error.

## 18. Online-Only Future Features
If future sync/cloud feature needs network:
show scoped unavailable state.
Core app remains usable.

## 19. Error Anatomy
Short title
human-readable reason
Retry action
safe fallback action where useful
technical details hidden under optional details

## 20. Retry
Retry must be idempotent.
Never duplicate Task, reward, purchase or ledger transaction.

## 21. Recoverable Error
Examples:
failed asset load
temporary storage read issue
notification scheduling failure
optional module catalog issue

## 22. Critical Corruption
If player/wallet schema invalid:
do not guess balances.
Use recovery workflow / backup restore / safe diagnostic.

## 23. Active Match Corruption
Quarantine invalid Match.
Route Home.
Keep committed ledger transactions.
Offer:
«Match قابل بازیابی نبود»

## 24. Migration Failure
Do not wipe.
Show:
«به‌روزرسانی اطلاعات کامل نشد»
Retry migration
Restore backup option

## 25. Permission Blocked
Notifications denied:
feature-specific message.
App continues normally.

## 26. Asset Failure
Hero/background/icon:
fallback placeholder frame designed in same visual language.
Production fallback is not emoji.

## 27. Image Loading
Reserve layout dimensions.
Avoid Home jumping when Hero/background loads.

## 28. Empty Search
«نتیجه‌ای پیدا نشد»
Clear filters/search.

## 29. Empty Match Task Pool
Block Match start safely.
CTA Tasks.
No fake Minion task.

## 30. Timer / Gameplay Error
If non-critical visual subsystem fails:
continue gameplay.
If deterministic Match state cannot be trusted:
pause and checkpoint before recovery.

## 31. Toasts
Success:
short and non-blocking.
Error:
actionable when needed.
Never use toast as only confirmation for destructive operation.

## 32. Network Retry
No aggressive polling.
Use explicit retry + lifecycle recheck.

## 33. Accessibility
State conveyed by text, not color only.
Skeleton respects Reduce Motion.
No flashing retry indicators.

## 34. RTL
All Persian messages RTL.
Technical IDs/details may remain LTR inside details area.

## 35. Mobile
States fit 360–430px.
Primary CTA reachable.
No illustration pushes CTA below unsafe area.

## 36. Visual Tone
Premium dark navy/gold/cyan.
Empty/error screens still feel like game UI, not generic web admin pages.

## 37. Prototype
Step36 concept switches among Ready, Empty, Loading, Offline, Recoverable Error and Corrupt Match states.

## 38. QA
No infinite loading
offline core usable
empty task pool blocks Match safely
retry idempotent
corrupt Match routes Home
migration failure never wipes data
fallback Hero not emoji
CTA safe on 360×800

## 39. Failure Conditions
white screen
fake data inserted to hide empty state
offline treated as fatal
duplicate submit on retry
corrupt wallet guessed
Match opens with zero tasks
error modal traps user

## 40. Quality Gate
For every failure or empty condition, user sees a clear state and a safe next action without losing committed data.

## STEP 37
AUDIO / HAPTICS / FEEDBACK SYSTEM
Battle audio layers, UI sounds, haptic patterns, settings, lifecycle behavior and Reduce Motion/Sound accessibility.
