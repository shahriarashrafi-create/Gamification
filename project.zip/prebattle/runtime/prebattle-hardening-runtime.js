function uid(prefix='id'){
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2,10)}`;
}

export function validateSettings(s){
  if(!s) return {ok:false,reason:'settings_missing'};
  if(s.matchMinutes<10 || s.matchMinutes>90) return {ok:false,reason:'match_minutes_invalid'};
  if(s.waveSeconds<10) return {ok:false,reason:'wave_seconds_invalid'};
  if(s.towerHP<=0 || s.baseHP<=0 || s.towerDamage<=0 || s.baseDamage<=0)
    return {ok:false,reason:'combat_values_invalid'};
  return {ok:true};
}

export function validateHero(hero){
  if(!hero?.id || !hero.owned || !hero.unlocked) return {ok:false,reason:'hero_invalid'};
  if(!hero.runtimeAssetSetId || !hero.battleCoreAssetReady) return {ok:false,reason:'hero_asset_missing'};
  return {ok:true};
}

export function snapshotTasks(tasks){
  const eligible=(tasks||[]).filter(t=>t.activeInGame && t.status==='active');
  if(!eligible.length) return {ok:false,reason:'no_eligible_tasks'};
  return {
    ok:true,
    tasks:eligible.map(t=>({
      taskId:t.id,title:t.title,category:t.category,difficulty:t.difficulty,
      xp:t.xp||0,gold:t.gold||0,diamond:t.diamond||0,
      repeatMode:t.repeatMode||'reusable',activeInGame:true
    }))
  };
}

export function validateMap(map){
  if(!map || map.worldWidth!==1200 || map.worldHeight!==2600) return {ok:false,reason:'map_invalid'};
  if(!Array.isArray(map.lanes) || map.lanes.length!==3) return {ok:false,reason:'lane_map_invalid'};
  return {ok:true};
}

export function buildMatchBootstrap({player,hero,tasks,settings,map,nowIso=new Date().toISOString()}){
  const sv=validateSettings(settings); if(!sv.ok) return sv;
  const hv=validateHero(hero); if(!hv.ok) return hv;
  const tv=snapshotTasks(tasks); if(!tv.ok) return tv;
  const mv=validateMap(map); if(!mv.ok) return mv;

  const id=uid('match');
  const bootstrapTxId=uid('bootstrap');

  const match={
    id,
    schemaVersion:77,
    bootstrapTxId,
    createdAt:nowIso,
    status:'ready',
    resultType:null,
    snapshots:{
      settings:{...settings},
      hero:{
        heroId:hero.id,
        runtimeAssetSetId:hero.runtimeAssetSetId,
        loadoutSnapshot:{...(hero.loadout||{})},
        visualVariant:hero.visualVariant||'default'
      },
      taskPool:tv.tasks,
      map:JSON.parse(JSON.stringify(map)),
      progressionRules:{...(player.progressionRules||{})}
    },
    objectiveState:{
      tower_a_1:'unlocked',tower_b_1:'unlocked',tower_c_1:'unlocked',
      tower_a_2:'locked',tower_b_2:'locked',tower_c_2:'locked',
      enemy_base:'shield_locked',completedLanes:0
    },
    worldState:{
      heroPosition:{...(map.heroSpawn||{x:50,y:89})},
      towers:{
        tower_a_1:settings.towerHP,tower_a_2:settings.towerHP,
        tower_b_1:settings.towerHP,tower_b_2:settings.towerHP,
        tower_c_1:settings.towerHP,tower_c_2:settings.towerHP
      },
      enemyBaseHP:settings.baseHP
    },
    timerState:{
      state:'ready',
      durationMs:settings.matchMinutes*60000,
      startedAt:null
    },
    waveState:{
      state:'ready',
      intervalMs:settings.waveSeconds*1000,
      lastWaveIndex:0
    },
    transactionState:{}
  };
  return {ok:true,match};
}

export async function persistBootstrapAtomically({match,store}){
  if(!match?.id) return {ok:false,reason:'match_missing'};
  await store.writeMatch(match);
  const verify=await store.readMatch(match.id);
  if(!verify || verify.id!==match.id || verify.bootstrapTxId!==match.bootstrapTxId){
    await store.quarantineMatch?.(match.id);
    return {ok:false,reason:'read_back_verification_failed'};
  }
  await store.setActiveMatchId(match.id);
  return {ok:true,matchId:match.id};
}

export function canRouteGameplay({match,activeMatchId}){
  return !!(
    match &&
    match.status==='ready' &&
    activeMatchId===match.id &&
    match.snapshots?.settings &&
    match.snapshots?.hero &&
    match.snapshots?.taskPool?.length &&
    match.snapshots?.map
  );
}
