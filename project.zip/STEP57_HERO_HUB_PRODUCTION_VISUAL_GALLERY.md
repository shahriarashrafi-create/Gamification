# STEP 57 — HERO HUB PRODUCTION VISUAL GALLERY

هدف این مرحله تبدیل Hero Hub به یک گالری Premium موبایلی با حس بازی‌های MOBA است.

## Composition
Top Bar
Selected Hero Stage
Horizontal Hero Gallery
Hero Identity
Loadout Slots
Primary Action

## Selected Hero Stage
Hero تمام‌قد.
سر و پا نباید Crop شوند.
Hero حدود 42–50% ارتفاع مفید Stage.
پس‌زمینه Armory/Citadel.
Gold key light + Cyan rim light.
Selected Hero frame طلایی.

## Hero Gallery
کارت‌های portrait.
حالت‌ها:
selected
owned
locked

Selected:
Gold frame + subtle cyan glow.

Owned:
Dark navy + gold accent.

Locked:
Dark desaturated presentation + lock ornament.
هیچ silhouette انسانی CSS در Production مجاز نیست.

## Identity
نام فارسی Hero
Descriptor فارسی
Ownership state
No combat stats.

## Loadout
outfit
accessory
aura
effect
background
frame
title

Slots compact.
Equipped item clearly visible.
Empty slot = هیچ‌کدام.

## Locked Flow
CTA:
رفتن به فروشگاه

## Owned Flow
CTA:
انتخاب

## Selected Flow
CTA:
انتخاب‌شده

## Responsive
360–430 CSS px
100dvh
Hero Stage shrinks before CTA disappears.
Primary action always reachable.
No app bottom navigation inside Hero Hub.

## Asset Contract
Hero final runtime:
transparent WebP
full body
consistent floor anchor
no baked UI text

Reference art may remain temporary until final transparent cuts are approved.

## Motion
Hero idle: subtle breathing only.
Selection: 220–360ms gold/cyan reveal.
Locked: no flashy animation.
Reduce Motion: fade only.

## Rules
Hero is visual identity only.
No damage/speed/XP/Gold multiplier.
No Energy.

## STEP 58
HERO ASSET RUNTIME RESOLUTION & FALLBACK
Hero asset registry، transparent runtime slot، preload، fallback و Home/Hub/Match asset resolution را یکپارچه می‌کنیم.
