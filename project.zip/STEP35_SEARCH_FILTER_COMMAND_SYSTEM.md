# SHAHRIAR GAME — STEP 35
## SEARCH / FILTER / COMMAND SYSTEM

مرجع رسمی جستجو، فیلتر و Quick Command در کل اپ.

## 1. Goal
کاربر باید بتواند خیلی سریع Task، عضو شبکه، Prospect، برنامه تایم‌شیت یا ماژول موردنظر را پیدا کند، بدون اینکه Home تبدیل به داشبورد شلوغ شود.

## 2. Entry
Global Search از یک کنترل کوچک در App Shell یا Search action داخل صفحات قابل دسترس است.
Home همچنان Lobby بازی باقی می‌ماند.

## 3. Search Scope
Tasks
Network Tree
Timesheet
Networking CRM
Events
Vision Goals
Achievements
Heroes
Secondary Modules

## 4. Stats Rule
Search در بخش آمار فقط Memberهای Network Tree را جستجو می‌کند.
هیچ KPI/Match Stats به Stats اضافه نمی‌شود.

## 5. Global Search
Global search returns grouped results.
Default groups:
کارها
افراد شبکه
CRM
تایم‌شیت
رویدادها
اهداف
دستاوردها
Hero / Modules

## 6. Search Normalization
trim
lowercase where relevant
normalize Persian/Arabic variants:
ي → ی
ك → ک
remove duplicate spaces
optional diacritic normalization

## 7. Persian Search
RTL input.
Persian-first labels.
Search should match normalized Persian text.

## 8. Matching
Initial production:
prefix + contains.
Future optional fuzzy matching.

## 9. Ranking
Exact title/name
Prefix
Contains
Recent usage
Relevant active state

## 10. Result Limit
Global preview:
max 5 results per group.
«نمایش همه» opens scoped result page.

## 11. Empty State
«نتیجه‌ای پیدا نشد»
Offer clear filter action, not fake recommendations.

## 12. Tasks Filters
category
difficulty
status
activeInGame
reward type
search text

## 13. Network Tree Filters
name
status
rank
parent/branch
active/growing/follow-up/inactive

## 14. Timesheet Filters
date
category
completed/pending
linked task
search text

## 15. CRM Filters
prospect status
action type
next follow-up date
consultant/referrer
search text

## 16. Events Filters
active/ended/upcoming
qualification state
search text

## 17. Vision Filters
year
category
status
priority
search text

## 18. Achievements Filters
period
state
metric type
priority

## 19. Hero Filters
owned/unowned
archetype
price range
selected

## 20. Filter Chips
Compact, horizontally scrollable if needed.
Active filter count visible.

## 21. Clear Filters
One clear action resets current scope filters only.

## 22. Saved Filters
Not required for first production.
Future feature.

## 23. Quick Commands
Search can expose safe navigation commands:
رفتن به کارها
رفتن به تایم‌شیت
رفتن به شبکه‌سازی
باز کردن فروشگاه
باز کردن رویدادها
باز کردن تنظیمات
شروع بازی

## 24. Command Safety
«شروع بازی» routes Pre-Battle.
Never bypass Match initialization.

## 25. No Destructive Commands
Global command palette does not expose delete/reset/purchase/claim actions in first production.

## 26. Result Tap
Task → Task detail/edit
Tree Member → focus member in tree
Timesheet → selected date/entry
CRM → prospect detail
Event → event detail
Vision → goal detail
Achievement → achievement detail
Hero → Hero Hub
Module → route module

## 27. Tree Focus
Search result can center/focus a Network Tree member.
No route away from Stats required when already there.

## 28. Search State
Query is transient by default.
Scoped page may preserve query until route changes.

## 29. Keyboard
Search input autofocus only after explicit Search open.
Do not pop keyboard automatically on Home launch.

## 30. Debounce
Local search debounce ~120–180ms.
No network request required.

## 31. Performance
Use indexed normalized fields where data grows.
Avoid rebuilding entire tree layout for each keystroke; filter/find then focus.

## 32. Highlight
Matched text can be highlighted.
Must preserve Persian readability.

## 33. Recent Searches
Optional local list max 5.
Can be cleared.
Do not sync externally.

## 34. Privacy
All search local in initial architecture.

## 35. Accessibility
Search clear button labelled.
Filter state not color-only.
Keyboard navigation where platform permits.
Touch target >=44dp.

## 36. Mobile
360–430px.
Search overlay/sheet uses full usable width.
Results single-column.
Keyboard safe viewport.

## 37. Prototype
Step35 concept demonstrates Persian normalization, grouped search, scoped filters and safe quick commands.

## 38. QA
Persian ی/ي matches
Persian ک/ك matches
filters combine correctly
clear filters works
Tree result focuses member
Start Game command goes Pre-Battle
no destructive command
no sixth nav item

## 39. Failure Conditions
Home becomes search dashboard
Stats gets non-tree analytics
Search opens Match directly
delete/reset exposed as quick command
keyboard opens on launch
filter state silently affects unrelated scope

## 40. Quality Gate
Search reduces navigation effort while preserving the game-lobby identity and all route guards.

## STEP 36
APP-WIDE EMPTY / LOADING / ERROR / OFFLINE STATES
Unified resilient states for every module, retry behavior, local-first offline UX and corruption-safe recovery messaging.
