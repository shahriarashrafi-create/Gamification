# GitHub Upload + APK Build — Step 99

فعلاً ZIP را داخل Repository به عنوان یک فایل واحد نگه ندار.

محتویات ZIP را Extract کن و فایل‌ها/پوشه‌های داخلش را در Root Repository آپلود کن.

بعد از Commit:

1. وارد تب Actions شو.
2. Workflow با نام `Build Android Debug APK` را باز کن.
3. `Run workflow` را بزن.
4. بعد از سبز شدن Build، پایین صفحه Artifact با نام `shahriar-game-debug-apk` را بگیر.
5. داخل Artifact فایل `app-debug.apk` قرار دارد.

اگر Build قرمز شد، Step99 طوری تنظیم شده که مرحله دقیق Failure مشخص باشد.
