# SHAHRIAR GAME — STEP 33
## BACKUP / EXPORT / IMPORT & SAFE RESET UX

مرجع رسمی تجربه کاربری Backup، Restore/Import و Reset امن.

## 1. Goal
کاربر باید بتواند داده‌های اپ را خارج کند، برگرداند و بخش‌های مشخصی را Reset کند بدون اینکه با یک لمس اشتباه اطلاعات مهم از بین برود.

## 2. Entry
Settings → Data & Backup

Sections:
Backup
Restore
Selective Reset
Full Reset

## 3. Manual Backup
Primary action:
«ساخت نسخه پشتیبان»

Creates:
shahriar_game_backup_<timestamp>.zip

## 4. Backup Package
Contains:
manifest.json
player.json
wallet.json
tasks.json
network_tree.json
timesheet.json
networking_crm.json
heroes.json
vision.json
events.json
achievements.json
match_history.json
transaction_ledger.json
settings.json

Active Match may be included only if checkpoint is valid.

## 5. Backup Manifest
backupVersion
schemaVersion
createdAt
appVersion
recordCounts
checksums

## 6. Export Safety
Backup is read-only output.
Creating backup must not mutate wallet/tasks/history.

## 7. Export Progress
Show real stage labels:
Preparing
Validating
Packaging
Done

Do not fake percentage if true byte progress unavailable.

## 8. Export Success
Show:
file name
created time
schema version
record count summary

Action:
Share / Save file

## 9. Restore Entry
«بازیابی از نسخه پشتیبان»

User selects ZIP/JSON package.

## 10. Restore Validation
Before any overwrite:
validate package structure
manifest
schema version
required files
checksums when present
duplicate IDs
enum values
numeric ranges
wallet nonnegative
ledger transaction uniqueness

## 11. Unsupported Future Schema
If backup schema > app-supported schema:
do not import.
Message:
«این نسخه پشتیبان با نسخه جدیدتری از برنامه ساخته شده است.»

## 12. Older Schema
If supported migration path exists:
migrate backup in temporary staging area before import.

## 13. Safety Backup Before Restore
Before replacing current data:
automatically create a local safety backup.

If safety backup fails:
do not proceed with destructive restore by default.

## 14. Import Mode
First production:
Replace All

Future:
Merge with conflict resolution.

## 15. Replace All Warning
Explicit copy:
«اطلاعات فعلی با نسخه پشتیبان جایگزین می‌شود. قبل از ادامه یک نسخه ایمنی ساخته خواهد شد.»

## 16. Confirmation
Two-step confirmation:
review backup summary
confirm replace

No accidental single-tap restore.

## 17. Restore Transaction
staging validation
safety backup
begin DB transaction
replace domain rows
rebuild indexes
validate critical rows
commit
reload app state

## 18. Restore Failure
Rollback.
Current data remains intact.
Show actionable reason.

## 19. Restore Success
Return Settings/Data.
Show:
«بازیابی با موفقیت انجام شد»
Then safely refresh global stores.

## 20. Active Match on Restore
If imported backup contains active Match:
fresh app UI still routes Home.
Offer recovery card only if valid.

## 21. Selective Reset
Options:
Gameplay History
Tasks
Network Tree
Timesheet
Networking CRM
Vision Goals
Events
Achievements Progress
Hero Inventory/Loadouts
Settings

Wallet reset should be separate/high-risk.

## 22. Reset Gameplay History
Deletes/archives match history and result summaries.
Must NOT remove wallet ledger transactions needed for accounting integrity.

## 23. Reset Tasks
Master Tasks reset/delete according to selected action.
Historical Match task snapshots remain.

## 24. Reset Network Tree
Requires explicit confirmation.
Root/default tree handling defined by business defaults.

## 25. Reset Wallet
High-risk.
Separate screen.
Displays current Gold/Diamond before change.

## 26. Wallet Reset Behavior
Restore configured default values only after explicit confirmation.
Write admin/reset ledger event if historical audit is retained.

## 27. Full Reset
Removes user-managed data and restores app defaults.

Requires:
confirmation screen
typed phrase or hold-to-confirm
final irreversible warning

## 28. Full Reset Phrase
Suggested:
RESET

Persian UX can display:
«برای تأیید RESET را وارد کن»

## 29. Backup Before Full Reset
Offer:
«قبل از Reset نسخه پشتیبان بساز»

Recommended default action.

## 30. Full Reset Exclusions
Do not delete app installation itself.
Do not touch unrelated phone files.

## 31. Recovery From Interrupted Reset
Reset should be transactional/marker-based.
On reboot, finish or rollback safely.

## 32. Data Deletion Semantics
Historical immutable ledger integrity may require archive/tombstone rather than physical delete.
User-facing reset can hide cleared history while preserving minimal audit rows if technically required.

## 33. Privacy
Backup exists locally until user chooses share/save destination.
No automatic cloud upload in this architecture.

## 34. Share
Use Android share sheet later.
No hardcoded external service dependency.

## 35. File Naming
Backup:
shahriar_game_backup_YYYYMMDD_HHmm.zip

Safety:
shahriar_game_safety_before_restore_YYYYMMDD_HHmm.zip

## 36. Accessibility
Destructive actions not color-only.
Clear labels:
ایمن
هشدار
غیرقابل بازگشت

## 37. Mobile Layout
Single-column Settings flow.
Danger Zone visually separated at bottom.
Buttons >=44dp.

## 38. Prototype
Step33 concept simulates Backup, Restore validation, selective reset and typed Full Reset confirmation.

## 39. Failure Conditions
restore without safety backup
single-tap full reset
wallet goes negative
future schema imported
history reset deletes accounting ledger incorrectly
backup creation mutates data
active Match auto-opens after restore

## 40. Quality Gate
No destructive data action occurs without clear scope, validation and an explicit confirmation path.

## STEP 34
NOTIFICATION / REMINDER / LOCAL SCHEDULING ARCHITECTURE
Task reminders, Timesheet alerts, event countdowns, recovery reminders and Android notification channels.
