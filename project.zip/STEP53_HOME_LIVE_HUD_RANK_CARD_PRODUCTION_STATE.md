# STEP 53 — HOME LIVE HUD & RANK CARD PRODUCTION STATE

در این مرحله HUD و Rank Card صفحه Home به Player State Store واقعی متصل می‌شوند.

## HUD Source
تنها منبع:
Committed Player State

Fields:
name
level
currentXP
xpRequired
gold
diamonds
selectedHeroId
rankId
rankScore

## Render States
loading
ready
refreshing
recoverable_error
corrupt_state

## Loading
Skeleton کوتاه.
هیچ مقدار جعلی مثل Gold=0 یا Diamond=0 نمایش داده نمی‌شود.

## Refresh
Home قبلی قابل مشاهده می‌ماند.
اطلاعات جدید به صورت atomic جایگزین می‌شود.

## Recoverable Error
آخرین snapshot معتبر حفظ می‌شود.
CTA:
تلاش دوباره

## Corrupt State
Wallet حدس زده نمی‌شود.
Start Game غیرفعال.
Recovery flow اجرا می‌شود.

## XP
percentage = currentXP / xpRequired
clamp 0–100
اگر Level Up قبلاً commit شده، Home فقط state جدید را نشان می‌دهد.

## Rank Card
rankId
rank label
rankScore / rankRPRequired

Tap:
Rank Detail Sheet
نه Stats.

## Wallet
Gold و Diamond فقط از ledger-derived Player State.
هیچ count-up در Home مقدار واقعی را تغییر نمی‌دهد.

## Hero
selectedHeroId از همان snapshot.
اگر Hero asset هنوز load نشده، layout space حفظ می‌شود.

## Start Game
فقط ready state.
در refreshing قابل استفاده است اگر snapshot قبلی معتبر باشد.
در corrupt_state غیرفعال.

## Reconciliation
startup:
read player
verify wallet ledger consistency
verify rank/level state
repair derived cache if safe
render

## Fresh Launch
Route = Home.
Loading HUD → Ready Home.

## Responsive
360–430.
HUD نباید Hero/CTA را هل دهد.
XP bar compact.
Rank Card compact.

## Rules
Bottom nav exactly five.
Stats Tree only.
No Energy.

## STEP 54
HOME MODULE CARDS LIVE ROUTING & STATE
چهار ماژول فروشگاه، رویدادها، آینده‌بینی و دستاوردها را به Route و State واقعی وصل می‌کنیم.
