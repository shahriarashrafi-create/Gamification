export function inspectActiveMatch({activeMatchId,matches}){
  if(!activeMatchId) return {state:'none'};
  const match=(matches||[]).find(m=>m.id===activeMatchId);
  if(!match) return {state:'stale_pointer',activeMatchId};
  if(match.resultType || match.finalizedAt) return {state:'finalized_pointer',match};
  if(match.corrupt) return {state:'corrupt_active',match};
  if(match.recoverable) return {state:'recoverable',match};
  if(match.active) return {state:'valid_active',match};
  return {state:'stale_pointer',match};
}

export function validateHomeStart({
  playerBound,
  heroValid,
  heroBattleAssetReady,
  eligibleTaskCount,
  activeState,
  starting
}){
  if(starting) return {ok:false,reason:'start_in_progress'};
  if(!playerBound) return {ok:false,reason:'player_not_bound'};
  if(!heroValid || !heroBattleAssetReady) return {ok:false,reason:'hero_invalid'};
  if((eligibleTaskCount||0)<=0) return {ok:false,reason:'no_eligible_tasks'};
  if(['valid_active','recoverable','corrupt_active'].includes(activeState)){
    return {ok:false,reason:'active_match_exists'};
  }
  return {ok:true};
}

export class HomeStartGuard {
  constructor(){ this.starting=false; this.lastRequestId=null; }

  request({requestId,context}){
    if(this.starting) return {ok:false,duplicate:true,reason:'start_in_progress'};
    if(!requestId || requestId===this.lastRequestId) return {ok:false,duplicate:true};
    this.starting=true;
    this.lastRequestId=requestId;
    return {
      ok:true,
      state:'validating',
      prebattleRequest:{
        requestedDuration:context.requestedDuration,
        selectedHeroId:context.selectedHeroId,
        eligibleTaskCount:context.eligibleTaskCount,
        startRequestId:requestId
      }
    };
  }

  release(){ this.starting=false; }
}

export function recoverableMatchCard(match){
  if(!match) return null;
  return {
    title:'بازی نیمه‌کاره',
    remainingMs:match.remainingMs,
    selectedHeroId:match.selectedHeroId,
    objective:match.lastKnownObjective,
    savedAt:match.savedAt,
    actions:['resume','safe_end']
  };
}

export function resumeValidation({match,heroAssetReady,timerValid,waveStateValid,entitiesValid}){
  if(!match || match.resultType) return {ok:false,reason:'match_not_resumable'};
  if(!heroAssetReady) return {ok:false,reason:'hero_asset_missing'};
  if(!timerValid) return {ok:false,reason:'timer_invalid'};
  if(!waveStateValid) return {ok:false,reason:'wave_state_invalid'};
  if(!entitiesValid) return {ok:false,reason:'entity_state_invalid'};
  return {ok:true,action:'reconcile_then_match'};
}

export function safeEndRecoverable(match){
  if(!match || match.resultType) return {ok:false,reason:'not_active'};
  return {
    ok:true,
    resultType:'manual_exit',
    preserveCommittedRewards:true,
    useFinalizationFlow:'step73'
  };
}

export function clearVerifiedStalePointer(activeState){
  if(!['stale_pointer','finalized_pointer'].includes(activeState)){
    return {ok:false,reason:'pointer_not_verified_stale'};
  }
  return {ok:true,activeMatchId:null};
}
