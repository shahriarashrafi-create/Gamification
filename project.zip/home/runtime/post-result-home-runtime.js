export function bindHomePlayerState(playerState){
  if(!playerState) return {ok:false,recoverable:true,reason:'player_state_missing'};
  const required=['level','xp','xpRequired','gold','diamonds','rankId','rankScore','selectedHeroId'];
  const missing=required.filter(k=>playerState[k]===undefined || playerState[k]===null);
  if(missing.length) return {ok:false,recoverable:true,reason:'player_state_incomplete',missing};
  return {
    ok:true,
    hud:{
      level:playerState.level,
      xp:playerState.xp,
      xpRequired:playerState.xpRequired,
      gold:playerState.gold,
      diamonds:playerState.diamonds
    },
    rank:{
      rankId:playerState.rankId,
      rankScore:playerState.rankScore,
      rankRPRequired:playerState.rankRPRequired||100
    },
    heroId:playerState.selectedHeroId
  };
}

export function buildCelebrationQueue({snapshot,playerBefore,playerAfter}){
  const q=[];
  if(playerBefore?.rankId && playerAfter?.rankId && playerBefore.rankId!==playerAfter.rankId){
    q.push({type:'rank_up',title:'رتبه جدید',value:playerAfter.rankId});
  }
  if((playerAfter?.level||0)>(playerBefore?.level||0)){
    q.push({type:'level_up',title:'سطح جدید',value:playerAfter.level});
  }
  if((snapshot?.diamondEarned||0)>0){
    q.push({type:'diamond_gain',title:'الماس جدید',value:snapshot.diamondEarned});
  }
  if(snapshot?.resultType==='victory'){
    q.push({type:'victory_return',title:'پیروزی ثبت شد'});
  }

  const priority={rank_up:0,level_up:1,diamond_gain:2,victory_return:3};
  q.sort((a,b)=>priority[a.type]-priority[b.type]);

  if(q.length<=2) return q;
  return [
    q[0],
    {
      type:'combined',
      title:'پیشرفت جدید',
      items:q.slice(1)
    }
  ];
}

export function postResultHomeTransition({match,resultSnapshot,playerState}){
  if(!match?.id || !match?.resultType) return {ok:false,reason:'finalized_match_missing'};
  return {
    ok:true,
    systemUI:'normal',
    activeMatchId:null,
    finalizedMatchId:match.id,
    refreshPlayerState:true,
    recalculateRewards:false,
    markResultsSeen:true,
    route:'home',
    snapshot:resultSnapshot,
    playerState
  };
}

export function canStartGame({playerBound,activeMatchId,eligibleTaskCount,heroValid}){
  if(!playerBound) return {ok:false,reason:'player_not_bound'};
  if(activeMatchId) return {ok:false,reason:'active_match_exists'};
  if((eligibleTaskCount||0)<=0) return {ok:false,reason:'no_eligible_tasks'};
  if(!heroValid) return {ok:false,reason:'hero_invalid'};
  return {ok:true,route:'prebattle'};
}
