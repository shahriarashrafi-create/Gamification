# SHAHRIAR GAME — 100 STEP REBUILD
## STEP 03 — GAME WORLD & MAP ARCHITECTURE

این سند مرجع رسمی نقشه و فضای Gameplay است.
از این مرحله به بعد هر طراحی Battlefield، Camera، Minimap و Entity Placement باید با این معماری سازگار باشد.

---

# 1. هدف نقشه

نقشه باید حس MOBA بدهد، اما برای هدف اصلی بازی یعنی انجام کار واقعی، بیش از حد پیچیده نشود.

اصل طراحی:

- قابل فهم در ۳ ثانیه
- Portrait-first
- سه مسیر مشخص
- فضای کافی برای حرکت آزاد Hero
- بدون Teleport
- Camera Follow واقعی
- امکان Backtrack
- امکان Lane Switch
- خوانایی بالا روی گوشی
- فضای کافی برای Minion / Tower / Fog / Effects

---

# 2. World Coordinate System

برای منطق بازی، کل Map با Coordinate نرمال‌شده ذخیره می‌شود:

X = 0 تا 100
Y = 0 تا 100

تعریف جهت:

- Y = 100 پایین نقشه / Own Base
- Y = 0 بالای نقشه / Enemy Base
- X = 0 لبه چپ
- X = 100 لبه راست

این مدل باعث می‌شود:
- Map روی گوشی‌های مختلف Scaling شود
- Minimap ساده بماند
- Collision مستقل از Pixel باشد
- Camera calculations قابل کنترل باشد

---

# 3. Virtual World Size

Reference World:

- Width: 1200 units
- Height: 2600 units
- Ratio: تقریباً 1 : 2.17

Viewport:
- Portrait
- نسبت هدف: 9:19.5 تا 9:21
- Camera فقط بخشی از World را نشان می‌دهد
- Map زیر Camera حرکت می‌کند

Hero نباید روی یک Map ثابت کوچک حرکت کند.
World باید واقعاً از Viewport بلندتر باشد.

---

# 4. Camera Philosophy

Camera رفتار حرفه‌ای دارد:

Hero Position Target:
- حدود 60% تا 66% ارتفاع صفحه
- حدود 50% عرض صفحه

Dead Zone:
- Hero می‌تواند کمی داخل Dead Zone حرکت کند
- Camera برای حرکت‌های خیلی کوچک نباید بلرزد

Camera Follow:
- Smooth interpolation
- Lag بسیار کم
- Ease نرم
- Clamp به مرزهای World

Camera ممنوع:
- Snap
- Teleport
- Jump هنگام Encounter
- تغییر ناگهانی Zoom

---

# 5. Three Lane Structure

سه Lane از Own Base به Enemy Base می‌روند.

## Lane A — Strategic Lane
مسیر چپ نقشه

ویژگی:
- فضای بیشتر برای Minion Wave
- مناسب Taskهای معمولی / تکرارشونده

## Lane B — Main Lane
مسیر وسط

ویژگی:
- کوتاه‌ترین مسیر
- خواناترین مسیر
- مناسب Objective اصلی Match

## Lane C — Growth Lane
مسیر راست

ویژگی:
- فضای بیشتر برای Lane Switch
- مناسب Taskهای مهم‌تر / Networking-linked در آینده

نام‌های نمایش نهایی می‌توانند بعداً فارسی شوند.
در Logic از IDs ثابت استفاده می‌شود:
`lane_a`, `lane_b`, `lane_c`

---

# 6. Lane Geometry

Laneها کاملاً خط صاف نیستند.

برای طبیعی‌تر شدن:
- Slight curve
- Connector paths
- Crossroads
- Visual widening نزدیک Towerها

Center Path X positions تقریبی:

Lane A:
28%

Lane B:
50%

Lane C:
72%

Curve Offset:
حداکثر ±6%

---

# 7. Lane Connections

سه Crossroad اصلی:

## Lower Crossroad
Y ≈ 73

هدف:
بازیکن بعد از Wave اول بتواند Lane عوض کند.

## Mid Crossroad
Y ≈ 51

هدف:
بعد از Tower 1 آزادی واقعی مسیر ایجاد شود.

## Upper Crossroad
Y ≈ 29

هدف:
قبل از Tower 2 / Final Push تغییر Lane ممکن باشد.

Crossroadها باید:
- Visual واضح
- Collision آزاد
- بدون Invisible Wall

---

# 8. Own Base

Position:
X = 50
Y = 93

Base Zone:
Radius ≈ 9%

Hero Spawn:
X = 50
Y = 89

Own Base Visual:
- Command Crystal
- Healing / safe aura فقط بصری در نسخه اولیه
- Hero spawn platform
- Friendly light
- Blue/Cyan identity

Own Base نباید در Match به Player Damage سیستم تبدیل شود.
فعلاً نقش:
Spawn + Orientation + Recall Point آینده

---

# 9. Enemy Base

Position:
X = 50
Y = 7

Base Core Radius:
≈ 8%

Unlock:
وقتی مسیر نهایی موردنیاز باز شده باشد.

Final Objective:
4 Task/Hit پیش‌فرض

Visual:
- Dark Crimson
- Unstable energy
- Multiple crack states
- Final collapse
- Victory cinematic

---

# 10. Tower Placement

هر Lane دو Tower دارد.

## Tower 1
Y ≈ 59–63

Lane A:
X ≈ 27
Y ≈ 62

Lane B:
X ≈ 50
Y ≈ 59

Lane C:
X ≈ 73
Y ≈ 62

## Tower 2
Y ≈ 24–30

Lane A:
X ≈ 31
Y ≈ 28

Lane B:
X ≈ 50
Y ≈ 24

Lane C:
X ≈ 69
Y ≈ 28

Tower Range:
- Visual radius ≈ 10–13%
- Encounter radius کمتر از Range visual

---

# 11. Minion Wave Anchors

هر Lane چند Anchor دارد.

Lower Wave:
Y ≈ 78

Mid Wave:
Y ≈ 48

Upper Wave:
Y ≈ 18

هر Wave:
- 2 تا 4 Minion نمایشی
- ولی فقط تعداد لازم Objective فعال شود
- Crowd نباید صفحه را شلوغ کند

Minionها:
- Bob / Walk animation
- Slight forward movement
- Lane-bound
- به Hero Teleport نمی‌شوند

---

# 12. Objective Density

قاعده:
در هر Viewport معمولاً بیشتر از:

- 1 Objective اصلی
- 2 Objective ثانویه
- 1 Tower prominent

نمایش داده نشود.

هدف:
کاربر بداند «الان باید چه کار کند».

---

# 13. Collision Model

Collision ساده اما واقعی:

Hero Collision Circle:
≈ 2.3% World Width

Minion Collision:
≈ 2%

Tower Collision:
≈ 4.5%

Base Core Collision:
≈ 6%

Environment Collision:
- Rock
- Wall
- Tower body
- Base structure

No Collision:
- Grass
- Fog
- Light
- Decorative rune
- Lane paint

---

# 14. Walkable Areas

Walkable:
- Lane surface
- Crossroad
- Base platform
- Lane shoulder محدود

Restricted:
- خارج Map
- پشت Cliff
- داخل Tower body
- داخل Base structure

هدف:
Hero آزادی داشته باشد ولی از نقشه خارج نشود.

---

# 15. Hero Pathing

نسخه اولیه:
Manual joystick control

Path Rules:
- Hero آزادانه حرکت می‌کند
- Auto-path فقط در آینده و محدود
- Encounter با proximity
- هیچ Auto-run اجباری به Objective نداریم

Joystick:
- Lower-left
- Safe from Android gesture area
- Dynamic or semi-fixed قابل بررسی در UX Step

---

# 16. Camera Dead Zone

Reference:

Horizontal:
±8% viewport width

Vertical:
±6% viewport height

وقتی Hero داخل Dead Zone است:
Camera ثابت می‌ماند.

وقتی خارج شود:
Camera smooth follow

---

# 17. Camera Look Ahead

برای حرفه‌ای‌تر شدن:

اگر Hero رو به بالا حرکت کند:
Camera کمی به بالا Look Ahead می‌دهد.

اگر Hero رو به پایین حرکت کند:
Look Ahead کمتر.

هدف:
Objective بعدی زودتر دیده شود.

مقدار اولیه:
4–7% viewport height

---

# 18. Encounter Camera

هنگام Encounter:

Camera Position:
Freeze نرم روی Hero + Target midpoint

Zoom:
حداکثر 3–5% در نسخه اولیه

Battlefield:
- Darken
- Soft blur
- No hard cut

پس از Complete/Cancel:
Camera smoothly returns.

---

# 19. Tower Camera Behavior

نزدیک Tower:

- Tower باید وارد upper-middle viewport شود
- Hero پایین‌تر بماند
- Tower range visible
- Objective HUD concise

Camera نباید Tower را Crop کند.

---

# 20. Minimap

Position:
Upper-left یا Upper-right بر اساس HUD نهایی

Minimap Content:
- Hero
- Own Base
- Enemy Base
- Tower 1 / Tower 2
- Alive waves
- Lane paths
- Destroyed state

Minimap نباید:
- متن زیاد
- جزئیات تزئینی
- Task names

داشته باشد.

---

# 21. Minimap Coordinate Rule

همان Coordinate اصلی World استفاده می‌شود.

World:
X 0–100
Y 0–100

Minimap:
normalized transform

Example:
mapX = worldX %
mapY = worldY %

این باعث می‌شود Minimap و Main Map هیچ‌وقت از Sync خارج نشوند.

---

# 22. Fog & Vision

Fog در نسخه اول:
Visual / readability system

نه سیستم پیچیده competitive vision.

Fog:
- Edge vignette
- Environmental mist
- Target reveal around Hero
- Tower/Objective glow وقتی نزدیک شود

هدف:
Depth و حس زنده بودن Map

---

# 23. Environment Layers

Layer 0:
Far background

Layer 1:
Ground

Layer 2:
Lane markings / river-like glow

Layer 3:
Decorative rocks / vegetation

Layer 4:
Entities

Layer 5:
Hero

Layer 6:
Particles / projectiles

Layer 7:
HUD-world indicators

Layer 8:
Encounter cinematic overlay

---

# 24. Visual Biomes

برای جلوگیری از یکنواختی:

Lower Zone:
Friendly Citadel
- Cyan
- Clean stone
- Calm particles

Middle Zone:
Contested Grounds
- Deep navy
- Mist
- Broken structures

Upper Zone:
Enemy Dominion
- Crimson accents
- Dark stone
- Stronger particles

Transition تدریجی باشد، نه سه صفحه جدا.

---

# 25. Map Progression Readability

بازیکن بدون Minimap هم باید بفهمد چقدر پیش رفته.

نشانه‌ها:
- تغییر رنگ محیط
- Tower silhouettes
- Enemy glow قوی‌تر
- Own Base دورتر
- sky / architecture shift

---

# 26. Lane Choice Readability

در Crossroad:

- هر Lane یک subtle identity دارد
- Path highlight بسیار کم
- Objective icon روی HUD
- Minimap واضح

ممنوع:
سه فلش بزرگ Arcade که UI را شلوغ کند.

---

# 27. Safe Zones for Mobile UI

Top:
HUD safe area

Bottom-left:
Joystick

Bottom-right:
Action buttons

Center-bottom:
Hero visual space

Center:
Gameplay readability

No important world target should دائماً زیر HUD یا joystick قرار بگیرد.

---

# 28. Modern Phone Aspect Ratios

Target:
- 19.5:9
- 20:9
- 21:9

Fallback:
- 18:9

Rules:
- World height مستقل
- Camera viewport responsive
- HUD anchored to safe areas
- Gameplay fullscreen
- No clipped Start / Objective UI

---

# 29. Entity IDs

Own Base:
`base_own`

Enemy Base:
`base_enemy`

Tower examples:
`tower_a_1`
`tower_a_2`
`tower_b_1`
`tower_b_2`
`tower_c_1`
`tower_c_2`

Wave examples:
`wave_a_lower`
`wave_a_mid`
`wave_a_upper`

این IDs در تمام Steps بعدی ثابت می‌مانند.

---

# 30. Map State

هر Entity:

- id
- type
- lane
- x
- y
- radius
- hp
- maxHp
- alive
- unlocked
- visualState

Map Progress:
- destroyed towers
- defeated waves
- active encounter
- hero position
- camera position

---

# 31. Performance Rules

برای گوشی:

- Transform-based movement
- Avoid layout thrashing
- Reuse particles
- Keep world DOM limited
- No hundreds of minions
- Minimap lightweight
- CSS/Canvas/WebGL decision later

هدف:
60fps حس‌شده روی گوشی‌های جدید

---

# 32. STEP 03 LOCKED MAP

World:
1200 × 2600 reference units

Coordinate:
0–100 normalized

Own Base:
(50, 93)

Hero Spawn:
(50, 89)

Enemy Base:
(50, 7)

Lane Centers:
A ≈ 28
B ≈ 50
C ≈ 72

Crossroads:
Y ≈ 73 / 51 / 29

Tower 1:
Y ≈ 59–62

Tower 2:
Y ≈ 24–28

Waves:
Y ≈ 78 / 48 / 18

Gameplay:
Portrait + Camera Follow + Backtrack + Lane Switch + no teleport

---

# STEP 04

PLAYER / HERO CONTROL ARCHITECTURE

در قدم ۴ طراحی می‌شود:

- Joystick physics
- acceleration/deceleration
- input smoothing
- facing
- walk/run transitions
- collision response
- camera coupling
- encounter lock behavior
- hero animation state machine
