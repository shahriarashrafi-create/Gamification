# STEP 72 — MATCH TIMER + WAVE SCHEDULER FULL RUNTIME INTEGRATION

این مرحله زمان واقعی Match و Wave Scheduler را در یک runtime واحد می‌بندد.

## Defaults

Match:
30 minutes

Wave:
every 45 seconds

هر دو از Settings snapshot ابتدای Match خوانده می‌شوند.

تغییر Settings وسط Match روی Match جاری اثر ندارد.

## Time Authority

Timer بر اساس timestamp کار می‌کند، نه شمارش ساده frame.

Authoritative fields:

startedAt
durationMs
pausedAccumulatedMs
pauseStartedAt
finalizedAt

remainingMs =
durationMs - effectiveElapsedMs

این باعث می‌شود:
background
frame drop
process delay
timer drift
باعث زمان اشتباه نشوند.

## Match Timer States

idle
running
paused
ending
ended

## Wave Scheduler States

idle
running
paused
stopped
completed

## Wave Schedule

Default:
45 seconds

Wave index:
1, 2, 3...

nextWaveAt بر اساس Match elapsed time محاسبه می‌شود.

Scheduler نباید با setInterval انباشته‌شونده به‌عنوان authority کار کند.

## Pause

وقتی Pause واقعی Match فعال است:

Timer freezes
Wave scheduler freezes
Hero movement freezes
Minion movement freezes
new Encounter blocked

Resume:
pause duration به pausedAccumulatedMs اضافه می‌شود.

## Task Encounter

طبق تنظیم پیش‌فرض پروژه:
timerRunsDuringTask = true

بنابراین Task Encounter به‌تنهایی Timer را Pause نمی‌کند.

Wave spawn هنگام Task sheet:
می‌تواند schedule شود،
ولی spawn presentation تا safe gameplay state defer شود.

## Background

اگر اپ به Background رفت:

Match state persist می‌شود.

Policy default:
timer continues in background unless explicit pause was active.

در Resume:
remaining time از timestamp دوباره محاسبه می‌شود.

Wave scheduler:
missed waves را به‌صورت burst تولید نمی‌کند.

فقط reconcile می‌کند و با spawn cap فعلی ادامه می‌دهد.

## Missed Wave Reconciliation

اگر چند Wave در Background از دست رفت:

do not spawn all missed waves at once.

Calculate latest eligible wave index.

Then:
respect global Minion cap = 6
respect lane cap = 2
reserve valid Tasks before spawn

## Time End

وقتی remainingMs <= 0:

TIME_END_REQUEST
→ block new encounters
→ stop scheduler
→ lock new objective transactions
→ resolve any already committed transaction
→ finalize resultType = time_end
→ preserve all committed rewards
→ no Victory bonus
→ create result snapshot
→ route Results

Time End:
شکست محسوب نمی‌شود.

## Race: Victory vs Time End

Authoritative rule:

اگر Base HP صفر و Base destruction transaction قبل از Time End authority commit شده باشد:
Victory.

اگر زمان تمام شده و Time End lock قبل از Base damage commit گرفته شده باشد:
Time End.

هیچ دو Result همزمان مجاز نیست.

Result finalization uses a single finalization lock.

## Already Committed Task

اگر Task completion قبل از Time End commit شده:

pipeline اجازه دارد transaction وابسته را safely finish کند.

اگر همان transaction Base را به HP صفر رساند:
Victory می‌تواند نتیجه نهایی باشد.

## Wave Stop

Scheduler stops permanently on:

Victory commit
Time End finalization
Manual Exit finalization

Pause فقط scheduler را freeze می‌کند.

## Persistence

Persist:
timer timestamps
pause state
wave index
nextWaveAt
scheduler state
finalization lock

## Recovery

Process death:
fresh app launch still opens Home.

اگر active Match معتبر وجود دارد:
Home recoverable Match card نمایش می‌دهد.

ورود خودکار به Match ممنوع.

Resume Match:
Timer/Wave state reconcile می‌شود.

## Formatting

HUD:
MM:SS

Under 60 seconds:
warning presentation

Under 15 seconds:
critical presentation

Warning visual does not mutate Timer.

## QA

30 minute default
45 second default Wave
Settings snapshot immutable during Match
timestamp-based timer
Pause freezes Timer/Waves
Task sheet does not Pause Timer by default
Background does not create timer drift
missed waves never burst-spawn
spawn caps preserved
Time End neutral
Time End preserves committed rewards
Time End gives no Victory bonus
single result finalization lock
Victory/Time End race deterministic
scheduler stops on final result
process recovery does not auto-enter Match
no Energy

## STEP 73

TIME END + MANUAL EXIT RESULT FLOW

Time End ceremony، Manual Exit confirmation، reward preservation و Results routing را production flow می‌کنیم.
