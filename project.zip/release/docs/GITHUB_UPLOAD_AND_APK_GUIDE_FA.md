# راهنمای نهایی GitHub و APK

ZIP را Extract کن و همه فایل‌های داخل پوشه را مستقیماً در Root ریپازیتوری جدید GitHub آپلود کن.

بعد از Commit:
Actions → Android Debug APK → Run workflow

وقتی Build سبز شد:
Workflow Run → Artifacts → shahriar-game-debug-apk

Artifact را دانلود کن، ZIP Artifact را باز کن و `app-debug.apk` را روی گوشی نصب کن.

اگر Build قرمز شد، وارد همان Run شو و متن اولین Step قرمز را کپی کن. خطا معمولاً در `npm ci`، `npm run build`، `npx cap sync android` یا `./gradlew assembleDebug` مشخص می‌شود.

هیچ Keystore، Password یا Signing Secret خصوصی را در Repository عمومی Commit نکن.
