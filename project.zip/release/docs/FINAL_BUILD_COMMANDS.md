# FINAL BUILD COMMANDS

node scripts/verify-final-release.mjs
npm ci
npm run build
npx cap sync android
cd android
./gradlew assembleDebug

Expected APK:
android/app/build/outputs/apk/debug/app-debug.apk
