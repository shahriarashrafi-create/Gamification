# STEP 45 — BATTLEFIELD ENTITY ART & STATES

این مرحله زبان تصویری اختصاصی Entityهای میدان را قفل می‌کند.

## Minion
Actionable Minion نماینده یک Task واقعی است.
خانواده بصری: melee / ranged / siege.
نسخه نهایی بازی می‌تواند یک خانواده اصلی را انتخاب کند؛ این Step Art Direction و State Contract را تعریف می‌کند.

States:
idle
walk
focused
hit
defeated

Minion نباید Player Combat Stat یا Loot تصادفی ایجاد کند.

## Tower
States:
healthy 67–100
damaged 34–66
critical 1–33
destroyed 0

Tower1 و Tower2 از یک خانواده بصری هستند ولی Tier/ornament می‌تواند تفاوت ظریف داشته باشد.
Enemy Tower با نور/Crystal قرمز-گرم قابل تشخیص است.
Destroyed باید collision را پس از commit باز کند.

## Base
Enemy Base:
stable 76–100
unstable 51–75
critical 26–50
collapse_ready 1–25
destroyed 0

Own Base visual identity آبی/Cyan و Enemy Base قرمز/گرم است.
Enemy Base destruction تنها مرجع Victory است.

## Objective Marker
انواع:
tower
base
minion_task
current_objective
locked_objective
completed_objective

Current Objective: Gold/Cyan.
Locked: muted.
Completed: low-emphasis/removed based on context.

## Minimap
Hero / Tower / Base / Task Objective markerها باید کوچک و خوانا باشند.
Minimap display-only است؛ Teleport ممنوع.

## Runtime Asset Contract
Artboard تولیدشده داخل:
assets/production/battlefield/reference/

قرار گرفته است.
Cropها Reference هستند و Final transparent cutout محسوب نمی‌شوند.

Final Runtime Entity باید:
transparent WebP
بدون متن bake‌شده
pivot metadata
collision radius
interaction anchor
health-bar anchor
projectile-hit anchor
داشته باشد.

## State Transition
HP commit authoritative است.
Visual state فقط از HP committed خوانده می‌شود.
Visual animation نمی‌تواند HP را تعیین کند.

## Reward
Reward فقط بعد از Task transaction commit و damage commit.
Destroyed bonus فقط یک بار.

## Accessibility
State فقط با رنگ بیان نشود؛ silhouette/crack/smoke/HP label نیز تغییر کند.
Reduce Motion: collapse ساده‌تر، بدون shake شدید.

## Rules
No Energy.
No Mana.
No Hero power advantage.
No random Diamond.
No tap-to-teleport.

## QA Gate
هیچ Entity هندسی ساده Step44 نباید در Production نهایی باقی بماند.
Artboard فعلی مسیر تصویری رسمی است و مرحله‌های بعد آن را به transparent runtime assets تبدیل می‌کنند.

## STEP 46
ENTITY RUNTIME CUTOUT & BATTLEFIELD INTEGRATION
ساخت Runtime Asset slotها و جایگزینی Entityهای هندسی میدان با Minion/Tower/Base asset render layers و state switching واقعی.
