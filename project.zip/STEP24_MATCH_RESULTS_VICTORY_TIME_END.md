# SHAHRIAR GAME — STEP 24
## MATCH RESULTS / VICTORY & TIME-END EXPERIENCE

مرجع رسمی صفحه نتیجه Match.

## 1. Result Types
victory
time_end
manual_exit

## 2. Victory
Enemy Base destroyed.
Cinematic victory transition → Results.
No extra penalty.
Victory bonus applies once.

## 3. Time End
Timer reaches zero.
Current committed transaction finishes.
Then Results.
All earned rewards preserved.
No punishment or currency loss.

## 4. Manual Exit
User-confirmed exit.
Keep already committed rewards.
No victory bonus.
Future rule may track incomplete match separately.

## 5. Results Hierarchy
1 Result title
2 Match duration
3 Total real-world Tasks completed
4 Objectives destroyed
5 Earned XP / Gold / Diamond
6 Level progression
7 Rank progression
8 Task summary
9 CTA: Home
10 Optional CTA: New Match

## 6. Victory Header
VICTORY
Enemy Base Destroyed
Gold/cyan cinematic treatment.

## 7. Time End Header
TIME END
Progress Saved
Neutral/premium treatment, not failure/red defeat.

## 8. Manual Exit Header
MATCH ENDED
Progress Saved

## 9. Match Summary
completedTasks
minionsDefeated
towersDestroyed
enemyBaseDestroyed
matchDuration
lanesVisited

## 10. Reward Summary
taskXP
taskGold
taskDiamond
objectiveXP
objectiveGold
objectiveDiamond
matchBonus
victoryBonus
totals

## 11. XP
Animate old XP → new XP.
Multiple level-ups supported.
Never fake level-up.

## 12. Level Up
If XP crosses threshold:
Level badge flare
new Level
overflow XP continues into next bar.

## 13. Multiple Levels
Sequence can compress:
Level 28 → 29 → 30
Final XP shown accurately.

## 14. Rank
Rank Points animate separately from XP.
No demotion in current default rules.

## 15. Rank Up
If RP crosses threshold:
Rank badge promotion.
Overflow RP retained.

## 16. Rewards
Gold wallet updates.
Diamond only shown as earned if >0.
No celebratory Diamond if total Diamond = 0.

## 17. Victory Bonus Defaults
+400 XP
+150 Gold
+1 Diamond

## 18. Match Completion Bonus Defaults
+80 XP
+20 Gold

## 19. Tower Bonus
Tower1 destruction +150 XP / +60 Gold
Tower2 destruction +220 XP / +90 Gold
As defined in economy configuration.

## 20. Task Summary
List completed real-world tasks.
Each row:
title
category
XP
Gold
Diamond if >0

## 21. Deferred Tasks
Optional collapsed section.
Not counted completed.
No reward.

## 22. Cancelled Current
Not shown by default in success summary.
Can appear under Match Log if future needed.

## 23. Objectives
Compact battlefield strip:
Lane A
Lane B
Lane C
Tower states + Base state

No giant dashboard.

## 24. Results Motion
Header reveal
summary count-up
reward cards
XP/Rank bars
Level/Rank promotion
CTA reveal

## 25. Motion Timing
header 300–500ms
summary 250ms
rewards 350ms
xp tween 600–900ms
rank tween 500–700ms
CTA after ~900ms
Reduced Motion: immediate/fade.

## 26. Interaction Lock
During reward calculation:
CTAs disabled.
After persisted result:
CTAs enabled.

## 27. Persistence
Result generated from finalized MatchTransaction.
Result screen does not independently recalculate rewards.

## 28. Idempotency
Victory bonus and match completion bonus stored with unique transaction ids.
Reload cannot duplicate rewards.

## 29. Home CTA
Exit immersive mode.
Restore Android system bars.
Navigate Home.

## 30. New Match CTA
Optional.
Returns to Home first or launches a clean initialized Match depending final UX.
Default recommendation: Home first.

## 31. Home Launch Rule
Fresh app launch remains Home regardless of last Results page.

## 32. Back Button
Android back on Results should navigate Home, not reopen destroyed battlefield state.

## 33. Share
Future optional share card.
Not part of core Step24.

## 34. Match History
Future data source may store result snapshots.
Stats page still remains Network Tree only.

## 35. Accessibility
No essential reward info by animation alone.
Readable static final values.
Reduced Motion supported.

## 36. Mobile
360–430 portrait.
Scrollable content if task list long.
Primary CTA sticky/safe above bottom gesture inset.

## 37. Bottom Navigation
Not shown inside Results.
Home CTA returns to normal app shell with canonical nav.

## 38. Failure Conditions
duplicate rewards
Victory bonus on Time End
lost earned rewards
Diamond celebration at zero
Results recalculates reward differently than transaction
Back reopens stale Match
CTA under gesture bar
Stats dashboard introduced

## 39. Prototype
Step24 concept switches between Victory / Time End / Manual Exit and animates XP, Rank and reward summary.

## 40. Quality Gate
Results must feel rewarding while remaining an accurate receipt of real-world actions completed during the Match.

## STEP 25
MATCH INITIALIZATION / PRE-BATTLE EXPERIENCE
Pre-match setup, task pool snapshot, lane/entity initialization, timer settings snapshot, selected Hero, encounter queue and Start transition.
