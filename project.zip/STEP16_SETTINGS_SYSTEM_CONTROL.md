# SHAHRIAR GAME — 100 STEP REBUILD
## STEP 16 — SETTINGS / SYSTEM CONTROL

این سند مرجع رسمی «تنظیمات / مرکز کنترل سیستم» است.

## 1. هویت
Settings باید مثل System Control یک بازی حرفه‌ای باشد، نه صفحه تنظیمات عمومی اندروید.
همه پارامترهای مهم قابل ویرایش، ولی با Default امن و Reset مستقل هر بخش.

## 2. Entry
از آیکن Settings در Home HUD باز می‌شود؛ Bottom Nav مستقل ندارد.

## 3. بخش‌ها
- پروفایل بازیکن
- Gameplay
- Economy & Rewards
- XP / Level
- Rank
- Tasks
- Hero & Customization
- Accessibility / Motion
- Data / Reset

## 4. Player Profile
- playerName
- level
- currentXP
- gold
- diamonds
- selectedHeroId
Avatar/Hero از Hero Hub مدیریت می‌شود.

## 5. Gameplay
- matchMinutes (default 30)
- waveSeconds (45)
- towerHP (100)
- baseHP (100)
- towerDamagePerTask (34)
- baseDamagePerTask (25)
- timerRunsDuringTask (true)
- immersiveGameplay (true)

NO ENERGY FIELD.

## 6. Match Duration
Default = 30 دقیقه.
Editable با بازه پیشنهادی 10–90 دقیقه.
CTA Home باید مقدار فعلی را نمایش دهد.

## 7. Economy
- entity multipliers
- tower/base bonuses
- match completion bonus
- hero/cosmetic prices
- real reward Diamond costs

Gold و Diamond هرگز با هم یکی نمی‌شوند.

## 8. XP Curve
- baseXPRequired = 1000
- growthPercent = 16
- multipleLevelUps = true

## 9. Rank
نام Rankها، RP required و reward milestones قابل ویرایش.
Default ladder همان 15 رتبه Step 06 است.
Level و Rank مستقل‌اند.

## 10. Tasks
- categories editable
- difficulty labels editable
- reward defaults editable
- gameplay active rules editable

## 11. Hero
Settings فقط Shortcut به Hero Hub دارد.
Hero قدرت خریدنی نمی‌دهد.
Cosmetic / Hero unlock با Gold.

## 12. Accessibility
- reduceMotion
- joystick size
- joystick opacity
- leftHandMode
- camera sensitivity
این تنظیمات نباید منطق Reward را تغییر دهند.

## 13. Immersive
فقط داخل Match:
status/navigation bars hide.
خارج Match:
normal system UI.

## 14. Validation
هیچ مقدار منفی برای HP، Reward، Currency یا زمان مجاز نیست.
matchMinutes حداقل 10.
waveSeconds حداقل 10.
growthPercent بازه پیشنهادی 0–100.

## 15. Reset
سه سطح:
- Reset section
- Reset gameplay/economy defaults
- Full app data reset

Full Reset باید تأیید دو مرحله‌ای داشته باشد.
Prototype Step16 فقط Reset Section را شبیه‌سازی می‌کند.

## 16. Persistence
Settings باید persistent باشد.
Schema version داشته باشد تا Migration ممکن باشد.

## 17. Live Preview
تغییر matchMinutes فوراً در Preview CTA دیده شود.
تغییر playerName/HUD values فوراً در Preview دیده شود.

## 18. Save
Draft edits → Validate → Save → persist → UI refresh.
Auto-save برای فیلدهای حساس اقتصادی فعلاً توصیه نمی‌شود.

## 19. Visual
Dark navy / black، gold/cyan controls، segmented tabs، compact tactical forms.
روی 360px تک‌ستونه و بدون horizontal overflow.

## 20. Quality Gate
PASS اگر:
- Player/Game/Economy/Rank/Tasks/Accessibility بخش‌بندی شده باشد
- 30min قابل تغییر باشد
- XP growth قابل تغییر باشد
- Rank قابل ویرایش باشد
- Task categories قابل ویرایش باشد
- Hero Hub shortcut باشد
- Validation و Reset باشد
- Live Preview باشد
- هیچ Energy وجود نداشته باشد
- RTL و mobile-safe باشد

# STEP 17
HERO HUB / SELECTION & CUSTOMIZATION
در قدم ۱۷ Hero roster، انتخاب Hero، unlock، outfit/accessory/effect/background و Loadout طراحی می‌شود.
