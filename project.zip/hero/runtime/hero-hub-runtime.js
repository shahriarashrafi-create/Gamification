export function heroState(heroId,ownership,selectedHeroId){
  if(!ownership.has(heroId)) return 'locked';
  return heroId===selectedHeroId?'selected':'owned';
}
export function selectHero(heroId,ownership,state){
  if(!ownership.has(heroId)) return {ok:false,reason:'not_owned',state};
  state.selectedHeroId=heroId;
  return {ok:true,state};
}
export function compatible(item,hero){
  if(item.compatibility==='all_heroes') return true;
  if(item.compatibility==='male_only') return hero.gender==='male';
  if(item.compatibility==='female_only') return hero.gender==='female';
  if(item.compatibility==='hero_ids') return (item.heroIds||[]).includes(hero.id);
  return false;
}
export function equipCosmetic({hero,item,ownership,loadouts}){
  if(!ownership.has(item.id)) return {ok:false,reason:'not_owned'};
  if(!compatible(item,hero)) return {ok:false,reason:'incompatible'};
  loadouts[hero.id] ||= {};
  loadouts[hero.id][item.slot]=item.id;
  return {ok:true,loadouts};
}
export function unequipCosmetic({heroId,slot,loadouts}){
  loadouts[heroId] ||= {};
  loadouts[heroId][slot]=null;
  return {ok:true,loadouts};
}
