export function resolveHeroAsset({hero,variant,available,registry}){
  const exact=hero.assets?.[variant]?.path;
  if(exact && available.has(exact)) return {ok:true,path:exact,source:'requested_variant'};
  if(variant==='battle_attack'){
    const idle=hero.assets?.battle_idle?.path;
    if(idle && available.has(idle)) return {ok:true,path:idle,source:'battle_idle_plus_vfx'};
  }
  const lobby=hero.assets?.lobby?.path;
  if(['home','hub'].includes(variant) && lobby && available.has(lobby))
    return {ok:true,path:lobby,source:'compatible_default_variant'};
  const fallback=registry.productionFallback?.[variant];
  if(fallback && available.has(fallback)) return {ok:true,path:fallback,source:'declared_production_fallback'};
  return {ok:false,error:'hero_asset_unavailable'};
}
export function heroStyle(meta){
  return {objectFit:'contain',transformOrigin:`${meta.footAnchor[0]*100}% ${meta.footAnchor[1]*100}%`};
}
