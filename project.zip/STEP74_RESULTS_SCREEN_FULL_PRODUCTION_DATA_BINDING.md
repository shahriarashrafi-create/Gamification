# STEP 74 — RESULTS SCREEN FULL PRODUCTION DATA BINDING

این مرحله Victory / Time End / Manual Exit را به یک Results Screen واحد، production-safe و کاملاً data-bound وصل می‌کند.

## Supported Result Types

victory
time_end
manual_exit

## Source of Truth

Results هیچ Reward جدیدی نمی‌سازد.

Source فقط:
committed result snapshot
committed ledger
committed progression state

اگر snapshot موجود باشد:
reuse

اگر snapshot ناقص باشد:
rebuild idempotently from committed data

## Header Copy

Victory:
پیروزی
بیس دشمن نابود شد

Time End:
زمان تمام شد
پاداش‌های ثبت‌شده حفظ شدند

Manual Exit:
بازی پایان داده شد
پاداش‌های ثبت‌شده حفظ شدند

## Result Data

durationPlayed
tasksCompleted
minionsDefeated
towersDestroyed
lanesCompleted
xpEarned
goldEarned
diamondEarned

Progression:
levelBefore
levelAfter
xpBefore
xpAfter
xpRequired
rankBefore
rankAfter
rankScoreBefore
rankScoreAfter

## Level Up

Level Up فقط از committed progression نمایش داده می‌شود.

اگر levelAfter > levelBefore:
Level Up ceremony

اگر چند Level:
نمایش final level
optional step count

Visual هرگز XP اضافه نمی‌کند.

## Rank Up

Rank Up فقط از committed rank state.

اگر rankAfter != rankBefore:
Rank Up banner

اگر Rank تغییر نکرد:
فقط RP progress

Stats page همچنان فقط درختواره است.
Match results هرگز به Stats analytics تبدیل نمی‌شوند.

## Reward Cards

XP
Gold
Diamond

Diamond card:
فقط وقتی delta > 0 برجسته شود.

Zero Diamond:
نمایش خنثی یا compact.

## Match Summary

Tasks completed
Minions defeated
Towers destroyed
Lanes completed
Duration

هیچ win/loss dashboard عمومی ساخته نمی‌شود.

## CTA

Primary:
بازگشت به خانه

Secondary:
بازی دوباره

Replay:
به Home/PreBattle pipeline برمی‌گردد
Match ID جدید
snapshot جدید
هیچ reward replay نمی‌شود

## Home Return

Results → Home:
exit immersive
restore normal system bars
refresh Player State
clear finalized active Match pointer
do not recalculate rewards

Fresh app launch همچنان Home.

## Replay Safety

Replay button:
never resumes finalized Match
never reuses Match ID
never reuses reward transaction IDs
never replays Victory bonus

## Results Seen

resultsSeenAt persisted

اگر crash قبل از دیده‌شدن Results:
Home recovery card می‌تواند Results را باز کند.

اگر seen شده:
Match دیگر recoverable gameplay نیست.

## Animation

Count-up:
display-only

XP bar:
before → after committed values

Rank bar:
before → after committed values

Reward fly-up:
display-only

Reduce Motion:
instant values + fades

## Victory Visual

Gold/cyan premium ceremony
Hero victory pose
Rank emblem
reward panels

## Neutral Visual

Time End / Manual Exit:
premium but calm
no red defeat styling
no sad language
no punishment tone

## Corrupt Snapshot

If committed match exists but snapshot invalid:
rebuild from ledger.

If ledger unavailable/corrupt:
do not guess values.
show recoverable state:
«نتیجه بازی نیاز به بازیابی دارد»

No fake zero wallet.

## QA

single Results screen handles 3 result types
Victory copy correct
Time End neutral copy correct
Manual Exit neutral copy correct
no defeat wording
no reward mutation in Results
XP count-up display only
Rank progression display only
Diamond highlight only positive
Replay creates new Match ID
Replay cannot duplicate rewards
Home return restores system UI
finalized Match never resumes
fresh launch Home
Stats remains tree-only
no Energy

## STEP 75

HOME POST-RESULT CELEBRATION + LIVE PROGRESSION REFRESH

بازگشت به Home بعد از Results، Level/Rank تغییرکرده، Reward state و Celebration کوتاه را به production flow وصل می‌کنیم.
