# ART BIBLE QUICK REFERENCE

## Palette roles
Obsidian — deepest background
Midnight Navy — main surfaces
Royal Gold — hierarchy / premium structure
Arcane Cyan — interaction / magical utility
Diamond Blue — Diamond economy
Victory Gold — success / claim / promotion
Danger Crimson — destructive / tower danger only

## Material language
Obsidian glass + dark brushed metal + aged gold + cyan crystal.

## Hero render recipe
Full body / transparent / realistic premium game render / consistent 3-quarter camera / warm key + cyan rim / grounded shadow.

## Environment recipe
Portrait cinematic depth with clear central gameplay/UI safe zones.

## Final rule
If a screen can be mistaken for a generic web dashboard, the art pass has failed.
