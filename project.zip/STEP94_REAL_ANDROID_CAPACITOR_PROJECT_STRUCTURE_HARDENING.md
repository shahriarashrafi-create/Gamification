# STEP 94 — REAL ANDROID APP SHELL + CAPACITOR PROJECT STRUCTURE HARDENING

این مرحله معماری واقعی project را برای ورود به GitHub و ساخت APK آماده می‌کند.

## Goal

Project باید از حالت design/runtime blueprint خارج شود و ساختار استاندارد قابل Build داشته باشد:

Web App
→ Capacitor
→ Android Project
→ Gradle
→ APK / AAB

## App Identity

App Name:
Shahriar Game

Android package:
com.shahriar.game

Version:
0.94.0

Version Code:
94

Orientation:
portrait

Theme:
dark

## Project Structure

root/
package.json
capacitor.config.ts
vite.config.js
index.html
app/
  src/
  public/
android/
  app/
    build.gradle
    src/main/
      AndroidManifest.xml
      java/com/shahriar/game/
        MainActivity.java
        ImmersiveModePlugin.java
      res/
.github/workflows/
scripts/
qa/

## Frontend Build

Recommended:
Vite

Commands:

npm install
npm run build
npx cap sync android
npx cap open android

Production web output:
dist/

Capacitor webDir:
dist

## Capacitor

Core packages:

@capacitor/core
@capacitor/cli
@capacitor/android

No Cordova dependency required.

## Native Plugin

Step93 native immersive plugin remains:

ImmersiveModePlugin.java

Registered in:
MainActivity.java

Package:
com.shahriar.game

## Android Manifest

Required:

INTERNET not required for core local gameplay.
VIBRATE optional for haptics.
POST_NOTIFICATIONS only Android 13+ notification features.

Orientation:
portrait

Theme:
dark launch theme

Exported launcher activity:
true

## Permissions Policy

Core gameplay is local-first.

Avoid unnecessary permissions.

Do NOT request:

location
contacts
camera
microphone
storage-wide access

unless a future explicit feature requires them.

## SDK

Recommended baseline:

minSdk 24
targetSdk 35
compileSdk 35

Java compatibility:
17

## Build Types

debug:
standard debug

release:
minifyEnabled false initially for easier stabilization

Future production:
R8/minification can be enabled after Step96+ QA.

## Gradle

Android app module must include Capacitor dependencies via generated Android structure.

GitHub Actions later can run:

npm ci
npm run build
npx cap sync android
./gradlew assembleDebug

APK output:

android/app/build/outputs/apk/debug/app-debug.apk

## App Launch

Fresh launch:
Home.

Never restore old route stack.

Recoverable Match:
Home recovery card only.

## System Bars

Main UI:
visible.

Gameplay:
native immersive plugin.

Results/Home:
restore visible bars.

## Data

Local-first persistence architecture remains.

Do not put runtime DB files in repository.

.gitignore:
node_modules
dist
android/.gradle
android/app/build
*.keystore
*.jks
local.properties

## Signing

Debug:
default Android debug signing.

Release:
NO private signing key inside repository.

Keystore must never be committed.

## GitHub Readiness

User should later be able to upload entire project contents.

Repository root must include:

package.json
capacitor.config.ts
android/
.github/workflows/ when APK automation is added
README.md

No need to upload nested ZIP into repository for final production flow.

## APK Automation Preparation

Step94 includes workflow scaffold only.

Actual hardened GitHub APK build:
future Step98/99.

## QA

package is com.shahriar.game
app name defined
versionCode 94
portrait locked
Vite build config exists
Capacitor config exists
webDir is dist
Android Manifest exists
MainActivity exists
ImmersiveModePlugin exists
minSdk defined
targetSdk defined
compileSdk defined
Java 17 contract
debug build target documented
release signing secrets excluded
gitignore excludes keystores
fresh launch Home contract retained
no unnecessary Android permissions
no Energy
no Mana

## STEP 95

REAL APP ENTRY + ROUTER + PERSISTENT DATA STORE BOOTSTRAP

Home/Tasks/Stats/Timesheet/Networking routes و App State واقعی را داخل project shell به یک entry point اجرایی متصل می‌کنیم.
