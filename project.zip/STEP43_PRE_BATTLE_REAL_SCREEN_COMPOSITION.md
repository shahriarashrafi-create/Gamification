# SHAHRIAR GAME — STEP 43
## PRE-BATTLE REAL SCREEN COMPOSITION

مرجع رسمی صفحه واقعی قبل از ورود به Match.

## 1. Goal
Pre-Battle باید آخرین ایستگاه امن قبل از ورود به Battlefield باشد:
Hero انتخاب‌شده
مدت Match
آمادگی Task Pool
قوانین Snapshot
پیش‌نمایش نقشه سه‌لاین
ورود Immersive

## 2. Entry
Home Start CTA → Pre-Battle.
هرگز مستقیم وارد Match نشو.

## 3. Primary Screen Blocks
Header
Hero Preview
Match Duration
Task Pool Readiness
Map Preview
Rules Snapshot
Enter Battle CTA
Back

## 4. Hero Preview
Hero انتخاب‌شده تمام‌قد/Reference.
نام و Archetype.
Hero Power Advantage ندارد.

## 5. Match Duration
Default:
۳۰ دقیقه

Editable from Settings.
Pre-Battle فقط Snapshot فعلی را نشان می‌دهد.

## 6. Task Pool
Show:
تعداد Task فعال
تعداد دسته‌ها
Task Pool ready / blocked

## 7. Zero Task Pool
Block CTA.
Message:
«برای شروع بازی حداقل یک کار فعال لازم است»

CTA:
«رفتن به کارها»

## 8. Map Preview
Portrait three-lane preview:
Lane A
Lane B
Lane C
Own Base bottom
Enemy Base top
Two Towers per lane

## 9. Lane Preview
Visual guidance only.
No lane selection lock before Match.

## 10. Initial Instruction
«مسیرت را انتخاب کن»

## 11. Snapshot
At Enter Battle:
match duration
wave interval
tower HP
base HP
tower damage/task
base damage/task
timer behavior
selected Hero
eligible Task snapshots
accessibility/control settings

## 12. Snapshot Lock
After Match creation:
mid-Match Settings changes do not alter deterministic values.

## 13. Match ID
Create unique Match ID before gameplay input.

## 14. Init Order
validate Hero
validate Tasks
snapshot settings
build task pool
initialize map
initialize entities
persist initial Match
enter immersive
battle intro
enable controls
start timer

## 15. Persistence
Initial Match must be persisted before controls activate.

## 16. Asset Readiness
Critical required:
battlefield
Hero
Own Base
Enemy Base
Tower
Minion
HUD
Core VFX

## 17. Critical Asset Failure
Do not start Match.
Show recoverable error.

## 18. Noncritical Asset Failure
Use approved fallback and continue.

## 19. CTA States
idle
validating
building_match
persisting
entering_immersive
ready
blocked

## 20. Fake Percentage
Forbidden.

## 21. Progress Feedback
Use real stage labels:
«بررسی Hero»
«آماده‌سازی کارها»
«ساخت میدان»
«ذخیره Match»
«ورود به میدان»

## 22. Back
Before Match creation:
Back → Home.

After authoritative Match creation but before gameplay:
safe cancellation/close transaction.

## 23. Existing Match
If active recoverable Match exists:
do not create new Match.
route Home recovery flow.

## 24. Immersive
Only after initialization has succeeded.
System bars hide before battlefield transition.

## 25. Bottom Nav
Hidden in Pre-Battle.
Not part of canonical main shell.

## 26. Device
Portrait only.

## 27. Responsive
360–430 CSS px.
CTA always reachable.

## 28. Hero Layout
Hero on one side/center visual.
Do not dominate vertical space.

## 29. Map Layout
Compact tactical preview.
No tap-to-teleport.
No fake path animation suggesting locked lane.

## 30. Task Readiness Card
Green/cyan ready state.
Gold warning near minimum pool.
Red only for blocking invalid state.

## 31. Rules Card
Compact:
۳۰ دقیقه
Wave هر ۴۵ ثانیه
Tower 100 HP
Base 100 HP

## 32. Accessibility
Text labels for all critical states.
No state conveyed only by color.

## 33. Reduce Motion
Battle entry becomes short fade.
No camera sweep.

## 34. Audio
Pre-Battle low suspense ambience.
Enter Battle confirmation cue.
Respects mute.

## 35. Haptic
Medium confirm on Enter Battle.
No repeated vibration during loading.

## 36. Offline
Works fully offline using local tasks/assets.

## 37. Prototype
`concept/prebattle-real.html` simulates:
Ready
No Tasks
Asset Error
Initialization sequence
Enter Battle

## 38. QA
zero Task blocks
existing Match blocks second
no fake %
persist before controls
Immersive after init success
Bottom Nav absent
Hero power neutral
no Energy
CTA visible 360×800

## 39. Failure Conditions
direct Match entry
timer starts during Pre-Battle
missing Task replaced with fake Task
asset error ignored
second active Match
bottom nav appears
Hero stat bonus shown
Energy appears

## 40. Quality Gate
Enter Battle only becomes authoritative after validation, snapshot, initialization and initial persistence succeed.

## STEP 44
BATTLEFIELD REAL VISUAL COMPOSITION
Build the real portrait battlefield shell using three lanes, bases, towers, minimap, timer, rewards HUD, joystick and contextual action controls.
