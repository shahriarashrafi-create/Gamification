# STEP 56 — HERO HUB LIVE OWNERSHIP & EQUIP FLOW

در این مرحله Hero Hub به Ownership واقعی Shop، انتخاب Hero، Cosmetic Loadout و Home Refresh متصل می‌شود.

## Hero Source

Hero Catalog
+
Ownership
+
Selected Hero
+
Per-Hero Loadout

## Hero States

locked
owned
selected

## Locked Hero

CTA:
رفتن به فروشگاه

Hero Hub خودش خرید انجام نمی‌دهد.
خرید در Shop انجام می‌شود.

## Owned Hero

CTA:
انتخاب

Selection flow:
validate ownership
→ persist selectedHeroId
→ refresh Hero Hub
→ notify Home state
→ Home Hero asset refresh

## Selected Hero

State:
انتخاب‌شده

CTA disabled or secondary.

## Cosmetic Slots

outfit
accessory
aura
effect
background
frame
title

Each slot:
none
owned compatible item
equipped item

## Equip Flow

open slot
→ list owned compatible cosmetics
→ choose item
→ validate ownership
→ validate compatibility
→ persist per-Hero loadout
→ refresh Hero visual

## Unequip

Allowed.
Returns slot to none.

## Compatibility

Cosmetic can define:
all_heroes
male_only
female_only
hero_ids

Invalid cosmetic cannot equip.

## Ownership

Hero Hub never trusts only UI.
Every Select/Equip reads ownership store.

## Home Sync

If selectedHeroId changes:
Home Hero Stage refreshes from committed selectedHeroId.

If selected Hero cosmetic changes:
Home Hero visual/loadout refreshes.

## Match Sync

Current active Match uses Hero snapshot from Match initialization.
Changing Hero during an active Match does not mutate that Match.

Next Match uses latest selected Hero/loadout.

## No Power

Hero
outfit
aura
effect
background
frame
title

all visual only.

No:
damage
speed
reward boost
rank boost

## Asset State

If final transparent Hero runtime asset missing:
use approved generic production fallback only.
Never CSS human silhouette in production.

## Recovery

If Hero selection persists but UI crashes:
restart reads selectedHeroId.

If cosmetic equip write fails:
previous committed loadout remains.

## QA

locked Hero cannot be selected
owned Hero can be selected
Shop owns purchase authority
selection persists
Home refreshes selected Hero
active Match Hero snapshot is unchanged
compatibility enforced
unequip works
no gameplay power
no Energy

## STEP 57

HERO HUB PRODUCTION VISUAL GALLERY

Hero Gallery را از state/runtime به ظاهر نهایی premium تبدیل می‌کنیم: full-body cards، selected frame، locked presentation، loadout slots و responsive mobile composition.
