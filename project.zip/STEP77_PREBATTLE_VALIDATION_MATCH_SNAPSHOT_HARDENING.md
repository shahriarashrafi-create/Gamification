# STEP 77 — PREBATTLE VALIDATION + MATCH SNAPSHOT HARDENING

این مرحله PreBattle را به نقطه قطعی و امن ساخت Match تبدیل می‌کند.

## Authority

Home:
فقط Start Request می‌سازد.

PreBattle:
تنها authority برای ساخت Match جدید است.

Gameplay:
فقط Match از قبل persist‌شده را اجرا می‌کند.

## Validation Order

START_REQUEST
→ acquire prebattle bootstrap lock
→ verify no active Match
→ validate Player State
→ validate selected Hero ownership
→ resolve required Hero battle assets
→ load eligible Tasks
→ validate Settings
→ validate map/world definition
→ build immutable snapshots
→ generate Match ID
→ generate bootstrap transaction ID
→ initialize entity/objective state
→ initialize Timer/Wave state
→ persist complete Match atomically
→ verify persisted Match
→ enter immersive mode
→ route Gameplay

اگر persistence کامل نشود:
Gameplay باز نمی‌شود.

## Match ID

هر Match:
ID جدید و یکتا.

Replay:
ID جدید.

Recover:
همان ID قبلی.

هیچ Match finalized دوباره استفاده نمی‌شود.

## Immutable Snapshot

بعد از bootstrap، این موارد برای Match جاری immutable هستند:

settingsSnapshot
heroSnapshot
taskPoolSnapshot
mapSnapshot
economySnapshot
progressionRulesSnapshot

تغییر Settings/Tasks/Hero در اپ:
فقط Match بعدی را تغییر می‌دهد.

## Settings Snapshot

matchMinutes
waveSeconds
timerRunsDuringTask
towerHP
baseHP
towerDamage
baseDamage
immersiveGameplay

Validation:
matchMinutes 10–90
waveSeconds >= 10
HP > 0
damage > 0

## Hero Snapshot

heroId
ownershipState
runtimeAssetSetId
loadoutSnapshot
visualVariant

Hero:
هیچ gameplay power ندارد.

اگر battle core asset آماده نباشد:
Match ساخته نمی‌شود.

## Task Pool Snapshot

فقط Taskهای eligible در لحظه Start.

هر entry:
taskId
title
category
difficulty
xp
gold
diamond
repeatMode
activeInGame

Reward values snapshot می‌شوند.

ویرایش Task بعد از Start:
Reward Match جاری را تغییر نمی‌دهد.

هیچ Task ساختگی مجاز نیست.

## Map Snapshot

worldWidth = 1200
worldHeight = 2600
heroSpawn
lane paths
crossroads
Tower IDs
Base IDs
collision version
map version

Map snapshot باید با runtime collision contract سازگار باشد.

## Initial Objective State

Tower A1/B1/C1:
unlocked

Tower A2/B2/C2:
locked

Enemy Base:
shield_locked

completedLanes:
0

## Initial Entity State

Own Base:
alive

Enemy Base:
HP = snapshot baseHP

All Tower1:
HP = towerHP

All Tower2:
HP = towerHP

Minion wave entities:
از Scheduler/Reservation runtime ساخته می‌شوند.

PreBattle fake Minion/Task نمی‌سازد.

## Timer Snapshot

durationMs = matchMinutes × 60 × 1000
waveIntervalMs = waveSeconds × 1000

state:
ready

startedAt:
فقط هنگام Gameplay start commit.

بنابراین زمان Loading/PreBattle از Match کم نمی‌شود.

## Atomic Persistence

Match record باید یکجا persist شود.

Required fields:
id
schemaVersion
createdAt
status
snapshots
worldState
objectiveState
timerState
waveState
transactionState

بعد از write:
read-back verification.

اگر verification fail:
quarantine partial bootstrap
clear active pointer if it points to incomplete Match
stay PreBattle
show recoverable error

## Active Match Pointer

activeMatchId فقط بعد از Match record موفق تنظیم شود.

Never:
pointer first, record later.

## Bootstrap Lock

prebattleBootstrapLock:
از duplicate Match creation جلوگیری می‌کند.

Home startLock با این lock فرق دارد.

## Route Safety

Gameplay route only when:

matchPersisted
readBackVerified
activeMatchId == match.id
status == ready
snapshots valid

سپس:
immersive ON
status → running
startedAt commit
Timer starts
Wave scheduler starts
controls enabled

## Failure Copy

Hero:
قهرمان برای ورود به میدان آماده نیست.

Tasks:
برای شروع بازی حداقل یک کار فعال لازم است.

Settings:
تنظیمات بازی نیاز به اصلاح دارد.

Map:
اطلاعات میدان بازی نیاز به بازیابی دارد.

Persistence:
ساخت بازی کامل نشد. دوباره تلاش کن.

## Crash Boundaries

Crash before Match persist:
no Match exists.

Crash after Match persist but before active pointer:
orphan ready Match can be detected/quarantined safely.

Crash after active pointer but before Gameplay:
Home sees recoverable Match.

Crash after Gameplay start:
normal Match recovery.

Fresh launch:
Home only.

## Security / Integrity

Client-local integrity:
snapshot checksum/hash metadata
schemaVersion
createdAt
bootstrapTxId

Hash is corruption detection, not anti-cheat security.

## QA

PreBattle is only new Match creation authority
new Match ID every new game
settings snapshot immutable
Hero snapshot immutable
Task reward snapshot immutable
map snapshot immutable
no fake Tasks
no fake Minions
invalid Hero blocks Match
zero eligible Tasks blocks Match
invalid Settings block Match
invalid Map blocks Match
Match record persisted before active pointer
read-back verification required
Gameplay cannot route on partial Match
Timer does not start in PreBattle
Wave scheduler does not start in PreBattle
fresh launch Home
recoverable Match retains same ID
Hero has no power advantage
Stats tree-only
bottom nav exact five outside gameplay
no Energy

## STEP 78

GAMEPLAY BOOTSTRAP + FIRST FRAME RUNTIME

Match ready → immersive → timer start → camera/hero/entity hydration → controls unlock → first playable frame را production-grade می‌کنیم.
