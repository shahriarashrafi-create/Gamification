# SHAHRIAR GAME — STEP 27
## LANE PROGRESSION & OBJECTIVE ROUTING

مرجع رسمی پیشروی در سه Lane، Tower gating، Crossroads و انتخاب آزاد مسیر.

## 1. Philosophy
بازیکن باید حس انتخاب واقعی مسیر داشته باشد.
سیستم Objective راهنمایی می‌کند، اما Hero را Teleport یا روی یک Lane قفل نمی‌کند.

## 2. Lanes
A = Left
B = Center
C = Right

Each lane:
Lower region
Tower 1
Mid crossroads
Tower 2
Upper approach
Enemy Base access

## 3. Default Gate
Tower 1 must be destroyed before Tower 2 of the same lane becomes an active attack objective.
Tower 2 may be visible before unlock but clearly marked locked/inactive.

## 4. Base Access
Default:
Destroy at least one lane's Tower1 + Tower2 chain to unlock Enemy Base as an attack objective.
Other lanes remain explorable.

## 5. Free Movement
Hero can:
advance
backtrack
switch lane at crossroads
return toward Own Base
explore unlocked walkable corridors

No forced forward-only movement.

## 6. Crossroads
Three primary cross-lane corridors:
lower
middle
upper

They provide readable lane switching without teleport.

## 7. Objective Recommendation
System may recommend:
nearest actionable Minion
unlocked Tower
Enemy Base after access
but recommendation is not movement automation.

## 8. Objective Priority
Encounter trigger proximity overrides remote recommendation.
Recommendation never opens Task panel from distance.

## 9. Tower 1
Initially active/unlocked.
Can be approached and attacked through completed real-world Tasks.

## 10. Tower 2
Initially progression-locked per lane.
Unlock condition:
same lane Tower1 destroyed.

## 11. Locked Tower Visual
Dim core
lock/rune marker
no actionable encounter
world remains visually present

## 12. Unlock Feedback
Tower1 destroyed
→ lane route pulse
→ Tower2 core activates
→ compact objective callout
→ minimap state update

## 13. Enemy Base
Visible from world composition.
Not actionable until Base access condition met.

## 14. Base Unlock
Default when any complete lane chain has both towers destroyed.
Configurable later to require more lanes if desired.

## 15. Base Locked Feedback
Approach before unlock:
«برای دسترسی به Base، یک مسیر را کامل کن»
No task consumption.

## 16. Lane Switching
Crossroad movement only through walkable map geometry.
No lane-select buttons that move Hero.

## 17. Backtracking
Always allowed unless temporary cinematic lock.
Destroyed objectives remain non-blocking.

## 18. Minions
Can remain actionable on multiple lanes within spawn caps.
Ignoring a lane does not create infinite buildup.

## 19. Routing State
Each lane:
tower1: alive/destroyed
tower2: locked/alive/destroyed
route: open/advanced/complete

## 20. Base State
locked
unlocked
active
destroyed

## 21. Recommended Objective Algorithm
1 nearby active encounter
2 current lane unlocked Tower
3 nearby actionable Minion
4 nearest incomplete lane Tower1
5 unlocked Base
6 free explore

Recommendation can be tuned later.

## 22. Player Intent
If player moves away from recommendation, do not snap camera/path back.
Recommendation updates after a short grace interval.

## 23. Guidance
World-space beacon + minimap cue + compact HUD label.
Never giant permanent arrow covering battlefield.

## 24. Distance
HUD can show approximate direction/distance.
No exact GPS-like navigation required.

## 25. Fog
Guidance respects vision rules.
Locked objective can have silhouette/known marker without revealing unrelated entities.

## 26. Minimap
Shows lane objective states:
alive
locked
destroyed
Base locked/unlocked.

## 27. Collision
Alive Tower collision blocks only its physical footprint, not entire lane.
Destroyed Tower becomes passable after commit.

## 28. Crossroad Safety
No objective should spawn directly in a narrow crossing in a way that blocks lane switching.

## 29. Encounter During Routing
Encounter modal pauses movement input.
After resolution, routing recomputes from current Hero position.

## 30. Tower Destruction
Lane state update is atomic with destruction transaction.
Tower2 unlock cannot happen twice.

## 31. Base Unlock Atomicity
First qualifying completed lane sets Base unlocked.
Subsequent completed lanes do not duplicate unlock reward/effect.

## 32. Rewards
Routing/unlock itself does not invent random currency.
Only configured objective/task/achievement rewards.

## 33. Time End
If time expires mid-progression, current map state is summarized in Results.
No penalty.

## 34. Recovery
Persist lane objective states and Base access in active Match snapshot.
Recovery recreates same progression state.

## 35. Accessibility
Locked/unlocked/destroyed states use text/icon + visual treatment, not color alone.

## 36. Reduce Motion
Route pulse becomes static highlight.
No essential routing information depends on animation.

## 37. Mobile
Guidance stays outside joystick/action safe zones.
Minimap remains compact.

## 38. Prototype
Step27 concept allows destroying towers, switching current lane and demonstrates Base unlock.

## 39. Failure Conditions
Tower2 attackable before Tower1
Base attackable before route complete
forced teleport
no backtracking
duplicate unlock transaction
guidance covers controls
destroyed tower still blocks path

## 40. Quality Gate
Player must always understand what is actionable next while retaining freedom to move, switch lanes and backtrack.

## STEP 28
CAMERA / FOG / MINIMAP FINAL GAMEPLAY SYSTEM
Camera bounds, dead-zone, look-ahead, fog reveal, minimap projection, objective markers and mobile readability.
