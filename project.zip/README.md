# Shahriar Game — 100 Step Rebuild

## Step 01
Master Vision + Visual Direction Foundation

### فایل‌ها
- `STEP01_MASTER_VISION.md` — سند رسمی Vision و قوانین پایه پروژه
- `concept/index.html` — کانسپت بصری اولیه قابل اجرا در مرورگر گوشی
- `concept/style.css` — Design Direction اولیه

### اجرا
فایل `concept/index.html` را در مرورگر باز کنید.

### نکته
این Step هنوز اپ نهایی یا Gameplay نیست.
هدف مرحله ۱ قفل کردن Vision، Product Identity و کیفیت بصری پایه است.
در Step 02 معماری دقیق Match 30 دقیقه‌ای و Core Loop ساخته می‌شود.


---

## Step 02
Core Loop + 30-Minute Match Architecture

فایل‌های جدید:
- `STEP02_CORE_LOOP.md`
- `gameplay/core-loop-config.json`
- `concept/core-loop.html`
- `concept/core-loop.css`

کانسپت Step 02 ساختار کامل:
Spawn → Minion → Real Task → Attack → Reward → Tower → Lane Choice → Enemy Base
را نمایش می‌دهد.


---

## Step 03
Game World & Map Architecture

فایل‌های جدید:
- `STEP03_WORLD_MAP_ARCHITECTURE.md`
- `gameplay/world-map-config.json`
- `concept/world-map.html`
- `concept/world-map.css`
- `concept/world-map.js`

این مرحله نقشه Portrait، سه Lane، Baseها، Towerها، Waveها،
Crossroadها، Collision، Camera Safe Zone و Minimap را قفل می‌کند.

کانسپت Step 03 تعاملی است:
- Slider موقعیت Hero را در طول Map تغییر می‌دهد.
- دکمه‌های Lane، Hero را بین سه مسیر جابه‌جا می‌کنند.
- Minimap هم‌زمان با World Coordinate به‌روز می‌شود.


---

## Step 04
Player / Hero Control Architecture

فایل‌های جدید:
- `STEP04_HERO_CONTROL_ARCHITECTURE.md`
- `gameplay/hero-control-config.json`
- `concept/hero-control.html`
- `concept/hero-control.css`
- `concept/hero-control.js`

کانسپت Step 04 روی گوشی قابل تست است: Joystick، Acceleration/Deceleration، IDLE/WALK/RUN، Facing، Attack و نمونه Collision Slide.


---

## Step 05
Real-World Task Encounter System

فایل‌های جدید:
- `STEP05_TASK_ENCOUNTER_SYSTEM.md`
- `gameplay/task-encounter-config.json`
- `concept/task-encounter.html`
- `concept/task-encounter.css`
- `concept/task-encounter.js`

کانسپت Step 05 قابل تست است:
- «نزدیک شدن به Minion» Encounter را باز می‌کند.
- Complete باعث Attack، Hit، Defeat و Reward می‌شود.
- Defer Task را فقط در Match جاری کنار می‌گذارد.
- Cancel فقط Encounter فعلی را می‌بندد و Task را حذف نمی‌کند.


---

## Step 06
Reward / XP / Level / Rank Economy

فایل‌های جدید:
- `STEP06_ECONOMY_PROGRESSION.md`
- `gameplay/economy-config.json`
- `concept/economy.html`
- `concept/economy.css`
- `concept/economy.js`

کانسپت Step 06 قابل تست است:
- سه نوع Reward را انتخاب کنید.
- XP/Gold/Diamond/RP اعمال می‌شوند.
- Level Up overflow و Rank overflow شبیه‌سازی می‌شود.
- نقش Gold و Diamond از هم جدا نگه داشته شده است.


---

## Step 07
Home / Lobby Experience Architecture

فایل‌های جدید:
- `STEP07_HOME_LOBBY_ARCHITECTURE.md`
- `ui/home-layout-config.json`
- `concept/home-lobby.html`
- `concept/home-lobby.css`
- `concept/home-lobby.js`

قوانین مهم این مرحله:
- Home در هر اجرای تازه App صفحه شروع است.
- Bottom Nav دقیقاً ۵ آیتم دارد.
- Hero، Rank، چهار Module و CTA همگی باید در Viewport واقعی گوشی جا شوند.
- هیچ Energy، Friend List یا Mission strip وجود ندارد.
- CTA همیشه بالای Bottom Nav می‌ماند.


---

## Step 08
Tasks Management Experience

فایل‌های جدید:
- `STEP08_TASKS_MANAGEMENT.md`
- `data/task-schema.json`
- `concept/tasks.html`
- `concept/tasks.css`
- `concept/tasks.js`

کانسپت Step 08 قابل تست است:
- افزودن Task
- ویرایش Task
- حذف با Confirmation
- فعال/غیرفعال کردن Gameplay
- جستجو
- فیلتر
- XP / Gold / Diamond
- دسته‌بندی و سختی

صفحه عمداً به شکل Tactical Objective Arsenal طراحی شده و از ظاهر جدول/ادمین دور نگه داشته شده است.


---

## Step 09
Network Tree / Stats Experience

فایل‌های جدید:
- `STEP09_NETWORK_TREE_STATS.md`
- `data/network-tree-schema.json`
- `concept/network-tree.html`
- `concept/network-tree.css`
- `concept/network-tree.js`

کانسپت Step 09 قابل تست است:
- Expand / Collapse
- Pan
- Zoom + / -
- Reset
- Search
- Add child
- Edit member
- Remove member
- Root protected from deletion

صفحه «آمار» عمداً فقط Tree است و هیچ Dashboard/Chart جدا در آن قرار نگرفته است.


---

## Step 10
Timesheet / Weekly Tactical Planner

فایل‌های جدید:
- `STEP10_TIMESHEET_WEEKLY_PLANNER.md`
- `data/timesheet-schema.json`
- `concept/timesheet.html`
- `concept/timesheet.css`
- `concept/timesheet.js`

کانسپت Step 10 قابل تست است:
- هفته شنبه‌محور
- ۷ روز قابل انتخاب
- هفته قبل / بعد / امروز
- افزودن، ویرایش و حذف برنامه
- Complete / Revert
- Search
- Weekly Recurring
- لینک اختیاری به Task

Timesheet به‌صورت مستقیم XP/Gold/Diamond نمی‌دهد و حذف برنامه، Task مرتبط را حذف نمی‌کند.


---

## Step 11
Networking / CRM Command Center

فایل‌های جدید:
- `STEP11_NETWORKING_CRM_COMMAND_CENTER.md`
- `data/networking-schema.json`
- `concept/networking.html`
- `concept/networking.css`
- `concept/networking.js`

کانسپت Step 11 قابل تست است:
- Prospect CRUD
- پنج Action Type رسمی
- ثبت Result
- معرف و مشاور
- دو Next Action
- تاریخ/ساعت Follow-up
- نتیجه‌های اقدام بعدی
- Search
- Filter بر اساس Action Type
- Action History
- ویرایش Action

ثبت CRM Action مستقیماً XP/Gold/Diamond نمی‌دهد.


---

## Step 12
Shop / Reward Armory

فایل‌های جدید:
- `STEP12_SHOP_REWARD_ARMORY.md`
- `data/shop-schema.json`
- `concept/shop.html`
- `concept/shop.css`
- `concept/shop.js`

کانسپت Step 12 قابل تست است:
- خرید Hero با Gold
- انتخاب Hero خریداری‌شده
- خرید و Equip Cosmetic
- Real Reward CRUD
- Claim با Diamond
- Wallet validation
- Purchase/Claim History
- Transaction snapshot
- جلوگیری از خرید دوباره آیتم Owned

Gold و Diamond عمداً نقش جدا دارند و هیچ Hero Power خریدنی وجود ندارد.


---

## Step 13
Events / Qualification War Room

فایل‌های جدید:
- `STEP13_EVENTS_QUALIFICATION_WAR_ROOM.md`
- `data/events-schema.json`
- `concept/events.html`
- `concept/events.css`
- `concept/events.js`

کانسپت Step 13 قابل تست است:
- Event CRUD
- Participant CRUD
- Qualified
- Close to target
- Should Reach
- Progress / Target
- Search
- Status filter
- چند Event فعال

رویدادها از Home باز می‌شوند و Bottom Nav ندارند.


---

## Step 14
Vision / Future Realm

فایل‌های جدید:
- `STEP14_VISION_FUTURE_REALM.md`
- `data/vision-schema.json`
- `concept/vision.html`
- `concept/vision.css`
- `concept/vision.js`

کانسپت Step 14 قابل تست است:
- Goal CRUD
- Year grouping
- Category filter
- Search
- Target / Current / Progress
- Priority
- Image URL
- Note
- Pause / Reactivate
- Achieve

Vision از Home باز می‌شود و Bottom Nav ندارد.


---

## Step 15
Achievements / Honor Hall

فایل‌های جدید:
- `STEP15_ACHIEVEMENTS_HONOR_HALL.md`
- `data/achievements-schema.json`
- `concept/achievements.html`
- `concept/achievements.css`
- `concept/achievements.js`

کانسپت Step 15 قابل تست است:
- Daily / Weekly / Monthly / Long-term
- Locked / Progress / Ready / Claimed
- Progress auto calculation
- Auto Ready at target
- Claim XP / Gold / Diamond
- Double Claim guard
- Achievement CRUD
- Search
- State filter

دستاوردها از Home باز می‌شوند و Bottom Nav ندارند.


---

## Step 16 — Settings / System Control

فایل‌های جدید:
- `STEP16_SETTINGS_SYSTEM_CONTROL.md`
- `data/settings-schema.json`
- `concept/settings.html`
- `concept/settings.css`
- `concept/settings.js`

قابل تست:
Player Profile، Match Duration Live Preview، Gameplay values، XP Growth، Rank RP، Task Categories، Accessibility controls، Validation و Reset Section.

هیچ Energy field در Settings یا Schema وجود ندارد.

---
## Step 17 — Hero Hub / Selection & Customization
فایل‌ها:
- STEP17_HERO_HUB_SELECTION_CUSTOMIZATION.md
- data/hero-hub-schema.json
- concept/hero-hub.html/css/js

کانسپت: 8 Hero archetype، فیلتر مرد/زن، Gold unlock، انتخاب Hero، 7 slot شخصی‌سازی، purchase/equip/unequip و Loadout مستقل هر Hero. هیچ Power Advantage یا Energy وجود ندارد.

---
## Step 18 — Art Direction & Asset Pipeline
اضافه شد:
- STEP18_ART_DIRECTION_ASSET_PIPELINE.md
- art/ART_BIBLE_QUICK_REFERENCE.md
- art/asset-manifest.json
- concept/art-direction.html
- concept/art-direction.css

این مرحله استاندارد نهایی Hero، Environment، UI Ornament، Icon، VFX، naming، formats، compression، safe zones، performance و asset approval pipeline را قفل می‌کند.

---
## Step 19 — Master Design System / UI Component Library
اضافه شد:
- STEP19_MASTER_DESIGN_SYSTEM_UI_LIBRARY.md
- design-system/tokens.json
- design-system/COMPONENT_CATALOG.md
- concept/design-system.html/css

رنگ‌ها، typography scale، spacing، radius، motion، layers، buttons، cards، inputs، chips، HUD، sheet و Bottom Navigation استاندارد شدند.

---
## Step 20 — Home Lobby Final Responsive Blueprint
اضافه شد:
- STEP20_HOME_LOBBY_FINAL_RESPONSIVE_BLUEPRINT.md
- ui/home-responsive-config.json
- concept/home-final.html
- concept/home-final.css

Home برای 360×800 تا 430×932 با Hero پویا، چهار ماژول، Rank، CTA رزروشده بالای Bottom Nav و Safe Area طراحی شده است. Hero موجود در کانسپت فقط placeholder اندازه‌گیری است و برای Production مجاز نیست.

---
## Step 21 — Gameplay HUD & Battlefield Final Responsive Blueprint
اضافه شد:
- STEP21_GAMEPLAY_HUD_BATTLEFIELD_RESPONSIVE_BLUEPRINT.md
- ui/gameplay-responsive-config.json
- concept/gameplay-final.html/css/js

Portrait immersive battlefield، سه Lane، Timer، Minimap، Joystick، contextual action، Tower warning، task encounter sheet و Safe Area برای 360×800 تا 430×932 تعریف شد.

---
## Step 22 — Task Encounter Final Cinematic Interaction
اضافه شد:
- STEP22_TASK_ENCOUNTER_FINAL_CINEMATIC_BLUEPRINT.md
- ui/task-encounter-cinematic-config.json
- concept/task-encounter-final.html/css/js

Complete choreography از Commit تا Attack/Projectile/Hit/Damage/Reward/Resume، همراه با Defer/Cancel، Double-Complete Guard و Reward Snapshot تعریف شد.

---
## Step 23 — Combat Feedback / Tower & Base Destruction
اضافه شد:
- STEP23_COMBAT_FEEDBACK_TOWER_BASE_DESTRUCTION.md
- gameplay/combat-feedback-config.json
- concept/combat-feedback.html/css/js

World-space HP، Damage Stages، Projectile/Impact، Tower destruction، Enemy Base collapse، Victory shockwave و transaction guards تعریف شدند.

---
## Step 24 — Match Results / Victory & Time-End Experience
اضافه شد:
- STEP24_MATCH_RESULTS_VICTORY_TIME_END.md
- gameplay/match-results-config.json
- concept/match-results.html/css/js

Victory، Time End و Manual Exit، reward receipt، XP/Level/Rank progress، task summary، objective progress و بازگشت امن به Home تعریف شدند.

---
## Step 25 — Match Initialization / Pre-Battle Experience
اضافه شد:
- STEP25_MATCH_INITIALIZATION_PRE_BATTLE.md
- gameplay/match-initialization-config.json
- concept/pre-battle.html/css/js

Hero validation، Settings snapshot، Task Pool، Map/Entity initialization، Match ID، persistence، Immersive transition و شروع Timer فقط بعد از Battle Ready قفل شدند.

---
## Step 26 — Minion Wave & Task Distribution System
اضافه شد:
- STEP26_MINION_WAVE_TASK_DISTRIBUTION.md
- gameplay/minion-wave-task-distribution-config.json
- concept/wave-distribution.html/css/js

Wave Scheduler، Task Reservation، سه Lane، Anti-Repetition، Spawn Cap، Small-Pool Recycling و جلوگیری از assignment همزمان یک Task تعریف شدند.

---
## Step 27 — Lane Progression & Objective Routing
اضافه شد:
- STEP27_LANE_PROGRESSION_OBJECTIVE_ROUTING.md
- gameplay/lane-progression-routing-config.json
- concept/lane-routing.html/css/js

Tower1→Tower2 gating، Base unlock، سه Crossroad، lane switching، backtracking، objective recommendation و عدم Teleport قفل شدند.

---
## Step 28 — Camera / Fog / Minimap Final Gameplay System
اضافه شد:
- STEP28_CAMERA_FOG_MINIMAP_FINAL_SYSTEM.md
- gameplay/camera-fog-minimap-config.json
- qa/step28-camera-minimap-qa.json
- concept/camera-fog-minimap.html/css/js

Camera anchor/dead-zone/look-ahead، world clamp، سه حالت Fog، Hero vision و Minimap projection همگام و بدون tap-to-teleport قفل شدند.

---
## Step 29 — Gameplay Control Polish / Joystick & Interaction
اضافه شد:
- STEP29_GAMEPLAY_CONTROL_POLISH_JOYSTICK_INTERACTION.md
- gameplay/gameplay-controls-config.json
- qa/step29-gameplay-controls-qa.json
- concept/gameplay-controls.html/css/js

Dead Zone 0.12، response curve 1.35، max speed 6.6، acceleration/deceleration، run threshold، sticky target، touch priority، Left-Hand Mode و focus-loss guards قفل شدند.

---
## Step 30 — Pause / Lifecycle / Android Immersive Recovery
اضافه شد:
- STEP30_PAUSE_LIFECYCLE_ANDROID_IMMERSIVE_RECOVERY.md
- gameplay/pause-lifecycle-immersive-config.json
- native/android/MainActivity.java
- native/android/ImmersiveModePlugin.java
- qa/step30-lifecycle-qa.json
- concept/lifecycle.html/css/js

Pause، Android Back، background/foreground، checkpoint recovery، phantom-input guard و Android 11+ WindowInsetsController با legacy IMMERSIVE_STICKY قفل شدند.

---
## Step 31 — App Navigation / Route & State Architecture
اضافه شد:
- STEP31_APP_NAVIGATION_ROUTE_STATE_ARCHITECTURE.md
- app/navigation-config.json
- app/global-state-domains.json
- qa/step31-navigation-state-qa.json
- concept/navigation-lab.html/css/js

Canonical five-tab shell، secondary routes، gameplay isolation، Back Stack، route guards، fresh-launch Home و system-UI boundaries یکپارچه شدند.

---
## Step 32 — Global Data Model / Storage & Schema Migration
اضافه شد:
- STEP32_GLOBAL_DATA_MODEL_STORAGE_SCHEMA_MIGRATION.md
- data/schema-v32.json
- data/transaction-ledger-example.json
- storage/migrations-v32.json
- storage/backup-manifest-spec.json
- qa/step32-storage-migration-qa.json
- concept/storage-lab.html/css/js

Local-first persistence، SQLite architecture، immutable Match snapshots، unique Transaction Ledger، migration 31→32، corruption guard و backup/import foundations قفل شدند.

---
## Step 33 — Backup / Export / Import & Safe Reset UX
اضافه شد:
- STEP33_BACKUP_EXPORT_IMPORT_SAFE_RESET_UX.md
- storage/backup-import-reset-config.json
- storage/backup-manifest-example.json
- qa/step33-backup-reset-qa.json
- concept/backup-reset.html/css/js

Backup محلی، Restore validation، Safety Backup، Replace-All transaction، Selective Reset، Wallet high-risk flow و Full Reset با عبارت RESET قفل شدند.

---
## Step 34 — Notification / Reminder / Local Scheduling
اضافه شد:
- STEP34_NOTIFICATION_REMINDER_LOCAL_SCHEDULING.md
- notifications/notification-config.json
- notifications/notification-schema.json
- qa/step34-notifications-qa.json
- concept/notification-lab.html/css/js

Local Notifications، پنج Channel، Task/Timesheet/Event reminders، Match Recovery امن، Permission timing، Quiet Hours، deduplication و safe notification routing قفل شدند.

---
## Step 35 — Search / Filter / Command System
اضافه شد:
- STEP35_SEARCH_FILTER_COMMAND_SYSTEM.md
- search/search-config.json
- search/filter-schema.json
- qa/step35-search-filter-qa.json
- concept/search-lab.html/css/js

Persian normalization، grouped local search، scope filters، Tree focus architecture، safe Quick Commands و Pre-Battle route guard قفل شدند.

---
## Step 36 — App-wide Empty / Loading / Error / Offline States
اضافه شد:
- STEP36_APP_WIDE_EMPTY_LOADING_ERROR_OFFLINE_STATES.md
- app/resilient-states-config.json
- app/state-messages-fa.json
- qa/step36-resilient-states-qa.json
- concept/resilient-states.html/css/js

Local-first Offline UX، Empty States، Skeleton Loading، idempotent Retry، corruption quarantine، migration recovery و zero-task Match guard قفل شدند.

---
## Step 37 — Audio / Haptics / Feedback System
اضافه شد:
- STEP37_AUDIO_HAPTICS_FEEDBACK_SYSTEM.md
- feedback/audio-haptics-config.json
- feedback/feedback-event-catalog.json
- qa/step37-audio-haptics-qa.json
- concept/feedback-lab.html/css/js

Audio buses، adaptive battle layers، Task/Tower/Base/Victory feedback، Haptic intensity، Pause ducking، lifecycle audio safety و transaction-based feedback deduplication قفل شدند.

---
## Step 38 — Animation / Motion / Transition System
اضافه شد:
- STEP38_ANIMATION_MOTION_TRANSITION_SYSTEM.md
- motion/motion-config.json
- motion/motion-event-catalog.json
- qa/step38-motion-qa.json
- concept/motion-lab.html/css/js

Motion tokens، Lobby Hero idle، navigation transitions، encounter/attack/projectile/impact choreography، Tower/Base/Victory motion، Reduce Motion و 60fps performance budget قفل شدند.

---
## Step 39 — Visual Asset Integration Contract
اضافه شد:
- STEP39_VISUAL_ASSET_INTEGRATION_CONTRACT.md
- assets/contracts/runtime-asset-contract.json
- assets/manifests/asset-manifest-example.json
- qa/step39-asset-integration-qa.json
- concept/asset-lab.html/css

Runtime asset sizes، full-body Hero anchors، background safe regions، preload/lazy groups، fallback chain، caching/versioning و Production Placeholder Removal قفل شدند.

---
## Step 40 — Production Hero & Home Art Pack v1
اضافه شد:
- STEP40_PRODUCTION_HERO_HOME_ART_PACK.md
- 3 generated production artboards
- Hero/Home/Rank/Resource/CTA reference crops
- 13 usable SVG icons
- ornate Start Game SVG frame
- ornate Rank SVG frame
- assets/manifests/step40-home-art-pack.json
- qa/step40-home-art-pack-qa.json
- concept/step40-art-pack.html/css

این اولین مرحله‌ای است که Visual Direction واقعیِ تولیدشده وارد ZIP تجمعی پروژه شده است.

---
## Step 41 — Home Screen Real Asset Composition
اضافه شد:
- STEP41_HOME_SCREEN_REAL_ASSET_COMPOSITION.md
- ui/home-real-composition-config.json
- qa/step41-home-real-composition-qa.json
- concept/home-real.html/css/js

Step40 Art Pack وارد یک Home واقعی Responsive شد: HUD، Hero Stage، چهار Module، Rank، Start CTA و Bottom Nav پنج‌تایی canonical. قوانین 360–430px، 100dvh، safe-area و tight-height scaling قفل شدند.

---
## Step 42 — Home Interaction / Microstate / Hero Hub Entry
اضافه شد:
- STEP42_HOME_INTERACTION_MICROSTATE_HERO_HUB_ENTRY.md
- ui/home-interaction-config.json
- qa/step42-home-interactions-qa.json
- concept/home-step42.html/css/js

Home حالا interaction contract کامل دارد: Hero Hub entry، module routing، Rank detail، Start validation، duplicate guard، zero-task block، recoverable Match card و Resume/End safe flow.

---
## Step 43 — Pre-Battle Real Screen Composition
اضافه شد:
- STEP43_PRE_BATTLE_REAL_SCREEN_COMPOSITION.md
- gameplay/prebattle-real-config.json
- ui/prebattle-screen-config.json
- qa/step43-prebattle-qa.json
- concept/prebattle-real.html/css/js

Pre-Battle واقعی ساخته شد: Hero preview، Task Pool readiness، Rules Snapshot، سه‌لاین Map Preview، Zero-Task block، Asset error guard و initialization sequence تا Persist + Immersive entry.

---
## Step 44 — Battlefield Real Visual Composition
اضافه شد:
- STEP44_BATTLEFIELD_REAL_VISUAL_COMPOSITION.md
- gameplay/battlefield-visual-config.json
- qa/step44-battlefield-visual-qa.json
- concept/battlefield-real.html/css/js

میدان Portrait واقعی ساخته شد: سه Lane، شش Tower، دو Base، Minionها، Hero، Timer/Objectives HUD، Minimap نمایشی، Joystick، Context Action و Pause. حرکت Prototype نرم است و Minimap امکان Teleport ندارد.

---
## Step 45 — Battlefield Entity Art & States
اضافه شد: Generated Entity Art Board، Reference Cropهای Minion/Tower/Base/Objective/Minimap، State Contract و QA. تصاویر Reference از Final transparent runtime cutout جدا علامت‌گذاری شده‌اند.

---
## Step 46 — Entity Runtime Cutout & Battlefield Integration
اضافه شد: Runtime Entity Registry، Asset Slot Manifest، deterministic Tower/Base State Resolver، duplicate transaction guard و integration lab. Reference Art مرحله ۴۵ همچنان از Final transparent cutout جدا نگه داشته شده است.

---
## Step 47 — Task Encounter Real UI in Battlefield
Task Sheet فارسی RTL وارد Battlefield شد. Complete/Defer/Cancel، transaction lock، cinematic attack sequence، Tower damage، XP/Gold commit و Persian whole-word wrapping در Prototype اجرایی اضافه شدند.

---
## Step 48 — Attack Projectile Impact VFX Runtime
اضافه شد: quadratic projectile trajectory، distance-based duration، bounded impact particles، HP tween، entity-state sync، reward fly-up و Reduce Motion path. VFX فقط نمایشی است و state authoritative را تغییر نمی‌دهد.

---
## Step 49 — Tower & Base Destruction Cinematic Runtime
Tower1→Tower2→Lane Complete→Enemy Base progression به destruction commit متصل شد. Collision release، objective unlock، idempotent destruction/Victory و recovery from committed state تعریف و در Prototype اجرایی نمایش داده شدند.

---
## Step 50 — Match Victory / Time End / Manual Exit Results Integration
نقطه نیمه مسیر ۱۰۰ مرحله‌ای. سه نوع پایان Match به finalization idempotent، ledger aggregation، progression و Results Screen وصل شدند. Time End خنثی است، Manual Exit جریمه ندارد و Victory فقط با Enemy Base HP=0 ثبت می‌شود.

---
## Step 51 — Results Production Visual & Progression Ceremony
Results به Ceremony سینمایی ارتقا یافت: Result reveal، reward count-up نمایشی، XP progress، Level Up، Rank Up، Diamond positive-only و safe Home transition. Replay انیمیشن هیچ Reward یا progression جدیدی ایجاد نمی‌کند.

---
## Step 52 — Home Return State Refresh & Post-Match Loop
حلقه Match → Results → committed progression → Home Refresh → Next Match بسته شد. Home هیچ Reward را دوباره محاسبه نمی‌کند و HUD/Rank/Wallet را فقط از Player State ثبت‌شده Refresh می‌کند.

---
## Step 53 — Home Live HUD & Rank Card Production State
HUD و Rank Card Home به committed Player State contract متصل شدند. Loading بدون Wallet جعلی، atomic refresh، recoverable error، corrupt-state guard، XP clamp و Rank Detail routing اضافه شد.

---
## Step 54 — Home Module Cards Live Routing & State
چهار ماژول فروشگاه، رویدادها، آینده‌بینی و دستاوردها به route/state مستقل وصل شدند. Failure هر ماژول Home را خراب نمی‌کند، badgeها derived هستند و Bottom Nav همچنان دقیقاً پنج مورد است.

---
## Step 55 — Shop Live Data & Purchase Flow
Shop به wallet/ownership transaction contract وصل شد. Hero/Cosmetic فقط با Gold و Real-Life Reward فقط با Diamond؛ double-debit guard، insufficient balance guard، purchase/claim history و no-power rule اضافه شدند.

---
## Step 56 — Hero Hub Live Ownership & Equip Flow
Hero Hub به ownership واقعی Shop متصل شد. Hero locked/owned/selected، انتخاب persistable، per-Hero loadout، cosmetic ownership/compatibility، unequip و Home refresh contract اضافه شدند. Active Match همچنان Hero snapshot خودش را حفظ می‌کند.

---
## Step 57 — Hero Hub Production Visual Gallery
Hero Hub به composition نهایی‌تر گالری ارتقا یافت: full-body runtime slot، selected/owned/locked presentation، Hero identity، هفت Loadout slot، CTA وابسته به ownership و responsive 360–430. Runtime art contract همچنان transparent WebP و بدون CSS human silhouette است.

---
## Step 58 — Hero Asset Runtime Resolution & Fallback
یک Hero Asset Resolver مشترک برای Home، Hero Hub، Pre-Battle، Match و Results تعریف شد. Transparent WebP slots، preload groups، crop-safe metadata، fallback کنترل‌شده و active-Match asset snapshot اضافه شدند. Reference crops همچنان reference-only هستند.

---
## Step 59 — Gameplay Hero Animation State Machine
Hero Match به state machine قطعی Idle/Walk/Run/Attack/Hit/Victory/Recall متصل شد. Locomotion از velocity واقعی، facing هشت‌جهته، priority deterministic، Attack target-facing و Victory lock اضافه شدند. Animation هیچ HP/Reward transactionی را mutate نمی‌کند.

---
## Step 60 — Gameplay Hero Movement + Collision + Camera Follow
Joystick physics، acceleration/deceleration، delta clamp، circle collision با slide response، smooth camera follow، dead-zone/look-ahead و encounter/pause movement locks به Hero runtime متصل شدند. Tap-to-move و teleport همچنان ممنوع‌اند.

---
## Step 61 — Map Collision Geometry & Walkable Lane Mesh
سه Lane، سه Crossroad، Own/Enemy Base zone، blockerها، Tower colliderها، Enemy Base gate و nearest-valid-position recovery به collision runtime اضافه شدند. Tower collision فقط بعد از destruction commit آزاد می‌شود و Base gate بعد از کامل‌شدن حداقل یک Lane باز می‌شود.

---
## Step 62 — Objective Interaction Zones + Target Acquisition
Minion، Tower و Enemy Base به interaction radius، sticky target، eligibility، marker state و Task Encounter trigger وصل شدند. Locked Tower/Base targetable نیستند، فقط یک encounter هم‌زمان مجاز است و Defer/Cancel هیچ Damage یا Rewardی ایجاد نمی‌کنند.

---
## Step 63 — Minion Task Reservation + Spawn Runtime Integration
Wave scheduler به Task Pool واقعی متصل شد. هر actionable Minion دقیقاً یک reservation دارد، duplicate Task assignment ممنوع است، cap کل 6 و هر Lane حداکثر 2 Minion است. Defer تا پایان همان Match Task را کنار می‌گذارد، Cancel reservation را نگه می‌دارد و recovery orphanها امن است.

---
## Step 64 — Minion Movement + Lane Path Following
Minionهای رزروشده به path واقعی Lane متصل شدند: spawn، حرکت deterministic، waypoint progression، staging stop، focus lock، Cancel/Defer/Defeat و despawn lifecycle. Minion teleport و auto-combat ندارد و pause/resume مسیر را بدون jump حفظ می‌کند.

---
## Step 65 — Minion Visual States + Animation Runtime
حالت‌های Idle، Walk، Focused، Hit و Defeated به runtime متصل شدند. اولویت visual قطعی است، facing از velocity/target واقعی می‌آید و animation کاملاً display-only است؛ هیچ Task، Reward یا Progression را تغییر نمی‌دهد. Step45 همچنان reference art است و final transparent Minion cutout هنوز جداگانه تولید می‌شود.

---
## Step 66 — Minion Encounter + Defeat Full Transaction Pipeline
چرخه کامل Minion در یک pipeline idempotent بسته شد: Task commit → Attack visual → Defeat commit → Reward commit → Reservation complete → Despawn. هر مرحله transaction ID مستقل دارد و crash/retry یا callback تکراری نمی‌تواند Reward یا Completion را دوباره اعمال کند.

---
## Step 67 — Tower Encounter + Damage Transaction Pipeline
Tower pipeline کامل شد: Task commit → Hero attack visual → Damage commit -34 → HP state sync → Task reward → در HP صفر Destruction commit → bonus → collision release → Lane progression. Tower1 فقط Tower2 همان Lane را باز می‌کند و Tower2 همان Lane را Complete می‌کند. همه Damage/Reward/Destruction callbackها idempotent هستند.

---
## Step 68 — Tower Destruction Visual + Collision Release Runtime
Destruction Commit به چرخه visual واقعی وصل شد: fracture → core flash → collapse → debris → smoke → settled. Objective marker بعد از commit پاک می‌شود و Tower collider فقط با transaction مستقل Collision Release خاموش می‌شود؛ animation هرگز HP، Reward یا Lane Progression را تغییر نمی‌دهد. Recovery و Reduce Motion هم برای همین چرخه اضافه شدند.

---
## Step 69 — Tower2 + Lane Complete + Enemy Base Unlock Presentation
Tower2 destruction اکنون Lane همان مسیر را Complete می‌کند، completedLanes را idempotent به‌روزرسانی می‌کند و اولین Lane کامل‌شده می‌تواند Enemy Base را با transaction مستقل unlock کند. Base shield، gate collision، minimap marker و objective routing هم به state committed وصل شدند؛ هیچ حرکت یا Teleport اجباری وجود ندارد و Lane Complete/Base Unlock Reward اضافی نمی‌دهند.

---
## Step 70 — Enemy Base Encounter + Damage + Victory Transaction Pipeline
چرخه نهایی Objective بسته شد: Task commit → Hero attack → Base damage -25 → Base state → Task reward → در HP صفر Base destruction → Victory bonus (+400 XP / +150 Gold / +1 Diamond) → Victory commit → Result snapshot. Victory فقط از Enemy Base HP=0 می‌آید و همه damage/reward/victory transactionها idempotent هستند.

---
## Step 71 — Enemy Base Destruction + Victory Cinematic Runtime
Victory transaction قدم 70 به سینمای نهایی وصل شد: Base core overload → shield implosion → fracture → final collapse → shockwave → smoke → Hero victory → بنر «پیروزی» → verify/rebuild Result snapshot → Results. تمام Rewardهای Victory فقط نمایش داده می‌شوند و هیچ visual یا ceremony اجازه تغییر Ledger، Victory یا HP را ندارد.

---
## Step 72 — Match Timer + Wave Scheduler Full Runtime Integration
Timer واقعی ۳۰ دقیقه و Wave Scheduler هر ۴۵ ثانیه یکپارچه شدند. Timer timestamp-based است، Pause هر دو سیستم را freeze می‌کند، Task Encounter به‌صورت پیش‌فرض Timer را متوقف نمی‌کند و Background recovery بدون drift یا burst-spawn انجام می‌شود. Time End خنثی است، Rewardهای commit‌شده را حفظ می‌کند و با Victory از یک finalization lock مشترک استفاده می‌کند.

---
## Step 73 — Time End + Manual Exit Result Flow
دو مسیر غیر-Victory نهایی شدند. Time End و Manual Exit هر دو خنثی‌اند، هیچ penalty یا defeat wording ندارند و همه XP/Gold/Diamond و Bonusهای قبلاً commit‌شده را حفظ می‌کنند. Manual Exit confirmation اجباری است و result finalization برای Victory/Time End/Manual Exit یک lock مشترک دارد تا هیچ Match دو نتیجه نگیرد.

---
## Step 74 — Results Screen Full Production Data Binding
Victory، Time End و Manual Exit به یک Results Screen واحد متصل شدند. Reward/XP/Rank فقط از committed snapshot و ledger خوانده می‌شوند؛ count-up و progression کاملاً display-only هستند. Replay همیشه Match ID و transactionهای جدید می‌سازد و Home return سیستم‌بارها را برمی‌گرداند و Player State را بدون محاسبه مجدد Reward refresh می‌کند.

---
## Step 75 — Home Post-Result Celebration + Live Progression Refresh
بازگشت Results → Home به committed Player State وصل شد. Level، XP، Rank، Gold، Diamond و Hero از State واقعی Refresh می‌شوند؛ active Match نهایی پاک می‌شود و System UI حالت عادی می‌گیرد. Celebrationهای Rank/Level/Diamond/Victory فقط display-only هستند، حداکثر دو مورد نشان داده می‌شوند و Home را Block نمی‌کنند.

---
## Step 76 — Home Start Game Guard + Recoverable Match Flow
Start Game روی Home production-safe شد: Player/Hero/Task/Active Match validation، duplicate-tap guard و انتقال فقط به PreBattle. Match نیمه‌کاره هیچ‌وقت خودکار باز نمی‌شود؛ Home کارت «بازی نیمه‌کاره» با ادامه یا پایان امن نشان می‌دهد. Zero-task هیچ Task ساختگی تولید نمی‌کند و PreBattle همچنان تنها نقطه ساخت Match است.

---
## Step 77 — PreBattle Validation + Match Snapshot Hardening
PreBattle حالا تنها authority ساخت Match جدید است. Hero، Task Pool، Settings و Map قبل از ساخت Match validate و snapshot می‌شوند؛ Match ID و bootstrap transaction یکتا ساخته می‌شود، Match ابتدا atomic persist و read-back verify می‌شود و فقط بعد activeMatchId تنظیم می‌شود. Timer/Wave در PreBattle شروع نمی‌شوند و Gameplay روی bootstrap ناقص هرگز باز نمی‌شود.

---
## Step 78 — Gameplay Bootstrap + First Playable Frame
Match verified از PreBattle حالا به اولین Frame واقعاً قابل بازی تبدیل می‌شود. World/Entities/Hero/Camera/Collision/HUD ابتدا hydrate می‌شوند، سپس Immersive درخواست می‌شود و Match start commit تایمر و Wave Scheduler را فعال می‌کند. Controls آخرین بخش هستند که unlock می‌شوند؛ بنابراین هیچ input زودهنگام، reset شدن Timer یا Minion ساختگی وجود ندارد.

---
## Step 79 — Gameplay Live HUD + Objective Guidance Runtime
HUD داخل Match به MatchClock، committed ledger و entity/objective state واقعی متصل شد. Timer، XP/Gold/Diamond همین Match، هدف پیشنهادی، HP هدف و Minimap همگی فقط نمایش‌دهنده State معتبر هستند و هیچ‌کدام authority برای Reward، Damage یا Movement ندارند. Objective guidance صرفاً راهنماست؛ Minimap tap-to-move/teleport ندارد و Energy/Mana وجود ندارد.

---
## Step 80 — Minimap + Fog + Objective Marker Production Runtime
Minimap به World 1200×2600 متصل شد. Hero، Base، Towerها، Minionهای معتبر و Objective با projection واقعی نمایش داده می‌شوند. Fog سه حالت unseen/known/visible دارد و Minimap کاملاً display-only است؛ Tap-to-Move، Teleport یا تغییر Objective ندارد.

---
## Step 81 — Hero Vision Radius + Fog Reveal + Exploration Persistence
Fog حالا با حرکت واقعی Hero باز می‌شود. World روی Grid منطقی 40-unit تقسیم شده و هر Cell یکی از unseen/known/visible است. Static objectiveهای کشف‌شده روی Minimap dim باقی می‌مانند، اما Minionهای متحرک فقط وقتی واقعاً visible باشند نشان داده می‌شوند. Exploration روی Match persist می‌شود و Resume آن را Reset نمی‌کند.

---
## Step 82 — World Objective Proximity + Directional Compass Guidance
Objectiveهای unseen حالا فقط جهت هشت‌گانه و Distance Band می‌دهند و مختصات دقیق‌شان را لو نمی‌دهند. Objectiveهای known می‌توانند Marker کم‌رنگ و visibleها Marker دقیق داشته باشند. Guidance فقط پیشنهاد می‌دهد؛ Teleport، Auto-path، Forced Lane یا Objective mutation ندارد.

---
## Step 83 — Smart Objective Selection + Lane Choice Assist
بین Objectiveهای آزاد حالا سیستم Recommendation امتیازدهی می‌کند: فاصله، ارزش Progression، Task آماده، ادامه Lane و Fog familiarity. یک پیشنهاد اصلی و حداکثر دو Alternative نمایش داده می‌شود. Anti-flicker با Hold دوثانیه‌ای و Switch Threshold اضافه شد. تصمیم نهایی همیشه با بازیکن است؛ هیچ Forced Lane، Auto-path، Teleport یا Auto-unlock وجود ندارد.

---
## Step 84 — Objective Recommendation UI + World Edge Indicators
Recommendation هوشمند وارد HUD واقعی Gameplay شد: Objective Card، دلیل پیشنهاد، جهت/فاصله، حداکثر دو Alternative و Edge Arrow برای هدف خارج از Camera. انتخاب Alternative فقط Preference موقت است. Fog privacy، safe-area، anti-flicker و Reduce Motion حفظ شده‌اند؛ Teleport/Auto-path/Forced Lane وجود ندارد.

---
## Step 85 — Task Encounter Final Mobile UX Polish
Task Encounter برای موبایل واقعی نهایی شد: RTL کامل، wrap صحیح متن فارسی، محتوای بلند scrollable با action bar ثابت، دکمه‌های حداقل 48dp، Safe Area، Double-tap Guard و Reward Preview غیر-authoritative. انجام شد فقط بعد از Task commit موفق وارد Combat handoff می‌شود؛ بعداً/لغو هیچ Reward یا Damage ندارند.

---
## Step 86 — Task Encounter → Combat Handoff Cinematic Polish
بعد از Task Commit موفق، انتقال به Combat حالا Sequence کامل دارد: Sheet Exit → Camera Refocus → Hero Face Target → Attack Windup → Projectile → Impact → Entity Commit → HP Feedback → Reward Commit/Fly-up → Objective Refresh → Movement Resume. Projectile/Impact فقط Visual هستند و هیچ Damage یا Reward نمی‌سازند. Recovery و Reduce Motion نیز تعریف شده‌اند.

---
## Step 87 — Live Wave Spawn + Real Task Minion Battlefield Integration
Wave Scheduler حالا به Task Reservation و Minion entity واقعی متصل شد. اولین Wave پیش‌فرض در 45 ثانیه است و هیچ موج ساختگی فوری نداریم. قبل از Spawn ظرفیت 6 Minion سراسری/2 Minion هر Lane بررسی می‌شود؛ هر Minion دقیقاً Reservation یک Task واقعی دارد و سپس با Step64 روی Lane حرکت می‌کند، Fog/Minimap را رعایت می‌کند و Encounter آن از Step62/66/86 عبور می‌کند. Recovery موج‌های از دست‌رفته را burst نمی‌کند.

---
## Step 88 — Live Minion Crowd + Path Separation + Collision Polish
حرکت چند Minion همزمان حالا Lane-aware است: Spawn Stagger پیش‌فرض 220ms، فاصله مطلوب 42u، حداقل فاصله 28u، Lateral Offset قطعی -8/0/+8، کاهش نرم سرعت پشت Minion جلویی و جلوگیری از Overtake. Minion Focused می‌ایستد و Minionهای پشت سر Slow می‌شوند؛ Minionهای مخفی زیر Fog همچنان Simulate می‌شوند. هیچ Teleport یا Hero-push وجود ندارد.

---
## Step 89 — Multi-Target Priority + Sticky Target + Encounter Lock
وقتی چند Entity نزدیک Hero هستند فقط یک Target انتخاب می‌شود. اولویت: Active Encounter → Sticky Target → Minion واقعی → Tower → Enemy Base. Hysteresis +1.5 از Flicker جلوگیری می‌کند و Match-level Encounter Lock اجازه بیش از یک Task Sheet را نمی‌دهد. Cancel دارای Cooldown 700ms است؛ Complete تا پایان Combat Handoff Lock را نگه می‌دارد.

---
## Step 90 — Full Playable Match Loop Integration Test
برای اولین بار کل حلقه بازی به شکل End-to-End یکپارچه شد: Home → PreBattle → Gameplay → Wave → Real Task Minion → Combat → Tower → Lane Complete → Enemy Base → Victory/Time End/Manual Exit → Results → Home Refresh. Authority هر بخش مشخص است و تمام Guardهای جلوگیری از Fake Task/Minion، Duplicate Match/Damage/Reward/Victory و Stacked Encounter حفظ شده‌اند. این Step معیار Playable Loop قبل از Failure Injection و APK production hardening است.

---
## Step 91 — Failure Injection + Crash Recovery QA
Crash/Background/Double Tap/Storage Failure در نقاط حساس Match مدل‌سازی شد. Transaction Journal و Idempotency Gate مشخص می‌کنند state ثبت‌شده هرگز دوباره اجرا نشود. Task، Damage، Reward، Wave، Encounter و Victory پس از Recovery تکرار نمی‌شوند؛ Storage failure هم UI را به‌اشتباه جلو نمی‌برد. Process Death همچنان ابتدا Home را باز می‌کند و Match نیمه‌کاره فقط به‌صورت Recoverable Card نمایش داده می‌شود.

---
## Step 92 — Performance + 60FPS + Memory + Thermal Optimization
Gameplay برای Android واقعی بهینه شد: 60FPS هدف اصلی و 30FPS fallback، dt clamp تا 50ms، Minion logic در 30Hz، Fog threshold=10u و throttle=150ms، Minimap Hero throttle=90ms، VFX/Minion Pool، visibility culling، DPR cap=2 و توقف کامل RAF در Background. سه Quality Tier داریم: High / Balanced / Battery؛ تغییر Tier فقط ظاهر را سبک‌تر می‌کند و هیچ Reward، Damage، Timer یا Wave Rule را تغییر نمی‌دهد.

---
## Step 93 — Android Safe Area + System Bars + Immersive Final Hardening
رفتار Android نهایی شد: تمام صفحات عادی با Status/Navigation Bar قابل‌مشاهده و Safe Area-aware اجرا می‌شوند، اما فقط Gameplay وارد Immersive Fullscreen می‌شود. در Task Encounter، Pause و Victory Cinematic حالت Immersive حفظ می‌شود و قبل از Results/Return Home System Bars فوراً Restore می‌شوند. `100dvh`، safe-area env tokens، Gesture Navigation padding و native WindowInsetsController/IMMERSIVE_STICKY contract نیز اضافه شد.

---
## Step 94 — Real Android App Shell + Capacitor Project Structure Hardening
Project حالا ساختار واقعی Vite + Capacitor + Android دارد: `package.json`، `capacitor.config.ts`، `android/`، Manifest، Gradle config، Java 17، package `com.shahriar.game`، portrait lock، native Immersive plugin و build script Debug APK اضافه شده‌اند. `.gitignore` هم keystore/build/node_modules را خارج می‌کند. Workflow فعلی scaffold است و در Stepهای پایانی GitHub/APK hardening نهایی می‌شود.

---
## Step 95 — Real App Entry + Router + Persistent App State Bootstrap
App Entry واقعی اضافه شد. Hash Router حالا Home، Tasks، Stats، Timesheet، Networking و تمام Secondary routeها را کنترل می‌کند. Fresh Launch همیشه Home است و Route قبلی persist نمی‌شود. Store مشترک با Local Persistence اضافه شده و Player/Tasks/Network Tree/Timesheet/CRM/Settings/Active Match را نگه می‌دارد. Bottom Nav دقیقاً پنج آیتم دارد، Gameplay آن را مخفی می‌کند و Stats فقط Network Tree است. Quick Task و Quick Prospect هم واقعاً State مشترک را تغییر می‌دهند و بعد از Reload باقی می‌مانند.

---
## Step 96 — Primary Modules Persistent UI Hardening
چهار ماژول اصلی داده‌ای از Shell اولیه خارج شدند: Tasks حالا Add/Archive/Delete/Active Toggle/Search و Reward fields دارد؛ Stats فقط Network Tree است و Add/Delete/Reparent/Search دارد؛ Timesheet ثبت بازه زمانی/Complete/Delete دارد؛ Networking CRM هم Prospect + Action Timeline با پنج Action Type اصلی دارد. تمام Mutationها از AppStore می‌گذرند و بعد از Reload باقی می‌مانند. Bottom Nav همچنان دقیقاً پنج آیتم است و Energy/Mana وجود ندارد.

---
## Step 97 — Secondary Modules Real UI + Persistent State
Shop، Events، Vision، Achievements، Hero Hub و Settings از Placeholder خارج شدند. Heroها فقط با Gold خرید/انتخاب می‌شوند و هیچ قدرت Gameplay ندارند؛ Real Reward فقط با Diamond Claim می‌شود. Event/Vision CRUD و Progress اضافه شد، Achievement Claim به Player State وصل شد، Hero Selection persist می‌شود و Settings شامل Match Duration، Wave Interval، Quality Tier، Reduce Motion و Left-Hand Mode است. هیچ‌کدام به Bottom Nav اضافه نشده‌اند.

---
## Step 98 — Live Match Orchestrator + Real Gameplay Route Wiring
Gameplay از Placeholder خارج شد و به `LiveMatchOrchestrator` واقعی متصل شد. Home فقط PreBattle را درخواست می‌کند، PreBattle Match persisted می‌سازد و Gameplay همان Match را mount می‌کند. Timer، Wave، Real Task Minion، Encounter، Minion/Tower/Base transaction، Reward ledger، Victory/Time End، Results و Return Home اکنون در یک Coordinator مشترک به AppStore/Router وصل شده‌اند. Gameplay route Bottom Nav ندارد و Results از `resultSnapshot` committed می‌خواند. Visualهای میدان هنوز runtime ساده‌اند و Production art در مرحله نهایی جایگزین می‌شود.

---
## Step 99 — GitHub Actions + Gradle + Capacitor APK Build Hardening
Workflow نهایی Debug APK اضافه شد. Repository بعد از Upload روی GitHub می‌تواند با Node 22 + Java 17، `npm ci`، Vite build، `npx cap sync android` و `./gradlew assembleDebug` فایل `app-debug.apk` بسازد و آن را به‌عنوان Artifact با نام `shahriar-game-debug-apk` منتشر کند. Release keys و signing secrets داخل Repository قرار نمی‌گیرند.

---
## Step 100 — Final Release Handoff + Audit
طراحی ۱۰۰ قدمی تکمیل شد. بسته نهایی شامل Source Project، Android/Capacitor shell، Router/State، ماژول‌های اصلی و فرعی، Live Match Orchestrator، QA، GitHub Actions و راهنمای ساخت APK است. Fresh Launch همیشه Home، Bottom Nav دقیقاً پنج مورد، Stats فقط Network Tree و Gameplay تنها بخش Immersive است. این بسته سورس نهایی است؛ APK واقعی باید در GitHub Actions/Android SDK کامپایل شود.
