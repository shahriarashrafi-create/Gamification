# SHAHRIAR GAME — 100 STEP REBUILD
## STEP 15 — ACHIEVEMENTS / HONOR HALL

این سند مرجع رسمی ماژول «دستاوردها» است.

---

# 1. هویت ماژول

Achievements باید حس یک Honor Hall / Trophy Vault سینمایی داشته باشد.

نه Checklist ساده.
نه جدول امتیاز.

هدف:
تبدیل پیشرفت واقعی کاربر به مجموعه‌ای از افتخارات قابل دیدن و Claim.

---

# 2. Entry Point

دستاوردها:
از Home secondary module

نه Bottom Nav.

---

# 3. Achievement Periods

چهار گروه اصلی:

- daily
- weekly
- monthly
- long_term

فارسی:

- روزانه
- هفتگی
- ماهانه
- بلندمدت

---

# 4. Achievement Model

Achievement:

- id
- title
- description
- period
- metricType
- targetValue
- currentValue
- state
- rewardXP
- rewardGold
- rewardDiamond
- badgeIcon
- priority
- active
- createdAt
- updatedAt

---

# 5. States

Canonical states:

- locked
- progress
- ready
- claimed

فارسی:

- قفل
- در حال پیشرفت
- آماده دریافت
- دریافت‌شده

---

# 6. Locked

locked:
هنوز شرط فعال‌شدن فراهم نشده.

مثال:
دستاوردی که بعد از Level 30 باز می‌شود.

---

# 7. Progress

progress:
فعال است ولی هنوز کامل نشده.

---

# 8. Ready

ready:
شرط کامل شده
ولی Reward هنوز Claim نشده.

---

# 9. Claimed

claimed:
Reward دریافت شده.

Claim دوباره:
غیرممکن.

---

# 10. Progress Formula

Default:

progressPercent =
currentValue / targetValue * 100

Visual clamp:
0–100%

---

# 11. Auto Ready Rule

اگر:

currentValue >= targetValue
و state != claimed

State:
ready

---

# 12. Claim Rule

Claim فقط وقتی:

state == ready

باشد.

---

# 13. Reward Types

Achievement می‌تواند بدهد:

- XP
- Gold
- Diamond

هر سه قابل تنظیم.

---

# 14. Diamond Rule

Diamond:
rare

برای Achievementهای کوچک:
معمولاً 0

برای Milestoneهای مهم:
ممکن است > 0

---

# 15. Atomic Claim

Claim transaction:

1. validate ready
2. validate not claimed
3. add reward
4. set claimed
5. create claim history
6. persist

همه باید atomic باشد.

---

# 16. Double Claim Guard

اگر claimed:
Reward دوباره داده نشود.

---

# 17. Claim History

Record:

- id
- achievementId
- titleSnapshot
- rewardSnapshot
- claimedAt

---

# 18. Snapshot

Reward history:
باید Snapshot باشد.

اگر Reward بعداً تغییر کرد:
Claim قبلی تغییر نکند.

---

# 19. Daily Achievements

Examples:

- تکمیل ۳ Task
- ۱ Match کامل
- ۵ Networking Action
- ۳۰ دقیقه مطالعه

---

# 20. Weekly Achievements

Examples:

- ۲۰ Task
- ۵ Match
- ۱۰ Follow-up
- ۳ روز برنامه کامل

---

# 21. Monthly Achievements

Examples:

- ۸۰ Task
- ۲۰ Match
- ۵۰ Networking Action
- رسیدن به یک Rank milestone

---

# 22. Long-Term Achievements

Examples:

- Level 50
- 1000 Task
- 100 Victory
- 100 Network Members
- Major Vision Goal

---

# 23. Achievement CRUD

User/Admin can:

- Add
- Edit
- Delete
- Activate/Deactivate

Delete:
confirmation.

---

# 24. Metric Types

Examples:

- tasks_completed
- matches_completed
- victories
- networking_actions
- followups
- towers_destroyed
- level
- rank_score
- network_members
- vision_goals_achieved
- custom_manual

---

# 25. Manual Metric

custom_manual:
currentValue manually editable

برای هدف‌هایی که سیستم نمی‌تواند خودکار محاسبه کند.

---

# 26. Derived Metric

System metric:
currentValue از داده‌های واقعی اپ می‌آید.

Future:
event-driven update.

---

# 27. Period Bounds

Daily:
current day

Weekly:
Saturday → Friday

Monthly:
Persian calendar month future

Long-term:
no reset

---

# 28. Rollover

Daily/Weekly/Monthly:
در پایان دوره reset/rollover می‌شوند.

Claim history:
باقی می‌ماند.

---

# 29. Period Instance

Future-safe model:

Achievement Template
+
Period Instance

برای جلوگیری از خراب شدن History.

---

# 30. Template vs Instance

Template:
تعریف Achievement

Instance:
پیشرفت همان روز/هفته/ماه

Long-term:
ممکن است مستقیم روی Template state کار کند.

---

# 31. Claim Window

Default:
Ready Reward بعد از پایان دوره هم قابل Claim باشد.

Future setting:
claimExpiry

---

# 32. No Negative Reward

Failing Achievement:
جریمه ندارد.

Currency:
کم نمی‌شود.

Rank:
کم نمی‌شود.

---

# 33. Visual Card

Achievement Card:

- Badge
- Title
- Period
- Progress
- Reward
- State
- Claim CTA if ready

---

# 34. Locked Visual

Muted
dark
chain/lock motif

---

# 35. Progress Visual

Cyan progress rail

---

# 36. Ready Visual

Gold glow

Subtle pulse

CTA:
`دریافت پاداش`

---

# 37. Claimed Visual

Honor seal
Muted completed state

---

# 38. Period Tabs

Top:

روزانه
هفتگی
ماهانه
بلندمدت

---

# 39. Search

Search:

- title
- description
- metricType

---

# 40. Filter

Optional:

- همه
- آماده دریافت
- در حال پیشرفت
- دریافت‌شده

---

# 41. Sort

Default:
ready first

Then:
progress descending

Then:
priority

---

# 42. Empty State

Copy:
«دستاوردی در این بخش تعریف نشده.»

CTA:
`ساخت دستاورد`

---

# 43. Reward Preview

Show:

+XP
+Gold
+Diamond

No hidden reward.

---

# 44. Claim Feedback

Sequence:

button lock
→ badge flare
→ XP/Gold/Diamond fly-up
→ state claimed
→ wallet update

No gambling effects.

---

# 45. Home Integration

Home Achievements module can show:

- ready-to-claim count
- nearest achievement

Compact only.

---

# 46. Performance

100+ achievement templates:
smooth filter/list

---

# 47. Mobile

360px:
single-column cards

CTA always visible.

---

# 48. RTL

All text:
RTL

Rewards:
numeric safe

---

# 49. Example Achievement

Title:
فرمانده پیگیری

Period:
weekly

Metric:
followups

Target:
10

Current:
8

Reward:
150 XP
80 Gold
0 Diamond

State:
progress

---

# 50. Quality Gate

Achievements PASS اگر:

- 4 period type داشته باشد
- 4 state داشته باشد
- Progress محاسبه شود
- Ready auto شود
- Claim فقط در Ready ممکن باشد
- Double Claim غیرممکن باشد
- Reward Snapshot حفظ شود
- CRUD کامل باشد
- no penalty باشد
- ظاهر Honor Hall داشته باشد
- هیچ Energy وجود نداشته باشد

---

# STEP 16

SETTINGS / SYSTEM CONTROL

در قدم ۱۶:
- gameplay settings
- economy settings
- rank settings
- player profile
- task categories
- match duration
- reward rules
- hero/customization access
طراحی می‌شود.
