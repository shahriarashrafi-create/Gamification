# STEP 62 — OBJECTIVE INTERACTION ZONES + TARGET ACQUISITION

این مرحله Minion، Tower و Base را به interaction radius، current target، objective marker و Task Encounter trigger واقعی وصل می‌کند.

## Objective Types

minion_task
tower
enemy_base

## Interaction Radius

minion: 5.5 world units
tower: 7.0
enemy_base: 7.5

Exit hysteresis:
trigger radius + 1.5

Hero وقتی وارد radius می‌شود:
eligible targets محاسبه می‌شوند.

## Eligibility Priority

1. Current sticky target if still valid
2. Minion task in immediate proximity
3. Current unlocked Tower
4. Enemy Base if unlocked
5. Nearest eligible objective

Locked Tower2 و locked Enemy Base targetable نیستند.

## Target Score

distance
objective priority
current lane affinity
sticky target bonus
visibility
locked state

## Sticky Target

Target بعد از انتخاب، تا زمانی که:
out of exit radius
destroyed/defeated
locked
encounter resolved
invalidated by progression

حفظ می‌شود.

## Objective Marker

States:
available
focused
locked
completed

Marker فقط visual state است.
Progression source authoritative نیست.

## Minion Trigger

Approach actionable Minion
→ focus marker
→ soft stop
→ open real Task Encounter

یک Minion actionable دقیقاً یک reserved real task دارد.

## Tower Trigger

Approach unlocked Tower
→ focus
→ open Task Encounter
→ Complete Task
→ attack sequence
→ committed damage -34

## Enemy Base Trigger

Base only targetable after at least one complete lane.
Complete Task
→ attack
→ committed damage -25.

## Encounter Guards

No double encounter.
One active target at a time.
One active task sheet at a time.
Target invalidation closes safely without reward duplication.

## Defer

Minion Task Defer:
task excluded for current Match
minion loses actionable reservation
target clears
Hero resumes

Tower/Base Defer:
current encounter closes
objective remains available

## Cancel

No reward
No damage
Target may remain available after cooldown.

## Line of Interaction

Target must:
be within radius
not be behind blocking geometry when LOS check enabled
be in same interaction region

## Camera

On focus:
slight target bias
no snap
no teleport

## Input Priority

modal
task encounter
critical cinematic
pause
context action
joystick
world

## QA

nearest eligible target selected
sticky target stable
locked Tower2 ignored
locked Base ignored
Minion opens task encounter
Tower opens task encounter
Base opens only when unlocked
one active encounter only
Defer no reward/damage
Cancel no reward/damage
marker does not mutate progression
no teleport
no Energy

## STEP 63

MINION TASK RESERVATION + SPAWN RUNTIME INTEGRATION

Minion wave system را به task reservation واقعی، spawn/despawn، defer release و duplicate prevention وصل می‌کنیم.
