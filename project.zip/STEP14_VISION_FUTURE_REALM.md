# SHAHRIAR GAME — 100 STEP REBUILD
## STEP 14 — VISION / FUTURE REALM

این سند مرجع رسمی ماژول «آینده‌بینی» است.

---

# 1. هویت ماژول

Vision باید حس یک Future Realm / Vision Board سینمایی داشته باشد.

نه جدول هدف.
نه فرم مالی خشک.

هدف:
کاربر بتواند آینده‌ای که می‌خواهد بسازد را ببیند، ثبت کند و پیشرفت آن را دنبال کند.

---

# 2. Entry Point

آینده‌بینی:
از Home secondary module

نه Bottom Nav.

---

# 3. Vision Goal Model

Vision Goal:

- id
- title
- year
- category
- targetValue
- currentValue
- unit
- progressPercent
- imageUrl
- note
- status
- priority
- createdAt
- updatedAt

---

# 4. Year Grouping

Goals باید بر اساس سال گروه‌بندی شوند.

Examples:

2026
2027
2028
2030

Year:
editable

---

# 5. Categories

Suggested categories:

- مالی
- شغلی
- شبکه
- دارایی
- سبک زندگی
- سفر
- رشد فردی
- خانواده
- سلامت
- شخصی

Editable later.

---

# 6. Goal Types

Goal می‌تواند نماینده:

- Asset
- Income target
- Rank/Business outcome
- Lifestyle
- Travel
- Purchase
- Experience
- Personal achievement

باشد.

---

# 7. Target Value

targetValue:
optional number

Examples:
- 1,000,000,000 تومان
- 10,000 GPV
- 3 سفر
- 1 خانه

---

# 8. Current Value

currentValue:
optional number

Progress:
current / target

---

# 9. Manual Progress

اگر Goal عددی نیست:
manual progress percent

Future schema-compatible field:
progressMode

- numeric
- manual

---

# 10. Unit

Examples:
- تومان
- GPV
- نفر
- عدد
- سفر
- درصد

Editable text.

---

# 11. Progress

Numeric mode:

progressPercent =
currentValue / targetValue * 100

Visual clamp:
0–100%

Raw overachievement can exceed 100%.

---

# 12. Image

imageUrl / asset:
optional

Purpose:
make Vision visual.

Final implementation:
local image picker or remote URL depending architecture.

---

# 13. Card Design

Vision Card:

- image/background
- year
- category
- title
- progress
- target
- note preview

---

# 14. Visual Hierarchy

1. Dream/Goal image
2. Title
3. Year
4. Progress
5. Target
6. Note

---

# 15. Status

Default:

- planned
- active
- achieved
- paused

Persian:

برنامه‌ریزی‌شده
فعال
تحقق‌یافته
متوقف

---

# 16. Achieved

Goal achieved:
special visual seal

But:
goal remains in history

---

# 17. Priority

priority:

- low
- medium
- high
- core

Purpose:
sort and focus

No game punishment.

---

# 18. CRUD

User can:

- Add
- Edit
- Delete
- Achieve
- Pause
- Reactivate

Delete:
confirmation.

---

# 19. Add Goal Form

Fields:

- title
- year
- category
- target value
- current value
- unit
- image URL
- note
- status
- priority

---

# 20. Edit Goal

All fields editable.

Past achieved timestamp future optional.

---

# 21. Delete Goal

Delete:
confirmation

Preferred future:
archive instead of hard delete

---

# 22. Year Tabs

Top:
horizontal year chips

Example:

2026 | 2027 | 2028 | همه

---

# 23. Category Filter

Optional compact filter:
category

No dashboard overload.

---

# 24. Search

Search:

- title
- category
- note

---

# 25. Sort

Default:
priority + progress

Alternatives:
year
newest
progress
target value

---

# 26. Heroic Visual Language

Dark horizon

Portal / distant city / mountain / estate / travel scene

Gold/cyan frame

Subtle particles

---

# 27. Empty State

Copy:
«هنوز تصویری از آینده‌ات ثبت نکرده‌ای.»

CTA:
`اولین Vision را بساز`

---

# 28. Goal Detail

Tap Card:

open immersive detail sheet

- full image
- title
- target
- current
- progress
- note
- edit

---

# 29. Update Progress

Quick:
`به‌روزرسانی پیشرفت`

Numeric:
edit current value

Manual:
edit percent

---

# 30. Achieve Action

Action:
`تحقق یافت`

Sets:
status = achieved

Progress visual:
100%

No automatic Diamond reward by default.

---

# 31. Vision ↔ Achievement

Future:
Goal achieved can trigger Achievement.

Not automatic unless configured.

---

# 32. Vision ↔ Shop

Future:
Real reward can be linked to Goal milestone.

Not automatic.

---

# 33. Vision ↔ Tasks

Future:
Goal can have linked Tasks.

Step 14:
relationship conceptual only.

---

# 34. Vision ↔ Timesheet

Future:
Goal milestones can generate weekly actions.

No auto-scheduling now.

---

# 35. No Direct Reward

Updating/achieving Vision:
does not automatically award Gold/Diamond/XP.

Reward rules must be explicit elsewhere.

---

# 36. No Negative Progression

Paused Goal:
no penalty.

Missed year:
no currency/rank loss.

---

# 37. Data Persistence

Goals:
persistent

Selected year:
UI state

---

# 38. Image Handling

If image fails:
fallback cinematic placeholder

No broken card.

---

# 39. Card Ratio

Mobile:
image ratio approx 16:9 or 4:3

Text below/overlay readable.

---

# 40. Mobile Layout

360px:
single-column cards

390+:
single-column premium cards preferred

Vision is visual, not dense grid.

---

# 41. Safe Area

Full-screen module:
top/back safe
bottom safe

No fixed Bottom Nav.

---

# 42. RTL

Text:
RTL

Numbers:
safe

Year:
LTR-neutral

---

# 43. Accessibility

Image alt/fallback

Text + progress labels

Touch:
44dp+

---

# 44. Performance

Lazy-load images future.

Limit heavy blur.

---

# 45. Example Goal

Title:
خرید خانه شخصی

Year:
2028

Category:
دارایی

Target:
15,000,000,000

Current:
3,200,000,000

Unit:
تومان

Progress:
21%

---

# 46. Example Goal 2

Title:
سفر اروپا

Year:
2027

Category:
سفر

Progress:
40%

Image:
optional

---

# 47. Step 14 Locked Structure

Header

Year tabs

Search/filter

Vision cards

Goal CRUD

Progress update

Achieve/Pause

Detail sheet

---

# 48. Visual Quality Rule

Vision must feel:
aspirational
premium
cinematic

not:
spreadsheet
CRM
financial dashboard

---

# 49. Home Integration

Home Vision module can show:

- current core goal
- current progress
- next milestone

Compact only.

---

# 50. Quality Gate

Vision PASS اگر:

- Goal CRUD کامل باشد
- Year grouping باشد
- Category باشد
- target/current/progress باشد
- imageUrl باشد
- note باشد
- achieved/paused باشد
- Search/Filter کار کند
- no direct reward باشد
- ظاهر Vision Board سینمایی باشد
- هیچ Energy وجود نداشته باشد

---

# STEP 15

ACHIEVEMENTS / HONOR HALL

در قدم ۱۵:
- daily / weekly / monthly / long-term
- locked / progress / ready / claimed
- CRUD
- claim rewards
- progress rules
طراحی می‌شود.
