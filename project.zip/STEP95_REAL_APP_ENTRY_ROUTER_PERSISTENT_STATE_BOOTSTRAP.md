# STEP 95 — REAL APP ENTRY + ROUTER + PERSISTENT APP STATE BOOTSTRAP

این مرحله اولین App Entry واقعی را می‌سازد.

هدف:
Home، Tasks، Stats، Timesheet و Networking به یک Router واقعی و App State مشترک وصل شوند.

## Launch Rule

هر Fresh Launch:
Home

Route قبلی ذخیره نمی‌شود.

اگر Match نیمه‌کاره وجود داشته باشد:
Home باز می‌شود
و Recoverable Match Card نمایش داده می‌شود.

Gameplay هیچ‌وقت Fresh Launch route نیست.

## Canonical Bottom Navigation

دقیقاً پنج مورد:

خانه
کارها
آمار
تایم‌شیت
شبکه‌سازی

هیچ آیتم ششم اضافه نمی‌شود.

## Routes

Primary:
/
#/home
#/tasks
#/stats
#/timesheet
#/networking

Secondary:
#/shop
#/events
#/vision
#/achievements
#/hero
#/settings
#/prebattle
#/gameplay
#/results

## Router Rules

Bottom Nav:
فقط Primary routes

Secondary routes:
از Home/Card/Action

Gameplay:
Bottom Nav hidden

Stats:
فقط Network Tree

## App State

Global state domains:

player
tasks
networkTree
timesheet
networking
settings
navigation
activeMatch
ui

## Persistence

Step95 uses a local persistence adapter.

Storage version:
95

Persist:

player
tasks
networkTree
timesheet
networking
settings
activeMatch reference

Do NOT persist:
current route
temporary modal
toast
open sheet
visual animation state

## State Hydration

App startup:

load persisted state
validate schema
merge safe defaults
force route Home
render Home

If hydration fails:
safe defaults for non-financial UI domains
wallet/progression corruption must not silently become zero

For Step95 shell:
player default is only used for first install.

## State Store

Store API:

getState()
setState(updater)
subscribe(listener)
hydrate()
persistDomain(domain)

State mutations remain centralized.

## Router

Hash-based router for current Vite/Capacitor shell.

Benefits:
simple
offline
works inside WebView
no server rewrite needed

## Main Entry

main.js:

create store
hydrate
create router
bind shell
force Home
start render

## Primary Screen Shells

Step95 implements executable shells for:

Home
Tasks
Stats / Network Tree
Timesheet
Networking

They are still early production shells,
but routes and shared state are real.

## Home

Shows:

player name
level
XP
Gold
Diamond
rank
Start Game button
four secondary module buttons
five-item bottom nav

No Energy.
No Friend List.
No Main Mission strip.

## Tasks

Shows real Task state list.

Can add a simple Task.
Can mark active/inactive.

Full advanced Task UI remains based on Step08.

## Stats

Shows only Network Tree shell.

No charts.
No KPI dashboard.

## Timesheet

Shows weekly planner shell.

## Networking

Shows CRM action shell.

## Secondary Screens

Shop
Events
Vision
Achievements
Hero Hub
Settings

Step95 provides route placeholders bound to same shell.

## Navigation State

Navigation state is runtime-only.

Fresh launch does not restore previous route.

## Active Match

If persisted active Match exists and is recoverable:

Home gets a recoverable card.

Resume action:
routes to gameplay only after validation.

New Start:
blocked while recoverable Match exists.

## Data Safety

Do not overwrite valid persisted state with defaults.

First install:
defaults allowed.

Corrupt critical Player progression:
show recovery state.

## RTL

Entire shell:
dir=rtl

## QA

fresh launch always Home
current route not persisted
bottom nav exactly five
Home route works
Tasks route works
Stats route works
Timesheet route works
Networking route works
secondary routes work
Gameplay hides app bottom nav
Stats shows tree only
shared Player state visible on Home
Task add mutates shared state
state survives app reload
route resets Home after reload
recoverable Match card can appear on Home
new Match blocked if active recoverable Match
no Energy
no Mana

## STEP 96

REAL TASK CRUD + NETWORK TREE + TIMESHEET + CRM PERSISTENT UI HARDENING

پنج بخش اصلی را از shell اولیه به UI قابل استفاده و persistent واقعی ارتقا می‌دهیم.
