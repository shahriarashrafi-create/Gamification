# STEP 88 — LIVE MINION CROWD + PATH SEPARATION + COLLISION POLISH

این مرحله حرکت چند Minion همزمان را روی سه Lane حرفه‌ای می‌کند.

## Goal

وقتی چند Minion در یک Lane حرکت می‌کنند:

روی هم نیفتند
داخل هم نروند
در Spawn یک‌جا ظاهر نشوند
حرکت‌شان مصنوعی و رباتیک دیده نشود
اما Path اصلی Lane را ترک نکنند

## Principles

Minion movement remains path-following.
Separation is a local visual/movement correction, not free roaming.

No teleport.
No physics chaos.
No Minion pushing Hero.

## Spawn Stagger

Minions from same Wave should not visually pop at same millisecond.

Suggested stagger:
180–260ms between Minions in same Lane.

Across different Lanes:
can overlap slightly.

Default:
220ms.

Spawn transaction remains atomic/persisted first.
Stagger affects only visual activation timing.

## Forward Spacing

Each Minion keeps preferred longitudinal spacing from Minion ahead.

Default:
preferredGap = 42 world units
minimumGap = 28 world units

If too close:
reduce speed smoothly.

Never reverse because of spacing.

## Lane Lateral Offset

To avoid exact pixel overlap:

Each Minion receives a small deterministic lateral lane offset.

Suggested:
-8
0
+8 world units

Offset must remain inside lane corridor.

Deterministic by Minion ID.

No random drift every frame.

## Separation

Nearby Minions can apply a small local separation force.

Radius:
34 world units

Max correction:
6 world units

Correction should mostly affect lateral offset.

Do not break path progression order.

## Path Order

Minions in same Lane should maintain stable order.

A trailing Minion should not overtake the leading Minion during normal movement.

If recovery positions overlap:
resolve with safe forward/back spacing without teleport animation.

## Speed

Base Step64 speed:
2.4 world units/sec

Dynamic crowd factor:
1.0 normal
0.85 approaching another Minion
0.65 very close

Minimum moving factor:
0.55

Do not stop permanently unless focused/paused.

## Focused Minion

When Task Encounter focuses one Minion:

that Minion stops.

Following Minions:
slow down / maintain spacing.

They do not pass through focused Minion.

## Defeated / Despawned

Once Minion defeat commit is authoritative:
remove it from spacing graph.

Following Minions smoothly regain normal speed.

## Collision

Minion-Minon collision:
soft separation only.

Minion-Hero:
no hard physical blocking.

Minion-Tower/Map:
respect path/walkable geometry.

## Fog

Crowd simulation continues for persisted Minions even if hidden by Fog.

Visual rendering:
only currently visible Minions.

Hidden Minions should not freeze merely because they are hidden.

## Pause

Pause freezes path progress and separation updates.

Resume continues smoothly.

## Background

Match background behavior follows Step72 lifecycle.

Minion path state reconciles on return.
Do not animate all missed movement frame-by-frame.

## Recovery

Persist:
pathProgress
laneId
ordering key
lateralOffsetSeed
movementState

On recovery:
rebuild ordered Lane groups
repair overlaps conservatively
continue.

## Performance

Max 6 active Minions total.

O(n²) local separation is acceptable at this cap,
but lane grouping is preferred.

Update movement:
60fps render
logic can run fixed 30Hz.

## QA

same-lane Minions do not visually overlap
spawn uses stagger
spawn stagger does not delay persistence
preferred gap maintained
minimum gap protected
trailing Minion does not overtake leading Minion
focused Minion blocks following Minions softly
following Minions slow instead of clipping through
lateral offsets deterministic
lateral offsets stay inside Lane
separation does not leave path corridor
defeated Minion removed from spacing graph
hidden Minions continue simulation
Pause freezes crowd movement
Resume continues smoothly
Recovery repairs overlaps
no teleport
no Hero pushing
no Energy
no Mana

## STEP 89

MINION ENCOUNTER PRIORITY + MULTI-TARGET PROXIMITY RESOLUTION

وقتی چند Minion یا Tower همزمان نزدیک Hero باشند، Target انتخابی، Sticky Target، اولویت Encounter و جلوگیری از بازشدن چند Task Sheet را production-ready می‌کنیم.
