# STEP 98 — LIVE MATCH ORCHESTRATOR + REAL GAMEPLAY ROUTE WIRING

این مرحله شکاف اصلی بین Blueprintهای Gameplay و App واقعی را کم می‌کند.

تا اینجا:
Timer، Wave، Targeting، Encounter، Minion، Tower، Base، Result، Recovery و HUD هرکدام Contract/Runtime جدا داشتند.

در Step98:
یک Coordinator مرکزی ساخته می‌شود که Router + AppStore + Match State + Gameplay Screen را به هم وصل می‌کند.

## Authority

Home:
فقط درخواست Start

PreBattle:
فقط ساخت Match جدید

Gameplay Orchestrator:
اجرای Match persisted

Results:
فقط نمایش Snapshot نهایی

## Live Match Orchestrator Responsibilities

1. Load active Match
2. Validate Match
3. Start Match once
4. Own Gameplay tick
5. Reconcile Timer
6. Reconcile Wave schedule
7. Move Hero
8. Update Fog/Minimap
9. Spawn real Task Minions
10. Select interaction target
11. Open one Task Encounter
12. Route Complete to entity pipeline
13. Commit Task
14. Commit Minion/Tower/Base damage
15. Commit reward
16. Advance objective state
17. Finalize Victory/Time End
18. Persist Match checkpoints
19. Route Results
20. Recover after reload

## Important Rule

Orchestrator does NOT invent rewards.

Rewards come only from committed task/objective transactions.

Visuals never mutate:
HP
Gold
Diamond
XP
Rank
Victory

## Match Shape

activeMatch:
id
status
createdAt
startedAt
durationMs
settingsSnapshot
heroSnapshot
taskPoolSnapshot
mapSnapshot
worldState
timerState
waveState
objectiveState
reservations
entities
transactions
ledger
resultSnapshot

## Gameplay Runtime Loop

requestAnimationFrame:
visual loop

30Hz:
simulation helpers where appropriate

Timer authority:
elapsed time

Wave authority:
elapsed interval index

## Start Flow

Home Start
→ PreBattle
→ buildMatch()
→ persist activeMatch
→ Gameplay route
→ orchestrator.mount()
→ ensureStartedAt()
→ immersive
→ controls enabled

## Gameplay Route

Step98 replaces the generic Gameplay placeholder.

Gameplay now renders:

Timer
Objective text
XP / Gold / Diamond earned this Match
Battlefield
Hero
Minions
Tower states
Base state
Joystick shell
Pause
Task Encounter
Target information

Visuals are still simplified runtime shapes until final production art integration,
but logic is connected to live AppStore Match state.

## Real Task Binding

Minions use only tasks where:

activeInGame == true
status == active

No fake Task.

Each spawned Minion gets:
reservationId
taskId
taskSnapshot

## Wave

Default:
45 seconds

Step98 includes DEV-safe first-wave trigger for visual testing only when explicitly invoked.

Production normal flow:
no immediate fake Wave.

## Encounter

One active Encounter only.

Complete:
Task commit first.

Then:
Minion defeat
OR Tower damage
OR Base damage

Then:
Reward commit

## Minion

Complete Task:
Minion defeated
reward once
reservation completed
despawn

## Tower

HP:
100 default

Damage:
34

Sequence:
100 → 66 → 32 → 0

Tower1 destroyed:
unlock Tower2 same Lane

Tower2 destroyed:
complete Lane

One complete Lane:
Enemy Base unlocked

## Enemy Base

HP:
100

Damage:
25

Sequence:
100 → 75 → 50 → 25 → 0

HP 0:
Victory finalize once

Victory Bonus:
+400 XP
+150 Gold
+1 Diamond

Only once.

## Time End

remaining <= 0:
stop new encounters
stop new waves
finalize time_end
preserve committed reward
no Victory bonus

## Ledger

Every reward transaction has deterministic txId.

Duplicate tx:
ignored.

## Persistence

After authoritative mutations:
AppStore persists activeMatch.

Examples:
Task commit
Damage commit
Reward commit
Wave spawn
Tower destruction
Lane progression
Base destruction
Finalization

## Results

Orchestrator finalizes resultSnapshot.

Then:
route results.

Results UI can bind:
resultType
tasksCompleted
minionsDefeated
towersDestroyed
lanesCompleted
xp
gold
diamond
durationPlayed

## Fresh Launch

Always Home.

If active Match exists:
Recoverable Match Card.

Resume:
Gameplay route
→ same Match ID
→ same startedAt
→ reconcile elapsed timer
→ no duplicate Wave/Reward/Damage.

## Android

Gameplay mount:
immersive true

Gameplay unmount:
immersive false unless transitioning between gameplay internal overlays.

## QA

one active Match
one startedAt
no duplicate Wave tx
no duplicate Task commit
one Encounter
no duplicate damage
no duplicate reward
Tower progression correct
Base unlock correct
Victory bonus once
Time End no Victory bonus
fresh launch Home
resume same Match
no fake Tasks
Gameplay bottom nav hidden
Stats remains tree only
no Energy
no Mana

## STEP 99

GITHUB APK BUILD HARDENING + REAL GRADLE / CAPACITOR CI

Project را طوری می‌بندیم که مستقیم داخل GitHub آپلود شود و GitHub Actions یک APK قابل نصب بسازد.
