# STEP 79 — GAMEPLAY LIVE HUD + OBJECTIVE GUIDANCE RUNTIME

این مرحله HUD داخل Match را به State واقعی و committed بازی متصل می‌کند.

## HUD Structure

Top:
Timer
Current Objective
Pause

Compact resource strip:
XP earned this Match
Gold earned this Match
Diamond earned this Match

Battlefield:
Target HP
Objective marker
Minimap

No Energy.
No Mana.
No Hero power meter.

## Timer

Source:
MatchClock runtime

Display:
MM:SS

Never:
setInterval counter as authority

States:
normal
warning
critical
zero

Suggested thresholds:
warning <= 05:00
critical <= 01:00

Warnings fire once.

## Session Reward Delta

HUD displays only rewards committed during current Match.

XP delta
Gold delta
Diamond delta

This is NOT wallet authority.

Player wallet remains ledger-derived.

If transaction commits:
HUD delta refreshes.

If VFX plays without commit:
HUD does not change.

Diamond:
only changes when committed positive Diamond exists.

## Current Objective

Objective guidance is advisory only.

Priority:
active encounter target
nearest actionable minion
current unlocked Tower
Enemy Base when unlocked
free exploration

Possible labels:
کار نزدیک
تاور اول مسیر A
تاور دوم مسیر B
بیس دشمن
حرکت آزاد

Objective guidance never:
teleports Hero
forces movement
locks lane choice
creates Task
changes progression

## Target HP

When target selected:

Minion:
compact target indicator

Tower:
HP / maxHP
state healthy/damaged/critical

Base:
HP / maxHP
state stable/unstable/critical/collapse_ready

HP source:
committed entity state only.

VFX cannot mutate HUD HP.

## Objective Marker

World-space marker:
only on actionable target/objective.

Locked Tower:
no actionable marker.

Locked Base:
shield/locked marker only, not interact CTA.

Destroyed Tower:
completed marker briefly then clear.

## Minimap

Display only.

Shows:
Hero
Own Base
Enemy Base
Tower states
visible/persisted Minions
lane completion
recommended objective

No tap-to-move.
No teleport.
No direct objective mutation.

## Fog

Minimap respects known/visible state.

Unseen:
hidden/obscured

Known:
dim

Visible:
normal

## Pause

Pause button:
opens Pause UI.

HUD stays visible/dimmed behind pause.

Pause freezes MatchClock and Wave Scheduler through existing runtime.

## Task Encounter

HUD remains behind cinematic overlay.

If timerRunsDuringTask = true:
Timer display continues.

If false:
Timer freezes.

Reward HUD updates only after transaction commit.

## Responsive

Portrait 360–430 CSS px.

HUD must not collide with Android safe area.

Top HUD uses:
safe-area-inset-top

Joystick/action zones remain unobstructed.

## Runtime Data Model

HUD reads:

match.id
clock.remainingMs
match.resultType
objectiveState
worldState
targetState
ledger committed Match rows
fogState
minimapState

No independent duplicate gameplay state.

## Performance

HUD render:
event-driven where possible.

Timer visual:
250–1000ms refresh.

World/minimap:
throttled.

No full app rerender every frame.

## Recovery

After Match recovery:
HUD reconstructs from persisted committed state.

Do not reset:
Timer
reward deltas
Tower HP
Base HP
objective progression

## QA

Timer reads MatchClock
Timer never goes negative
warning/critical fire once
reward delta committed-only
HUD cannot mutate wallet
Diamond positive committed-only
objective guidance advisory only
no forced movement
no teleport
Tower HP committed-only
Base HP committed-only
Minimap display-only
locked objective not actionable
destroyed Tower marker clears
pause uses existing clock/scheduler pause
Task overlay preserves HUD context
safe area respected
fresh launch Home
no Energy
no Mana

## STEP 80

GAMEPLAY MINIMAP + FOG + OBJECTIVE MARKER PRODUCTION RUNTIME

Minimap projection، Fog states، Tower/Base/Minion markers و Objective guidance را به world coordinates واقعی وصل می‌کنیم.
