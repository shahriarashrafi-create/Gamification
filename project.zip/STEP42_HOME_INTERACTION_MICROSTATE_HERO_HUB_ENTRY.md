# SHAHRIAR GAME — STEP 42
## HOME INTERACTION / MICROSTATE / HERO HUB ENTRY

مرجع رسمی رفتار تعاملی Home.

## 1. Goal
Home فقط زیبا نباشد؛ تمام Tapها، Press Stateها، Routeها و Match Recovery باید دقیق و امن باشند.

## 2. Hero Tap
Tap Hero Stage → Hero Hub.
No long delay.
Hero tap does not change gameplay power.

## 3. Secondary Modules
فروشگاه → shop
رویدادها → events
آینده‌بینی → vision
دستاوردها → achievements

## 4. Settings
Gear → settings.

## 5. Start CTA
Tap:
validate Hero
validate at least one eligible Task
snapshot settings
route Pre-Battle

Never direct route into active Match.

## 6. Start CTA States
idle
pressed
validating
blocked_no_tasks
ready
disabled_during_transition

## 7. No Tasks
Message:
«برای شروع بازی حداقل یک کار فعال لازم است»
CTA:
«رفتن به کارها»

## 8. Recoverable Match Card
Only appears when valid recoverable activeMatch metadata exists.

## 9. Recovery Card Copy
«یک Match نیمه‌تمام داری»
Show compact:
remaining time
current lane/objective if valid
Resume
End Match

## 10. Resume
Resume → validate checkpoint → enter immersive → restore Match.
Never reconstruct rewards from UI.

## 11. End Recoverable Match
Requires confirmation.
Committed rewards preserved.
No Victory bonus.

## 12. Fresh Launch
Still Home.
Recovery card never auto-enters Match.

## 13. Recovery Card Placement
Compact floating/inline card between Hero context and modules only when present.
Must not hide Start CTA or bottom nav.

## 14. Start With Existing Match
If recoverable Match exists, normal Start button should not silently create second active Match.
Offer Resume or End current Match first.

## 15. Press State
Buttons:
scale ~0.98
border/glow response
80–140ms

## 16. Selected Bottom Nav
Home selected in gold.
Other tabs neutral cyan/gray.

## 17. Bottom Nav Tap
Switch canonical main route.
No deep history stacking.

## 18. Module Transition
220ms secondary transition.
Back returns Home.

## 19. Hero Hub Transition
Hero stage light responds.
Then Hero Hub opens.

## 20. Double Tap Guard
Start Game cannot initialize twice.
Module navigation ignores duplicate transition taps.

## 21. Wallet HUD
Gold/Diamond tap may show compact info sheet later.
Does not route Shop automatically in this Step.

## 22. XP HUD
Tap can show compact Level progress sheet later.
No Stats dashboard.

## 23. Rank Tap
Tap opens compact Rank detail sheet.
Not Stats page.

## 24. Rank Detail
Current rank
RP progress
next sub-rank
cosmetic reward preview if defined

## 25. Accessibility
Every icon button has accessible label.
Pressed/selected state not color-only.

## 26. Haptics
Light tap for normal navigation.
Medium confirmation for Start.
Respects Step37 settings.

## 27. Sound
UI tap/confirm from Step37.
No sound if muted.

## 28. Reduce Motion
Module/Hero transitions become simple fade.
No loss of functionality.

## 29. Offline
All Home local routes remain usable.
No fatal offline state.

## 30. Loading
Hero/background may load independently.
Interactions wait only if their own required state is unavailable.

## 31. Route Guard
Unknown route → Home.
Invalid Hero Hub selection → default selected Hero.

## 32. Android Back
From Home:
system default/back behavior.
Do not open stale route.

## 33. App Resume
Recheck recoverable Match metadata.
Update recovery card without auto-navigation.

## 34. Match Closed
Recovery card disappears immediately after authoritative close.

## 35. CTA Label
Reads current editable match duration:
«شروع بازی — {minutes} دقیقه»

## 36. Interaction State Model
homeReady
homeTransitioning
preBattleValidating
recoveryValidating
secondaryTransition

## 37. Prototype
Step42 extends executable Home with:
route taps
Start validation
No-Task block simulation
Recovery Match card
Resume/End confirmation
Rank detail
pressed states

## 38. QA
double Start blocked
existing Match blocks second Match
Resume validates checkpoint
End preserves committed rewards
fresh launch Home
Hero opens Hero Hub
Rank doesn't open Stats
bottom nav exactly five
no Energy

## 39. Failure Conditions
double Match
auto resume
Start bypasses task validation
End Match loses rewards
Hero tap changes power
sixth nav
recovery card hides CTA
rank opens analytics dashboard

## 40. Quality Gate
Every Home interaction produces one deterministic safe state transition.

## STEP 43
PRE-BATTLE REAL SCREEN COMPOSITION
Build the real Pre-Battle screen using selected Hero, match duration, task pool readiness, lane-map preview and immersive transition.
