# STEP 100 — FINAL RELEASE HANDOFF + AUDIT

این مرحله پایان طراحی ۱۰۰ قدمی پروژه است.

## Final Contract

App: Shahriar Game
Android package: com.shahriar.game
Orientation: Portrait
Frontend: Vite
Native shell: Capacitor Android

Fresh Launch:
همیشه Home.

Bottom Navigation:
خانه | کارها | آمار | تایم‌شیت | شبکه‌سازی

Stats:
فقط Network Tree.

Gameplay:
Immersive.

Outside Gameplay:
System bars visible.

Energy: ندارد.
Mana: ندارد.

## Final Release Flow

1. ZIP نهایی را Extract کن.
2. تمام محتویات داخل پوشه را در Root ریپازیتوری GitHub آپلود کن.
3. خود ZIP را به‌تنهایی داخل Repository نگذار.
4. Commit کن.
5. وارد Actions شو.
6. Workflow `Android Debug APK` را Run کن.
7. بعد از سبز شدن Build، Artifact با نام `shahriar-game-debug-apk` را دانلود کن.
8. APK را روی گوشی نصب و تست کن.

## Required Root Structure

package.json
capacitor.config.ts
vite.config.js
index.html
app/
android/
.github/
scripts/
README.md

## Final QA Gates

Home:
HUD readable
Hero section responsive
Rank visible
4 secondary modules visible
Start CTA visible above nav
No Friend List
No Main Mission
No Energy

Primary:
Tasks persistent
Stats tree only
Timesheet persistent
Networking persistent

Secondary:
Shop Gold/Diamond rules
Events persistent
Vision persistent
Achievements persistent
Hero selection persistent
Settings persistent

Gameplay:
PreBattle requires active task
Match persisted before Gameplay
startedAt once
timestamp-based Timer
real Task waves only
one Encounter
idempotent transactions
Tower progression
Base unlock
Victory once
Time End neutral
Results from committed snapshot
Fresh launch never jumps into Gameplay

Android:
portrait
package com.shahriar.game
Java 17
safe area
immersive Gameplay only
system bars restored outside Gameplay
keystore excluded

## Important Build Truth

این ZIP سورس نهایی پروژه است، نه APK کامپایل‌شده.

APK واقعی باید توسط GitHub Actions یا Android Studio با Android SDK و Gradle ساخته شود.

## Production Art Truth

منطق، Routeها، State، Match Orchestrator و UI اجرایی در پروژه هستند؛ اما کیفیت تصویری دقیق در حد بازی‌های بزرگ موبایلی نیازمند جایگزینی placeholderهای Hero/Map با Assetهای نهایی Hero/Environment/VFX است.

## After Step 100

مسیر بعدی:
GitHub Upload
→ APK Build
→ Install on Phone
→ Device QA
→ Fix runtime/build issues
→ Production Art Pass
→ Release Candidate
