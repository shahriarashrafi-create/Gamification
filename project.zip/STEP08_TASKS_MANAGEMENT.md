# SHAHRIAR GAME — 100 STEP REBUILD
## STEP 08 — TASKS MANAGEMENT EXPERIENCE

این سند مرجع رسمی صفحه «کارها» و مدیریت Taskها است.

---

# 1. نقش صفحه کارها

صفحه «کارها» یک Admin Table نیست.

هویت صفحه:
**Objective Arsenal / Battle Objectives**

کاربر باید حس کند:
«این‌ها مأموریت‌های واقعی من برای پیشروی در میدان هستند.»

---

# 2. Bottom Navigation

آیتم:
کارها

جایگاه:
دوم از پنج Bottom Nav

Navigation ثابت:
خانه | کارها | آمار | تایم‌شیت | شبکه‌سازی

---

# 3. Core Capabilities

Tasks Page باید پشتیبانی کند:

- Add
- Edit
- Delete
- Search
- Filter
- Category
- Difficulty
- XP
- Gold
- Diamond
- activeInGame
- Note

---

# 4. Task Card Philosophy

هر Task به‌صورت Tactical Objective Card نمایش داده می‌شود.

Card باید در ۳ ثانیه نشان دهد:

- نام
- دسته
- سختی
- Reward
- فعال/غیرفعال در بازی
- وضعیت

---

# 5. Task Fields

Task Model:

- id
- title
- category
- difficulty
- xp
- gold
- diamond
- activeInGame
- note
- createdAt
- updatedAt
- completedCount
- lastCompletedAt

---

# 6. Title

نام Task:
اجباری

حداقل:
2 حرف

حداکثر پیشنهادی:
70 حرف

---

# 7. Category

Category:
Editable

Default examples:
- شبکه‌سازی
- فروش
- پیگیری
- یادگیری
- برنامه‌ریزی
- شخصی
- سلامت
- مالی

Settings آینده:
Add/Edit/Delete categories

---

# 8. Difficulty

Difficulty IDs:

- easy
- normal
- important
- hard
- strategic

نمایش فارسی:

Easy:
آسان

Normal:
متوسط

Important:
مهم

Hard:
سخت

Strategic:
استراتژیک

---

# 9. Difficulty Visual

Easy:
Cyan

Normal:
Steel Blue

Important:
Gold

Hard:
Crimson

Strategic:
Purple/Gold

رنگ فقط Accent باشد، نه کل Card.

---

# 10. Reward Fields

هر Task می‌تواند:

XP:
0+

Gold:
0+

Diamond:
0+

داشته باشد.

Diamond پیش‌فرض:
0

چون Diamond باید Rare بماند.

---

# 11. Active in Gameplay

Toggle:
«فعال در بازی»

ON:
Task وارد Encounter Pool می‌شود.

OFF:
Task در مدیریت باقی می‌ماند ولی در Match انتخاب نمی‌شود.

---

# 12. Note

Note:
اختیاری

در Card:
Preview کوتاه

در Edit:
کامل

Gameplay:
در Encounter Panel قابل نمایش

---

# 13. Task Status

Master Task Status:

- active
- paused
- archived

Gameplay state مستقل:

- unused
- active encounter
- completed current match
- deferred current match

این دو نباید قاطی شوند.

---

# 14. Search

Search روی:

- title
- category
- note

Live search

No page reload

---

# 15. Filters

Filters:

- همه
- فعال در بازی
- غیرفعال در بازی
- Category
- Difficulty
- Diamond reward
- Recently added

---

# 16. Sorting

Sort:

- جدیدترین
- قدیمی‌ترین
- XP بیشتر
- Gold بیشتر
- سختی
- بیشترین تکمیل

---

# 17. Summary Strip

در بالا می‌توان یک Summary بسیار فشرده داشت:

- Total Tasks
- Active in Game
- Diamond Tasks

اما:
نه Dashboard
نه KPIهای متعدد

---

# 18. Add Task CTA

Primary Action:

`+ افزودن کار`

Position:
Top action یا Floating game-styled button

باید همیشه واضح باشد.

---

# 19. Add / Edit Panel

Form باید داخل:
Tactical Sheet / Modal

نه صفحه سفید.

Fields:

Title
Category
Difficulty
XP
Gold
Diamond
Active in Game
Note

Actions:
Save
Cancel

---

# 20. Delete Rule

Permanent Delete:
فقط در Tasks Management

Delete confirmation:
الزامی

Copy:
«این کار از لیست اصلی حذف می‌شود.»

---

# 21. Gameplay Delete Separation

داخل Gameplay:
Delete button وجود ندارد.

فقط:
- Complete
- Defer
- Cancel Encounter

---

# 22. Reward Editing

Reward fields:
Editable per Task

اگر کاربر XP/Gold/Diamond را تغییر دهد:
Encounterهای آینده مقدار جدید را می‌گیرند.

Encounter فعال:
Reward Snapshot خودش را نگه می‌دارد.

---

# 23. Snapshot Rule

وقتی Encounter ساخته می‌شود:

rewardPreview snapshot:

- xp
- gold
- diamond

تا اگر Task وسط Match بیرون بازی Edit شد:
Encounter جاری تغییر نکند.

---

# 24. Task ID

Task ID:
Stable UUID

Edit:
ID تغییر نمی‌کند

Delete:
record حذف یا soft-delete policy در implementation step تعیین می‌شود.

---

# 25. Created / Updated

createdAt:
first save

updatedAt:
every edit

برای sorting و audit.

---

# 26. Completed Count

completedCount:
هر Complete واقعی +1

lastCompletedAt:
آخرین زمان Complete

---

# 27. Reusable Tasks

Task می‌تواند:
چند Match مختلف دوباره استفاده شود.

مثال:
فالوآپ روزانه

Task Completed در یک Match:
به معنای حذف دائمی Task نیست.

---

# 28. Repeatable vs One-Time

Future optional field:

repeatMode:
- reusable
- one-time

Default:
reusable

One-time:
بعد Complete می‌تواند Auto-archive شود.

در Step اولیه optional است.

---

# 29. Card Layout

Task Card:

Top:
Title + Active status

Middle:
Category + Difficulty

Bottom:
XP / Gold / Diamond

Actions:
Edit
More/Delete

نباید 8 دکمه روی Card باشد.

---

# 30. Compact Mobile Density

روی 360px width:
هر Card باید کامل خوانا باشد.

پیشنهاد:
1-column cards

نه grid دو ستونه فشرده.

---

# 31. Swipe Actions

Future optional:

Swipe:
Edit / Archive

اما Default:
Explicit buttons

برای جلوگیری از حذف اشتباه.

---

# 32. Empty State

اگر Task نداریم:

Visual:
Empty objective rack

Copy:
«هنوز Objective واقعی برای میدان تعریف نکرده‌ای.»

CTA:
`اولین کار را اضافه کن`

---

# 33. No Active Tasks

اگر Task هست ولی activeInGame = false:

Warning compact:
«هیچ کاری برای Gameplay فعال نیست.»

CTA:
فعال‌کردن یک Task

---

# 34. Diamond Task Mark

اگر diamond > 0:

Card:
small crystal badge

نباید خیلی بزرگ باشد.

---

# 35. Category Icons

Category icon optional

مثال:
Networking:
nodes

Learning:
book/rune

Health:
shield/heart

Planning:
map

Final icon set در Design System step.

---

# 36. Search UX

Search Bar:
dark game panel

Placeholder:
«جستجو در کارها…»

Clear button:
visible when text exists.

---

# 37. Filter Chips

Chips:
- همه
- فعال
- سخت
- Diamond

Horizontal scroll if needed.

---

# 38. Tactical Visual Language

Background:
Deep Navy

Cards:
Layered metal/glass

Accent:
Gold / Cyan

Active:
Cyan glow

Disabled:
Muted steel

Danger:
Crimson

---

# 39. CRUD Confirmation

Save:
Immediate

Delete:
Confirm

Cancel edit:
اگر تغییر unsaved باشد:
optional warning

---

# 40. Local Data First

نسخه پایه:
Local Storage / IndexedDB / app persistence

در Data Architecture step:
storage implementation قفل می‌شود.

---

# 41. Example Task

Title:
فالوآپ با پراسپکت امروز

Category:
شبکه‌سازی

Difficulty:
متوسط

XP:
120

Gold:
35

Diamond:
1

Active:
true

Note:
نتیجه و اقدام بعدی را ثبت کن.

---

# 42. Task Pool Compatibility

Gameplay selection مستقیماً از Tasks Page data می‌خواند.

Required:
activeInGame = true

No duplicate schema.

---

# 43. Match State Separation

Master task data:
persistent

Match usage:
temporary match state

این تفکیک حیاتی است.

---

# 44. Accessibility

Touch:
44dp minimum

Text:
Readable Persian

Toggle:
Text + visual state

Do not rely only on color.

---

# 45. RTL

Cards:
RTL

Reward numbers:
stable

Icons:
consistent

Search:
RTL input

---

# 46. Performance

100+ Task:
smooth

Search:
debounced / efficient

No huge DOM effects

---

# 47. Import / Export Future

Future:
JSON backup/import

نه در Step فعلی

---

# 48. Quick Duplicate

Future useful action:
Duplicate Task

برای Taskهای مشابه

نه Primary Action

---

# 49. STEP 08 LOCKED STRUCTURE

Header:
Title + Add

Search

Filter Chips

Compact Summary

Objective Cards

Bottom Nav

Task Card:
Title
Category
Difficulty
Rewards
activeInGame
Edit/Delete

---

# 50. Quality Gate

Tasks PASS اگر:

- CRUD کامل باشد
- Delete فقط اینجا permanent باشد
- Search کار کند
- Filter کار کند
- activeInGame قابل تغییر باشد
- XP/Gold/Diamond قابل ویرایش باشد
- Card روی 360px readable باشد
- ظاهر Table/Admin نداشته باشد
- Master Task با Match State جدا باشد
- Gameplay همان Task model را مصرف کند

---

# STEP 09

NETWORK TREE / STATS EXPERIENCE

در قدم ۹:
- صفحه آمار فقط Tree
- recursive network
- expand/collapse
- zoom/pan
- member status
- sales / GPV / goals
- add/edit/remove member
طراحی می‌شود.
