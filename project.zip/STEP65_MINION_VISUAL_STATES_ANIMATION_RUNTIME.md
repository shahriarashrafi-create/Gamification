# STEP 65 — MINION VISUAL STATES + ANIMATION RUNTIME

این مرحله movement و lifecycle قدم 64 را به visual state و animation runtime متصل می‌کند.

## States

idle
walk
focused
hit
defeated

## State Priority

defeated
> hit
> focused
> walk
> idle

## Transition Rules

idle → walk
وقتی velocity > 0.10

walk → idle
وقتی velocity <= 0.10

walk/idle → focused
وقتی Hero وارد interaction radius شود

focused → hit
بعد از Task completion commit و Hero attack impact

hit → defeated
فقط اگر defeat commit شده باشد

focused → idle
بعد از Cancel Encounter

focused → defeated
بعد از Defer visual exit only if state policy marks deferred terminal visual

## Authority

Animation هرگز:
Task را complete نمی‌کند
Reward نمی‌دهد
HP یا progression را تغییر نمی‌دهد

Visual state فقط committed runtime state را نمایش می‌دهد.

## Asset Variants

minion_idle
minion_walk
minion_focused
minion_hit
minion_defeated

Preferred runtime:
transparent WebP

Reference-only art from Step45 remains visual direction, not final runtime cutout.

## Animation Timing

idle loop:
1200–1800ms

walk loop:
700–950ms

focused pulse:
900–1200ms

hit:
120ms

defeated:
360–600ms

## Focus Visual

Focused:
cyan target ring
subtle pulse
small objective marker
no oversized glow

## Hit Visual

Hit:
short impact flash
small recoil
particle burst

No repeated shake.

## Defeated Visual

Defeated:
short collapse/dissolve
reward flyup only if committed reward > 0
despawn after feedback

## Facing

Walk animation follows 8-direction facing from actual velocity.

Focused:
faces Hero if interaction active.

Hit:
faces attack source.

## Reduce Motion

No recoil travel
No large dissolve
Use:
brief opacity + scale fade

## Performance

Max animated actionable Minions:
6

Off-camera Minions:
animation throttled
simulation remains authoritative

## Asset Resolution

Resolution order:
requested state asset
→ compatible fallback state
→ generic approved Minion asset
→ explicit asset error

Forbidden production fallback:
emoji
CSS creature/human silhouette

## Recovery

App resume:
rebuild visual state from runtime state.

Never resume halfway through hit animation unless hit transaction still active.

Defeated committed Minion:
finish despawn safely.

## QA

idle/walk based on actual velocity
focused overrides walk
hit overrides focused
defeated highest priority
animation cannot mutate Task/Reward
facing uses real velocity/target
Reduce Motion works
off-camera throttling works
reference art not mislabeled final
no emoji fallback
no Energy

## STEP 66

MINION ENCOUNTER + DEFEAT FULL PIPELINE

Task Encounter، Hero attack، Minion hit، reward، reservation completion و despawn را به یک transaction pipeline واحد وصل می‌کنیم.
