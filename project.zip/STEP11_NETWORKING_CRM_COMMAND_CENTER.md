# SHAHRIAR GAME — 100 STEP REBUILD
## STEP 11 — NETWORKING / CRM COMMAND CENTER

این سند مرجع رسمی صفحه «شبکه‌سازی» است.

---

# 1. هویت صفحه

شبکه‌سازی نباید شبیه CRM خشک سازمانی باشد.

هویت:
**Network Command Center**

هدف:
کاربر سریع بفهمد:
- با چه کسی در ارتباط است
- آخرین اقدام چه بوده
- نتیجه چه شده
- اقدام بعدی چیست
- چه زمانی باید پیگیری کند

---

# 2. Bottom Navigation

آیتم پنجم:

شبکه‌سازی

Navigation ثابت:

خانه | کارها | آمار | تایم‌شیت | شبکه‌سازی

---

# 3. پنج Action Type رسمی

Action Typeها دقیقاً:

1. ارتباط‌سازی
2. پیش‌مشاوره
3. دعوت
4. معرفی کار
5. فالوآپ

هیچ نام جایگزین در نسخه اصلی استفاده نشود.

---

# 4. Prospect Model

Prospect:

- id
- name
- referrerName
- consultantName
- status
- note
- createdAt
- updatedAt

---

# 5. Action Record

هر Action:

- id
- prospectId
- actionType
- actionDate
- actionTime
- result
- nextAction1
- nextAction2
- nextActionDate
- nextActionTime
- nextActionResult1
- nextActionResult2
- note
- completed
- createdAt
- updatedAt

---

# 6. Prospect Name

اجباری.

Searchable.

---

# 7. Referrer Name

فیلد:
معرف

اختیاری.

---

# 8. Consultant

فیلد:
مشاور / مشاور معرف

اختیاری.

---

# 9. Action Type UX

پنج Action باید به شکل Tactical Chips یا Segmented Control باشد.

مثال:
ارتباط‌سازی | پیش‌مشاوره | دعوت | معرفی کار | فالوآپ

---

# 10. Action Result

Result:
متن آزاد + preset optional

Preset examples:
- مثبت
- نیازمند پیگیری
- بی‌پاسخ
- رد
- انجام شد

---

# 11. Next Two Actions

هر Record باید دو اقدام بعدی را نگه دارد:

nextAction1
nextAction2

هدف:
Pipeline ذهنی کاربر واضح باشد.

---

# 12. Follow-up Date

Action بعدی باید Date/Time داشته باشد.

برای:
Reminder
Timesheet sync future
Follow-up queue

---

# 13. Next Action Results

برای دو اقدام بعدی:

nextActionResult1
nextActionResult2

قابل ثبت و ویرایش.

---

# 14. Prospect Card

Card باید نشان دهد:

- نام
- وضعیت
- آخرین Action
- آخرین Result
- Next Action
- زمان Follow-up

---

# 15. Command Center Header

بالا:

- عنوان
- Search
- Add Prospect
- Quick filter

نه Dashboard شلوغ.

---

# 16. Compact Summary

حداکثر ۳ شاخص:

- کل Prospectها
- Follow-up امروز
- نیازمند اقدام

این‌ها فقط Summary کوچک‌اند.

---

# 17. Search

Search:

- Prospect name
- Referrer
- Consultant
- Result
- Next Action

---

# 18. Filters

Allowed:

- همه
- پیگیری امروز
- بی‌پاسخ
- نیازمند پیگیری
- Action Type

---

# 19. Prospect Status

Default:

- new
- active
- follow_up
- converted
- paused

Persian:

جدید
فعال
نیازمند پیگیری
تبدیل‌شده
متوقف

---

# 20. Add Prospect

Fields:

- Name
- Referrer
- Consultant
- Status
- Note

بعد Save:
می‌توان اولین Action را ثبت کرد.

---

# 21. Add Action

از Prospect Detail:

`+ ثبت اقدام`

Fields:
- Action Type
- Date
- Time
- Result
- Next 1
- Next 2
- Next date/time
- Note

---

# 22. History

هر Prospect:
Action History دارد.

Newest first.

Timeline style.

---

# 23. Edit

Prospect:
Editable

Action:
Editable

IDها ثابت می‌مانند.

---

# 24. Delete

Prospect delete:
Confirmation

Policy:
با Prospect، Action history مربوط به آن هم حذف/آرشیو می‌شود.

Implementation final:
soft-delete preferred.

---

# 25. Delete Action

Action delete:
Confirmation

Prospect باقی می‌ماند.

---

# 26. Follow-up Queue

اگر nextActionDate نزدیک باشد:

Card:
badge

مثال:
امروز
فردا
عقب‌افتاده

---

# 27. Overdue

اگر تاریخ Action بعدی گذشته و completed نشده:

Status accent:
Crimson/Amber

بدون تنبیه.

---

# 28. Result Completion

ثبت Result:
Action را completed می‌کند.

اگر Next Action تعریف شده:
Prospect همچنان active/follow_up می‌ماند.

---

# 29. CRM ↔ Timesheet

Future integration:

Follow-up می‌تواند:
`Add to Timesheet`

ولی داده اصلی CRM مستقل است.

---

# 30. CRM ↔ Tasks

Future integration:

یک Follow-up می‌تواند:
Task بسازد.

Default:
خودکار نسازد.

---

# 31. CRM ↔ Gameplay

Gameplay در آینده می‌تواند Taskهای شبکه‌سازی فعال را مصرف کند.

CRM Action مستقیم Reward نمی‌دهد.

---

# 32. No Direct Reward

ثبت CRM Action:
XP/Gold/Diamond مستقیم ندارد.

Reward فقط اگر به Task/Gameplay/Achievement rule وصل شود.

---

# 33. Action Visual Language

ارتباط‌سازی:
Cyan

پیش‌مشاوره:
Blue

دعوت:
Gold

معرفی کار:
Purple/Gold

فالوآپ:
Amber

---

# 34. Prospect Node Atmosphere

Card می‌تواند:
radar / signal / node motif

اما نباید شلوغ شود.

---

# 35. Detail Sheet

Tap Prospect:

- Profile
- Referrer
- Consultant
- Status
- Last Action
- Next Actions
- History
- Edit
- Add Action

---

# 36. Timeline

Action History:

Time
Action Type
Result
Next Action

Compact.

---

# 37. Next Action Priority

نمایش اولویت:

1. Overdue
2. Today
3. Tomorrow
4. Upcoming
5. None

---

# 38. Date Storage

Canonical:
YYYY-MM-DD

Display:
Persian localized

Time:
HH:mm

---

# 39. Local First

Base version:
local persistence

Sync architecture later.

---

# 40. Sorting

Default:
nearest next action

Alternate:
newest
name
last activity

---

# 41. Empty State

Copy:
«هنوز کسی وارد مرکز فرمان شبکه نشده.»

CTA:
`اولین Prospect را اضافه کن`

---

# 42. No Next Action

Badge:
«اقدام بعدی تعیین نشده»

این مورد باید قابل Search/Filter باشد.

---

# 43. Contact Details Future

Future optional:
phone
telegram
instagram
email

Step فعلی:
schema-compatible but not required.

---

# 44. Privacy

اطلاعات CRM:
private local user data

در sync step:
secure handling لازم است.

---

# 45. Touch Targets

44dp minimum

Action chips:
scrollable horizontal

---

# 46. RTL

تمام فرم و Timeline:
RTL

Time/date:
numeric safe

---

# 47. Mobile Layout

360px:

Single column cards

Detail Sheet:
bottom sheet

No desktop table.

---

# 48. Step 11 Locked Structure

Header:
Search + Add

5 Action Type filter chips

Compact summary

Prospect cards

Detail Sheet

Action history

Bottom Nav

---

# 49. Example Prospect

Name:
علی رضایی

Referrer:
محمد

Consultant:
شهریار

Last Action:
دعوت

Result:
علاقه‌مند شد، نیاز به زمان دارد

Next Action 1:
فالوآپ

Next Action 2:
معرفی کار

---

# 50. Quality Gate

Networking PASS اگر:

- پنج Action Type دقیق باشند
- Prospect CRUD کامل باشد
- Action CRUD کامل باشد
- Referrer ذخیره شود
- Consultant ذخیره شود
- Result ذخیره شود
- دو Next Action ذخیره شوند
- Date/Time Follow-up ذخیره شود
- Next Action Results ذخیره شوند
- Search/Filter کار کند
- CRM مستقیم Reward ندهد
- ظاهر Dashboard اداری نداشته باشد

---

# STEP 12

SHOP / REWARD ARMORY

در قدم ۱۲:
- Gold Shop
- Hero unlock
- Cosmetic inventory
- Diamond real-life rewards
- CRUD reward items
- purchase / claim
- history
طراحی می‌شود.
