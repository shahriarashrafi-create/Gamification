export const DEFAULT_STATE = {
  schemaVersion: 95,
  player: {
    name: 'شهریار',
    level: 28,
    xp: 6240,
    xpRequired: 8000,
    gold: 2437,
    diamonds: 12,
    rankId: 'epic_3',
    rankLabel: 'حماسی III',
    rankScore: 72,
    selectedHeroId: 'young_stylish'
  },
  tasks: [
    {
      id: 'task_demo_1',
      title: 'یک اقدام مهم امروز',
      category: 'برنامه‌ریزی',
      difficulty: 'normal',
      xp: 100,
      gold: 30,
      diamond: 0,
      activeInGame: true,
      status: 'active'
    }
  ],
  networkTree: {
    rootId: 'member_root',
    members: [
      {
        id: 'member_root',
        parentId: null,
        name: 'شهریار',
        rank: 'Root',
        level: 28,
        status: 'active',
        sales: 0,
        gpv: 0
      }
    ]
  },
  timesheet: [],
  networking: {
    prospects: [],
    actions: []
  },
  settings: {
    matchMinutes: 30,
    waveSeconds: 45,
    immersiveGameplay: true,
    reduceMotion: false,
    qualityTier: 'balanced',
    leftHandMode: false
  },

  shop: {
    heroes: [
      {id:'young_stylish',name:'آقای جوان خوش‌تیپ',priceGold:0,owned:true},
      {id:'luxury_mature_m',name:'آقای میان‌سال لاکچری',priceGold:2400,owned:false},
      {id:'charismatic_m',name:'آقای خوش‌برخورد',priceGold:2200,owned:false},
      {id:'disciplined_m',name:'آقای بادیسیپلین',priceGold:2600,owned:false}
    ],
    realRewards: [
      {id:'reward_coffee',title:'قهوه',costDiamond:5},
      {id:'reward_meal',title:'یک وعده دلخواه',costDiamond:12},
      {id:'reward_cinema',title:'سینما',costDiamond:18}
    ],
    transactions: []
  },
  events: [],
  vision: [],
  achievements: [
    {
      id:'ach_first_5_tasks',
      title:'شروع جدی',
      description:'۵ کار را کامل کن',
      metricType:'tasks_completed',
      targetValue:5,
      currentValue:0,
      state:'progress',
      rewardXP:150,
      rewardGold:60,
      rewardDiamond:0
    }
  ],
  heroes: {
    selectedHeroId:'young_stylish',
    loadouts:{}
  },
  matchHistory: [],
  activeMatch: null
};
