import { DEFAULT_STATE } from './default-state.js';
import { LocalStateStorage } from '../storage/local-state-storage.js';

function clone(v){
  return structuredClone(v);
}

function mergePersisted(defaults,persisted){
  if(!persisted) return clone(defaults);
  return {
    ...clone(defaults),
    ...persisted,
    player: {...defaults.player,...persisted.player},
    networkTree: {...defaults.networkTree,...persisted.networkTree},
    networking: {...defaults.networking,...persisted.networking},
    settings: {...defaults.settings,...persisted.settings},
    shop: {...defaults.shop,...persisted.shop},
    heroes: {...defaults.heroes,...persisted.heroes}
  };
}

export class AppStore {
  constructor(storage = new LocalStateStorage()){
    this.storage = storage;
    this.state = clone(DEFAULT_STATE);
    this.listeners = new Set();
    this.hydration = 'idle';
  }

  getState(){
    return this.state;
  }

  async hydrate(){
    this.hydration = 'loading';
    const persisted = await this.storage.load();

    if(persisted?.__corrupt){
      this.hydration = 'recoverable_error';
      return {
        ok:false,
        reason:'corrupt_storage',
        criticalPlayerUnknown:true
      };
    }

    if(persisted?.schemaVersion && persisted.schemaVersion > 95){
      this.hydration = 'recoverable_error';
      return {ok:false,reason:'newer_schema'};
    }

    this.state = mergePersisted(DEFAULT_STATE,persisted);
    this.state.schemaVersion = 95;
    this.hydration = 'ready';
    await this.storage.save(this.state);
    return {ok:true,state:this.state};
  }

  subscribe(listener){
    this.listeners.add(listener);
    return ()=>this.listeners.delete(listener);
  }

  async setState(updater){
    const next = typeof updater === 'function'
      ? updater(clone(this.state))
      : updater;

    this.state = next;
    await this.storage.save(this.state);
    this.listeners.forEach(fn=>fn(this.state));
    return this.state;
  }

  async updateDomain(domain,updater){
    return this.setState(state=>{
      state[domain] = typeof updater === 'function'
        ? updater(state[domain],state)
        : updater;
      return state;
    });
  }
}
