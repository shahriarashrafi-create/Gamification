export const NAV_ITEMS = [
  ['home','خانه'],
  ['tasks','کارها'],
  ['stats','آمار'],
  ['timesheet','تایم‌شیت'],
  ['networking','شبکه‌سازی']
];

export function escapeHtml(input=''){
  return String(input)
    .replaceAll('&','&amp;')
    .replaceAll('<','&lt;')
    .replaceAll('>','&gt;')
    .replaceAll('"','&quot;')
    .replaceAll("'","&#039;");
}

export function bottomNav(active){
  return `
    <nav class="bottom-nav">
      ${NAV_ITEMS.map(([id,label])=>`
        <button data-route="${id}" class="${active===id?'active':''}">
          <span>${label}</span>
        </button>
      `).join('')}
    </nav>
  `;
}

export function screenHeader(title,subtitle=''){
  return `
    <header class="screen-header">
      <div>
        <small>${escapeHtml(subtitle)}</small>
        <h1>${escapeHtml(title)}</h1>
      </div>
    </header>
  `;
}
