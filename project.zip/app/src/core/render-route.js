import { homeScreen } from '../screens/home-screen.js';
import { tasksScreen } from '../screens/tasks/tasks-screen.js';
import { statsScreen } from '../screens/stats/stats-screen.js';
import { timesheetScreen } from '../screens/timesheet/timesheet-screen.js';
import { networkingScreen } from '../screens/networking/networking-screen.js';
import { renderSecondary } from '../screens/secondary/index.js';

export function renderRoute(route,state){
  if(route==='home') return homeScreen(state);
  if(route==='tasks') return tasksScreen(state);
  if(route==='stats') return statsScreen(state);
  if(route==='timesheet') return timesheetScreen(state);
  if(route==='networking') return networkingScreen(state);
  return renderSecondary(route,state);
}
