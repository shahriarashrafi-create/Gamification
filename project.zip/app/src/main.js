import './styles.css';
import { AppStore } from './state/app-store.js';
import { AppRouter } from './router/app-router.js';
import { renderRoute } from './core/render-route.js';
import { uid } from './utils/helpers.js';
import { buildMatchFromState } from './gameplay/state/match-builder.js';
import { LiveMatchOrchestrator } from './gameplay/orchestrator/live-match-orchestrator.js';

const app=document.getElementById('app');
const store=new AppStore();

let currentRoute='home';
let router;
let matchOrchestrator;

function bindInteractions(){
  app.querySelectorAll('[data-route]').forEach(el=>{
    el.addEventListener('click',()=>router.go(el.dataset.route));
  });

  const taskForm=app.querySelector('#task-form');
  if(taskForm){
    taskForm.addEventListener('submit',async e=>{
      e.preventDefault();
      const f=new FormData(taskForm);
      const title=String(f.get('title')||'').trim();
      if(!title) return;
      await store.updateDomain('tasks',tasks=>[
        ...tasks,
        {
          id:uid('task'),
          title,
          category:String(f.get('category')||'شخصی'),
          difficulty:String(f.get('difficulty')||'normal'),
          xp:Number(f.get('xp')||0),
          gold:Number(f.get('gold')||0),
          diamond:Number(f.get('diamond')||0),
          activeInGame:true,
          status:'active',
          createdAt:new Date().toISOString()
        }
      ]);
    });
  }

  app.querySelectorAll('[data-action="toggle-task"]').forEach(btn=>{
    btn.addEventListener('click',async()=>{
      const id=btn.dataset.id;
      await store.updateDomain('tasks',tasks=>tasks.map(t=>
        t.id===id?{...t,activeInGame:!t.activeInGame}:t
      ));
    });
  });

  app.querySelectorAll('[data-action="archive-task"]').forEach(btn=>{
    btn.addEventListener('click',async()=>{
      const id=btn.dataset.id;
      await store.updateDomain('tasks',tasks=>tasks.map(t=>
        t.id===id?{...t,status:t.status==='archived'?'active':'archived'}:t
      ));
    });
  });

  app.querySelectorAll('[data-action="delete-task"]').forEach(btn=>{
    btn.addEventListener('click',async()=>{
      const id=btn.dataset.id;
      await store.updateDomain('tasks',tasks=>tasks.filter(t=>t.id!==id));
    });
  });

  const taskSearch=app.querySelector('#task-search');
  if(taskSearch){
    taskSearch.addEventListener('input',()=>{
      const q=taskSearch.value.trim().toLowerCase();
      app.querySelectorAll('.task-card').forEach(card=>{
        card.hidden=q && !card.dataset.search.includes(q);
      });
    });
  }

  const memberForm=app.querySelector('#member-form');
  if(memberForm){
    memberForm.addEventListener('submit',async e=>{
      e.preventDefault();
      const f=new FormData(memberForm);
      const name=String(f.get('name')||'').trim();
      if(!name) return;
      await store.updateDomain('networkTree',tree=>({
        ...tree,
        members:[
          ...tree.members,
          {
            id:uid('member'),
            parentId:String(f.get('parentId')||tree.rootId),
            name,
            rank:String(f.get('rank')||'عضو'),
            level:Number(f.get('level')||1),
            status:'active',
            sales:0,
            gpv:0
          }
        ]
      }));
    });
  }

  app.querySelectorAll('[data-action="delete-member"]').forEach(btn=>{
    btn.addEventListener('click',async()=>{
      const id=btn.dataset.id;
      await store.updateDomain('networkTree',tree=>{
        if(id===tree.rootId) return tree;
        const target=tree.members.find(m=>m.id===id);
        if(!target) return tree;
        const members=tree.members
          .filter(m=>m.id!==id)
          .map(m=>m.parentId===id?{...m,parentId:target.parentId}:m);
        return {...tree,members};
      });
    });
  });

  const memberSearch=app.querySelector('#member-search');
  if(memberSearch){
    memberSearch.addEventListener('input',()=>{
      const q=memberSearch.value.trim().toLowerCase();
      app.querySelectorAll('.tree-node').forEach(node=>{
        node.style.opacity=!q || node.textContent.toLowerCase().includes(q)?'1':'.2';
      });
    });
  }

  const tsForm=app.querySelector('#timesheet-form');
  if(tsForm){
    tsForm.addEventListener('submit',async e=>{
      e.preventDefault();
      const f=new FormData(tsForm);
      const start=String(f.get('startTime')||'');
      const end=String(f.get('endTime')||'');
      if(end<=start) return;
      await store.updateDomain('timesheet',rows=>[
        ...rows,
        {
          id:uid('timesheet'),
          title:String(f.get('title')||'').trim(),
          date:String(f.get('date')||''),
          startTime:start,
          endTime:end,
          category:String(f.get('category')||'شخصی'),
          completed:false
        }
      ]);
    });
  }

  app.querySelectorAll('[data-action="toggle-timesheet"]').forEach(btn=>{
    btn.addEventListener('click',async()=>{
      const id=btn.dataset.id;
      await store.updateDomain('timesheet',rows=>rows.map(x=>
        x.id===id?{...x,completed:!x.completed}:x
      ));
    });
  });

  app.querySelectorAll('[data-action="delete-timesheet"]').forEach(btn=>{
    btn.addEventListener('click',async()=>{
      const id=btn.dataset.id;
      await store.updateDomain('timesheet',rows=>rows.filter(x=>x.id!==id));
    });
  });

  const prospectForm=app.querySelector('#prospect-form');
  if(prospectForm){
    prospectForm.addEventListener('submit',async e=>{
      e.preventDefault();
      const f=new FormData(prospectForm);
      const name=String(f.get('name')||'').trim();
      if(!name) return;
      await store.updateDomain('networking',net=>({
        ...net,
        prospects:[
          ...(net.prospects||[]),
          {
            id:uid('prospect'),
            name,
            referrerName:String(f.get('referrerName')||''),
            consultantName:String(f.get('consultantName')||''),
            status:'new',
            createdAt:new Date().toISOString()
          }
        ]
      }));
    });
  }

  const actionForm=app.querySelector('#network-action-form');
  if(actionForm){
    actionForm.addEventListener('submit',async e=>{
      e.preventDefault();
      const f=new FormData(actionForm);
      const prospectId=String(f.get('prospectId')||'');
      if(!prospectId) return;
      await store.updateDomain('networking',net=>({
        ...net,
        actions:[
          ...(net.actions||[]),
          {
            id:uid('action'),
            prospectId,
            actionType:String(f.get('actionType')||'ارتباط‌سازی'),
            result:String(f.get('result')||''),
            createdAt:new Date().toISOString()
          }
        ]
      }));
    });
  }

  app.querySelectorAll('[data-action="delete-prospect"]').forEach(btn=>{
    btn.addEventListener('click',async()=>{
      const id=btn.dataset.id;
      await store.updateDomain('networking',net=>({
        prospects:(net.prospects||[]).filter(p=>p.id!==id),
        actions:(net.actions||[]).filter(a=>a.prospectId!==id)
      }));
    });
  });


  app.querySelectorAll('[data-action="buy-hero"]').forEach(btn=>{
    btn.addEventListener('click',async()=>{
      const id=btn.dataset.id;
      const state=store.getState();
      const hero=state.shop.heroes.find(h=>h.id===id);
      if(!hero || hero.owned || state.player.gold < hero.priceGold) return;

      await store.setState(s=>{
        s.player.gold -= hero.priceGold;
        s.shop.heroes = s.shop.heroes.map(h=>h.id===id?{...h,owned:true}:h);
        s.shop.transactions.push({
          id:uid('tx'),
          type:'hero_purchase',
          heroId:id,
          gold:-hero.priceGold,
          createdAt:new Date().toISOString()
        });
        return s;
      });
    });
  });

  app.querySelectorAll('[data-action="select-hero"]').forEach(btn=>{
    btn.addEventListener('click',async()=>{
      const id=btn.dataset.id;
      const hero=store.getState().shop.heroes.find(h=>h.id===id);
      if(!hero?.owned) return;
      await store.setState(s=>{
        s.heroes.selectedHeroId=id;
        s.player.selectedHeroId=id;
        return s;
      });
    });
  });

  app.querySelectorAll('[data-action="claim-real-reward"]').forEach(btn=>{
    btn.addEventListener('click',async()=>{
      const id=btn.dataset.id;
      const state=store.getState();
      const reward=state.shop.realRewards.find(r=>r.id===id);
      if(!reward || state.player.diamonds < reward.costDiamond) return;
      await store.setState(s=>{
        s.player.diamonds -= reward.costDiamond;
        s.shop.transactions.push({
          id:uid('tx'),
          type:'real_reward_claim',
          rewardId:id,
          diamond:-reward.costDiamond,
          createdAt:new Date().toISOString()
        });
        return s;
      });
    });
  });

  const eventForm=app.querySelector('#event-form');
  if(eventForm){
    eventForm.addEventListener('submit',async e=>{
      e.preventDefault();
      const f=new FormData(eventForm);
      await store.updateDomain('events',events=>[
        ...events,
        {
          id:uid('event'),
          title:String(f.get('title')||'').trim(),
          startDate:String(f.get('startDate')||''),
          endDate:String(f.get('endDate')||''),
          targetValue:Number(f.get('targetValue')||100),
          currentValue:0,
          status:'tracking'
        }
      ]);
    });
  }

  app.querySelectorAll('[data-action="event-progress"]').forEach(btn=>{
    btn.addEventListener('click',async()=>{
      const id=btn.dataset.id;
      await store.updateDomain('events',events=>events.map(e=>{
        if(e.id!==id) return e;
        const currentValue=Math.min(e.targetValue,(e.currentValue||0)+10);
        return {...e,currentValue,status:currentValue>=e.targetValue?'qualified':'tracking'};
      }));
    });
  });

  app.querySelectorAll('[data-action="delete-event"]').forEach(btn=>{
    btn.addEventListener('click',async()=>{
      const id=btn.dataset.id;
      await store.updateDomain('events',events=>events.filter(e=>e.id!==id));
    });
  });

  const visionForm=app.querySelector('#vision-form');
  if(visionForm){
    visionForm.addEventListener('submit',async e=>{
      e.preventDefault();
      const f=new FormData(visionForm);
      await store.updateDomain('vision',goals=>[
        ...goals,
        {
          id:uid('goal'),
          title:String(f.get('title')||'').trim(),
          year:Number(f.get('year')||1406),
          category:String(f.get('category')||'شخصی'),
          targetValue:Number(f.get('targetValue')||100),
          currentValue:0,
          status:'active'
        }
      ]);
    });
  }

  app.querySelectorAll('[data-action="vision-progress"]').forEach(btn=>{
    btn.addEventListener('click',async()=>{
      const id=btn.dataset.id;
      await store.updateDomain('vision',goals=>goals.map(g=>{
        if(g.id!==id) return g;
        const step=Math.max(1,Math.round(g.targetValue*.1));
        const currentValue=Math.min(g.targetValue,(g.currentValue||0)+step);
        return {...g,currentValue,status:currentValue>=g.targetValue?'achieved':'active'};
      }));
    });
  });

  app.querySelectorAll('[data-action="vision-achieve"]').forEach(btn=>{
    btn.addEventListener('click',async()=>{
      const id=btn.dataset.id;
      await store.updateDomain('vision',goals=>goals.map(g=>
        g.id===id?{...g,currentValue:g.targetValue,status:'achieved'}:g
      ));
    });
  });

  app.querySelectorAll('[data-action="delete-vision"]').forEach(btn=>{
    btn.addEventListener('click',async()=>{
      const id=btn.dataset.id;
      await store.updateDomain('vision',goals=>goals.filter(g=>g.id!==id));
    });
  });

  app.querySelectorAll('[data-action="claim-achievement"]').forEach(btn=>{
    btn.addEventListener('click',async()=>{
      const id=btn.dataset.id;
      await store.setState(s=>{
        const a=s.achievements.find(x=>x.id===id);
        if(!a || a.state!=='ready') return s;
        a.state='claimed';
        s.player.xp += a.rewardXP||0;
        s.player.gold += a.rewardGold||0;
        s.player.diamonds += a.rewardDiamond||0;
        return s;
      });
    });
  });

  const settingsForm=app.querySelector('#settings-form');
  if(settingsForm){
    settingsForm.addEventListener('submit',async e=>{
      e.preventDefault();
      const f=new FormData(settingsForm);
      await store.updateDomain('settings',s=>({
        ...s,
        matchMinutes:Math.max(10,Math.min(90,Number(f.get('matchMinutes')||30))),
        waveSeconds:Math.max(10,Number(f.get('waveSeconds')||45)),
        qualityTier:String(f.get('qualityTier')||'balanced'),
        reduceMotion:f.get('reduceMotion')==='on',
        leftHandMode:f.get('leftHandMode')==='on'
      }));
    });
  }


  const confirmPrebattle=app.querySelector('[data-action="confirm-prebattle"]');
  if(confirmPrebattle){
    confirmPrebattle.addEventListener('click',async()=>{
      if(store.getState().activeMatch) return;
      const built=buildMatchFromState(store.getState());
      if(!built.ok) return;
      await store.updateDomain('activeMatch',()=>built.match);
      router.go('gameplay');
    });
  }

  app.querySelectorAll('[data-action="open-minion-encounter"]').forEach(btn=>{
    btn.addEventListener('click',async()=>{
      await matchOrchestrator?.setEncounter({kind:'minion',id:btn.dataset.id});
    });
  });

  app.querySelectorAll('[data-action="open-tower-encounter"]').forEach(btn=>{
    btn.addEventListener('click',async()=>{
      await matchOrchestrator?.setEncounter({kind:'tower',id:btn.dataset.id});
    });
  });

  const baseEncounter=app.querySelector('[data-action="open-base-encounter"]');
  if(baseEncounter){
    baseEncounter.addEventListener('click',async()=>{
      await matchOrchestrator?.setEncounter({kind:'base',id:'base_enemy'});
    });
  }

  const completeEncounter=app.querySelector('[data-action="complete-live-encounter"]');
  if(completeEncounter){
    completeEncounter.addEventListener('click',async()=>{
      completeEncounter.disabled=true;
      await matchOrchestrator?.completeEncounter();
    });
  }

  const deferEncounter=app.querySelector('[data-action="defer-live-encounter"]');
  if(deferEncounter){
    deferEncounter.addEventListener('click',async()=>{
      await matchOrchestrator?.deferEncounter();
    });
  }

  const cancelEncounter=app.querySelector('[data-action="cancel-live-encounter"]');
  if(cancelEncounter){
    cancelEncounter.addEventListener('click',async()=>{
      await matchOrchestrator?.cancelEncounter();
    });
  }

  const pauseMatch=app.querySelector('[data-action="pause-match"]');
  if(pauseMatch){
    pauseMatch.addEventListener('click',async()=>{
      await matchOrchestrator?.pause();
    });
  }

  const resumeLive=app.querySelector('[data-action="resume-match-live"]');
  if(resumeLive){
    resumeLive.addEventListener('click',async()=>{
      await matchOrchestrator?.resume();
    });
  }

  app.querySelectorAll('[data-action="manual-exit-match"]').forEach(btn=>{
    btn.addEventListener('click',async()=>{
      await matchOrchestrator?.manualExit();
    });
  });

  const devSpawn=app.querySelector('[data-action="dev-spawn-minion"]');
  if(devSpawn){
    devSpawn.addEventListener('click',async()=>{
      await matchOrchestrator?.devSpawnMinion();
    });
  }

  const resultsHome=app.querySelector('[data-action="results-home"]');
  if(resultsHome){
    resultsHome.addEventListener('click',async()=>{
      await matchOrchestrator?.finishResultsToHome();
    });
  }

  const start=app.querySelector('[data-action="start-game"]');
  if(start){
    start.addEventListener('click',()=>{
      if(store.getState().activeMatch) return;
      router.go('prebattle');
    });
  }

  const resume=app.querySelector('[data-action="resume-match"]');
  if(resume){
    resume.addEventListener('click',()=>{
      const match=store.getState().activeMatch;
      if(match?.status==='running' || match?.status==='ready'){
        router.go('gameplay');
      }
    });
  }

  const end=app.querySelector('[data-action="end-match"]');
  if(end){
    end.addEventListener('click',async()=>{
      await store.updateDomain('activeMatch',()=>null);
    });
  }
}

function render(){
  app.innerHTML=renderRoute(currentRoute,store.getState());
  document.body.dataset.route=currentRoute;
  bindInteractions();
}

store.subscribe(()=>render());

const hydration=await store.hydrate();

if(!hydration.ok){
  app.innerHTML=`
    <main class="boot-error">
      <section>
        <h1>اطلاعات نیاز به بازیابی دارد</h1>
        <p>State محلی قابل اعتماد نیست و بدون تأیید بازنویسی نمی‌شود.</p>
      </section>
    </main>
  `;
}else{
  router=new AppRouter(async route=>{
    if(currentRoute==='gameplay' && route!=='gameplay'){
      matchOrchestrator?.unmount();
    }

    currentRoute=route;

    if(!matchOrchestrator){
      matchOrchestrator=new LiveMatchOrchestrator({store,router});
      matchOrchestrator.subscribe(()=>render());
    }

    render();

    if(route==='gameplay'){
      await matchOrchestrator.mount();
    }
  });
  router.start();
}
