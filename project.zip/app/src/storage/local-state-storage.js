const STORAGE_KEY = 'shahriar_game_state_v95';

export class LocalStateStorage {
  async load(){
    const raw = localStorage.getItem(STORAGE_KEY);
    if(!raw) return null;
    try{
      return JSON.parse(raw);
    }catch{
      return {__corrupt:true};
    }
  }

  async save(state){
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    return true;
  }

  async clear(){
    localStorage.removeItem(STORAGE_KEY);
  }
}

export const STORAGE_VERSION = 95;
