export const PRIMARY_ROUTES = Object.freeze([
  'home','tasks','stats','timesheet','networking'
]);

export const SECONDARY_ROUTES = Object.freeze([
  'shop','events','vision','achievements','hero','settings',
  'prebattle','gameplay','results'
]);

export const ALL_ROUTES = new Set([
  ...PRIMARY_ROUTES,
  ...SECONDARY_ROUTES
]);

export function normalizeRoute(hash){
  const raw=(hash||'').replace(/^#\/?/,'').trim();
  if(!raw) return 'home';
  return ALL_ROUTES.has(raw) ? raw : 'home';
}

export class AppRouter {
  constructor(onRoute){
    this.onRoute=onRoute;
    this.current='home';
    this.bound=false;
  }

  start(){
    if(this.bound) return;
    this.bound=true;

    // Fresh launch always Home.
    history.replaceState(null,'','#/home');
    this.current='home';
    this.onRoute('home');

    window.addEventListener('hashchange',()=>{
      const route=normalizeRoute(location.hash);
      this.current=route;
      this.onRoute(route);
    });
  }

  go(route){
    const safe=ALL_ROUTES.has(route) ? route : 'home';
    if(this.current===safe){
      this.onRoute(safe);
      return;
    }
    location.hash=`#/${safe}`;
  }
}
