import { uid } from '../../utils/helpers.js';
import { commitTx,commitReward,rewardTotals,hasTx } from '../services/transaction-service.js';

const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));

export class LiveMatchOrchestrator {
  constructor({store,router}){
    this.store=store;
    this.router=router;
    this.running=false;
    this.raf=null;
    this.lastFrame=0;
    this.lastPersistAt=0;
    this.listeners=new Set();
  }

  subscribe(fn){
    this.listeners.add(fn);
    return ()=>this.listeners.delete(fn);
  }

  emit(){
    this.listeners.forEach(fn=>fn(this.snapshot()));
  }

  snapshot(){
    return this.store.getState().activeMatch;
  }

  async mount(){
    const match=this.snapshot();
    if(!match) return {ok:false,reason:'missing_match'};
    if(!['ready','running'].includes(match.status)){
      return {ok:false,reason:'invalid_match_status'};
    }

    if(match.status==='ready'){
      await this.store.updateDomain('activeMatch',m=>{
        if(!m.startedAt) m.startedAt=new Date().toISOString();
        m.status='running';
        m.timerState.lastReconciledAt=new Date().toISOString();
        return m;
      });
    }else{
      await this.reconcileElapsed();
    }

    this.running=true;
    this.startLoop();
    this.emit();
    return {ok:true};
  }

  unmount(){
    this.running=false;
    if(this.raf!=null) cancelAnimationFrame(this.raf);
    this.raf=null;
  }

  startLoop(){
    if(this.raf!=null) return;
    this.lastFrame=performance.now();
    const tick=async now=>{
      if(!this.running) return;
      const dt=Math.min(0.05,Math.max(0,(now-this.lastFrame)/1000));
      this.lastFrame=now;

      await this.tick(dt,now);
      this.raf=requestAnimationFrame(tick);
    };
    this.raf=requestAnimationFrame(tick);
  }

  async tick(dt,now){
    const match=this.snapshot();
    if(!match || match.status!=='running' || match.paused) return;

    await this.reconcileTimer(now);
    await this.reconcileWaves(now);

    if(now-this.lastPersistAt>1000){
      this.lastPersistAt=now;
      this.emit();
    }
  }

  async reconcileElapsed(){
    const match=this.snapshot();
    if(!match?.startedAt) return;

    const elapsed=Date.now()-new Date(match.startedAt).getTime();
    const remaining=Math.max(0,match.durationMs-elapsed);

    await this.store.updateDomain('activeMatch',m=>{
      m.timerState.remainingMs=remaining;
      m.timerState.lastReconciledAt=new Date().toISOString();
      return m;
    });

    if(remaining<=0){
      await this.finalize('time_end');
    }
  }

  async reconcileTimer(){
    const match=this.snapshot();
    if(!match?.startedAt) return;
    const elapsed=Date.now()-new Date(match.startedAt).getTime();
    const remaining=Math.max(0,match.durationMs-elapsed);

    if(Math.abs((match.timerState.remainingMs||0)-remaining)>250){
      await this.store.updateDomain('activeMatch',m=>{
        m.timerState.remainingMs=remaining;
        m.timerState.lastReconciledAt=new Date().toISOString();
        return m;
      });
    }

    if(remaining<=0){
      await this.finalize('time_end');
    }
  }

  async reconcileWaves(){
    const match=this.snapshot();
    if(!match?.startedAt || match.status!=='running') return;

    const elapsed=Date.now()-new Date(match.startedAt).getTime();
    const interval=match.waveState.intervalMs;
    const dueIndex=Math.floor(elapsed/interval);

    if(dueIndex<=match.waveState.lastWaveIndex) return;

    // Collapse missed waves; only latest due index is processed.
    await this.spawnWave(dueIndex);
  }

  nextTaskForReservation(match){
    const used=new Set(
      (match.reservations||[])
        .filter(r=>r.state==='reserved')
        .map(r=>r.taskId)
    );

    const unused=match.taskPoolSnapshot.find(t=>!used.has(t.taskId));
    return unused || match.taskPoolSnapshot[0] || null;
  }

  chooseLane(match){
    const counts={A:0,B:0,C:0};
    for(const m of match.worldState.minions||[]){
      if(!m.defeated && !m.despawned) counts[m.lane]=(counts[m.lane]||0)+1;
    }
    return Object.entries(counts).sort((a,b)=>a[1]-b[1])[0][0];
  }

  async spawnWave(index){
    const match=this.snapshot();
    if(!match || match.status!=='running') return;

    const txId=`${match.id}:wave:${index}:spawn`;
    if(hasTx(match,txId)) return;

    const active=(match.worldState.minions||[]).filter(m=>!m.defeated&&!m.despawned);
    if(active.length>=6){
      await this.store.updateDomain('activeMatch',m=>{
        m.waveState.lastWaveIndex=index;
        commitTx(m,{txId,type:'wave_skip_cap'});
        return m;
      });
      return;
    }

    const task=this.nextTaskForReservation(match);
    if(!task){
      await this.store.updateDomain('activeMatch',m=>{
        m.waveState.lastWaveIndex=index;
        commitTx(m,{txId,type:'wave_no_task'});
        return m;
      });
      return;
    }

    const lane=this.chooseLane(match);
    const reservationId=uid('reservation');
    const minionId=uid('minion');

    await this.store.updateDomain('activeMatch',m=>{
      m.reservations.push({
        id:reservationId,
        taskId:task.taskId,
        minionId,
        state:'reserved',
        waveIndex:index
      });

      m.worldState.minions.push({
        id:minionId,
        lane,
        taskId:task.taskId,
        reservationId,
        taskSnapshot:{...task},
        defeated:false,
        despawned:false,
        fogState:'visible',
        x:lane==='A'?28:lane==='B'?50:72,
        y:78
      });

      m.waveState.lastWaveIndex=index;
      commitTx(m,{txId,type:'wave_spawn'});
      return m;
    });
  }

  async devSpawnMinion(){
    const match=this.snapshot();
    if(!match || match.status!=='running') return;
    await this.spawnWave((match.waveState.lastWaveIndex||0)+1);
  }

  async setEncounter(target){
    const match=this.snapshot();
    if(!match || match.encounter) return {ok:false,reason:'encounter_locked'};
    if(!target) return {ok:false,reason:'missing_target'};

    let taskSnapshot=null;

    if(target.kind==='minion'){
      const minion=match.worldState.minions.find(m=>m.id===target.id);
      taskSnapshot=minion?.taskSnapshot||null;
    }else{
      taskSnapshot=match.taskPoolSnapshot.find(t=>
        !match.transactions.some(tx=>tx.type==='task_commit' && tx.taskId===t.taskId)
      ) || match.taskPoolSnapshot[0];
    }

    if(!taskSnapshot) return {ok:false,reason:'no_task'};

    await this.store.updateDomain('activeMatch',m=>{
      m.encounter={
        id:uid('encounter'),
        target:{...target},
        taskSnapshot:{...taskSnapshot},
        openedAt:new Date().toISOString(),
        state:'open'
      };
      return m;
    });

    return {ok:true};
  }

  async cancelEncounter(){
    await this.store.updateDomain('activeMatch',m=>{
      if(m) m.encounter=null;
      return m;
    });
  }

  async deferEncounter(){
    await this.store.updateDomain('activeMatch',m=>{
      if(!m?.encounter) return m;
      const target=m.encounter.target;
      if(target.kind==='minion'){
        const minion=m.worldState.minions.find(x=>x.id===target.id);
        if(minion){
          const r=m.reservations.find(x=>x.id===minion.reservationId);
          if(r) r.state='deferred_current_match';
          minion.despawned=true;
        }
      }
      m.encounter=null;
      return m;
    });
  }

  async completeEncounter(){
    const match=this.snapshot();
    const enc=match?.encounter;
    if(!enc || enc.state!=='open') return {ok:false,reason:'no_open_encounter'};

    const task=enc.taskSnapshot;
    const taskTxId=`${match.id}:task:${task.taskId}:enc:${enc.id}`;
    const rewardTxId=`${taskTxId}:reward`;

    await this.store.updateDomain('activeMatch',m=>{
      if(hasTx(m,taskTxId)) return m;

      commitTx(m,{
        txId:taskTxId,
        type:'task_commit',
        taskId:task.taskId,
        encounterId:enc.id
      });

      m.stats.tasksCompleted+=1;
      m.encounter.state='task_committed';
      return m;
    });

    const fresh=this.snapshot();
    const target=fresh.encounter?.target;

    if(target?.kind==='minion'){
      await this.resolveMinion(target.id,task,rewardTxId);
    }else if(target?.kind==='tower'){
      await this.resolveTower(target.id,task,rewardTxId);
    }else if(target?.kind==='base'){
      await this.resolveBase(task,rewardTxId);
    }

    await this.store.updateDomain('activeMatch',m=>{
      if(m) m.encounter=null;
      return m;
    });

    this.emit();
    return {ok:true};
  }

  async applyTaskReward(match,task,rewardTxId,sourceType,sourceId){
    const result=commitReward(match,{
      txId:rewardTxId,
      sourceType,
      sourceId,
      xp:Number(task.xp)||0,
      gold:Number(task.gold)||0,
      diamond:Number(task.diamond)||0
    });
    return result.committed;
  }

  async resolveMinion(minionId,task,rewardTxId){
    await this.store.updateDomain('activeMatch',m=>{
      const minion=m.worldState.minions.find(x=>x.id===minionId);
      if(!minion || minion.defeated) return m;

      const defeatTxId=`${m.id}:minion:${minionId}:defeat`;
      if(!hasTx(m,defeatTxId)){
        commitTx(m,{txId:defeatTxId,type:'minion_defeat',minionId});
        minion.defeated=true;
        minion.despawned=true;
        m.stats.minionsDefeated+=1;

        const r=m.reservations.find(x=>x.id===minion.reservationId);
        if(r) r.state='completed';
      }

      this.applyTaskReward(m,task,rewardTxId,'minion',minionId);
      return m;
    });
  }

  async resolveTower(towerId,task,rewardTxId){
    await this.store.updateDomain('activeMatch',m=>{
      const tower=m.worldState.towers[towerId];
      if(!tower || !tower.unlocked || tower.destroyed) return m;

      const damageTxId=`${m.id}:tower:${towerId}:damage:${m.stats.tasksCompleted}`;
      if(!hasTx(m,damageTxId)){
        const before=tower.hp;
        tower.hp=clamp(before-m.settingsSnapshot.towerDamage,0,m.settingsSnapshot.towerHP);
        commitTx(m,{
          txId:damageTxId,
          type:'tower_damage',
          towerId,
          before,
          after:tower.hp
        });
      }

      this.applyTaskReward(m,task,rewardTxId,'tower',towerId);

      if(tower.hp===0 && !tower.destroyed){
        const destructionTxId=`${m.id}:tower:${towerId}:destroy`;
        if(!hasTx(m,destructionTxId)){
          commitTx(m,{txId:destructionTxId,type:'tower_destruction',towerId});
          tower.destroyed=true;
          m.stats.towersDestroyed+=1;

          if(tower.slot===1){
            const next=`tower_${tower.lane.toLowerCase()}_2`;
            if(m.worldState.towers[next]) m.worldState.towers[next].unlocked=true;
          }else{
            if(!m.objectiveState.completedLanes.includes(tower.lane)){
              m.objectiveState.completedLanes.push(tower.lane);
              m.stats.lanesCompleted=m.objectiveState.completedLanes.length;
            }
            m.objectiveState.enemyBaseUnlocked=true;
            m.worldState.enemyBase.unlocked=true;
          }
        }
      }

      return m;
    });
  }

  async resolveBase(task,rewardTxId){
    let shouldVictory=false;

    await this.store.updateDomain('activeMatch',m=>{
      const base=m.worldState.enemyBase;
      if(!base.unlocked || base.destroyed) return m;

      const damageTxId=`${m.id}:base:damage:${m.stats.tasksCompleted}`;
      if(!hasTx(m,damageTxId)){
        const before=base.hp;
        base.hp=clamp(before-m.settingsSnapshot.baseDamage,0,m.settingsSnapshot.baseHP);
        commitTx(m,{
          txId:damageTxId,
          type:'base_damage',
          before,
          after:base.hp
        });
      }

      this.applyTaskReward(m,task,rewardTxId,'base','base_enemy');

      if(base.hp===0 && !base.destroyed){
        const destroyTxId=`${m.id}:base:destroy`;
        if(!hasTx(m,destroyTxId)){
          commitTx(m,{txId:destroyTxId,type:'base_destruction'});
          base.destroyed=true;
        }
        shouldVictory=true;
      }
      return m;
    });

    if(shouldVictory){
      await this.finalize('victory');
    }
  }

  async pause(){
    await this.store.updateDomain('activeMatch',m=>{
      if(m?.status==='running') m.paused=true;
      return m;
    });
  }

  async resume(){
    await this.store.updateDomain('activeMatch',m=>{
      if(m?.status==='running') m.paused=false;
      return m;
    });
  }

  async manualExit(){
    await this.finalize('manual_exit');
  }

  async finalize(resultType){
    const match=this.snapshot();
    if(!match || match.status==='finalized') return;
    if(!['victory','time_end','manual_exit'].includes(resultType)) return;

    const finalizeTxId=`${match.id}:finalize`;

    await this.store.updateDomain('activeMatch',m=>{
      if(hasTx(m,finalizeTxId) || m.status==='finalized') return m;

      if(resultType==='victory'){
        const bonusTxId=`${m.id}:victory_bonus`;
        if(!m.worldState.enemyBase.destroyed) return m;

        commitReward(m,{
          txId:bonusTxId,
          sourceType:'victory_bonus',
          sourceId:m.id,
          xp:400,
          gold:150,
          diamond:1
        });
      }

      commitTx(m,{
        txId:finalizeTxId,
        type:'result_finalize',
        resultType
      });

      m.status='finalized';
      m.resultType=resultType;
      m.endedAt=new Date().toISOString();

      const totals=rewardTotals(m);
      const played=Math.max(0,
        new Date(m.endedAt).getTime()-new Date(m.startedAt||m.createdAt).getTime()
      );

      m.resultSnapshot={
        matchId:m.id,
        resultType,
        durationPlayedMs:played,
        tasksCompleted:m.stats.tasksCompleted,
        minionsDefeated:m.stats.minionsDefeated,
        towersDestroyed:m.stats.towersDestroyed,
        lanesCompleted:m.stats.lanesCompleted,
        xp:totals.xp,
        gold:totals.gold,
        diamond:totals.diamond
      };

      return m;
    });

    await this.commitMatchRewardsToPlayerOnce();
    this.unmount();
    this.router.go('results');
  }

  async commitMatchRewardsToPlayerOnce(){
    const match=this.snapshot();
    if(!match?.resultSnapshot) return;

    const applyTxId=`${match.id}:apply_player_rewards`;

    await this.store.setState(s=>{
      const m=s.activeMatch;
      if(!m) return s;
      if(hasTx(m,applyTxId)) return s;

      const totals=m.resultSnapshot;
      s.player.xp += totals.xp||0;
      s.player.gold += totals.gold||0;
      s.player.diamonds += totals.diamond||0;

      commitTx(m,{txId:applyTxId,type:'player_reward_apply'});
      return s;
    });
  }

  async finishResultsToHome(){
    await this.store.setState(s=>{
      if(s.activeMatch?.status==='finalized'){
        s.matchHistory=[...(s.matchHistory||[]),s.activeMatch];
        s.activeMatch=null;
      }
      return s;
    });
    this.router.go('home');
  }
}
