export function hasTx(match,txId){
  return (match.transactions||[]).some(t=>t.txId===txId && t.committed===true);
}

export function commitTx(match,tx){
  if(hasTx(match,tx.txId)) return {match,committed:false,duplicate:true};
  match.transactions.push({
    ...tx,
    committed:true,
    committedAt:new Date().toISOString()
  });
  return {match,committed:true,duplicate:false};
}

export function ledgerHas(match,txId){
  return (match.ledger||[]).some(x=>x.txId===txId);
}

export function commitReward(match,reward){
  if(ledgerHas(match,reward.txId)){
    return {match,committed:false,duplicate:true};
  }
  match.ledger.push({
    ...reward,
    committedAt:new Date().toISOString()
  });
  return {match,committed:true,duplicate:false};
}

export function rewardTotals(match){
  return (match.ledger||[]).reduce((a,x)=>({
    xp:a.xp+(Number(x.xp)||0),
    gold:a.gold+(Number(x.gold)||0),
    diamond:a.diamond+(Number(x.diamond)||0)
  }),{xp:0,gold:0,diamond:0});
}
