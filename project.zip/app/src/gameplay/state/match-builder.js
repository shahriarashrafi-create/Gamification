import { uid } from '../../utils/helpers.js';

export function eligibleTasks(tasks=[]){
  return tasks.filter(t=>t.activeInGame === true && t.status === 'active');
}

export function buildMatchFromState(state){
  const tasks = eligibleTasks(state.tasks);
  if(!tasks.length){
    return {ok:false,reason:'no_eligible_tasks'};
  }

  const now = new Date().toISOString();
  const id = uid('match');
  const settings = state.settings || {};

  const match = {
    id,
    schemaVersion:98,
    status:'ready',
    resultType:null,
    createdAt:now,
    startedAt:null,
    endedAt:null,
    durationMs:(Number(settings.matchMinutes)||30)*60000,

    settingsSnapshot:{
      matchMinutes:Number(settings.matchMinutes)||30,
      waveSeconds:Number(settings.waveSeconds)||45,
      towerHP:100,
      baseHP:100,
      towerDamage:34,
      baseDamage:25
    },

    heroSnapshot:{
      heroId:state.heroes?.selectedHeroId || state.player.selectedHeroId
    },

    taskPoolSnapshot:tasks.map(t=>({
      taskId:t.id,
      title:t.title,
      category:t.category,
      difficulty:t.difficulty,
      xp:Number(t.xp)||0,
      gold:Number(t.gold)||0,
      diamond:Number(t.diamond)||0
    })),

    mapSnapshot:{
      worldWidth:1200,
      worldHeight:2600,
      heroSpawn:{x:50,y:89},
      lanes:['A','B','C']
    },

    worldState:{
      hero:{x:50,y:89,vx:0,vy:0},
      minions:[],
      towers:{
        tower_a_1:{id:'tower_a_1',lane:'A',slot:1,hp:100,unlocked:true,destroyed:false},
        tower_a_2:{id:'tower_a_2',lane:'A',slot:2,hp:100,unlocked:false,destroyed:false},
        tower_b_1:{id:'tower_b_1',lane:'B',slot:1,hp:100,unlocked:true,destroyed:false},
        tower_b_2:{id:'tower_b_2',lane:'B',slot:2,hp:100,unlocked:false,destroyed:false},
        tower_c_1:{id:'tower_c_1',lane:'C',slot:1,hp:100,unlocked:true,destroyed:false},
        tower_c_2:{id:'tower_c_2',lane:'C',slot:2,hp:100,unlocked:false,destroyed:false}
      },
      enemyBase:{id:'base_enemy',hp:100,unlocked:false,destroyed:false}
    },

    objectiveState:{
      completedLanes:[],
      currentTargetId:null,
      enemyBaseUnlocked:false
    },

    timerState:{
      remainingMs:(Number(settings.matchMinutes)||30)*60000,
      lastReconciledAt:null
    },

    waveState:{
      intervalMs:(Number(settings.waveSeconds)||45)*1000,
      lastWaveIndex:0
    },

    reservations:[],
    transactions:[],
    ledger:[],

    stats:{
      tasksCompleted:0,
      minionsDefeated:0,
      towersDestroyed:0,
      lanesCompleted:0
    },

    encounter:null,
    paused:false
  };

  return {ok:true,match};
}
