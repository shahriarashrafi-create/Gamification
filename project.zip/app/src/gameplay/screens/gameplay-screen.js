import { escapeHtml } from '../../components/shell-components.js';

function fmt(ms=0){
  const total=Math.max(0,Math.ceil(ms/1000));
  const m=Math.floor(total/60);
  const s=total%60;
  return `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
}

export function gameplayScreen(state){
  const m=state.activeMatch;
  if(!m){
    return `<main class="screen gameplay-live"><section class="panel"><b>Match پیدا نشد.</b><button data-route="home">خانه</button></section></main>`;
  }

  const totals=(m.ledger||[]).reduce((a,x)=>({
    xp:a.xp+(x.xp||0),
    gold:a.gold+(x.gold||0),
    diamond:a.diamond+(x.diamond||0)
  }),{xp:0,gold:0,diamond:0});

  const liveMinions=(m.worldState.minions||[]).filter(x=>!x.despawned&&!x.defeated);
  const towers=Object.values(m.worldState.towers||{});
  const base=m.worldState.enemyBase;

  return `
    <main class="gameplay-live">
      <header class="game-hud">
        <button data-action="pause-match">Pause</button>
        <div><small>زمان</small><b>${fmt(m.timerState.remainingMs)}</b></div>
        <div><small>هدف</small><b>${base.unlocked?'بیس دشمن':'تاورهای مسیر'}</b></div>
      </header>

      <div class="reward-strip">
        <span>${totals.xp} XP</span>
        <span>${totals.gold} Gold</span>
        <span>${totals.diamond} Diamond</span>
      </div>

      <section class="battlefield-live">
        <div class="base enemy-base ${base.unlocked?'unlocked':'locked'}">
          <small>Enemy Base</small>
          <b>${base.hp} HP</b>
          ${base.unlocked&&!base.destroyed?`<button data-action="open-base-encounter">حمله</button>`:''}
        </div>

        <div class="tower-grid">
          ${towers.map(t=>`
            <div class="tower ${t.unlocked?'unlocked':'locked'} ${t.destroyed?'destroyed':''}">
              <small>${t.id}</small>
              <b>${t.hp} HP</b>
              ${t.unlocked&&!t.destroyed?`<button data-action="open-tower-encounter" data-id="${t.id}">کار</button>`:''}
            </div>
          `).join('')}
        </div>

        <div class="minion-layer">
          ${liveMinions.map(minion=>`
            <button class="minion" data-action="open-minion-encounter" data-id="${minion.id}">
              <small>${minion.lane}</small>
              <b>${escapeHtml(minion.taskSnapshot?.title||'Task')}</b>
            </button>
          `).join('')}
        </div>

        <div class="hero-live">HERO</div>

        <div class="joystick-shell"><i></i></div>
      </section>

      <div class="game-controls">
        <button data-action="dev-spawn-minion">DEV Spawn Task Minion</button>
        <button data-action="manual-exit-match">خروج</button>
      </div>

      ${m.paused?`
        <div class="overlay-sheet">
          <div>
            <h2>بازی متوقف شده</h2>
            <button data-action="resume-match-live">ادامه بازی</button>
            <button data-action="manual-exit-match">خروج از بازی</button>
          </div>
        </div>
      `:''}

      ${m.encounter?`
        <div class="overlay-sheet">
          <div class="task-sheet">
            <small>کار واقعی</small>
            <h2>${escapeHtml(m.encounter.taskSnapshot.title)}</h2>
            <p>${m.encounter.taskSnapshot.xp||0} XP • ${m.encounter.taskSnapshot.gold||0} Gold ${m.encounter.taskSnapshot.diamond>0?`• ${m.encounter.taskSnapshot.diamond} Diamond`:''}</p>
            <button data-action="complete-live-encounter" class="complete">انجام شد</button>
            <button data-action="defer-live-encounter">بعداً</button>
            <button data-action="cancel-live-encounter">لغو</button>
          </div>
        </div>
      `:''}
    </main>
  `;
}
