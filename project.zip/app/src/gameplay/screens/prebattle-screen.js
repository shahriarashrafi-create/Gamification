export function prebattleScreen(state){
  const eligible=(state.tasks||[]).filter(t=>t.activeInGame&&t.status==='active');
  const hero=state.shop?.heroes?.find(h=>h.id===(state.heroes?.selectedHeroId||state.player.selectedHeroId));

  return `
    <main class="screen secondary-screen">
      <header class="screen-header">
        <small>PRE-BATTLE</small>
        <h1>آماده‌سازی بازی</h1>
      </header>
      <section class="panel stack">
        <div class="prep-row"><span>Hero</span><b>${hero?.name||'انتخاب نشده'}</b></div>
        <div class="prep-row"><span>کارهای فعال</span><b>${eligible.length}</b></div>
        <div class="prep-row"><span>مدت بازی</span><b>${state.settings.matchMinutes} دقیقه</b></div>
        <div class="prep-row"><span>Wave</span><b>${state.settings.waveSeconds} ثانیه</b></div>
      </section>
      ${eligible.length?`
        <button data-action="confirm-prebattle" class="primary-cta">ورود به میدان</button>
      `:`
        <section class="recover-card"><b>برای شروع بازی حداقل یک کار فعال لازم است.</b></section>
        <button data-route="tasks" class="back-home">رفتن به کارها</button>
      `}
      <button data-route="home" class="back-home">بازگشت</button>
    </main>
  `;
}
