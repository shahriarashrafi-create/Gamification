export function resultsScreen(state){
  const r=state.activeMatch?.resultSnapshot;
  if(!r){
    return `<main class="screen secondary-screen"><section class="panel"><b>نتیجه بازی نیاز به بازیابی دارد.</b><button data-route="home">خانه</button></section></main>`;
  }

  const title=r.resultType==='victory'
    ? 'پیروزی'
    : r.resultType==='time_end'
      ? 'زمان تمام شد'
      : 'بازی پایان داده شد';

  return `
    <main class="screen result-live">
      <header class="result-hero">
        <small>RESULT</small>
        <h1>${title}</h1>
      </header>
      <section class="result-grid">
        <div><small>کار</small><b>${r.tasksCompleted}</b></div>
        <div><small>Minion</small><b>${r.minionsDefeated}</b></div>
        <div><small>Tower</small><b>${r.towersDestroyed}</b></div>
        <div><small>Lane</small><b>${r.lanesCompleted}</b></div>
      </section>
      <section class="wallet-strip">
        <span>XP <b>+${r.xp}</b></span>
        <span>Gold <b>+${r.gold}</b></span>
        <span>Diamond <b>+${r.diamond}</b></span>
      </section>
      <button data-action="results-home" class="primary-cta">بازگشت به خانه</button>
    </main>
  `;
}
