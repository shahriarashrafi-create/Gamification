import { bottomNav,screenHeader } from '../../components/shell-components.js';
import { escapeHtml } from '../../utils/helpers.js';

function node(member,members){
  const children=members.filter(x=>x.parentId===member.id);
  return `
    <div class="tree-branch">
      <article class="tree-node">
        <small>${escapeHtml(member.rank||'')}</small>
        <b>${escapeHtml(member.name)}</b>
        <span>Level ${member.level||1}</span>
        <div class="card-actions">
          <button data-action="edit-member" data-id="${member.id}">ویرایش</button>
          ${member.parentId?`<button data-action="delete-member" data-id="${member.id}" class="danger">حذف</button>`:''}
        </div>
      </article>
      ${children.length?`<div class="tree-children">${children.map(c=>node(c,members)).join('')}</div>`:''}
    </div>
  `;
}

export function statsScreen(state){
  const members=state.networkTree.members||[];
  const root=members.find(x=>x.id===state.networkTree.rootId)||members[0];
  return `
    <main class="screen">
      ${screenHeader('آمار','NETWORK TREE ONLY')}
      <section class="panel stack">
        <form id="member-form" class="form-grid">
          <input name="name" placeholder="نام عضو" required />
          <select name="parentId">
            ${members.map(m=>`<option value="${m.id}">${escapeHtml(m.name)}</option>`).join('')}
          </select>
          <input name="rank" placeholder="رتبه" value="عضو" />
          <input name="level" type="number" min="1" value="1" />
          <button type="submit">افزودن عضو</button>
        </form>
      </section>
      <section class="panel compact">
        <input id="member-search" class="search-input" placeholder="جستجوی عضو..." />
      </section>
      <section class="tree-shell tree-scroll">
        ${root?node(root,members):'<p>درختواره خالی است.</p>'}
      </section>
      ${bottomNav('stats')}
    </main>
  `;
}
