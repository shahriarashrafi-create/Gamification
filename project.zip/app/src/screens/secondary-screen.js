import { screenHeader } from '../components/shell-components.js';

const titles={
  shop:'فروشگاه',
  events:'رویدادها',
  vision:'آینده‌بینی',
  achievements:'دستاوردها',
  hero:'Hero Hub',
  settings:'تنظیمات',
  prebattle:'آماده‌سازی بازی',
  gameplay:'Gameplay',
  results:'نتیجه بازی'
};

export function secondaryScreen(route){
  const gameplay=route==='gameplay';
  return `
    <main class="screen secondary ${gameplay?'gameplay-screen':''}">
      ${screenHeader(titles[route] || route,gameplay?'IMMERSIVE MATCH':'SECONDARY MODULE')}
      <section class="panel">
        <p>این Route به App Router واقعی متصل است.</p>
        ${route==='gameplay'
          ? '<button data-route="home">خروج آزمایشی به خانه</button>'
          : '<button data-route="home">بازگشت به خانه</button>'}
      </section>
    </main>
  `;
}
