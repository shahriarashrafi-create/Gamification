import { bottomNav,screenHeader } from '../../components/shell-components.js';
import { escapeHtml } from '../../utils/helpers.js';

const actionTypes=['ارتباط‌سازی','پیش‌مشاوره','دعوت','معرفی کار','فالوآپ'];

export function networkingScreen(state){
  const prospects=state.networking.prospects||[];
  const actions=state.networking.actions||[];
  return `
    <main class="screen">
      ${screenHeader('شبکه‌سازی','NETWORK COMMAND CENTER')}
      <section class="panel stack">
        <form id="prospect-form" class="form-grid">
          <input name="name" placeholder="نام شخص" required />
          <input name="referrerName" placeholder="معرف" />
          <input name="consultantName" placeholder="مشاور" />
          <button type="submit">افزودن شخص</button>
        </form>
      </section>

      <section class="panel stack">
        <form id="network-action-form" class="form-grid">
          <select name="prospectId" required>
            <option value="">انتخاب شخص</option>
            ${prospects.map(p=>`<option value="${p.id}">${escapeHtml(p.name)}</option>`).join('')}
          </select>
          <select name="actionType">
            ${actionTypes.map(x=>`<option>${x}</option>`).join('')}
          </select>
          <input name="result" placeholder="نتیجه" />
          <button type="submit">ثبت اقدام</button>
        </form>
      </section>

      <section class="list">
        ${prospects.map(p=>{
          const personActions=actions.filter(a=>a.prospectId===p.id).slice().reverse();
          return `
            <article class="list-card crm-card">
              <div>
                <small>${escapeHtml(p.status||'new')}</small>
                <b>${escapeHtml(p.name)}</b>
                <span>${escapeHtml(p.referrerName||'')}</span>
                <div class="timeline-mini">
                  ${personActions.map(a=>`<span>${escapeHtml(a.actionType)}${a.result?` — ${escapeHtml(a.result)}`:''}</span>`).join('')}
                </div>
              </div>
              <button data-action="delete-prospect" data-id="${p.id}" class="danger">حذف</button>
            </article>
          `;
        }).join('')}
      </section>

      ${bottomNav('networking')}
    </main>
  `;
}
