import { bottomNav,screenHeader,escapeHtml } from '../components/shell-components.js';

export function statsScreen(state){
  const members=state.networkTree.members || [];
  return `
    <main class="screen">
      ${screenHeader('آمار','NETWORK TREE ONLY')}
      <section class="tree-shell">
        ${members.map(m=>`
          <article class="tree-node">
            <small>${escapeHtml(m.rank || '')}</small>
            <b>${escapeHtml(m.name)}</b>
            <span>Level ${m.level || 1}</span>
          </article>
        `).join('')}
      </section>
      ${bottomNav('stats')}
    </main>
  `;
}
