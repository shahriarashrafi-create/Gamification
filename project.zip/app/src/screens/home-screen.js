import { bottomNav,screenHeader } from '../components/shell-components.js';

export function homeScreen(state){
  const p=state.player;
  const active=state.activeMatch;
  return `
    <main class="screen home-screen">
      ${screenHeader('خانه','BILLIONERS BATTLE')}
      <section class="hud-card">
        <div><small>بازیکن</small><b>${p.name}</b></div>
        <div><small>Level</small><b>${p.level}</b></div>
        <div><small>XP</small><b>${p.xp}/${p.xpRequired}</b></div>
        <div><small>Gold</small><b>${p.gold}</b></div>
        <div><small>Diamond</small><b>${p.diamonds}</b></div>
      </section>

      <section class="hero-stage">
        <div class="hero-placeholder">HERO</div>
        <div class="rank-card">
          <small>رنک</small>
          <b>${p.rankLabel}</b>
          <span>${p.rankScore}/100 RP</span>
        </div>
      </section>

      ${active ? `
        <section class="recover-card">
          <small>بازی نیمه‌کاره</small>
          <b>${active.status || 'running'}</b>
          <div class="row">
            <button data-action="resume-match">ادامه بازی</button>
            <button data-action="end-match">پایان دادن</button>
          </div>
        </section>
      ` : ''}

      <section class="module-grid">
        <button data-route="shop">فروشگاه</button>
        <button data-route="events">رویدادها</button>
        <button data-route="vision">آینده‌بینی</button>
        <button data-route="achievements">دستاوردها</button>
      </section>

      <button class="primary-cta" data-action="start-game" ${active?'disabled':''}>
        شروع بازی — ${state.settings.matchMinutes} دقیقه
      </button>

      ${bottomNav('home')}
    </main>
  `;
}
