import { screenHeader,escapeHtml } from '../../components/shell-components.js';

export function visionScreen(state){
  return `
    <main class="screen secondary-screen">
      ${screenHeader('آینده‌بینی','FUTURE REALM')}
      <section class="panel stack">
        <form id="vision-form" class="form-grid">
          <input name="title" placeholder="هدف" required />
          <input name="year" type="number" min="1405" value="1406" />
          <select name="category">
            ${['مالی','شغلی','شبکه','دارایی','سبک زندگی','سفر','رشد فردی','سلامت','شخصی'].map(x=>`<option>${x}</option>`).join('')}
          </select>
          <input name="targetValue" type="number" min="1" value="100" />
          <button type="submit">ثبت هدف</button>
        </form>
      </section>
      <section class="list">
        ${(state.vision||[]).map(g=>{
          const pct=Math.min(100,Math.round(((g.currentValue||0)/(g.targetValue||1))*100));
          return `
            <article class="list-card">
              <div>
                <small>${escapeHtml(g.category)} • ${g.year}</small>
                <b>${escapeHtml(g.title)}</b>
                <span>${pct}% • ${g.status}</span>
              </div>
              <div class="card-actions">
                <button data-action="vision-progress" data-id="${g.id}">+10%</button>
                <button data-action="vision-achieve" data-id="${g.id}">انجام شد</button>
                <button data-action="delete-vision" data-id="${g.id}" class="danger">حذف</button>
              </div>
            </article>
          `;
        }).join('')}
      </section>
      <button data-route="home" class="back-home">بازگشت به خانه</button>
    </main>
  `;
}
