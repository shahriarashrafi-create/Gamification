import { screenHeader,escapeHtml } from '../../components/shell-components.js';

export function heroScreen(state){
  const selected=state.heroes?.selectedHeroId || state.player.selectedHeroId;
  return `
    <main class="screen secondary-screen">
      ${screenHeader('Hero Hub','HERO VAULT')}
      <section class="hero-hub-stage">
        <div class="hero-placeholder">HERO</div>
        <b>${escapeHtml((state.shop.heroes||[]).find(h=>h.id===selected)?.name || selected)}</b>
        <span>Visual Identity Only</span>
      </section>
      <section class="list">
        ${(state.shop.heroes||[]).filter(h=>h.owned).map(h=>`
          <article class="list-card">
            <div><b>${escapeHtml(h.name)}</b><span>${selected===h.id?'انتخاب‌شده':'Owned'}</span></div>
            <button data-action="select-hero" data-id="${h.id}">انتخاب</button>
          </article>
        `).join('')}
      </section>
      <button data-route="home" class="back-home">بازگشت به خانه</button>
    </main>
  `;
}
