import { screenHeader,escapeHtml } from '../../components/shell-components.js';

export function achievementsScreen(state){
  return `
    <main class="screen secondary-screen">
      ${screenHeader('دستاوردها','HONOR HALL')}
      <section class="list">
        ${(state.achievements||[]).map(a=>`
          <article class="list-card">
            <div>
              <small>${a.state}</small>
              <b>${escapeHtml(a.title)}</b>
              <span>${a.currentValue}/${a.targetValue}</span>
              <span>${a.rewardXP||0} XP • ${a.rewardGold||0} Gold ${a.rewardDiamond>0?`• ${a.rewardDiamond} Diamond`:''}</span>
            </div>
            <button data-action="claim-achievement" data-id="${a.id}" ${a.state!=='ready'?'disabled':''}>
              دریافت
            </button>
          </article>
        `).join('')}
      </section>
      <button data-route="home" class="back-home">بازگشت به خانه</button>
    </main>
  `;
}
