import { screenHeader } from '../../components/shell-components.js';

export function settingsScreen(state){
  const s=state.settings;
  return `
    <main class="screen secondary-screen">
      ${screenHeader('تنظیمات','SYSTEM CONTROL')}
      <section class="panel stack">
        <form id="settings-form" class="form-grid">
          <label>مدت بازی
            <input name="matchMinutes" type="number" min="10" max="90" value="${s.matchMinutes}">
          </label>
          <label>فاصله Wave
            <input name="waveSeconds" type="number" min="10" value="${s.waveSeconds}">
          </label>
          <label>کیفیت
            <select name="qualityTier">
              ${['high','balanced','battery'].map(x=>`<option value="${x}" ${s.qualityTier===x?'selected':''}>${x}</option>`).join('')}
            </select>
          </label>
          <label class="toggle-label">
            <input name="reduceMotion" type="checkbox" ${s.reduceMotion?'checked':''}>
            Reduce Motion
          </label>
          <label class="toggle-label">
            <input name="leftHandMode" type="checkbox" ${s.leftHandMode?'checked':''}>
            حالت دست چپ
          </label>
          <button type="submit">ذخیره تنظیمات</button>
        </form>
      </section>
      <button data-route="home" class="back-home">بازگشت به خانه</button>
    </main>
  `;
}
