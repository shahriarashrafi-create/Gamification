import { shopScreen } from './shop-screen.js';
import { eventsScreen } from './events-screen.js';
import { visionScreen } from './vision-screen.js';
import { achievementsScreen } from './achievements-screen.js';
import { heroScreen } from './hero-screen.js';
import { settingsScreen } from './settings-screen.js';
import { secondaryScreen } from '../secondary-screen.js';
import { prebattleScreen } from '../../gameplay/screens/prebattle-screen.js';
import { gameplayScreen } from '../../gameplay/screens/gameplay-screen.js';
import { resultsScreen } from '../../gameplay/screens/results-screen.js';

export function renderSecondary(route,state){
  if(route==='shop') return shopScreen(state);
  if(route==='events') return eventsScreen(state);
  if(route==='vision') return visionScreen(state);
  if(route==='achievements') return achievementsScreen(state);
  if(route==='hero') return heroScreen(state);
  if(route==='settings') return settingsScreen(state);
  if(route==='prebattle') return prebattleScreen(state);
  if(route==='gameplay') return gameplayScreen(state);
  if(route==='results') return resultsScreen(state);
  return secondaryScreen(route);
}
