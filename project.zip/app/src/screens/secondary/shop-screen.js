import { screenHeader,escapeHtml } from '../../components/shell-components.js';

export function shopScreen(state){
  const shop=state.shop||{heroes:[],realRewards:[],transactions:[]};
  const selected=state.heroes?.selectedHeroId || state.player.selectedHeroId;
  return `
    <main class="screen secondary-screen">
      ${screenHeader('فروشگاه','REWARD ARMORY')}
      <section class="wallet-strip">
        <span>Gold <b>${state.player.gold}</b></span>
        <span>Diamond <b>${state.player.diamonds}</b></span>
      </section>

      <section class="panel">
        <h3>Hero</h3>
        <div class="list">
          ${(shop.heroes||[]).map(h=>`
            <article class="list-card">
              <div>
                <small>${h.owned?'Owned':`${h.priceGold} Gold`}</small>
                <b>${escapeHtml(h.name)}</b>
                <span>${selected===h.id?'انتخاب‌شده':''}</span>
              </div>
              <div class="card-actions">
                ${h.owned
                  ? `<button data-action="select-hero" data-id="${h.id}">انتخاب</button>`
                  : `<button data-action="buy-hero" data-id="${h.id}">خرید</button>`}
              </div>
            </article>
          `).join('')}
        </div>
      </section>

      <section class="panel">
        <h3>پاداش واقعی</h3>
        <div class="list">
          ${(shop.realRewards||[]).map(r=>`
            <article class="list-card">
              <div><b>${escapeHtml(r.title)}</b><span>${r.costDiamond} Diamond</span></div>
              <button data-action="claim-real-reward" data-id="${r.id}">دریافت</button>
            </article>
          `).join('')}
        </div>
      </section>

      <button data-route="home" class="back-home">بازگشت به خانه</button>
    </main>
  `;
}
