import { screenHeader,escapeHtml } from '../../components/shell-components.js';

export function eventsScreen(state){
  return `
    <main class="screen secondary-screen">
      ${screenHeader('رویدادها','QUALIFICATION WAR ROOM')}
      <section class="panel stack">
        <form id="event-form" class="form-grid">
          <input name="title" placeholder="عنوان رویداد" required />
          <input name="startDate" type="date" required />
          <input name="endDate" type="date" required />
          <input name="targetValue" type="number" min="1" value="100" />
          <button type="submit">ثبت رویداد</button>
        </form>
      </section>
      <section class="list">
        ${(state.events||[]).map(e=>`
          <article class="list-card">
            <div>
              <small>${escapeHtml(e.startDate)} تا ${escapeHtml(e.endDate)}</small>
              <b>${escapeHtml(e.title)}</b>
              <span>${e.currentValue||0}/${e.targetValue||0}</span>
            </div>
            <div class="card-actions">
              <button data-action="event-progress" data-id="${e.id}">+10</button>
              <button data-action="delete-event" data-id="${e.id}" class="danger">حذف</button>
            </div>
          </article>
        `).join('')}
      </section>
      <button data-route="home" class="back-home">بازگشت به خانه</button>
    </main>
  `;
}
