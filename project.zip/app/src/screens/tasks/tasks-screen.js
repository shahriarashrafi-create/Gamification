import { bottomNav,screenHeader } from '../../components/shell-components.js';
import { escapeHtml } from '../../utils/helpers.js';

export function tasksScreen(state){
  const tasks = state.tasks || [];
  return `
    <main class="screen">
      ${screenHeader('کارها','OBJECTIVE ARSENAL')}

      <section class="panel stack">
        <form id="task-form" class="form-grid">
          <input name="title" placeholder="عنوان کار" required />
          <select name="category">
            ${['شبکه‌سازی','فروش','پیگیری','یادگیری','برنامه‌ریزی','شخصی','سلامت','مالی'].map(x=>`<option>${x}</option>`).join('')}
          </select>
          <select name="difficulty">
            <option value="easy">آسان</option>
            <option value="normal" selected>متوسط</option>
            <option value="important">مهم</option>
            <option value="hard">سخت</option>
            <option value="strategic">استراتژیک</option>
          </select>
          <input name="xp" type="number" min="0" value="100" />
          <input name="gold" type="number" min="0" value="30" />
          <input name="diamond" type="number" min="0" value="0" />
          <button type="submit">ثبت کار</button>
        </form>
      </section>

      <section class="panel compact">
        <input id="task-search" class="search-input" placeholder="جستجوی کار..." />
      </section>

      <section class="list" id="task-list">
        ${tasks.map(t=>`
          <article class="list-card task-card" data-search="${escapeHtml((t.title+' '+t.category).toLowerCase())}">
            <div>
              <small>${escapeHtml(t.category || '')} • ${escapeHtml(t.difficulty || '')}</small>
              <b>${escapeHtml(t.title)}</b>
              <span>${t.xp||0} XP • ${t.gold||0} Gold ${t.diamond>0?`• ${t.diamond} Diamond`:''}</span>
              <span>${t.status==='archived'?'آرشیو':'فعال'} • ${t.activeInGame?'داخل بازی':'خارج بازی'}</span>
            </div>
            <div class="card-actions">
              <button data-action="toggle-task" data-id="${t.id}">${t.activeInGame?'غیرفعال بازی':'فعال بازی'}</button>
              <button data-action="archive-task" data-id="${t.id}">${t.status==='archived'?'بازگردانی':'آرشیو'}</button>
              <button data-action="delete-task" data-id="${t.id}" class="danger">حذف</button>
            </div>
          </article>
        `).join('')}
      </section>

      ${bottomNav('tasks')}
    </main>
  `;
}
