import { bottomNav,screenHeader,escapeHtml } from '../components/shell-components.js';

export function timesheetScreen(state){
  return `
    <main class="screen">
      ${screenHeader('تایم‌شیت','WEEKLY PLANNER')}
      <section class="panel">
        <p>${state.timesheet.length ? '' : 'هنوز برنامه‌ای ثبت نشده.'}</p>
        ${state.timesheet.map(x=>`
          <article class="list-card">
            <div><b>${escapeHtml(x.title)}</b><span>${x.date || ''} • ${x.startTime || ''}</span></div>
          </article>
        `).join('')}
      </section>
      ${bottomNav('timesheet')}
    </main>
  `;
}
