import { bottomNav,screenHeader,escapeHtml } from '../components/shell-components.js';

export function networkingScreen(state){
  const prospects=state.networking.prospects || [];
  return `
    <main class="screen">
      ${screenHeader('شبکه‌سازی','NETWORK COMMAND CENTER')}
      <section class="panel">
        <form id="quick-prospect-form" class="quick-form">
          <input name="name" dir="rtl" placeholder="نام شخص..." required />
          <button type="submit">اضافه</button>
        </form>
      </section>
      <section class="list">
        ${prospects.map(p=>`
          <article class="list-card">
            <div><small>${escapeHtml(p.status || 'new')}</small><b>${escapeHtml(p.name)}</b></div>
          </article>
        `).join('')}
      </section>
      ${bottomNav('networking')}
    </main>
  `;
}
