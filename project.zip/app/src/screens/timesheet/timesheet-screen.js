import { bottomNav,screenHeader } from '../../components/shell-components.js';
import { escapeHtml } from '../../utils/helpers.js';

export function timesheetScreen(state){
  const rows=[...(state.timesheet||[])].sort((a,b)=>
    `${a.date}${a.startTime}`.localeCompare(`${b.date}${b.startTime}`)
  );
  return `
    <main class="screen">
      ${screenHeader('تایم‌شیت','SATURDAY-FIRST WEEKLY PLANNER')}
      <section class="panel stack">
        <form id="timesheet-form" class="form-grid">
          <input name="title" placeholder="عنوان برنامه" required />
          <input name="date" type="date" required />
          <input name="startTime" type="time" required />
          <input name="endTime" type="time" required />
          <select name="category">
            ${['شبکه‌سازی','فروش','جلسه','یادگیری','برنامه‌ریزی','شخصی','سلامت'].map(x=>`<option>${x}</option>`).join('')}
          </select>
          <button type="submit">ثبت برنامه</button>
        </form>
      </section>
      <section class="list">
        ${rows.map(x=>`
          <article class="list-card ${x.completed?'done-card':''}">
            <div>
              <small>${escapeHtml(x.category||'')} • ${escapeHtml(x.date||'')}</small>
              <b>${escapeHtml(x.title)}</b>
              <span>${escapeHtml(x.startTime||'')} تا ${escapeHtml(x.endTime||'')}</span>
            </div>
            <div class="card-actions">
              <button data-action="toggle-timesheet" data-id="${x.id}">${x.completed?'انجام‌نشده':'انجام شد'}</button>
              <button data-action="delete-timesheet" data-id="${x.id}" class="danger">حذف</button>
            </div>
          </article>
        `).join('')}
      </section>
      ${bottomNav('timesheet')}
    </main>
  `;
}
