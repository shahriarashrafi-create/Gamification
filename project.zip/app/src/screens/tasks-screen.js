import { bottomNav,screenHeader,escapeHtml } from '../components/shell-components.js';

export function tasksScreen(state){
  return `
    <main class="screen">
      ${screenHeader('کارها','OBJECTIVE ARSENAL')}
      <section class="panel">
        <form id="quick-task-form" class="quick-form">
          <input name="title" dir="rtl" placeholder="کار جدید..." required />
          <button type="submit">اضافه</button>
        </form>
      </section>
      <section class="list">
        ${state.tasks.map(t=>`
          <article class="list-card">
            <div>
              <small>${escapeHtml(t.category || 'بدون دسته')}</small>
              <b>${escapeHtml(t.title)}</b>
              <span>${t.xp} XP • ${t.gold} Gold</span>
            </div>
            <button data-action="toggle-task" data-id="${t.id}">
              ${t.activeInGame?'فعال':'غیرفعال'}
            </button>
          </article>
        `).join('')}
      </section>
      ${bottomNav('tasks')}
    </main>
  `;
}
