export function hudFromPlayer(p){
 const pct=p.xpRequired>0?Math.max(0,Math.min(100,(p.currentXP/p.xpRequired)*100)):0;
 return {name:p.name,level:p.level,xp:p.currentXP,xpRequired:p.xpRequired,xpPercent:pct,gold:p.gold,diamonds:p.diamonds,rankId:p.rankId,rankScore:p.rankScore,selectedHeroId:p.selectedHeroId};
}
export function homeCanStart(state,lastValid){
 if(state==='corrupt_state') return false;
 if(state==='ready') return true;
 if(state==='refreshing' && lastValid) return true;
 return false;
}
