export function canOpenModule({moduleState,routeLock}){
  if(routeLock) return false;
  return ['idle','ready','empty','recoverable_error'].includes(moduleState);
}
export function moduleBadge(id,data){
  switch(id){
    case 'shop': return data.newOrUnlockedAssetCount||0;
    case 'events': return data.activeEventCount||0;
    case 'vision': return data.activeGoalCount||0;
    case 'achievements': return data.readyToClaimCount||0;
    default: return 0;
  }
}
export function navigateModule(router,id,guard){
  if(guard.busy) return {duplicate:true};
  guard.busy=true;
  router.push(id);
  return {duplicate:false};
}
