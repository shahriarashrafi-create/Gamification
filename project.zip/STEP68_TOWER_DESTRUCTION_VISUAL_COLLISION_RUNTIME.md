# STEP 68 — TOWER DESTRUCTION VISUAL + COLLISION RELEASE RUNTIME

این مرحله Destruction Commit قدم 67 را به visual collapse، marker clear و collision release واقعی وصل می‌کند.

## Core Rule

Tower destruction visual فقط committed destruction را نمایش می‌دهد.

هیچ visual callback نمی‌تواند:
HP را صفر کند
Reward بدهد
Lane Progression را تغییر دهد
Collision را زودتر آزاد کند

## Destruction Sequence

HP reaches 0 via committed damage
→ DESTRUCTION_COMMIT
→ controls temporarily constrained
→ objective marker clear
→ crystal fracture
→ core flash
→ structure collapse
→ debris burst
→ smoke/dust linger
→ collision release commit
→ lane progression commit
→ next objective reveal
→ controls resume

## Visual Phases

fracture
core_flash
collapse
debris
smoke
settled

## Timing Defaults

fracture:
140ms

core flash:
120ms

collapse:
420ms

debris:
260ms

smoke:
700ms

collision release:
after destruction commit + collapse threshold

total cinematic target:
~900–1200ms

## Collision Authority

Tower collider stays active until:
destruction committed
AND collision release stage committed

Visual collapse alone does not disable collision.

## Objective Marker

available/focused marker:
cleared after destruction commit

completed marker:
may display briefly for 300–500ms

Then hidden.

## Debris

Debris is VFX-only.

No debris hard collider.
No Hero trapping.
No permanent obstacle.

## Smoke

Smoke:
screen/world visual only
does not hide critical objective text
does not block controls

## Camera

Short local emphasis:
slight push or hold toward Tower

No snap.
No teleport.

Reduce Motion:
no camera push.

## Audio / Haptic

destruction commit:
medium/strong haptic

collapse:
low boom

next objective unlock:
short cyan/gold cue

Audio is feedback only.

## Reduce Motion

Replace:
large collapse translation
camera push
heavy debris

With:
fracture flash
opacity dissolve
short smoke fade
collision release remains identical

## Recovery

If app crashes after DESTRUCTION_COMMIT:
Tower returns as destroyed.

If collision release not committed:
resume at collision release.

If lane progression committed:
do not replay progression transaction.

Visual can replay shortened settled state,
but Reward/Bonus never repeats.

## Runtime State

tower:
destroyed
collisionEnabled
objectiveState
visualDestructionPhase
destructionCommittedAt
collisionReleasedAt

## Next Objective Reveal

Tower1 destroyed:
reveal Tower2 same Lane

Tower2 destroyed:
show Lane Complete
if first completed Lane:
Enemy Base unlock cue

No automatic switch to another Lane.

## QA

visual starts only after destruction commit
collision remains active before release commit
visual collapse cannot mutate collision
marker clears after destruction commit
debris has no hard collision
Reduce Motion preserves gameplay timing
crash after destruction restores destroyed state
collision recovery idempotent
next objective reveal follows committed lane progression
no duplicate destruction bonus
no teleport
no Energy

## STEP 69

TOWER2 + LANE COMPLETE + ENEMY BASE UNLOCK PRESENTATION

Tower2 destruction، Lane Complete ceremony، Base shield unlock و objective routing را به presentation نهایی وصل می‌کنیم.
