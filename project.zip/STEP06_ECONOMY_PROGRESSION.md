# SHAHRIAR GAME — 100 STEP REBUILD
## STEP 06 — REWARD / XP / LEVEL / RANK ECONOMY

این سند مرجع رسمی اقتصاد و پیشرفت بازیکن است.

---

# 1. هدف اقتصاد

اقتصاد بازی باید سه چیز را تقویت کند:

- اقدام واقعی
- استمرار
- پیشرفت قابل مشاهده

نباید:
- Pay-to-win شود
- Hero خریدنی باعث قدرت بیشتر شود
- Rewardها آن‌قدر زیاد باشند که بی‌ارزش شوند
- Diamond مثل Gold عادی خرج شود

---

# 2. Currency Roles

## XP
برای:
- Level Up
- نمایش رشد مستمر

XP قابل خرج نیست.

## Gold
برای:
- Hero Unlock
- Outfit
- Aura
- Frame
- Lobby Background
- Cosmetic Options

Gold = ارز اصلی داخل بازی

## Diamond
برای:
- پاداش‌های واقعی زندگی

Diamond = Rare Reward Currency

نمونه:
- یک قهوه
- خرید کوچک
- تفریح
- هدیه شخصی
- Reward سفارشی کاربر

---

# 3. XP Source

XP از:

- Task Complete
- Minion Objective
- Tower Milestone
- Base Final Push
- Achievement
- Event Milestone در آینده

XP نباید صرفاً با باز بودن App تولید شود.

---

# 4. Base XP per Task

پاداش پایه از خود Task می‌آید.

Task fields:

- xp
- gold
- diamond
- difficulty
- category

نمونه پیشنهادی:

Easy:
60–90 XP

Normal:
90–140 XP

Important:
140–220 XP

Hard:
220–350 XP

Strategic:
350–600 XP

این Range فقط Default است.
کاربر می‌تواند مقدار Task را ویرایش کند.

---

# 5. XP Curve

پیشنهاد اولیه:

Level 1 Threshold:
1000 XP

Growth:
16% per Level

Formula:

`requiredXP(level) = round(baseXP * growth^(level-1))`

Default:
baseXP = 1000
growth = 1.16

برای جلوگیری از رشد بیش از حد:
در Levelهای بالا بعداً Soft Cap بررسی می‌شود.

---

# 6. Level Progress

Player:

- level
- currentXP
- requiredXP

وقتی:
currentXP >= requiredXP

Loop:
- currentXP -= requiredXP
- level += 1
- requiredXP = next threshold

Multiple Level Up باید ممکن باشد.

---

# 7. Level Up Experience

Level Up باید حس Premium داشته باشد:

- HUD flash
- Gold/Cyan ring
- Hero aura burst
- Level number reveal
- Short haptic
- no full-screen interruption unless major milestone

مدت:
1.2 تا 2.0 ثانیه

---

# 8. Gold Sources

Gold از:

- Task
- Tower
- Base
- Achievement
- Event milestone

Gold Sink:

- Hero
- Outfit
- Aura
- Frame
- Background
- Cosmetic bundle

---

# 9. Gold Economy Principle

Gold باید:
- به اندازه کافی قابل جمع‌آوری باشد
- ولی خرید Hero فوری و بی‌ارزش نباشد

پیشنهاد:

Common cosmetic:
250–700

Premium cosmetic:
900–1800

Hero unlock:
1800–5000

Background:
1200–3000

این اعداد Default هستند و از Settings قابل ویرایش‌اند.

---

# 10. Diamond Sources

Diamond باید Rare باشد.

منابع:

- Taskهای ویژه
- Achievement مهم
- Base Victory
- Event milestone
- Manual admin reward

Default:
بیشتر Taskها Diamond = 0

---

# 11. Diamond Economy

Diamond Shop فقط:
Real-life Rewards

نمونه:

Coffee:
5

Meal:
12

Cinema:
18

Personal Purchase:
25

Day Off Reward:
40

Custom:
editable

قیمت‌ها توسط کاربر CRUD می‌شوند.

---

# 12. No Diamond for Hero Power

Diamond:
برای Hero Power استفاده نمی‌شود.

هیروها:
Visual only

Gold:
Cosmetic / Hero Unlock

---

# 13. Entity Multipliers

Task reward پایه:

Minion:
1.00x

Tower:
1.10x

Base:
1.20x

Achievement multiplier مستقل است.

Multipliers:
editable

---

# 14. Reward Calculation

Final Reward:

`taskReward × entityMultiplier`

XP:
round

Gold:
round

Diamond:
round conservatively

Diamond توصیه:
Multiplier فقط اگر Task خودش Diamond داشته باشد.

---

# 15. Tower Milestone Bonus

علاوه بر Task Reward:

Tower destroyed:
Bonus XP + Gold

Default:
+150 XP
+60 Gold

Tower 2:
+220 XP
+90 Gold

قابل ویرایش.

---

# 16. Base Victory Bonus

Enemy Base destroyed:

Default:
+400 XP
+150 Gold
+1 Diamond

این Bonus جدا از Task final hit است.

---

# 17. Time-End Reward

اگر Match با زمان تمام شود:

بازیکن همه Rewardهای Earned را حفظ می‌کند.

No punishment.

No currency removal.

Progress ثبت می‌شود.

---

# 18. Match Completion Bonus

اگر کاربر Match را تا پایان طبیعی ادامه دهد:

Completion bonus کوچک:

Default:
+80 XP
+20 Gold

هدف:
تشویق به Session discipline

---

# 19. Rank System

Rank جدا از Level است.

Level:
رشد تجمعی

Rank:
کیفیت و استمرار عملکرد

Rank Ladder پیشنهادی:

1. تازه‌کار I
2. تازه‌کار II
3. تازه‌کار III

4. پیگیر I
5. پیگیر II
6. پیگیر III

7. حرفه‌ای I
8. حرفه‌ای II
9. حرفه‌ای III

10. حماسی I
11. حماسی II
12. حماسی III

13. اسطوره‌ای I
14. اسطوره‌ای II
15. اسطوره‌ای III

---

# 20. Rank Score

Rank Score از:

- Task completion
- Match completion
- Tower progress
- Consistency
- Achievement milestones

می‌آید.

اما Rank نباید وابسته به خرید یا Hero باشد.

---

# 21. Rank Point Suggestions

Task Complete:
+2 RP

Important/Hard Task:
+3 تا +5 RP

Tower Destroyed:
+8 RP

Base Victory:
+15 RP

Full Match Completion:
+5 RP

Daily discipline future:
+3 RP

---

# 22. Rank Promotion

هر Sub-rank:
100 RP

وقتی RP >= 100:
- Promotion
- RP overflow منتقل شود

مثال:
120 RP
→ Rank Up
→ 20 RP باقی بماند

---

# 23. Rank Demotion

نسخه اولیه:
Demotion نداریم.

دلیل:
این بازی رشد شخصی است، نه PvP رقابتی.

در Season System آینده:
Soft reset قابل بررسی.

---

# 24. Rank Visual Language

Fresh / Beginner:
Steel / Blue

Consistent:
Cyan / Silver

Professional:
Gold

Epic:
Purple / Gold

Legendary:
Deep Gold / Crimson / Radiant

---

# 25. Rank Reward

Rank Up می‌تواند:

- Gold
- Cosmetic unlock
- Frame
- Background
- Title

بدهد.

Diamond فقط برای Rank milestone مهم.

---

# 26. XP vs Rank

XP:
«چقدر رشد کرده‌ای»

Rank:
«چقدر باکیفیت و مستمر عمل کرده‌ای»

این دو نباید یکی باشند.

---

# 27. Progression Data Model

Player progression:

- level
- xp
- xpRequired
- totalXP
- gold
- diamonds
- rankId
- rankScore
- totalTasksCompleted
- totalMatches
- victories
- towersDestroyed

Stats page همچنان فقط Network Tree است.
این داده‌ها می‌توانند داخلی یا در Profile/Results استفاده شوند.

---

# 28. Editable Economy

Settings باید در آینده اجازه دهد:

- baseXP
- xpGrowthPercent
- rank names
- rank points
- reward multipliers
- tower bonuses
- base victory bonus
- match completion bonus
- hero prices
- cosmetic prices
- real reward costs

---

# 29. Anti-Inflation

برای Gold:

- خریدهای Cosmetic واقعی
- Price bands
- Reward کنترل‌شده

برای Diamond:

- Rare source
- Real reward sink
- Task diamond default = 0

---

# 30. Reward Feedback

XP:
Cyan

Gold:
Warm Gold

Diamond:
Electric Aqua / White

Never use same visual for all currencies.

---

# 31. Reward Fly Animation

بعد از Hit:

- XP particle → XP HUD
- Gold coin → Gold counter
- Diamond crystal → Diamond counter

Counters:
smooth increment

---

# 32. Reward Summary

در پایان Match:

- XP Earned
- Gold Earned
- Diamond Earned
- Level Progress
- Rank Progress

نه Dashboard شلوغ.

---

# 33. Level Milestones

پیشنهاد:

Level 5:
Profile frame

Level 10:
Lobby aura

Level 20:
Background option

Level 30:
Title

Level 50:
Premium emblem

Cosmetic only.

---

# 34. Rank Milestones

Professional III:
Gold frame

Epic III:
Animated aura

Legendary:
Signature lobby effect

No gameplay power.

---

# 35. Reward Integrity

هر Reward Transaction:

- unique transaction id
- source
- amount
- timestamp
- matchId
- taskId optional
- entityId optional

برای جلوگیری از duplicate reward.

---

# 36. Balance Philosophy

Reward باید:

- Task مهم‌تر = محسوس‌تر
- ولی نه 10x بی‌دلیل
- Reward completion فوری
- Progression بلندمدت آرام

هدف:
انگیزه، نه اعتیاد به عدد.

---

# 37. Default Player Prototype

برای Concept فقط:

Name:
شهریار

Level:
28

XP:
6240 / 8000

Gold:
2437

Diamond:
12

Rank:
حماسی III

این‌ها Default نمایشی‌اند، نه محدودیت محصول.

---

# 38. Real-Life Reward Store

Reward Item:

- id
- title
- diamondCost
- icon
- note
- active
- claimedCount

Actions:
- Add
- Edit
- Delete
- Purchase
- Claim History

---

# 39. Purchase Validation

Real Reward:

اگر Diamond کافی نیست:
Purchase blocked

اگر کافی است:
- Diamond subtract
- Claim record
- success feedback

Atomic transaction.

---

# 40. STEP 06 DEFAULT VALUES

Base XP:
1000

XP Growth:
16%

Minion multiplier:
1.00

Tower multiplier:
1.10

Base multiplier:
1.20

Tower 1 bonus:
150 XP / 60 Gold

Tower 2 bonus:
220 XP / 90 Gold

Base victory:
400 XP / 150 Gold / 1 Diamond

Match completion:
80 XP / 20 Gold

Rank sub-level:
100 RP

---

# 41. Quality Gate

Economy PASS اگر:

- XP و Rank جدا باشند
- Diamond rare بماند
- Hero قدرت نخرد
- Double reward ممکن نباشد
- Level Up overflow درست باشد
- Rank overflow درست باشد
- Time End earned rewards را حذف نکند
- همه مقادیر اصلی قابل تنظیم باشند
- Reward feedback واضح و متفاوت باشد
- Real reward purchase atomic باشد

---

# STEP 07

HOME / LOBBY EXPERIENCE ARCHITECTURE

در قدم ۷:
- Home structure
- Hero showcase
- Rank
- top HUD
- Start Match CTA
- Shop / Events / Vision / Achievements
- responsive mobile layout
- no dashboard look
طراحی می‌شود.
