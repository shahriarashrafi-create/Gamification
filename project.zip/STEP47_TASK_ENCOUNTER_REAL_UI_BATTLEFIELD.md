# STEP 47 — TASK ENCOUNTER REAL UI IN BATTLEFIELD

این مرحله Task Encounter را از Blueprint به Runtime Battlefield وصل می‌کند.

## Flow
Hero نزدیک Target
→ interaction radius
→ Action فعال
→ Task Sheet
→ Complete / Later / Cancel
→ Complete transaction lock
→ Sheet exit
→ Hero face target
→ attack windup
→ projectile
→ impact
→ committed damage
→ visual state resolver
→ committed reward
→ reward fly-up
→ resume movement

## Task Sheet
متن Task اصلی‌ترین عنصر است.
RTL.
کلمه کامل به خط بعد می‌رود.
هیچ word-break وسط کلمه فارسی مجاز نیست.

Actions:
انجام شد
بعداً
لغو

## Complete
فقط Complete:
Task completion commit
damage
XP/Gold
Diamond only if task snapshot explicitly contains it

## Later
فقط در Match فعلی defer می‌شود.
Damage/Reward ندارد.
بعد از چند Encounter دیگر می‌تواند طبق Task distribution rules دوباره بررسی شود، اما در همان reservation فوراً باز نمی‌شود.

## Cancel
Encounter بسته می‌شود.
Task حذف دائمی نمی‌شود.
Damage/Reward ندارد.

## Atomicity
Complete button after first tap locks.
Transaction ID unique.
Double tap cannot duplicate:
completion
damage
reward
destruction bonus

## Battlefield
Task Sheet battlefield را کامل حذف نمی‌کند.
World dim/soft blur.
Hero + Target context preserved.

## Movement
During active Encounter:
movement soft-stop
joystick input ignored
after Resume input enabled

## Timer
Default continues during Task Sheet according to snapshot:
timerRunsDuringTask=true.

## Target Types
Minion → 1 Task
Tower → Task damages 34 by default
Base → Task damages 25 by default

## Reward
Entity multiplier from Step06.
Reward fly-up only after ledger commit.

## Text
Persian Task title:
direction rtl
text-align right
overflow-wrap normal
word-break normal
hyphens none

## Empty Task
Encounter cannot invent a Task.
If reservation invalid, close safely and rebuild task eligibility.

## State Machine
READY
COMMITTING
SHEET_EXIT
HERO_FACE_TARGET
ATTACK_WINDUP
PROJECTILE
HIT
DAMAGE_APPLY
REWARD_COMMIT
FEEDBACK
RESUME

## Failure
If Task commit fails:
no damage
no reward
sheet shows recoverable error.

If damage commit fails after completion:
persist recovery transaction state and do not duplicate completion.

## QA
Complete once
double tap guarded
Later no reward
Cancel no reward
Persian words never split
Timer follows snapshot
movement locked during encounter
no fake Diamond
no Energy

## STEP 48
ATTACK PROJECTILE IMPACT VFX RUNTIME
Attack sequence را با projectile trajectory، hit burst، HP tween، Tower/Base impact و reward fly-up visual runtime کامل می‌کنیم.
