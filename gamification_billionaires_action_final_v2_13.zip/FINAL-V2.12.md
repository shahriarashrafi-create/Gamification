# Final v2.12 — Achievement Claims & Android Back Flow

## Achievement notification flow

1. Achievement condition becomes true.
2. Achievement is stored as unlocked, but no achievement message is shown on the game screen.
3. A red dot is shown on the Achievements bottom-nav item.
4. User opens Achievements and taps the unlocked card.
5. Reward XP is applied and the achievement becomes claimed for the current cycle.
6. The red dot remains only while at least one unlocked reward is still unclaimed.

Daily/weekly/monthly achievements use cycle keys, so they can be earned and claimed again in their next cycle.

## Back behavior

- Non-home page + Back -> Home/Game.
- Home/Game + Back -> exit hint.
- Home/Game + second Back within 1.8 seconds -> move Android task to background (no finish()).
- Focus timer state uses absolute start/end timestamps and is revalidated on resume.
