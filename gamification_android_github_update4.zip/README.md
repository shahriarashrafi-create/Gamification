# Gamification Android — Update 4 (v2.4)

آپدیت دوم ظاهر اپ را حرفه‌ای‌تر می‌کند و موارد ۴ تا ۷ برنامه بازطراحی را پوشش می‌دهد:

- کارت‌های خلوت‌تر با Border و Shadow ظریف‌تر
- سلسله‌مراتب جدید در صفحه آمار؛ امتیاز امروز و پیشرفت لول در اولویت
- Progress Bar اختصاصی برای Level / Rank / Boost / Focus
- دکمه‌های گیمی‌تر با Primary واضح برای «انجام شد» و Press feedback

ویژگی‌های Update 1 شامل رنگ مودهای Safe / Classic / Rank و Badgeهای R/B حفظ شده‌اند.

## نکات مهم
- ساختار بدون اسکرول عمودی حفظ شده است.
- مدیریت تسک‌ها (افزودن، ویرایش، حذف، امتیاز، مود و R/B) حفظ شده است.
- این آپدیت پیشرفت ذخیره‌شده نسخه قبلی را پاک نمی‌کند.
- نصب کاملاً تازه همچنان Level 1 / Rank 1 / Magic Lv1 / Score 0 است.

## ساخت APK
GitHub Actions خروجی را با نام زیر می‌سازد:

`Gamification-Update2.apk`

جزئیات تغییرات: `UPDATE-2.md`

## Update 3 (v2.3)
Final visual game pass: polished bottom navigation, richer task cards, status hierarchy, and animated reward feedback for task completion, level/rank/magic upgrades and achievements. See `UPDATE-3.md`.


## Update 4 (v2.4)
این آپدیت فاصله‌گذاری صفحه بازی را متعادل می‌کند و تایمر واقعی ۲۵ دقیقه‌ای برای مجیک تمرکز اضافه می‌کند.

- عنوان و Badgeهای مأموریت دیگر روی هم نمی‌افتند.
- فضای خالی بزرگ کارت مأموریت با Focus Console کاربردی جایگزین شده است.
- تایمر ۲۵:۰۰ با زمان واقعی شروع می‌شود و با تغییر تسک قطع نمی‌شود.
- تا وقتی تایمر فعال است، ضریب تمرکز روی تمام تسک‌های انجام‌شده اعمال می‌شود.
- استفاده از مجیک تمرکز فقط پس از کامل شدن یک جلسه ۲۵ دقیقه‌ای ثبت می‌شود.
- تایمر با timestamp ذخیره می‌شود و با جابه‌جایی تب، تغییر تسک و بازگشت به اپ ادامه دارد.
- داده و پیشرفت نسخه قبلی پاک نمی‌شود.

خروجی GitHub Actions: `Gamification-Update4.apk`
